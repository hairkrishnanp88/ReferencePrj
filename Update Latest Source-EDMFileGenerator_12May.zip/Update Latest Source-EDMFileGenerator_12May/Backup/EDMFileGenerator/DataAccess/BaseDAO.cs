﻿using System;

using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;


namespace ScopeInt.SME.EDMFileGenerator.DataAccess
{
    public class BaseDAO
    {
        public Database GetEXPTransactDatabase()
        {
            return DatabaseFactory.CreateDatabase("EXPTRANSACTDB");
        }

        public Database GetSMETransactDatabase()
        {
            return DatabaseFactory.CreateDatabase("SMETRANSACTDB");
        }
    }
}
