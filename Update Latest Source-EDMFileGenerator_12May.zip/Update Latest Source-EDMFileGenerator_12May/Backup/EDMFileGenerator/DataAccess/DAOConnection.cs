﻿using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
//using System.Linq;
using System.Collections.Generic;
using EDMFileGenerator.Models;

namespace ScopeInt.SME.EDMFileGenerator.DataAccess
{
    public class CommonTextFileGenerator_DAO : BaseDAO
    {

        public IDataReader FetchDBContent(string strDatabase, string strSQL, string strWhereClause)
        {
            #region Create database object

            Database db = GetSMETransactDatabase();
            if (strDatabase.ToUpper() == "SCBEXTDATA")
            {
                db = GetEXPTransactDatabase();
            }

            #endregion Create database object

            #region Prepare parameter

            String sqlCommand = strSQL + ' ' + strWhereClause;

            DbCommand dbCommand = db.GetSqlStringCommand(sqlCommand); // .GetStoredProcCommand
            dbCommand.CommandTimeout = 0;

            #endregion Prepare parameter

            #region Execute command

            return db.ExecuteReader(dbCommand);

            #endregion Execute command
        }

        public List<EdmFileInfo> FetchEdmFileInfo(string strViewName)
        {
            #region Create database object

            Database db = GetEXPTransactDatabase();

            #endregion Create database object

            #region Prepare parameter

            String sqlCommand = string.Format("SELECT * FROM [dbo].[{0}]", strViewName);
            
            DbCommand dbCommand = db.GetSqlStringCommand(sqlCommand); // .GetStoredProcCommand
            dbCommand.CommandTimeout = 0;
            var listEdmFileInfo = new List<EdmFileInfo>();

            #endregion Prepare parameter

            #region Execute command

            var dt = db.ExecuteDataSet(dbCommand).Tables[0];

            foreach(DataRow item in dt.Rows){
                listEdmFileInfo.Add(new EdmFileInfo
                {
                    TableName = item["TableName"].ToString().ToLower(),
                    ServiceKey_TH = item["ServiceKey_TH"].ToString(),
                    ServiceKey_SG = item["ServiceKey_SG"].ToString(),
                    ServiceKey_MY = item["ServiceKey_MY"].ToString(),
                    ServiceKey_ID = item["ServiceKey_ID"].ToString(),
                    ServiceKey_HK = item["ServiceKey_HK"].ToString(),
                    ServiceKey_CN = item["ServiceKey_CN"].ToString(),
                    SourceFile_HK = item["SourceFile_HK"].ToString(),
                    SourceFile_CN = item["SourceFile_CN"].ToString(),
                    SourceFile_TH = item["SourceFile_TH"].ToString(),
                    SourceFile_SG = item["SourceFile_SG"].ToString(),
                    SourceFile_MY = item["SourceFile_MY"].ToString(),
                    SourceFile_ID = item["SourceFile_ID"].ToString(),
                    TargetFile_HK = item["TargetFile_HK"].ToString(),
                    TargetFile_ID = item["TargetFile_ID"].ToString(),
                    TargetFile_TH = item["TargetFile_TH"].ToString(),
                    TargetFile_SG = item["TargetFile_SG"].ToString(),
                    TargetFile_MY = item["TargetFile_MY"].ToString(),
                    TargetFile_CN = item["TargetFile_CN"].ToString()
                });
            }
            return listEdmFileInfo;

            #endregion Execute command
        }

        public DataSet getLinkKeys(string CountryCode, string DeltaRunDate)
        {
            #region Create database object

            Database db = GetSMETransactDatabase();

            #endregion Create database object

            #region Prepare parameter

            String sqlCommand = "usp_getApplicationInfoPerCountry";
            DbCommand dbCommand = db.GetStoredProcCommand(sqlCommand);
            dbCommand.CommandTimeout = 0;

            db.AddInParameter(dbCommand, "@CountryCode", DbType.String, CountryCode);
            db.AddInParameter(dbCommand, "@DeltaRunDate", DbType.String, DeltaRunDate);

            #endregion Prepare parameter

            #region Execute command

            return db.ExecuteDataSet(dbCommand);

            #endregion Execute command
        }

        public string getLinks(string strCountryCode, bool flgApplicationNo, bool flgSysRecordKey, string strDeltaRunDate)
        {
            DataSet links = getLinkKeys(strCountryCode, strDeltaRunDate);
            string sys_recordkey = string.Empty;
            string applicationNo = string.Empty;
            string strReturnValue = string.Empty;

            if (links != null && links.Tables.Count > 0)
            {
                foreach (DataRow row in links.Tables[0].Rows)
                {
                    if (sys_recordkey == string.Empty)
                    {
                        sys_recordkey = row["sys_recordkey"].ToString().Trim();
                    }
                    else
                    {
                        sys_recordkey = sys_recordkey + "," + row["sys_recordkey"].ToString().Trim();
                    }
                    if (applicationNo == string.Empty)
                    {
                        applicationNo = string.Format("'{0}'" , row["ApplicationNumber"].ToString().Trim());
                    }
                    else
                    {
                        applicationNo = string.Format("{0},'{1}'" ,applicationNo, row["ApplicationNumber"].ToString().Trim());
                    }
                }
            }
            links.Dispose();
            if (flgApplicationNo == true) strReturnValue = applicationNo;
            if (flgSysRecordKey == true) strReturnValue = sys_recordkey;
            return strReturnValue;
        }
    }

}