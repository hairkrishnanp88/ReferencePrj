﻿using System;
using System.Data;
using System.Data.Common;

using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ScopeInt.SME.EDMFileGenerator.DataAccess
{
    public class ErrorDAO : BaseDAO
    {
        #region Constants

        private const string USP_LOGERROR_ADD = "usp_log_LogError_ins";

        #endregion Constants

        public int InsertError
        (
            string source,
            string method,
            int lineNo,
            string message
        )
        {
            #region Create database object

            Database db = GetSMETransactDatabase();

            #endregion Create database object

            #region Prepare paramater

            String sqlCommand = USP_LOGERROR_ADD;
            DbCommand dbCommand = db.GetStoredProcCommand(sqlCommand);

            db.AddInParameter(dbCommand, "@source", DbType.String, source);
            db.AddInParameter(dbCommand, "@methodName", DbType.String, method);
            db.AddInParameter(dbCommand, "@lineNo", DbType.Int32, lineNo);
            db.AddInParameter(dbCommand, "@message", DbType.String, message);

            int errorNum = 0;
            db.AddOutParameter(dbCommand, "@errorID", DbType.Int32, errorNum);

            #endregion Prepare paramater

            #region Execute command

            int recordsAffected = db.ExecuteNonQuery(dbCommand);

            #endregion Execute command

            return Convert.ToInt32(db.GetParameterValue(dbCommand, "@errorID"));
        }
    }
}
