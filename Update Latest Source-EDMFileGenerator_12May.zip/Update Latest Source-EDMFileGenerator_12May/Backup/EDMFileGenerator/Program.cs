﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Collections;
using System.IO;

namespace ScopeInt.SME.EDMFileGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                GenerateTextFiles controller = new GenerateTextFiles();
                //var sshTransfer = new GenerateSshTransfer();
                controller.Run();
                //sshTransfer.CreateSshTransfer();
            }
            catch (Exception ex)
            {
                var sbLog = new StringBuilder();
                var strLogLocation = ConfigurationManager.AppSettings["EDMP_ISIS_LOG"].ToString();
                if (!Directory.Exists(strLogLocation)) Directory.CreateDirectory(strLogLocation);

                sbLog.AppendLine("=======================ErrorStartLog========================");
                sbLog.AppendLine("Time::: " + DateTime.Now.TimeOfDay);
                sbLog.AppendLine("Message::: " + ex.Message);
                sbLog.AppendLine("InnerException::: " + ex.InnerException);
                sbLog.AppendLine("Source::: " + ex.Source);
                sbLog.AppendLine("StackTrace::: " + ex.StackTrace);
                sbLog.AppendLine("=======================ErrorEndLog========================");

                //File.WriteAllLines(string.Format("{0}ErrorLog" + DateTime.Now.Date.ToString("yyyyMMdd") + ".txt"),ConfigurationManager.AppSettings["EDMP_ISIS_LOG"].ToString()),
                //    new string[] {sbLog.ToString()});

                using (TextWriter tw = new StreamWriter(string.Format("{0}ErrorLog" + DateTime.Now.Date.ToString("yyyyMMdd") + ".txt", strLogLocation), true))
                {
                    tw.WriteLine(sbLog.ToString());
                }
            }
        }
    }
}
