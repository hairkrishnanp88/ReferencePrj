﻿using System;

using ScopeInt.SME.EDMFileGenerator.Common;
using ScopeInt.SME.EDMFileGenerator.DataAccess;

namespace ScopeInt.SME.EDMFileGenerator.Common
{
    public class ErrorManager
    {
        public int LogError(Exception e)
        {
            ErrorDAO dao = new ErrorDAO();

            try
            {
                int errorNum = dao.InsertError(
                                                ExceptionHelper.GetSourceFileName(),
                                                ExceptionHelper.GetMethodName(),
                                                ExceptionHelper.GetLineNumber(),
                                                e.GetBaseException().Message);

                return errorNum;
            }
            catch (Exception ex)
            {
            }

            return 0;
        }

        public int LogError(string message)
        {
            ErrorDAO dao = new ErrorDAO();

            try
            {
                int errorNum = dao.InsertError(
                                                ExceptionHelper.GetSourceFileName(),
                                                ExceptionHelper.GetMethodName(),
                                                ExceptionHelper.GetLineNumber(),
                                                message);

                return errorNum;
            }
            catch (Exception ex)
            {
            }

            return 0;
        }
    }
}
