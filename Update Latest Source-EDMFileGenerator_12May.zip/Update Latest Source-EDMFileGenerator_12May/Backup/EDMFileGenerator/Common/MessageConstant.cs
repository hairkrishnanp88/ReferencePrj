﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace EDMFileGenerator.Common
{
    public static class MessageConstant
    {
        public const string CountryCodeText_CN = "cn";
        public const string CountryCodeText_MY = "my";
        public const string CountryCodeText_ID = "id";
        public const string CountryCodeText_SG = "sg";
        public const string CountryCodeText_HK = "hk";
        public const string CountryCodeText_TH = "th";

        public const string strDBMain = "SCBSMEV5";
        public const string strDBExt = "SCBEXTDATA";
        public const string strViewPrefix = "vw_edm_"; //strViewPrefix + strTable

        public const string CountryCode_CN = "5";
        public const string CountryCode_HK = "1";
        public const string CountryCode_ID = "17";
        public const string CountryCode_MY = "4";
        public const string CountryCode_SG = "2";
        public const string CountryCode_TH = "3";
    }
}
