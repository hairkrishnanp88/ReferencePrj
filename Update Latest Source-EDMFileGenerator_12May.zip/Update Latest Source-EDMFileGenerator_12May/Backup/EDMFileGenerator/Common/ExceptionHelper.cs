﻿using System;

using System.Diagnostics;

namespace ScopeInt.SME.EDMFileGenerator.Common
{
    public class ExceptionHelper
    {
        /// <summary>
        /// Get the name of the source code file where the error occurs
        /// </summary>
        /// <returns></returns>
        public static string GetSourceFileName()
        {
            StackFrame stack = new StackFrame(1, true);

            return stack.GetFileName();
        }

        /// <summary>
        /// Get the name of the method where the error occurs
        /// </summary>
        /// <returns></returns>
        public static string GetMethodName()
        {
            StackFrame stack = new StackFrame(1, true);

            return stack.GetMethod().Name;
        }
                
        /// <summary>
        /// Get the line number where the error occurs
        /// </summary>
        /// <returns></returns>
        public static int GetLineNumber()
        {
            StackFrame stack = new StackFrame(1, true);

            return stack.GetFileLineNumber();
        }
    }
}
