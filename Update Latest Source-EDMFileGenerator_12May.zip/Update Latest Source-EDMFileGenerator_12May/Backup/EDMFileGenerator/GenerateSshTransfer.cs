﻿using System.Collections.Generic;
using EDMFileGenerator.Models;
using System.Configuration;
using System.IO;
using ScopeInt.SME.EDMFileGenerator.DataAccess;
using System.Data;
using EDMFileGenerator.Common;
using System;

namespace ScopeInt.SME.EDMFileGenerator
{
    public class GenerateSshTransfer
    {
        public List<EdmFileInfo> ListEdmFileInfo { get; set; }
        public BatchRunInfo BatchInfo { get; set; }   
        public string strSpecialRunDate { get; set; }

        public void CreateSshTransfer()
        {
            var strViewName = ConfigurationManager.AppSettings["ViewFileInfo"].ToString();

            string strSSH_TargetPath = BatchInfo.strSSH_TargetPath;
            string strSSH_SourcePath = BatchInfo.strSSH_SourcePath;
            string SourcePath_th = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_TH); //ConfigurationManager.AppSettings["SSH_SourcePath_th"].ToString();
            string SourcePath_hk = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_HK); //ConfigurationManager.AppSettings["SSH_SourcePath_hk"].ToString();
            string SourcePath_cn = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_CN); //ConfigurationManager.AppSettings["SSH_SourcePath_cn"].ToString();
            string SourcePath_id = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_ID); //ConfigurationManager.AppSettings["SSH_SourcePath_id"].ToString();
            string SourcePath_sg = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_SG); //ConfigurationManager.AppSettings["SSH_SourcePath_sg"].ToString();
            string SourcePath_my = strSSH_SourcePath.Replace("{country}", BatchInfo.strCode_SourceRepl_MY); //ConfigurationManager.AppSettings["SSH_SourcePath_my"].ToString();
            string TargetPath_th = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_TH); //ConfigurationManager.AppSettings["SSH_TargetPath_th"].ToString();
            string TargetPath_hk = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_HK); //ConfigurationManager.AppSettings["SSH_TargetPath_hk"].ToString();
            string TargetPath_cn = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_CN); //ConfigurationManager.AppSettings["SSH_TargetPath_cn"].ToString();
            string TargetPath_id = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_ID); //ConfigurationManager.AppSettings["SSH_TargetPath_id"].ToString();
            string TargetPath_sg = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_SG); //ConfigurationManager.AppSettings["SSH_TargetPath_sg"].ToString();
            string TargetPath_my = strSSH_TargetPath.Replace("{countrycode}", BatchInfo.strCode_TargetRepl_MY); //ConfigurationManager.AppSettings["SSH_TargetPath_my"].ToString();
            string sshPk = BatchInfo.strSSH_PrivateKey; //ConfigurationManager.AppSettings["SSH_PrivateKey"].ToString();

            
            var EDMP_SSH_FILEPATH = BatchInfo.strEDMI_SSH_FilePath; //ConfigurationManager.AppSettings["EDMP_SSH_FILEPATH"].ToString();
            var OutputFileFormat = BatchInfo.strOutputFileFormat; //ConfigurationManager.AppSettings["OutputFileFormat"].ToString();
            var strFrq = BatchInfo.strFrequency; //ConfigurationManager.AppSettings["Frequency"].ToString();
            var strSeq = BatchInfo.strSequence; //ConfigurationManager.AppSettings["Sequence"].ToString();
            string strPSCPLocation = BatchInfo.strPSCPLocation;  //ConfigurationManager.AppSettings["PSCPLocation"].ToString();
           
            string strDateToday = BatchInfo.strSpecialRunDate == string.Empty || BatchInfo.strSpecialRunDate.ToUpper() == "NOW" ? DateTime.Now.AddDays(-1).ToString("yyyyMMdd") : BatchInfo.strSpecialRunDate.Replace("-", ""); //20160904

            if (!Directory.Exists(EDMP_SSH_FILEPATH)) Directory.CreateDirectory(EDMP_SSH_FILEPATH);

            using (StreamWriter stream_th = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_TH.bat", false))
            {
                stream_th.WriteLine("@ECHO OFF");
                stream_th.WriteLine("SETLOCAL");
                stream_th.WriteLine("(");
                using (StreamWriter stream_hk = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_HK.bat", false))
                {
                    stream_hk.WriteLine("@ECHO OFF");
                    stream_hk.WriteLine("SETLOCAL");
                    stream_hk.WriteLine("(");
                    using (StreamWriter stream_sg = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_SG.bat", false))
                    {
                        stream_sg.WriteLine("@ECHO OFF");
                        stream_sg.WriteLine("SETLOCAL");
                        stream_sg.WriteLine("(");
                        using (StreamWriter stream_my = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_MY.bat", false))
                        {
                            stream_my.WriteLine("@ECHO OFF");
                            stream_my.WriteLine("SETLOCAL");
                            stream_my.WriteLine("(");
                            using (StreamWriter stream_id = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_ID.bat", false))
                            {
                                stream_id.WriteLine("@ECHO OFF");
                                stream_id.WriteLine("SETLOCAL");
                                stream_id.WriteLine("(");
                                using (StreamWriter stream_cn = new StreamWriter(EDMP_SSH_FILEPATH + "PSCPCommand_CN.bat", false))
                                {
                                    stream_cn.WriteLine("@ECHO OFF");
                                    stream_cn.WriteLine("SETLOCAL");
                                    stream_cn.WriteLine("(");

                                    if (ListEdmFileInfo != null)
                                    {
                                        foreach(var edmFileInfo in ListEdmFileInfo){

                                            //TH
                                            stream_th.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_th_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                            stream_th.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_th_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_th, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                            stream_th.WriteLine(string.Format(" {0}transact_th_{1}_{2}_{3}_{4}.txt", TargetPath_th, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                            stream_th.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                            stream_th.WriteLine("");

                                            if (edmFileInfo.TableName.ToUpper() != "TH_BUREAU_MAN" && edmFileInfo.TableName.ToUpper() != "TH_BUREAU_MAN2")
                                            {
                                                //HK
                                                stream_hk.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_hk_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_hk.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_hk_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_hk, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_hk.WriteLine(string.Format(" {0}transact_hk_{1}_{2}_{3}_{4}.txt", TargetPath_hk, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_hk.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                                stream_hk.WriteLine("");

                                                //SG
                                                stream_sg.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_sg_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_sg.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_sg_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_sg, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_sg.WriteLine(string.Format(" {0}transact_sg_{1}_{2}_{3}_{4}.txt", TargetPath_sg, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_sg.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                                stream_sg.WriteLine("");

                                                //MY
                                                stream_my.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_my_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_my.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_my_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_my, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_my.WriteLine(string.Format(" {0}transact_my_{1}_{2}_{3}_{4}.txt", TargetPath_my, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_my.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                                stream_my.WriteLine("");

                                                //ID
                                                stream_id.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_id_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_id.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_id_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_id, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_id.WriteLine(string.Format(" {0}transact_id_{1}_{2}_{3}_{4}.txt", TargetPath_id, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_id.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                                stream_id.WriteLine("");

                                                //CN
                                                stream_cn.WriteLine(string.Format("echo|set /p=\"Transferring file 'transact_cn_{0}_{1}_{2}_{3}.txt' --> \" ", edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_cn.Write(string.Format(strPSCPLocation + "pscp.exe -i \"{0}\" \"{1}transact_cn_{2}_{3}_{4}_{5}.txt\"", sshPk, SourcePath_cn, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_cn.WriteLine(string.Format(" {0}transact_cn_{1}_{2}_{3}_{4}.txt", TargetPath_cn, edmFileInfo.TableName.ToLower(), strDateToday, strFrq, strSeq));
                                                stream_cn.WriteLine(" IF ERRORLEVEL 1 (ECHO Failed) ELSE (ECHO Succeeded)");
                                                stream_cn.WriteLine("");
                                            }
                                        }
                                        stream_cn.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_CN.log");
                                    }
                                    stream_id.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_ID.log");
                                }
                                stream_my.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_MY.log");
                            }
                            stream_sg.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_SG.log");
                        }
                        stream_hk.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_HK.log");
                    }
                    stream_th.Write(")>>" + EDMP_SSH_FILEPATH + "FileTransferInfo_TH.log");
                }

                //File Transfer log
                using (StreamWriter stream_ft_th = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_TH.log", false))
                {
                    //TH
                    stream_ft_th.WriteLine("------------------------------------------");
                    stream_ft_th.WriteLine(strDateToday + ": File Transfer Log: Thailand");
                    stream_ft_th.WriteLine("------------------------------------------");

                    using (StreamWriter stream_ft_hk = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_HK.log", false))
                    {
                        //HK
                        stream_ft_hk.WriteLine("------------------------------------------");
                        stream_ft_hk.WriteLine(strDateToday + ": File Transfer Log: Hong Kong");
                        stream_ft_hk.WriteLine("------------------------------------------");

                        using (StreamWriter stream_ft_sg = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_SG.log", false))
                        {
                            //SG
                            stream_ft_sg.WriteLine("------------------------------------------");
                            stream_ft_sg.WriteLine(strDateToday + ": File Transfer Log: Singapore");
                            stream_ft_sg.WriteLine("------------------------------------------");

                            using (StreamWriter stream_ft_my = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_MY.log", false))
                            {
                                //MY
                                stream_ft_my.WriteLine("------------------------------------------");
                                stream_ft_my.WriteLine(strDateToday + ": File Transfer Log: Malaysia");
                                stream_ft_my.WriteLine("------------------------------------------");

                                using (StreamWriter stream_ft_id = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_ID.log", false))
                                {
                                    //ID
                                    stream_ft_id.WriteLine("------------------------------------------");
                                    stream_ft_id.WriteLine(strDateToday + ": File Transfer Log: Indonesia");
                                    stream_ft_id.WriteLine("------------------------------------------");

                                    using (StreamWriter stream_ft_cn = new StreamWriter(EDMP_SSH_FILEPATH + "FileTransferInfo_CN.log", false))
                                    {
                                        //CN
                                        stream_ft_cn.WriteLine("------------------------------------------");
                                        stream_ft_cn.WriteLine(strDateToday + ": File Transfer Log: China");
                                        stream_ft_cn.WriteLine("------------------------------------------");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
