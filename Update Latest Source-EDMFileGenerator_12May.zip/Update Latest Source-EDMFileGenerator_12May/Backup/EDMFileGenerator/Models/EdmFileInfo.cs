﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace EDMFileGenerator.Models
{
    public class EdmFileInfo
    {
        //[Field("TableName")]
        public string TableName { get; set; }
        public string ServiceKey_HK { get; set; }
        public string ServiceKey_ID { get; set; }
        public string ServiceKey_SG { get; set; }
        public string ServiceKey_MY { get; set; }
        public string ServiceKey_CN { get; set; }
        public string ServiceKey_TH { get; set; }
        public string SourceFile_HK { get; set; }
        public string SourceFile_ID { get; set; }
        public string SourceFile_SG { get; set; }
        public string SourceFile_MY { get; set; }
        public string SourceFile_CN { get; set; }
        public string SourceFile_TH { get; set; }
        public string TargetFile_HK { get; set; }
        public string TargetFile_ID { get; set; }
        public string TargetFile_SG { get; set; }
        public string TargetFile_MY { get; set; }
        public string TargetFile_CN { get; set; }
        public string TargetFile_TH { get; set; }
    }
}
