﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EDMFileGenerator.Models
{
    public class BatchRunInfo
    {
        public string strSpecialRunDate  { get; set; }
        public string strSpecialRunDate_RunType { get; set; }
        public string strDeltaStartDate { get; set; }
        public string strOutputFileFormat { get; set; }
        public string strSequence { get; set; }
        public string strFrequency  { get; set; }
        public string strDaysRetentionPeriod { get; set; }
        public string strMQHFTUser { get; set; }
        public string strSSH_PrivateKey { get; set; }
        public string strSSH_TargetPath { get; set; }
        public string strCode_TargetRepl_CN { get; set; }
        public string strCode_TargetRepl_ID { get; set; }
        public string strCode_TargetRepl_HK { get; set; }
        public string strCode_TargetRepl_MY { get; set; }
        public string strCode_TargetRepl_SG { get; set; }
        public string strCode_TargetRepl_TH { get; set; }
        public string strSSH_SourcePath { get; set; }
        public string strCode_SourceRepl_CN { get; set; }
        public string strCode_SourceRepl_ID { get; set; }
        public string strCode_SourceRepl_HK { get; set; }
        public string strCode_SourceRepl_MY { get; set; }
        public string strCode_SourceRepl_SG { get; set; }
        public string strCode_SourceRepl_TH { get; set; }
        public string strEDMI_SSH_FilePath { get; set; }
        public string strEDMI_MQH_FilePath { get; set; }
        public string strPSCPLocation { get; set; }
        public string strOutputFileLocation { get; set; }
        public string strOutputFileLocation_Format { get; set; }
        public string strOutputPath_CN_Code_Repl { get; set; }
        public string strOutputPath_ID_Code_Repl { get; set; }
        public string strOutputPath_HK_Code_Repl { get; set; }
        public string strOutputPath_MY_Code_Repl { get; set; }
        public string strOutputPath_SG_Code_Repl { get; set; }
        public string strOutputPath_TH_Code_Repl { get; set; }
        public string strOutputFileLocation_Archive { get; set; }
        public string strCleanup_Archive_Folder { get; set; }
        public string strOutputPath_SSH_Repl { get; set; }
        public string strOutputPath_MQH_Repl { get; set; }
        public string strSQL_SysRecordKey_CN { get; set; }
        public string strSQL_SysRecordKey_ID { get; set; }
        public string strSQL_SysRecordKey_HK { get; set; }
        public string strSQL_SysRecordKey_MY { get; set; }
        public string strSQL_SysRecordKey_SG { get; set; }
        public string strSQL_SysRecordKey_TH { get; set; }
        public string strSQL_AppNo_CN { get; set; }
        public string strSQL_AppNo_ID { get; set; }
        public string strSQL_AppNo_HK { get; set; }
        public string strSQL_AppNo_MY { get; set; }
        public string strSQL_AppNo_SG { get; set; }
        public string strSQL_AppNo_TH { get; set; }
        public string strSQL_Delta_Filter { get; set; }
        public string strSSH_Enabled { get; set; }
    }
}
