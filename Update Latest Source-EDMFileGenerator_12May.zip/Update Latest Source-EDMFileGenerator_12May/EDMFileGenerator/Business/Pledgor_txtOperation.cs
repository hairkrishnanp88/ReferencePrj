﻿using System;
using System.Data;
using ScopeInt.SME.SCIFileGenerator.DataAccess;

namespace ScopeInt.SME.SCIFileGenerator.Business
{
    public class SCIPledgor_txtOperation
    {
        public IDataReader GetSCIPledgorTxt()
        {
            try
            {
                SCIPledgor_txtDAO dao = new SCIPledgor_txtDAO();
                IDataReader reader = dao.GetSCIPledgorTxt();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetSCIPledgorTxtTotal()
        {
            try
            {
                SCIPledgor_txtDAO dao = new SCIPledgor_txtDAO();
                IDataReader reader = dao.GetSCIPledgorTxtTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }
    }
}
