﻿using System;
using System.Data;
using ScopeInt.SME.SCIFileGenerator.DataAccess;

namespace ScopeInt.SME.SCIFileGenerator.Business
{
    public class SCIGroup_txtOperation
    {

        public IDataReader GetSCIGroupTxt()
        {
            try
            {
                SCIGroup_txtDAO dao = new SCIGroup_txtDAO();
                IDataReader reader = dao.GetSCIGroupTxt();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetSCIGroupTxtTotal()
        {
            try
            {
                SCIGroup_txtDAO dao = new SCIGroup_txtDAO();
                IDataReader reader = dao.GetSCIGroupTxtTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }
    }
}
