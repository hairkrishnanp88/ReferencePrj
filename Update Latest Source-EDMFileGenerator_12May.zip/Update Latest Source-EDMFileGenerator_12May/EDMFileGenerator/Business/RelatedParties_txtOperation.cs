﻿using System;
using System.Data;
using ScopeInt.SME.SCIFileGenerator.DataAccess;

namespace ScopeInt.SME.SCIFileGenerator.Business
{
    public class SCIRelatedParties_txtOperation
    {
        public IDataReader GetSCIRelatedPartiesTxt()
        {
            try
            {
                SCIRelatedParties_txtDAO dao = new SCIRelatedParties_txtDAO();
                IDataReader reader = dao.GetSCIRelatedPartiesTxt();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetSCIRelatedPartiesTxtTotal()
        {
            try
            {
                SCIRelatedParties_txtDAO dao = new SCIRelatedParties_txtDAO();
                IDataReader reader = dao.GetSCIRelatedPartiesTxtTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }
    }
}
