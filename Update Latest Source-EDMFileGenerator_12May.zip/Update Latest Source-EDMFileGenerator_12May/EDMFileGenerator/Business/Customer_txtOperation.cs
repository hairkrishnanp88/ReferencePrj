﻿using System;
using System.Data;
using ScopeInt.SME.SCIFileGenerator.DataAccess;

namespace ScopeInt.SME.SCIFileGenerator.Business
{
    public class SCICustomer_txtOperation
    {
        #region TRANS_SCI_APP_PUBLISH

        public IDataReader GetCust_TRANS_SCI_APP_PUBLISH()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_TRANS_SCI_APP_PUBLISH();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_TRANS_SCI_APP_PUBLISHTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_TRANS_SCI_APP_PUBLISHTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion TRANS_SCI_APP_PUBLISH

        #region P44_LE_MAIN_PROFILE

        public IDataReader GetCust_P44_LE_MAIN_PROFILE()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P44_LE_MAIN_PROFILE();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P44_LE_MAIN_PROFILETotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P44_LE_MAIN_PROFILETotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P44_LE_MAIN_PROFILE

        #region P46_LMP_REG_ADDR

        public IDataReader GetCust_P46_LMP_REG_ADDR()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P46_LMP_REG_ADDR();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P46_LMP_REG_ADDRTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P46_LMP_REG_ADDRTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P46_LMP_REG_ADDR

        #region P47_LMP_KNOW_YOUR_CUST

        public IDataReader GetCust_P47_LMP_KNOW_YOUR_CUST()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P47_LMP_KNOW_YOUR_CUST();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P47_LMP_KNOW_YOUR_CUSTTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P47_LMP_KNOW_YOUR_CUSTTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P47_LMP_KNOW_YOUR_CUST

        #region P48_LMP_ISIC_DTL

        public IDataReader GetCust_P48_LMP_ISIC_DTL()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P48_LMP_ISIC_DTL();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P48_LMP_ISIC_DTLTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P48_LMP_ISIC_DTLTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P48_LMP_ISIC_DTL

        #region P49_LMP_CREDIT_GRADE

        public IDataReader GetCust_P49_LMP_CREDIT_GRADE()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P49_LMP_CREDIT_GRADE();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P49_LMP_CREDIT_GRADETotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P49_LMP_CREDIT_GRADETotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P49_LMP_CREDIT_GRADE

        #region P52_LE_SUB_PROFILE

        public IDataReader GetCust_P52_LE_SUB_PROFILE()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P52_LE_SUB_PROFILE();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P52_LE_SUB_PROFILETotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P52_LE_SUB_PROFILETotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P52_LE_SUB_PROFILE

        #region P54_LSP_OFF_ADDR

        public IDataReader GetCust_P54_LSP_OFF_ADDR()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P54_LSP_OFF_ADDR();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P54_LSP_OFF_ADDRTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P54_LSP_OFF_ADDRTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P54_LSP_OFF_ADDR

        #region P55_LSP_SYS_XREF

        public IDataReader GetCust_P55_LSP_SYS_XREF()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P55_LSP_SYS_XREF();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P55_LSP_SYS_XREFTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P55_LSP_SYS_XREFTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P55_LSP_SYS_XREF

        #region P56_LSP_APPR_LMT_PROFILE

        public IDataReader GetCust_P56_LSP_APPR_LMT_PROFILE()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P56_LSP_APPR_LMT_PROFILE();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P56_LSP_APPR_LMT_PROFILETotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P56_LSP_APPR_LMT_PROFILETotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P56_LSP_APPR_LMT_PROFILE

        #region P58_LSP_APPR_LMTS

        public IDataReader GetCust_P58_LSP_APPR_LMTS()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P58_LSP_APPR_LMTS();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P58_LSP_APPR_LMTSTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P58_LSP_APPR_LMTSTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P58_LSP_APPR_LMTS

        #region P63_LSP_EMP_MAP

        public IDataReader GetCust_P63_LSP_EMP_MAP()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P63_LSP_EMP_MAP();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetCust_P63_LSP_EMP_MAPTotal()
        {
            try
            {
                SCICustomer_txtDAO dao = new SCICustomer_txtDAO();
                IDataReader reader = dao.GetCust_P63_LSP_EMP_MAPTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        #endregion P63_LSP_EMP_MAP

        public void UpdateSCIStatus()
        {
            SCICustomer_txtDAO dao = new SCICustomer_txtDAO();

            try
            {
                dao.UpdateSCIStatus();

            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }
    }
}
