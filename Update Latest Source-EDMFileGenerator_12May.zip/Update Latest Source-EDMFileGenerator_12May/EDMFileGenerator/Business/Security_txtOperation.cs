﻿using System;
using System.Data;
using ScopeInt.SME.SCIFileGenerator.DataAccess;

namespace ScopeInt.SME.SCIFileGenerator.Business
{
    public class SCISecurity_txtOperation
    {
        public IDataReader GetSCISecurityTxt()
        {
            try
            {
                SCISecurity_txtDAO dao = new SCISecurity_txtDAO();
                IDataReader reader = dao.GetSCISecurityTxt();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }

        public IDataReader GetSCISecurityTxtTotal()
        {
            try
            {
                SCISecurity_txtDAO dao = new SCISecurity_txtDAO();
                IDataReader reader = dao.GetSCISecurityTxtTotal();

                return reader;
            }
            catch (Exception ex)
            {
                // Exception Handling
                throw new ApplicationException(ex.ToString(), ex);
            }
        }
    }
}
