﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Configuration;
using System.IO;
using ScopeInt.SME.EDMFileGenerator.DataAccess;
//using ScopeInt.SME.EDMFileGenerator.Business;
using EDMFileGenerator.Common;
//using System.Linq;
using System.Threading;
using EDMFileGenerator.Models;

namespace ScopeInt.SME.EDMFileGenerator
{
    public class GenerateTextFiles
    {

        BatchRunInfo BatchInfo = new BatchRunInfo();
        string strSysRecordKey_CN_ND = string.Empty;
        string strSysRecordKey_HK_ND = string.Empty;
        string strSysRecordKey_ID_ND = string.Empty;
        string strSysRecordKey_MY_ND = string.Empty;
        string strSysRecordKey_SG_ND = string.Empty;
        string strSysRecordKey_TH_ND = string.Empty;

        string strApplicationNo_CN_ND = string.Empty;
        string strApplicationNo_HK_ND = string.Empty;
        string strApplicationNo_ID_ND = string.Empty;
        string strApplicationNo_MY_ND = string.Empty;
        string strApplicationNo_SG_ND = string.Empty;
        string strApplicationNo_TH_ND = string.Empty;

        string strOutputLocation_CN = string.Empty;
        string strOutputLocation_HK = string.Empty;
        string strOutputLocation_ID = string.Empty;
        string strOutputLocation_MY = string.Empty;
        string strOutputLocation_SG = string.Empty;
        string strOutputLocation_TH = string.Empty;
        string strOutputLocation_Program = string.Empty;
        string strOutputLocation_SSH = string.Empty;
        string strOutputFileLocation_MQH = string.Empty;//ConfigurationManager.AppSettings["OutputFileLocation_MQH"].ToString();

        //string strSequence = string.Empty;
        //string strFrequency = string.Empty;
        //public string strSpecialRunDate { get; set; }
        //string strSpecialRunDate = string.Empty;
        //string strDaysRetentionPeriod = string.Empty;

        //string strDeltaStartDate = string.Empty;
        string strDeltaFilter = string.Empty;
        string strDeltaDateFilter = ConfigurationManager.AppSettings["ManualDate"].ToString() != "NOW" ? ConfigurationManager.AppSettings["ManualDate"].ToString() : DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
        //DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"); //"06/05/2017";//
        string strDeltaStartDate = string.Empty;

        private string strSysRecordKey_CN { get; set; }
        private string strSysRecordKey_HK { get; set; }
        private string strSysRecordKey_ID { get; set; }
        private string strSysRecordKey_MY { get; set; }
        private string strSysRecordKey_SG { get; set; }
        private string strSysRecordKey_TH { get; set; }

        private string strApplicationNo_CN { get; set; }
        private string strApplicationNo_HK { get; set; }
        private string strApplicationNo_ID { get; set; }
        private string strApplicationNo_MY { get; set; }
        private string strApplicationNo_SG { get; set; }
        private string strApplicationNo_TH { get; set; }

        private List<EdmFileInfo> ListEdmFileInfo { get; set; }

        public void Run()
        {
            try
            {
                var sshTransfer = new GenerateSshTransfer();
                loadBatchRunInfo();
                GetEdmFileInfoViews();
                ArchiveFiles();
                ////-------------------------------------------------
                ////SSH File Transfer
                ////-------------------------------------------------
                //sshTransfer.ListEdmFileInfo = this.ListEdmFileInfo;
                //sshTransfer.BatchInfo = BatchInfo;
                //if (BatchInfo.strSSH_Enabled.ToUpper() == "Y")
                //{
                //    sshTransfer.CreateSshTransfer();
                //}
                //------------------------------------------------
                //Generate Files and EDM FTP files
                //------------------------------------------------
                StartProcessingFiles();
                //-------------------------------------------------
                PerformHouseKeeping();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void loadBatchRunInfo()
        {
            string strSQL = "SELECT TOP 1 * FROM [SCBEXTDATA].[dbo].[vw_edm_batch_run_info]";
            CommonTextFileGenerator_DAO BRInfo = new CommonTextFileGenerator_DAO();
            IDataReader reader = BRInfo.FetchDBContent(MessageConstant.strDBExt, strSQL, string.Empty);

            if (reader != null && !reader.IsClosed)
            {
                while (reader.Read())
                {
                    BatchInfo.strSpecialRunDate = reader["SpecialRunDate"].ToString().Trim();
                    BatchInfo.strSpecialRunDate_RunType = reader["SpecialRunDate_RunType"].ToString().Trim();
                    BatchInfo.strDeltaStartDate = reader["deltaStartDate"].ToString().Trim();
                    BatchInfo.strOutputFileFormat = reader["OutputFileFormat"].ToString().Trim();
                    BatchInfo.strSequence = reader["Sequence"].ToString().Trim();
                    BatchInfo.strFrequency = reader["Frequency"].ToString().Trim();
                    BatchInfo.strDaysRetentionPeriod = reader["DaysRetentionPeriod"].ToString().Trim();
                    BatchInfo.strMQHFTUser = reader["EDMP_ISIS_FTRQ_USERID"].ToString().Trim();
                    BatchInfo.strSSH_PrivateKey = reader["SSH_PrivateKey"].ToString().Trim();
                    BatchInfo.strSSH_TargetPath = reader["SSH_TargetPath"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_CN = reader["SSH_TargetPath_CN_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_ID = reader["SSH_TargetPath_ID_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_HK = reader["SSH_TargetPath_HK_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_MY = reader["SSH_TargetPath_MY_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_SG = reader["SSH_TargetPath_SG_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_TargetRepl_TH = reader["SSH_TargetPath_TH_Code_Repl"].ToString().Trim();
                    BatchInfo.strSSH_SourcePath = reader["SSH_SourcePath"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_CN = reader["SSH_SourcePath_CN_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_ID = reader["SSH_SourcePath_ID_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_HK = reader["SSH_SourcePath_HK_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_MY = reader["SSH_SourcePath_MY_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_SG = reader["SSH_SourcePath_SG_Code_Repl"].ToString().Trim();
                    BatchInfo.strCode_SourceRepl_TH = reader["SSH_SourcePath_TH_Code_Repl"].ToString().Trim();
                    BatchInfo.strEDMI_SSH_FilePath = reader["EDMP_SSH_FILEPATH"].ToString().Trim();
                    BatchInfo.strEDMI_MQH_FilePath = reader["EDMP_MQH_FILEPATH"].ToString().Trim();
                    BatchInfo.strPSCPLocation = reader["PSCPLocation"].ToString().Trim();
                    BatchInfo.strOutputFileLocation = reader["OutputFileLocation"].ToString().Trim();
                    BatchInfo.strOutputFileLocation_Format = reader["OutputFileLocation_Format"].ToString().Trim();
                    BatchInfo.strOutputPath_CN_Code_Repl = reader["OutputPath_CN_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_ID_Code_Repl = reader["OutputPath_ID_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_HK_Code_Repl = reader["OutputPath_HK_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_MY_Code_Repl = reader["OutputPath_MY_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_SG_Code_Repl = reader["OutputPath_SG_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_TH_Code_Repl = reader["OutputPath_TH_Code_Repl"].ToString().Trim();
                    BatchInfo.strOutputFileLocation_Archive = reader["OutputFileLocation_Archive"].ToString().Trim();
                    BatchInfo.strCleanup_Archive_Folder = reader["Cleanup_Archive_Folder"].ToString().Trim();
                    BatchInfo.strOutputPath_MQH_Repl = reader["OutputPath_MQH_Repl"].ToString().Trim();
                    BatchInfo.strOutputPath_SSH_Repl = reader["OutputPath_SSH_Repl"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_CN = reader["SQL_AppNo_CN"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_ID = reader["SQL_AppNo_ID"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_HK = reader["SQL_AppNo_HK"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_MY = reader["SQL_AppNo_MY"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_SG = reader["SQL_AppNo_SG"].ToString().Trim();
                    BatchInfo.strSQL_AppNo_TH = reader["SQL_AppNo_TH"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_CN = reader["SQL_SysRecordKey_CN"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_ID = reader["SQL_SysRecordKey_ID"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_HK = reader["SQL_SysRecordKey_HK"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_MY = reader["SQL_SysRecordKey_MY"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_SG = reader["SQL_SysRecordKey_SG"].ToString().Trim();
                    BatchInfo.strSQL_SysRecordKey_TH = reader["SQL_SysRecordKey_TH"].ToString().Trim();
                    BatchInfo.strSQL_Delta_Filter = reader["SQL_Delta_Filter"].ToString().Trim();
                    BatchInfo.strSSH_Enabled = reader["SSH_Enabled"].ToString().Trim();
                }
            }
        }

        #region Archive Files
        public void ArchiveFiles()
        {
            //fetch parameters from config file
            string sArchFile = ConfigurationManager.AppSettings["EDMP_ARC_FILEPATH"].ToString() + "\\" + DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            string OutputFileLocation = BatchInfo.strOutputFileLocation; //ConfigurationManager.AppSettings["OutputFileLocation"].ToString();
            string strOutputFileLocation_CountryFormat = BatchInfo.strOutputFileLocation_Format;

            strOutputLocation_CN = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_CN_Code_Repl);
            strOutputLocation_ID = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_ID_Code_Repl);
            strOutputLocation_HK = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_HK_Code_Repl);
            strOutputLocation_MY = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_MY_Code_Repl);
            strOutputLocation_SG = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_SG_Code_Repl);
            strOutputLocation_TH = strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_TH_Code_Repl);
            strOutputLocation_SSH = BatchInfo.strEDMI_SSH_FilePath; // strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_SSH_Repl);
            strOutputFileLocation_MQH = BatchInfo.strEDMI_MQH_FilePath; //strOutputFileLocation_CountryFormat.Replace("{country}", BatchInfo.strOutputPath_MQH_Repl);

            //prepare destination folders
            if (!Directory.Exists(sArchFile)) Directory.CreateDirectory(sArchFile);
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_CN_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_CN_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_ID_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_ID_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_HK_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_HK_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_MY_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_MY_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_SG_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_SG_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_TH_Code_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_TH_Code_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_SSH_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_SSH_Repl + "\\");
            if (!Directory.Exists(sArchFile + "\\" + BatchInfo.strOutputPath_MQH_Repl + "\\")) Directory.CreateDirectory(sArchFile + "\\" + BatchInfo.strOutputPath_MQH_Repl + "\\");

            //if (!Directory.Exists(sArchFile + "\\Indonesia\\")) Directory.CreateDirectory(sArchFile + "\\Indonesia\\");
            //if (!Directory.Exists(sArchFile + "\\HongKong\\")) Directory.CreateDirectory(sArchFile + "\\HongKong\\");
            //if (!Directory.Exists(sArchFile + "\\Malaysia\\")) Directory.CreateDirectory(sArchFile + "\\Malaysia\\");
            //if (!Directory.Exists(sArchFile + "\\Singapore\\")) Directory.CreateDirectory(sArchFile + "\\Singapore\\");
            //if (!Directory.Exists(sArchFile + "\\Thailand\\")) Directory.CreateDirectory(sArchFile + "\\Thailand\\");
            //if (!Directory.Exists(sArchFile + "\\SSHFTRF\\")) Directory.CreateDirectory(sArchFile + "\\SSHFTRF\\");
            //if (!Directory.Exists(sArchFile + "\\ISISFTRF\\")) Directory.CreateDirectory(sArchFile + "\\ISISFTRF\\");

            if (!Directory.Exists(strOutputLocation_CN)) Directory.CreateDirectory(strOutputLocation_CN);
            if (!Directory.Exists(strOutputLocation_HK)) Directory.CreateDirectory(strOutputLocation_HK);
            if (!Directory.Exists(strOutputLocation_ID)) Directory.CreateDirectory(strOutputLocation_ID);
            if (!Directory.Exists(strOutputLocation_MY)) Directory.CreateDirectory(strOutputLocation_MY);
            if (!Directory.Exists(strOutputLocation_SG)) Directory.CreateDirectory(strOutputLocation_SG);
            if (!Directory.Exists(strOutputLocation_TH)) Directory.CreateDirectory(strOutputLocation_TH);
            if (!Directory.Exists(strOutputLocation_SSH)) Directory.CreateDirectory(strOutputLocation_SSH);
            if (!Directory.Exists(strOutputFileLocation_MQH)) Directory.CreateDirectory(strOutputFileLocation_MQH);

            string[] sSourceFolder;
            string targetFolder = "";

            //China
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_CN); //OutputFileLocation + "\\China\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_CN_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //Hongkong
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_HK);//OutputFileLocation + "\\Hongkong\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_HK_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //Indonesia
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_ID); //OutputFileLocation + "\\Indonesia\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_ID_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //Malaysia
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_MY); //OutputFileLocation + "\\Malaysia\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_MY_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //Singapore
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_SG); //OutputFileLocation + "\\Singapore\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_SG_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //Thailand
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_TH); //OutputFileLocation + "\\Thailand\\");
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_TH_Code_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //SSH Files
            sSourceFolder = System.IO.Directory.GetFiles(strOutputLocation_SSH);
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_SSH_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                fi.Delete();
            }

            //MQHub Files
            sSourceFolder = System.IO.Directory.GetFiles(strOutputFileLocation_MQH);
            targetFolder = sArchFile + "\\" + BatchInfo.strOutputPath_MQH_Repl + "\\";
            foreach (String fileName in sSourceFolder)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
                if (fileName.EndsWith(".txt"))
                {
                    fi.CopyTo(System.IO.Path.Combine(targetFolder, fi.Name), true);
                    fi.Delete();
                }
            }
        }
        #endregion

        #region PerformHouseKeeping
        public void PerformHouseKeeping()
        {
            //fetch parameters from config file
            var strDaysRetentionPeriod = BatchInfo.strDaysRetentionPeriod.Trim(); //ConfigurationManager.AppSettings["DaysRetentionPeriod"].ToString().Trim();
            int intDaysRetentionPeriod = strDaysRetentionPeriod == "" ? 8 : Int16.Parse(strDaysRetentionPeriod) + 1;
            intDaysRetentionPeriod = intDaysRetentionPeriod - (intDaysRetentionPeriod * 2);
            string sArchFileToPurge = BatchInfo.strOutputFileLocation_Archive + "\\" + DateTime.Now.AddDays(intDaysRetentionPeriod).ToString("yyyyMMdd"); // ConfigurationManager.AppSettings["OutputFileLocation_Archive"].ToString()
            string[] strArrCleanupFolders = BatchInfo.strCleanup_Archive_Folder.ToString().Split(';');

            //remove archive more than x days retention
            if (System.IO.Directory.Exists(sArchFileToPurge))
            {
                System.IO.Directory.Delete(sArchFileToPurge, true);
            }

            //cleanup special folder
            foreach (string fldr in strArrCleanupFolders)
            {
                if (System.IO.Directory.Exists(fldr))
                {
                    System.IO.Directory.Delete(fldr, true);
                }
            }
        }
        #endregion

        #region Start Processing Files Async
        private void StartProcessingFiles()
        {
            CommonTextFileGenerator_DAO ct = new CommonTextFileGenerator_DAO();
            string strSpecialRunDate = BatchInfo.strSpecialRunDate;
            string strDeltaSQLFilter = BatchInfo.strSQL_Delta_Filter;
            DateTime dtDeltaStartDate = DateTime.Parse(BatchInfo.strDeltaStartDate);
            DateTime dtDeltaDateFilter = DateTime.Parse(strDeltaDateFilter);

            bool flgdeltaMode = dtDeltaDateFilter >= dtDeltaStartDate ? true : false;

            if (strSpecialRunDate.ToUpper() != "NOW")
            {
                strDeltaDateFilter = strSpecialRunDate;
                if (BatchInfo.strSpecialRunDate_RunType.ToUpper() == "D")
                {
                    flgdeltaMode = true;
                }
            }

            if (flgdeltaMode == false)
            {
                strDeltaDateFilter = "";
                strDeltaSQLFilter = "";
            }
            else
            {
                strDeltaSQLFilter = strDeltaSQLFilter.Replace("<DeltaRunDate>", strDeltaDateFilter);
            }

            strSysRecordKey_CN = BatchInfo.strSQL_SysRecordKey_CN + " " + strDeltaSQLFilter;
            strSysRecordKey_HK = BatchInfo.strSQL_SysRecordKey_HK + " " + strDeltaSQLFilter;
            strSysRecordKey_ID = BatchInfo.strSQL_SysRecordKey_ID + " " + strDeltaSQLFilter;
            strSysRecordKey_MY = BatchInfo.strSQL_SysRecordKey_MY + " " + strDeltaSQLFilter;
            strSysRecordKey_SG = BatchInfo.strSQL_SysRecordKey_SG + " " + strDeltaSQLFilter;
            strSysRecordKey_TH = BatchInfo.strSQL_SysRecordKey_TH + " " + strDeltaSQLFilter;

            strApplicationNo_CN = BatchInfo.strSQL_AppNo_CN + " " + strDeltaSQLFilter;
            strApplicationNo_HK = BatchInfo.strSQL_AppNo_HK + " " + strDeltaSQLFilter;
            strApplicationNo_ID = BatchInfo.strSQL_AppNo_ID + " " + strDeltaSQLFilter;
            strApplicationNo_MY = BatchInfo.strSQL_AppNo_MY + " " + strDeltaSQLFilter;
            strApplicationNo_SG = BatchInfo.strSQL_AppNo_SG + " " + strDeltaSQLFilter;
            strApplicationNo_TH = BatchInfo.strSQL_AppNo_TH + " " + strDeltaSQLFilter;

            strSysRecordKey_CN_ND = BatchInfo.strSQL_SysRecordKey_CN;
            strSysRecordKey_HK_ND = BatchInfo.strSQL_SysRecordKey_HK;
            strSysRecordKey_ID_ND = BatchInfo.strSQL_SysRecordKey_ID;
            strSysRecordKey_MY_ND = BatchInfo.strSQL_SysRecordKey_MY;
            strSysRecordKey_SG_ND = BatchInfo.strSQL_SysRecordKey_SG;
            strSysRecordKey_TH_ND = BatchInfo.strSQL_SysRecordKey_TH;

            strApplicationNo_CN_ND = BatchInfo.strSQL_AppNo_CN;
            strApplicationNo_HK_ND = BatchInfo.strSQL_AppNo_HK;
            strApplicationNo_ID_ND = BatchInfo.strSQL_AppNo_ID;
            strApplicationNo_MY_ND = BatchInfo.strSQL_AppNo_MY;
            strApplicationNo_SG_ND = BatchInfo.strSQL_AppNo_SG;
            strApplicationNo_TH_ND = BatchInfo.strSQL_AppNo_TH;

            string strTable = "";
            string strSelectFields = "SELECT * FROM ";
            string strSelectDistinctFields = "SELECT DISTINCT * FROM ";
            string strWhereApplicationNumber = " WHERE ApplicationNumber";
            string strWhereSysRecordKey = " WHERE sys_recordkey";

            StartCNThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);
            StartHKThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);
            StartIDThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);
            StartMYThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);
            StartSGThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);
            //StartTHThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber, strWhereSysRecordKey, flgdeltaMode);

            var listDelegated = new List<Action>();

            //listDelegated.Add(() => StartCNThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode));

            listDelegated.Add(() => StartHKThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
                    strWhereSysRecordKey, flgdeltaMode));

            //listDelegated.Add(() => StartMYThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode));

            //listDelegated.Add(() => StartSGThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode));

            //listDelegated.Add(() => StartIDThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode));

            //listDelegated.Add(() => StartTHThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode));

            #region threadpool comment out
            //ThreadPool.QueueUserWorkItem(delegate(object state)
            //{
            //    StartCNThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //        strWhereSysRecordKey, flgdeltaMode);
            //});
            ////CNThread.Start();

            //ThreadPool.QueueUserWorkItem(delegate(object state)
            //{
            //    StartHKThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //    strWhereSysRecordKey, flgdeltaMode);
            //});
            ////HKThread.Start();

            //ThreadPool.QueueUserWorkItem(delegate(object state) 
            //{
            //    StartMYThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //    strWhereSysRecordKey, flgdeltaMode);
            //});
            ////MYThread.Start();

            //ThreadPool.QueueUserWorkItem(delegate(object state)
            //{
            //    StartSGThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //    strWhereSysRecordKey, flgdeltaMode);
            //});
            ////SGThread.Start();

            //ThreadPool.QueueUserWorkItem(delegate(object state)
            //{
            //    StartIDThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //    strWhereSysRecordKey, flgdeltaMode);
            //});
            ////IDThread.Start();

            //ThreadPool.QueueUserWorkItem(delegate(object state)
            //{
            //    StartTHThread(strTable, strSelectFields, strSelectDistinctFields, strWhereApplicationNumber,
            //    strWhereSysRecordKey, flgdeltaMode);
            //});
            #endregion

            //SpawnAndWait(listDelegated);
        }

        private void StartCNThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            //strTable = "abcd_app_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_additionalcreditdocnew";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CallVerification";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CoBorrower";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Collateral";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralProperty";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyChargor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyTitle";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyValuation";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantExtra";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantOther";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CrossSystemReference";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CustomerGroup";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Facility";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Fulfillment";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_QuestionAnswer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OverallBankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")");
            //strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")");
            //strTable = "abcd_CoBorrower_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Collateral_CollateralFacility"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Fee";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Insurance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_TPSystem";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheck";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_FraudCheckHistory";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_Fulfillment_CreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditOpsDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_Doc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_SalesDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_DevelopmentProject";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScoresList";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_ProjectDeveloper";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_QuestionBank";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Solicitor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Valuer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_RelatedParty_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "Application10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Application11";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Application6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Application8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Application9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "ApplicationData1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Cust";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_ENT_10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Banking_Relation_Ent_9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "BankStmntAnalysis1_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "BankStmntAnalysis1_5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "BankStmntAnalysis4_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity1_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity10_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity2_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity3_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity4_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity6_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity7_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity8_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Bureau_Entity9_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "CbOrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_CN + ")");
            //strTable = "CbXrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_CN + ")");
            //strTable = "CustomerHKManBur";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "DAResults1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "DAResults2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "DAResults3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "DAResults4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "DAResults5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "doccache"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_CN_ND + ")"); // + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Notes";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            ////strTable = "TH_Bureau_Man"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            ////strTable = "TH_Bureau_Man2"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "entity_lookup";//revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_CN_ND + ")");
            //strTable = "EXPEntity_storage"; //revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_CN + ")");
            //strTable = "KeyTable";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "UserInfo"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")"
            //strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_CN, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            ////SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            //strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "abcd_cad_returnReasonCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_ProductType";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_app";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_cif";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_ebbs"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN_ND + ")");
            //strTable = "abcd_stp_fac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPAppNumLog";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")");
            //strTable = "EXPAppRemarks"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPdocuments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')");
            //strTable = "Expired_DataList";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")");
            //strTable = "Expired_DataRetention";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_CN + ")"); //AND Country_Origin = '" + MessageConstant.CountryCode_CN + "'");
            //strTable = "Expired_DataSetup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "EXPreportdetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')");
            //strTable = "EXPSalesDetails_ProductGroup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_CN + "')");
            //strTable = "tbl_maint_biz_nature";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblAppCompletedDate";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblBlacklist_stg";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklistCompany_stg";  // only for TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCGCPortfolioEligibility"; // only for MY	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCGCRelatedPeople";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");

            //strTable = "tblCNBureauReq";  //CN only?	 //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauRes";  //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "tblCreditRefDetail"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefRequest"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : " WHERE 1=2"));
            //strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefSummary"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDupCheckExport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "tblESE_Main"; //revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFinalDecision";//revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_CN_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFullfilmentPendDoc";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblHKEmail"; //HK Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "WHERE 1=2");
            //strTable = "tblICBS_AcctOpenRequest"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblISICcode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')");
            //strTable = "tblISICcode_Other";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')");
            //strTable = "tblMYRLSAcctSetup"; //MY Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPersonalDiscReport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPhysicalSiteVisit";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPSV_Attachments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_CN + ")");
            //strTable = "tblTHGateway_Letter"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_CN + ")");
            //strTable = "tblTHGateway_SMS"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblUnsecProd";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_CN + "')");
            //strTable = "tbNLnFac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "ref_ParamTxtSetting";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblFollowuprpt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_CN_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPappnum";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_CN + ")");
            //strTable = "EXPcustid";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "EXPSalesDetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_CN + "')");
            //strTable = "tblClusterBranch";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamMapId";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_CN + "')");
            //strTable = "tblParamTxt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamTxtMapCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblParamTxtVal";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_CN + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblSalesAccessMatrix";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_CN.ToUpper() + "')");
            //strTable = "tblTrxnUsers"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_CN, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        private void StartHKThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            //strTable = "abcd_app_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_additionalcreditdocnew";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CallVerification";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CoBorrower";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Collateral";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralProperty";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyChargor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyTitle";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyValuation";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantExtra";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantOther";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CrossSystemReference";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CustomerGroup";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Facility";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Fulfillment";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_QuestionAnswer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OverallBankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")");
            //strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")");
            //strTable = "abcd_CoBorrower_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Collateral_CollateralFacility"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Fee";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Insurance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_TPSystem";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheck";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheckHistory";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditOpsDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_Doc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_SalesDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_DevelopmentProject";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScoresList";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_ProjectDeveloper";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_QuestionBank";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Solicitor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Valuer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_RelatedParty_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "Application10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Application11";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Application6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Application8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Application9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "ApplicationData1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Cust";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_ENT_10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Banking_Relation_Ent_9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "BankStmntAnalysis1_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "BankStmntAnalysis1_5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "BankStmntAnalysis4_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity1_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity10_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity2_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity3_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity4_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity6_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity7_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity8_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Bureau_Entity9_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "CbOrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_HK + ")");
            //strTable = "CbXrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_HK + ")");
            //strTable = "CustomerHKManBur";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "DAResults1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "DAResults2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "DAResults3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "DAResults4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "DAResults5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "doccache"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_HK_ND + ")"); // + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Notes";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            ////strTable = "TH_Bureau_Man"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            ////strTable = "TH_Bureau_Man2"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "entity_lookup";//revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_HK_ND + ")");
            //strTable = "EXPEntity_storage"; //revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_HK + ")");
            //strTable = "KeyTable";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "UserInfo"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")"
            //strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_HK, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            ////SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            //strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "abcd_cad_returnReasonCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_ProductType";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_app";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_cif";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_ebbs";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK_ND + ")");
            //strTable = "abcd_stp_fac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPAppNumLog";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")");
            //strTable = "EXPAppRemarks"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPdocuments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')");
            //strTable = "Expired_DataList";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")");
            //strTable = "Expired_DataRetention";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_HK + ")"); // OR Country_Origin = '" + MessageConstant.CountryCode_HK + "'");
            //strTable = "Expired_DataSetup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "EXPreportdetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')");
            //strTable = "EXPSalesDetails_ProductGroup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_HK + "')");
            //strTable = "tbl_maint_biz_nature";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblAppCompletedDate";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblBlacklist_stg";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklistCompany_stg";  // only for TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCGCPortfolioEligibility"; // only for MY	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCGCRelatedPeople";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblCNBureauReq";  //CN only?	 TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauRes";  //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "tblCreditRefDetail"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCreditRefRequest"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : " WHERE 1=2"));
            //strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCreditRefSummary"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDupCheckExport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "tblESE_Main"; //revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFinalDecision";//revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_HK_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFullfilmentPendDoc";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblHKEmail"; //HK Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "WHERE 1=2");
            //strTable = "tblICBS_AcctOpenRequest"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblISICcode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')");
            //strTable = "tblISICcode_Other";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')");
            //strTable = "tblMYRLSAcctSetup"; //MY Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPersonalDiscReport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPhysicalSiteVisit";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPSV_Attachments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_HK + ")");
            //strTable = "tblTHGateway_Letter"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_HK + ")");
            //strTable = "tblTHGateway_SMS"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblUnsecProd";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_HK + "')");
            //strTable = "tbNLnFac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "ref_ParamTxtSetting";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblFollowuprpt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_HK_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPappnum";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_HK + ")");
            //strTable = "EXPcustid";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "EXPSalesDetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_HK + "')");
            //strTable = "tblClusterBranch";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamMapId";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_HK + "')");
            //strTable = "tblParamTxt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamTxtMapCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblParamTxtVal";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_HK + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblSalesAccessMatrix";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_HK.ToUpper() + "')");
            //strTable = "tblTrxnUsers"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_HK, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        private void StartMYThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            //strTable = "abcd_app_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_additionalcreditdocnew";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CallVerification";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CoBorrower";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Collateral";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralProperty";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyChargor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyTitle";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyValuation";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantExtra";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantOther";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CrossSystemReference";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CustomerGroup";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Facility";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Fulfillment";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_QuestionAnswer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OverallBankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")");
            //strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")");
            //strTable = "abcd_CoBorrower_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Collateral_CollateralFacility"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Fee";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Insurance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_TPSystem";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheck";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheckHistory";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditOpsDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_Doc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_SalesDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_DevelopmentProject";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScoresList";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_ProjectDeveloper";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_QuestionBank";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Solicitor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Valuer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_RelatedParty_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "Application10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Application11";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Application6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Application8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Application9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "ApplicationData1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Cust";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_ENT_10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Banking_Relation_Ent_9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "BankStmntAnalysis1_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "BankStmntAnalysis1_5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "BankStmntAnalysis4_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity1_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity10_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity2_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity3_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity4_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity6_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity7_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity8_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Bureau_Entity9_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "CbOrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_MY + ")");
            //strTable = "CbXrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_MY + ")");
            //strTable = "CustomerHKManBur";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "DAResults1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "DAResults2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "DAResults3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "DAResults4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "DAResults5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "doccache"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_MY_ND + ")"); // + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Notes";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            ////strTable = "TH_Bureau_Man"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            ////strTable = "TH_Bureau_Man2"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "entity_lookup";//revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_MY_ND + ")");
            //strTable = "EXPEntity_storage"; //revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_MY + ")");
            //strTable = "KeyTable";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "UserInfo";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")"
            //strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_MY, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            ////SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            //strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "abcd_cad_returnReasonCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_ProductType";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_app";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_cif";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_ebbs";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY_ND + ")");
            //strTable = "abcd_stp_fac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPAppNumLog";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")");
            //strTable = "EXPAppRemarks"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPdocuments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')");
            //strTable = "Expired_DataList";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")");
            //strTable = "Expired_DataRetention";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_MY + ")"); // OR Country_Origin = '" + MessageConstant.CountryCode_MY + "'");
            //strTable = "Expired_DataSetup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "EXPreportdetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')");
            //strTable = "EXPSalesDetails_ProductGroup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_MY + "')");
            //strTable = "tbl_maint_biz_nature";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblAppCompletedDate";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblBlacklist_stg";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklistCompany_stg";  // only for TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCGCPortfolioEligibility"; // only for MY	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCGCRelatedPeople";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblCNBureauReq";  //CN only? TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCNBureauRes";  //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "tblCreditRefDetail"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCreditRefRequest"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : " WHERE 1=2"));
            //strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefSummary"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDupCheckExport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "tblESE_Main"; //revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFinalDecision";//revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_MY_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFullfilmentPendDoc";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblHKEmail"; //HK Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "WHERE 1=2");
            //strTable = "tblICBS_AcctOpenRequest"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblISICcode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')");
            //strTable = "tblISICcode_Other";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')");
            //strTable = "tblMYRLSAcctSetup"; //MY Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPersonalDiscReport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPhysicalSiteVisit";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPSV_Attachments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_MY + ")");
            //strTable = "tblTHGateway_Letter"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_MY + ")");
            //strTable = "tblTHGateway_SMS"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblUnsecProd";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_MY + "')");
            //strTable = "tbNLnFac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "ref_ParamTxtSetting";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblFollowuprpt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_MY_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPappnum";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_MY + ")");
            //strTable = "EXPcustid";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "EXPSalesDetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_MY + "')");
            //strTable = "tblClusterBranch";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamMapId";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_MY + "')");
            //strTable = "tblParamTxt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamTxtMapCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblParamTxtVal";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_MY + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblSalesAccessMatrix";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_MY.ToUpper() + "')");
            //strTable = "tblTrxnUsers"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_MY, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        private void StartSGThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            //strTable = "abcd_app_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_additionalcreditdocnew";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CallVerification";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CoBorrower";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Collateral";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralProperty";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyChargor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyTitle";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyValuation";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantExtra";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantOther";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CrossSystemReference";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CustomerGroup";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Facility";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Fulfillment";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_QuestionAnswer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OverallBankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")");
            //strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")");
            //strTable = "abcd_CoBorrower_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Collateral_CollateralFacility"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Fee";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Insurance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_TPSystem";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheck";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_FraudCheckHistory";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_Fulfillment_CreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditOpsDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_Doc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_SalesDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_DevelopmentProject";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScoresList";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_ProjectDeveloper";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_QuestionBank";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Solicitor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Valuer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_RelatedParty_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "Application10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Application11";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Application6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Application8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Application9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "ApplicationData1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Cust";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_ENT_10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Banking_Relation_Ent_9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "BankStmntAnalysis1_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "BankStmntAnalysis1_5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "BankStmntAnalysis4_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity1_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity10_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity2_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity3_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity4_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity6_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity7_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity8_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Bureau_Entity9_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "CbOrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_SG + ")");
            //strTable = "CbXrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_SG + ")");
            //strTable = "CustomerHKManBur";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "DAResults1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "DAResults2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "DAResults3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "DAResults4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "DAResults5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "doccache"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Notes";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            ////strTable = "TH_Bureau_Man"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            ////strTable = "TH_Bureau_Man2"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "entity_lookup";//revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_SG_ND + ")");
            //strTable = "EXPEntity_storage"; //revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_SG + ")");
            //strTable = "KeyTable";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "UserInfo";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")"
            //strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_SG, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            ////SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            //strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "abcd_cad_returnReasonCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_ProductType";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_app";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_cif";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_ebbs";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG_ND + ")");
            //strTable = "abcd_stp_fac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPAppNumLog";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")");
            //strTable = "EXPAppRemarks"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_SG_ND + ")");  //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPdocuments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')");
            //strTable = "Expired_DataList";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")");
            //strTable = "Expired_DataRetention";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_SG + ")");// OR Country_Origin = '" + MessageConstant.CountryCode_SG + "'");
            //strTable = "Expired_DataSetup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "EXPreportdetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')");
            //strTable = "EXPSalesDetails_ProductGroup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_SG + "')");
            //strTable = "tbl_maint_biz_nature";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblAppCompletedDate";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklist_stg";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklistCompany_stg";  // only for TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCGCPortfolioEligibility"; // only for MY	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCGCRelatedPeople";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblCNBureauReq";  //CN only?	TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCNBureauRes";  //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "tblCreditRefDetail"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefRequest"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : " WHERE 1=2"));
            //strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefSummary"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblDupCheckExport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "tblESE_Main"; //revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFinalDecision";//revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_SG_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFullfilmentPendDoc";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblHKEmail"; //HK Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "WHERE 1=2");
            //strTable = "tblICBS_AcctOpenRequest"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblISICcode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')");
            //strTable = "tblISICcode_Other";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')");
            //strTable = "tblMYRLSAcctSetup"; //MY Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblPersonalDiscReport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPhysicalSiteVisit";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPSV_Attachments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_SG + ")");
            //strTable = "tblTHGateway_Letter"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_SG + ")");
            //strTable = "tblTHGateway_SMS"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_SG + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblUnsecProd";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_SG + "')");
            //strTable = "tbNLnFac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "ref_ParamTxtSetting";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblFollowuprpt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_SG_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPappnum";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_SG + ")");
            //strTable = "EXPcustid";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "EXPSalesDetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_SG + "')");
            //strTable = "tblClusterBranch";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamMapId";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_SG + "')");
            //strTable = "tblParamTxt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamTxtMapCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblParamTxtVal";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_SG + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblSalesAccessMatrix";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_SG.ToUpper() + "')");
            //strTable = "tblTrxnUsers"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_SG, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        private void StartTHThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            strTable = "abcd_app_AdditionalCreditDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_additionalcreditdocnew";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CallVerification";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CoBorrower";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Collateral";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CollateralProperty";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CollateralPropertyChargor";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CollateralPropertyTitle";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CollateralPropertyValuation";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Compliance";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Condition";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Covenant";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CovenantExtra";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CovenantOther";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CrossSystemReference";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_CustomerGroup";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Disbursement";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Facility";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_Fulfillment";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_QuestionAnswer";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_app_SecurityDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_BankStatement";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_BankStatementDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_Check";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_FinancialStatement";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_FinancialStatementDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_Income";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_IncomeDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_OtherBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_OtherScores";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CoBorrower_OverallBankStatement";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")");
            strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")");
            strTable = "abcd_CoBorrower_SCBBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Collateral_CollateralFacility"; //TXN
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Customer_Income";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Customer_IncomeDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Customer_OtherBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Customer_OtherScores";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Customer_SCBBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CustomerGroup_Check";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_fac_Disbursement";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_fac_Fee";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_fac_Insurance";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_fac_TPSystem";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_FraudCheck";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "abcd_FraudCheckHistory";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "abcd_Fulfillment_CreditDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Fulfillment_CreditOpsDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Fulfillment_Doc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_Fulfillment_SalesDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_maint_AdditionalCreditDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_maint_Compliance";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_maint_Condition";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_maint_Covenant";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_DevelopmentProject";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_OtherScores";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_OtherScoresList";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_ProjectDeveloper";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_QuestionBank";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_maint_SecurityDoc";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_Solicitor";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_maint_Valuer";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "abcd_RelatedParty_Income";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_RelatedParty_IncomeDtl";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_RelatedParty_OtherBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_RelatedParty_SCBBankingRelationship";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "Application10";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application11";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application6";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application8";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Application9";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "ApplicationData1";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Cust";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_1";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_ENT_10";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_3";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_4";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_5";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_6";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_8";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Banking_Relation_Ent_9";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "BankStmntAnalysis1_3";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "BankStmntAnalysis1_5_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "BankStmntAnalysis4_5";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity1";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity1_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity10";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity10_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity2_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity3";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity3_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity4";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity4_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity5";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity5_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity6";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity6_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity7_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity8";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity8_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity9";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Bureau_Entity9_2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "CbOrd";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_TH + ")");
            strTable = "CbXrd";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_TH + ")");
            strTable = "CustomerHKManBur";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "DAResults1";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "DAResults2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "DAResults3";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "DAResults4";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "DAResults5";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "doccache"; //TXN
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "Entity1";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity2";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity3";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity4";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity5";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity6";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity8";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity9";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Entity10";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Notes";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "TH_Bureau_Man"; //Thailand only	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "TH_Bureau_Man2"; //Thailand only	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "entity_lookup";//revised	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_TH_ND + ")");
            strTable = "EXPEntity_storage"; //revised	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_TH + ")");
            strTable = "KeyTable";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "UserInfo";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")"
            strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_TH, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            //SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            strTable = "abcd_cad_returnReasonCode";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "abcd_maint_ProductType";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_stp_app";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_stp_cif";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "abcd_stp_ebbs";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH_ND + ")");
            strTable = "abcd_stp_fac";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "EXPAppNumLog";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")");
            strTable = "EXPAppRemarks"; //TXN
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "EXPdocuments";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')");
            strTable = "Expired_DataList";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")");
            strTable = "Expired_DataRetention";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_TH + ")"); //OR Country_Origin = '" + MessageConstant.CountryCode_TH + "'");
            strTable = "Expired_DataSetup";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "EXPreportdetails";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')");
            strTable = "EXPSalesDetails_ProductGroup";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_TH + "')");
            strTable = "tbl_maint_biz_nature";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblAppCompletedDate";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblBlacklist_stg";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblBlacklistCompany_stg";  // only for TH	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblCGCPortfolioEligibility"; // only for MY	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblCGCRelatedPeople";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblCNBureauProcessingTime"; //CN only?	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblCNBureauReq";  //CN only?	TXN
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblCNBureauRes";  //CN only?	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            strTable = "tblCreditRefDetail"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblCreditRefRequest"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : " WHERE 1=2"));
            strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblCreditRefSummary"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblDupCheckExport";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            strTable = "tblESE_Main"; //revised	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblFinalDecision";//revised	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_TH_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblFullfilmentPendDoc";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblHKEmail"; //HK Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblICBS_AcctOpenRequest"; //TH only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblISICcode";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')");
            strTable = "tblISICcode_Other";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')");
            strTable = "tblMYRLSAcctSetup"; //MY Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblPersonalDiscReport";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblPhysicalSiteVisit";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "tblPSV_Attachments";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_TH + ")");
            strTable = "tblTHGateway_Letter"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_TH + ")");
            strTable = "tblTHGateway_SMS"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_TH + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblUnsecProd";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_TH + "')");
            strTable = "tbNLnFac";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "ref_ParamTxtSetting";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblFollowuprpt";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_TH_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            strTable = "EXPappnum";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_TH + ")");
            strTable = "EXPcustid";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "EXPSalesDetails";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_TH + "')");
            strTable = "tblClusterBranch";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblParamMapId";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_TH + "')");
            strTable = "tblParamTxt";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            strTable = "tblParamTxtMapCode";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblParamTxtVal";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_TH + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            strTable = "tblSalesAccessMatrix";
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_TH.ToUpper() + "')");
            strTable = "tblTrxnUsers"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_TH, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        private void StartIDThread(string strTable, string strSelectFields, string strSelectDistinctFields,
            string strWhereApplicationNumber, string strWhereSysRecordKey, bool flgdeltaMode)
        {
            //strTable = "abcd_app_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_additionalcreditdocnew";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CallVerification";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CoBorrower";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Collateral";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralProperty";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyChargor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyTitle";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CollateralPropertyValuation";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantExtra";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CovenantOther";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CrossSystemReference";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_CustomerGroup";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Facility";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_Fulfillment";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_QuestionAnswer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_app_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_BankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_FinancialStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CoBorrower_OverallBankStatement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")");
            //strTable = "abcd_CoBorrower_OverallBankStatementDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")");
            //strTable = "abcd_CoBorrower_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Collateral_CollateralFacility"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Customer_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_Check";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_CustomerGroup_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Disbursement";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Fee";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_Insurance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_fac_TPSystem";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_FraudCheck";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_FraudCheckHistory";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_Fulfillment_CreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_CreditOpsDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_Doc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_Fulfillment_SalesDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_AdditionalCreditDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Compliance";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Condition";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_Covenant";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_DevelopmentProject";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScores";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_OtherScoresList";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_ProjectDeveloper";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_QuestionBank";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_maint_SecurityDoc";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Solicitor";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_maint_Valuer";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "abcd_RelatedParty_Income";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_IncomeDtl";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_OtherBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_RelatedParty_SCBBankingRelationship";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "Application10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Application11";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            strTable = "Application12";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Application6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            strTable = "Application7";
            GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Application8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Application9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "ApplicationData1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Cust";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_ENT_10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Banking_Relation_Ent_9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "BankStmntAnalysis1_3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "BankStmntAnalysis1_5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "BankStmntAnalysis4_5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity1_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity10_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity2_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity3_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity4_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity5_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity6_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity7_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity8_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Bureau_Entity9_2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Call_Verification"; //vw_edm_ + Call_Verification	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "CbOrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_ID + ")");
            //strTable = "CbXrd";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE SYS_APPKEY IN(" + strSysRecordKey_ID + ")");
            //strTable = "CustomerHKManBur";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "DAResults1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "DAResults2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "DAResults3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "DAResults4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "DAResults5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "doccache"; //TXN
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE App_Num IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Doc_Rec_Date_Sales,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Status_Credit_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Doc_Complete_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "Entity1";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity2";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity3";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity4";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity5";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity6";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity7";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity8";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity9";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Entity10";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Notes";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            ////strTable = "TH_Bureau_Man"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            ////strTable = "TH_Bureau_Man2"; //Thailand only	
            ////GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "entity_lookup";//revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_ID_ND + ")");
            //strTable = "EXPEntity_storage"; //revised	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_num IN(" + strApplicationNo_ID + ")");
            //strTable = "KeyTable";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "UserInfo";
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")"
            //strTable = "Users"; //use distinct to avoid record duplication which only occurs in test env, in prod this is unique	
            //GenerateTextFile(MessageConstant.strDBMain, strTable, MessageConstant.CountryCodeText_ID, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
            ////SELECT * FROM dbo.tblDuplicateCheck_stg WHERE convert(nvarchar(10),decisiondate,103) = '09/14/2016' OR convert(nvarchar(10),ResponseTimestamp,103) = convert(nvarchar(10),'08/01/2016',103)	
            //strTable = "abcd_app_DupCheckRequest"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "abcd_cad_returnReasonCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "abcd_maint_ProductType";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryUser IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_app";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CompletedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CancelledDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_cif";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqTriggerTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp_RN,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "abcd_stp_ebbs";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID_ND + ")");
            //strTable = "abcd_stp_fac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),InqTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),InqResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddTriggerTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),AddResponseTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPAppNumLog";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")");
            //strTable = "EXPAppRemarks"; //TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_number IN(" + strApplicationNo_ID_ND + ")"); // + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_updated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPdocuments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')");
            //strTable = "Expired_DataList";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")");
            //strTable = "Expired_DataRetention";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE APPLICATION_NO IN(" + strApplicationNo_ID + ")"); //OR Country_Origin = '" + MessageConstant.CountryCode_ID + "'");
            //strTable = "Expired_DataSetup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE COUNTRY_ORIGIN IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),ENTERED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),UPDATED_DATETIME,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "EXPreportdetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')");
            //strTable = "EXPSalesDetails_ProductGroup";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCode_ID + "')");
            //strTable = "tbl_maint_biz_nature";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblAppCompletedDate";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_app_completed,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklist_stg";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateImported,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblBlacklistCompany_stg";  // only for TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "Where 1=2"); //(flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),DateEntered,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCGCPortfolioEligibility"; // only for MY	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Overall_Decision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblCGCRelatedPeople";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCNBureauProcessingTime"; //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblCNBureauReq";  //CN only?	TXN
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Dt_request,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCNBureauRes";  //CN only?	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE [Application Number] IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND ((CONVERT(nvarchar(10),Dt_response,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),CBCN_TMP_ReportDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)))" : ""));
            //strTable = "tblCreditRefDetail"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE DMAPPLN IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefRequest"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, ""); //(flgdeltaMode == true ? " WHERE 1=2 AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : " WHERE 1=2"));
            //strTable = "tblCreditRefRequest_ReconRpt"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, (flgdeltaMode == true ? " WHERE CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblCreditRefSummary"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE MLAPPN IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DateCreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblDupCheckExport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE TransactRegistrationNo IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DecisionDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblDuplicateCheck_stg"; //only applicable to TH	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE 1=2");
            //strTable = "tblESE_Main"; //revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),BureauReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),BureauResTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),ScorecardReqTimestamp,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFinalDecision";//revised	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Sys_recordkey IN(" + strSysRecordKey_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),SYS_UPDATEDATE,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Final_Decision_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblFullfilmentPendDoc";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Report_Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblHKEmail"; //HK Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),DateSend,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DateGenerate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblICBS_AcctDDWN_Rpt"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "WHERE 1=2");
            //strTable = "tblICBS_AcctOpenRequest"; //TH only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblICBS_AcctOpenRequestRpt"; //TH only TXN	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE app_no IN(" + strApplicationNo_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_created,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblISICcode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Ctry1 IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')");
            //strTable = "tblISICcode_Other";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')");
            //strTable = "tblMYRLSAcctSetup"; //MY Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Transact_AppNum IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),RLS_Sent_DateTime,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblPersonalDiscReport";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPhysicalSiteVisit";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereApplicationNumber + " IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),CreatedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),LastModifiedDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "tblPSV_Attachments";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE Attachment_Key IN(" + strApplicationNo_ID + ")");
            //strTable = "tblTHGateway_Letter"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_ID + ")");
            //strTable = "tblTHGateway_SMS"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE AppNo IN(" + strApplicationNo_ID + ")" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),datecreated,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblTHInterface_SIMS_AppProd"; //TH Only	
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE RecKey IN(" + strSysRecordKey_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblUnsecProd";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_ID + "')");
            //strTable = "tbNLnFac";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID + ")" + (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),App_DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "ref_ParamTxtSetting";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblFollowuprpt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, strWhereSysRecordKey + " IN(" + strSysRecordKey_ID_ND + ")"); //+ (flgdeltaMode == true ? " AND (CONVERT(nvarchar(10),Displayed_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),Generate_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),DDDate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121) OR CONVERT(nvarchar(10),OverallDecision_Date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121))" : ""));
            //strTable = "EXPappnum";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE application_num IN(" + strApplicationNo_ID + ")");
            //strTable = "EXPcustid";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "EXPSalesDetails";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCode_ID + "')");
            //strTable = "tblClusterBranch";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamMapId";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_ID + "')");
            //strTable = "tblParamTxt";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, "");
            //strTable = "tblParamTxtMapCode";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE CountryCode IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),Gen_date,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblParamTxtVal";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE val1 IN('" + MessageConstant.CountryCode_ID + "')" + (flgdeltaMode == true ? " AND CONVERT(nvarchar(10),dt_generate,121) = CONVERT(nvarchar(10), '" + strDeltaDateFilter + "',121)" : ""));
            //strTable = "tblSalesAccessMatrix";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectFields + MessageConstant.strViewPrefix + strTable, " WHERE country IN('" + MessageConstant.CountryCodeText_ID.ToUpper() + "')");
            //strTable = "tblTrxnUsers";
            //GenerateTextFile(MessageConstant.strDBExt, strTable, MessageConstant.CountryCodeText_ID, strSelectDistinctFields + MessageConstant.strViewPrefix + strTable, "");
        }

        #endregion

        #region Other Methods
        private void GenerateTextFile(string strDBName, string strTableName, string strCountry, string strSQL, string strWhereClause)
        {
            if (!Directory.Exists(strOutputLocation_CN)) Directory.CreateDirectory(strOutputLocation_CN);
            if (!Directory.Exists(strOutputLocation_HK)) Directory.CreateDirectory(strOutputLocation_HK);
            if (!Directory.Exists(strOutputLocation_ID)) Directory.CreateDirectory(strOutputLocation_ID);
            if (!Directory.Exists(strOutputLocation_MY)) Directory.CreateDirectory(strOutputLocation_MY);
            if (!Directory.Exists(strOutputLocation_SG)) Directory.CreateDirectory(strOutputLocation_SG);
            if (!Directory.Exists(strOutputLocation_TH)) Directory.CreateDirectory(strOutputLocation_TH);
            if (!Directory.Exists(strOutputFileLocation_MQH)) Directory.CreateDirectory(strOutputFileLocation_MQH);

            //strOutputLocation_MY = "C:\\SCBStaging\\EDMP\\Malaysia\\";

            int intFieldCount = 0;
            int intRowCount = 0;
            string strSpecialRunDate = BatchInfo.strSpecialRunDate; //ConfigurationManager.AppSettings["SpecialRunDate"].ToString();
            string strDateToday = strSpecialRunDate == string.Empty || strSpecialRunDate.ToUpper() == "NOW" ? DateTime.Now.AddDays(-1).ToString("yyyyMMdd") : strSpecialRunDate.Replace("-", ""); //20160904
            string strRunDate = strSpecialRunDate == string.Empty || strSpecialRunDate.ToUpper() == "NOW" ? DateTime.Now.AddDays(-1).ToString("yyyyMMdd") : strSpecialRunDate.Replace("-", ""); //20160904
            StringBuilder sb = new StringBuilder(BatchInfo.strOutputFileFormat);
            string strFilename = sb.Replace("{tablename}", strTableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", "d").Replace("{sequence}", "1").ToString();

            string strFieldValue = "";
            string strLineValue = "";
            string strFileLocation = "";
            switch (strCountry.ToUpper())
            {
                case "CN": strFileLocation = strOutputLocation_CN; break;
                case "HK": strFileLocation = strOutputLocation_HK; break;
                case "ID": strFileLocation = strOutputLocation_ID; break;
                case "MY": strFileLocation = strOutputLocation_MY; break;
                case "SG": strFileLocation = strOutputLocation_SG; break;
                case "TH": strFileLocation = strOutputLocation_TH; break;
            }

            using (TextWriter tw = new StreamWriter(strFileLocation + "\\" + strFilename))
            {
                //File Header 1
                tw.WriteLine("H" + "|" + strCountry.ToUpper() + "|" + "TRN" + "|" + strRunDate + "|" + strFilename.ToLower());

                //To retrieve Content
                #region To retrieve Content

                intRowCount = 0;
                string strDataType = "";

                CommonTextFileGenerator_DAO DC = new CommonTextFileGenerator_DAO();
                using (IDataReader reader = DC.FetchDBContent(strDBName, strSQL, strWhereClause))
                {
                    if (reader != null && !reader.IsClosed)
                    {
                        while (reader.Read())
                        {
                            intFieldCount = reader.FieldCount;
                            strLineValue = "";
                            strFieldValue = "";
                            for (int i = 0; i < intFieldCount; ++i)
                            {
                                strDataType = reader.GetDataTypeName(i).ToLower();
                                if (strDataType == "binary")
                                {
                                    string text = ByteArrayToString(ObjectToByteArray(reader.GetValue(i))).ToString();
                                    strFieldValue = (text != null && text.Length > 0 ? text : "");//(text != "" ? text : "")); 
                                }
                                else if (strDataType == "image")
                                {
                                    string text = ByteArrayToString(ObjectToByteArray(reader.GetValue(i))).ToString();
                                    strFieldValue = (text != null && text.Length > 0 ? text : "");//(text != "" ? text : "")); 
                                }
                                else if (strDataType == "datetime")
                                {
                                    strFieldValue = (!reader.GetValue(i).Equals(DBNull.Value) ? reader.GetDateTime(i).ToString("yyyy-MM-dd hh:mm:ss.mmm") : ""); //(!reader["TRANSACT_GRP_ID"].Equals(DBNull.Value) ? reader["TRANSACT_GRP_ID"].ToString() : ""));
                                }
                                else
                                {
                                    strFieldValue = (!reader.GetValue(i).Equals(DBNull.Value) ? reader.GetValue(i).ToString() : "");
                                    strFieldValue = strFieldValue.Replace("|", "{:}");
                                    strFieldValue = strFieldValue.Replace("\r", " ");
                                    strFieldValue = strFieldValue.Replace("\n", " ");
                                    strFieldValue = strFieldValue.Replace(Environment.NewLine, " ");
                                }
                                strLineValue = strLineValue + "|" + strFieldValue;
                            }
                            intRowCount += 1;
                            tw.WriteLine("D" + strLineValue);
                        }
                    }
                }

                #endregion To retrieve Content

                tw.Write("T" + "|" + strRunDate + "|" + intRowCount.ToString());
                tw.Close();
            }
            GenerateEDMI_txt(strFilename, strCountry, strTableName);
        }

        public delegate void Action();

        public static void SpawnAndWait(IEnumerable<Action> actions)
        {
            object key = new object();
            Queue<Action> queue = new Queue<Action>(actions);
            int count = 0;
            AutoResetEvent whenDone = new AutoResetEvent(false);

            WaitCallback callback = null;
            callback = delegate
            {
                Action action = null;
                lock (key)
                {
                    if (queue.Count > 0)
                        action = queue.Dequeue();
                }
                if (action != null)
                {
                    action();
                    ThreadPool.QueueUserWorkItem(callback);
                }
                else
                {
                    if (Interlocked.Increment(ref count) == 100000)
                        whenDone.Set();
                }

            };

            for (int i = 0; i < 100000; i++)
            {
                ThreadPool.QueueUserWorkItem(callback);
            }

            whenDone.WaitOne();
        }

        public static byte[] ObjectToByteArray(Object obj)//Our class instance
        {
            if (obj == null)
                return null;
            System.Xml.Serialization.XmlSerializer bf = new System.Xml.Serialization.XmlSerializer(obj.GetType());
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);
            return ms.ToArray();
        }

        public static string ByteArrayToString(byte[] ba)
        {
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }

        public static string ByteArrayToString2(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        private void GetEdmFileInfoViews()
        {
            var strViewName = ConfigurationManager.AppSettings["ViewFileInfo"].ToString();
            CommonTextFileGenerator_DAO DC = new CommonTextFileGenerator_DAO();
            ListEdmFileInfo = DC.FetchEdmFileInfo(strViewName);
        }

        private void CreateAndWriteTextFile(string sServiceName, string sInputFile, string sOutputFile, string sTableName, string sCountryPrefix)
        {
            string sEDM_EDMI_FILEPATH = BatchInfo.strEDMI_MQH_FilePath.ToString();  //ConfigurationManager.AppSettings["EDMP_ISIS_FILEPATH"].ToString();
            string sEDMIUser = BatchInfo.strMQHFTUser; //ConfigurationManager.AppSettings["EDMP_ISIS_FTRQ_USERID"].ToString();

            using (StreamWriter stream = new StreamWriter(string.Format("{0}{1}{2}.txt", sEDM_EDMI_FILEPATH, sCountryPrefix.ToLower(), sTableName.ToLower()), false))
            {
                stream.WriteLine("-s " + sServiceName);
                stream.WriteLine("-u " + sEDMIUser);
                stream.WriteLine("-i " + sInputFile); // string.Format("{0}.txt",sInputFile
                stream.WriteLine("-o " + sOutputFile); //string.Format("{0}.txt",
                stream.WriteLine("-end ");
                stream.Close();
            }
        }

        #endregion

        #region Generate ISISFTRF
        private void GenerateEDMI_txt(string strFileName, string strCountry, string strTableName)
        {
            //CREATE EDMI TXT FILE
            string sEDM_EDMI_FILEPATH = BatchInfo.strEDMI_MQH_FilePath; //ConfigurationManager.AppSettings["EDMP_ISIS_FILEPATH"].ToString();
            //string sEDMIUser = BatchInfo.strMQHFTUser;//ConfigurationManager.AppSettings["EDMP_ISIS_FTRQ_USERID"].ToString();
            string sServiceName = "";
            string sTargetFilePath = "";
            string sSourceFilePath = "";
            strTableName = strTableName.ToLower();
            //sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();

            //var strViewName = ConfigurationManager.AppSettings["ViewFileInfo"].ToString();

            //CommonTextFileGenerator_DAO DC = new CommonTextFileGenerator_DAO();
            //ListEdmFileInfo = DC.FetchEdmFileInfo(strViewName);

            var edmFileInfo = ListEdmFileInfo.Find(delegate(EdmFileInfo x)
            {
                return x.TableName == strTableName;
            });

            // ListEdmFileInfo..Where(x => x.TableName.ToLower() == strTableName.ToLower()).FirstOrDefault();

            if (edmFileInfo != null)
            {
                switch (strCountry)
                {
                    case MessageConstant.CountryCodeText_CN:
                        sServiceName = edmFileInfo.ServiceKey_CN != null ? edmFileInfo.ServiceKey_CN.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_CN != null ? edmFileInfo.SourceFile_CN.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_CN != null ? edmFileInfo.TargetFile_CN.ToString().Trim() : "";
                        break;
                    case MessageConstant.CountryCodeText_HK:
                        sServiceName = edmFileInfo.ServiceKey_HK != null ? edmFileInfo.ServiceKey_HK.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_HK != null ? edmFileInfo.SourceFile_HK.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_HK != null ? edmFileInfo.TargetFile_HK.ToString().Trim() : "";
                        break;
                    case MessageConstant.CountryCodeText_ID:
                        sServiceName = edmFileInfo.ServiceKey_ID != null ? edmFileInfo.ServiceKey_ID.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_ID != null ? edmFileInfo.SourceFile_ID.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_ID != null ? edmFileInfo.TargetFile_ID.ToString().Trim() : "";
                        break;
                    case MessageConstant.CountryCodeText_MY:
                        sServiceName = edmFileInfo.ServiceKey_MY != null ? edmFileInfo.ServiceKey_MY.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_MY != null ? edmFileInfo.SourceFile_MY.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_MY != null ? edmFileInfo.TargetFile_MY.ToString().Trim() : "";
                        break;
                    case MessageConstant.CountryCodeText_SG:
                        sServiceName = edmFileInfo.ServiceKey_SG != null ? edmFileInfo.ServiceKey_SG.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_SG != null ? edmFileInfo.SourceFile_SG.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_SG != null ? edmFileInfo.TargetFile_SG.ToString().Trim() : "";
                        break;
                    case MessageConstant.CountryCodeText_TH:
                        sServiceName = edmFileInfo.ServiceKey_TH != null ? edmFileInfo.ServiceKey_TH.ToString().Trim() : "";
                        sSourceFilePath = edmFileInfo.SourceFile_TH != null ? edmFileInfo.SourceFile_TH.ToString().Trim() : "";
                        sTargetFilePath = edmFileInfo.TargetFile_TH != null ? edmFileInfo.TargetFile_TH.ToString().Trim() : "";
                        break;
                }
                //sSourceFilePath = "SCBStaging\\EDMP\\Malaysia\\";
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + edmFileInfo.TableName, sTargetFilePath + edmFileInfo.TableName, edmFileInfo.TableName, string.Format("{0}_", strCountry.ToLower()));
                //CreateAndWriteTextFile(sServiceName, sSourceFilePath + strFileName, sTargetFilePath + strFileName, edmFileInfo.TableName, string.Format("{0}_", strCountry.ToLower()));
            }
        }

        private void GenerateEDMI_txt_DONOTUSE()
        {
            //CREATE EDMI TXT FILE
            string sEDM_EDMI_FILEPATH = ConfigurationManager.AppSettings["EDMP_ISIS_FILEPATH"].ToString();
            string sEDMIUser = BatchInfo.strMQHFTUser; //ConfigurationManager.AppSettings["EDMP_ISIS_FTRQ_USERID"].ToString();
            string sFrequency = BatchInfo.strFrequency; //ConfigurationManager.AppSettings["Frequency"].ToString();
            string sSequence = BatchInfo.strSequence; //ConfigurationManager.AppSettings["Sequence"].ToString();
            StringBuilder sb = new StringBuilder(BatchInfo.strOutputFileFormat);
            string strSpecialRunDate = BatchInfo.strSpecialRunDate;//ConfigurationManager.AppSettings["SpecialRunDate"].ToString();
            string strDateToday = BatchInfo.strSpecialRunDate == string.Empty || BatchInfo.strSpecialRunDate.ToUpper() == "NOW" ? DateTime.Now.AddDays(-1).ToString("yyyyMMdd") : strSpecialRunDate.Replace("-", ""); //20160904

            string sServiceName = "";
            string sTargetFilePath = "";
            string sSourceFilePath = "";
            string sFile = "";
            var strCountry = "";

            foreach (var edmFileInfo in ListEdmFileInfo)
            {
                //China
                sServiceName = edmFileInfo.ServiceKey_CN != null ? edmFileInfo.ServiceKey_CN.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_CN != null ? edmFileInfo.SourceFile_CN.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_CN != null ? edmFileInfo.TargetFile_CN.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_CN;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));

                //Hong Kong
                sServiceName = edmFileInfo.ServiceKey_HK != null ? edmFileInfo.ServiceKey_HK.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_HK != null ? edmFileInfo.SourceFile_HK.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_HK != null ? edmFileInfo.TargetFile_HK.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_HK;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));

                //Indonesia
                sServiceName = edmFileInfo.ServiceKey_ID != null ? edmFileInfo.ServiceKey_ID.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_ID != null ? edmFileInfo.SourceFile_ID.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_ID != null ? edmFileInfo.TargetFile_ID.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_ID;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));

                //Malaysia
                sServiceName = edmFileInfo.ServiceKey_MY != null ? edmFileInfo.ServiceKey_MY.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_MY != null ? edmFileInfo.SourceFile_MY.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_MY != null ? edmFileInfo.TargetFile_MY.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_MY;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));

                //Singapore
                sServiceName = edmFileInfo.ServiceKey_SG != null ? edmFileInfo.ServiceKey_SG.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_SG != null ? edmFileInfo.SourceFile_SG.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_SG != null ? edmFileInfo.TargetFile_SG.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_SG;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));

                //Thailand
                sServiceName = edmFileInfo.ServiceKey_TH != null ? edmFileInfo.ServiceKey_TH.ToString().Trim() : "";
                sSourceFilePath = edmFileInfo.SourceFile_TH != null ? edmFileInfo.SourceFile_TH.ToString().Trim() : "";
                sTargetFilePath = edmFileInfo.TargetFile_TH != null ? edmFileInfo.TargetFile_TH.ToString().Trim() : "";
                strCountry = MessageConstant.CountryCodeText_TH;
                sFile = sb.Replace("{tablename}", edmFileInfo.TableName.ToLower()).Replace("{countrycode}", strCountry.ToLower()).Replace("{date}", strDateToday).Replace("{frequency}", sFrequency).Replace("{sequence}", sSequence).ToString();
                CreateAndWriteTextFile(sServiceName, sSourceFilePath + sFile, sTargetFilePath + sFile, edmFileInfo.TableName.ToLower(), string.Format("{0}_", strCountry.ToLower()));
            }
        }

        private void GenerateEDMIPerServiceKey_DONOTUSE()
        {
            //CREATE EDMI TXT FILE
            string sEDM_EDMI_FILEPATH = ConfigurationManager.AppSettings["EDMP_ISIS_FILEPATH"].ToString();
            string sEDMIUser = BatchInfo.strMQHFTUser;//ConfigurationManager.AppSettings["EDMP_ISIS_FTRQ_USERID"].ToString();
            string sEDMIOutPath = ConfigurationManager.AppSettings["EDMI_TH_OFLOC"].ToString();
            string sServiceNAme = "";
            string sTargetFilename = "";
            string sSourceFile = "";
            var strTableName = "";
            //var PrevServiceKey = "";
            //string sEDMI_FILE = "edmi" + sEDMICode;

            string strSQL = "SELECT * FROM [SCBEXTDATA].[dbo].[vw_edm_file_info] order by [ServiceKey_TH]";

            CommonTextFileGenerator_DAO DC = new CommonTextFileGenerator_DAO();
            using (IDataReader reader = DC.FetchDBContent(MessageConstant.strDBExt, strSQL, string.Empty))

                if (reader != null && !reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        sServiceNAme = reader["ServiceKey_TH"].ToString().Trim();
                        strTableName = reader["TableName"].ToString().Trim();
                        sSourceFile = reader["SourceFile_TH"].ToString().Trim();
                        sTargetFilename = reader["TargetFile_TH"].ToString().Trim();

                        using (StreamWriter stream = new StreamWriter(sEDM_EDMI_FILEPATH + "th_" + strTableName.ToLower() + ".txt", false))
                        {
                            stream.WriteLine("-s " + sServiceNAme);
                            stream.WriteLine("-u " + sEDMIUser);
                            stream.WriteLine("-i " + sSourceFile + "transact_th_" + strTableName.ToLower() + "_20160904_d_1.txt");
                            stream.WriteLine("-o " + sTargetFilename + "transact_th_" + strTableName.ToLower() + "_20160904_d_1.txt");
                            stream.WriteLine("-end ");
                            stream.Close();
                            //PrevServiceKey = sServiceNAme;
                        }
                    }
                }
        }
    }
        #endregion
}
