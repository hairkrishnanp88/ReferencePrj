using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.Data.SqlClient;

public partial class CombiSet_AddCombisets : System.Web.UI.Page
{
  
    
    //DBFunctions objDbFunc = new DBFunctions();

    //Modified by Murali
    //Start
    Combisets objCombi = new Combisets();
    //End

    string CombiIds = "";
    string[] rangeData = new string[1000];
        ArrayList aryList = new ArrayList();
        string strOrderBy;
        string strOrderByVal;
        string strOrderByCombi;
        string strOrderBySub;

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        //Created By Murali
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());


        //List Displaying in Left Panels
        HtmlTable tblCombiList = new HtmlTable();
        tblCombiList.Border = 0;
        DataTable dtList = new DataTable();
        if (txtSearch.Text.Trim() == "")
        {
            dtList = objCombi.GetAllCombisets();
        }
        else
        {
            objCombi.CombisetName = txtSearch.Text;
            dtList = objCombi.GetSearchCombisets();
        }
        string range = UserCombi();

        rangeData = range.Split(',');
        for (int i = 0; i < dtList.Rows.Count; i++)
        {
            for (int j = 0; j < rangeData.Length; j++)
            {
                if (rangeData[j].ToString().Equals(dtList.Rows[i]["CombiId"].ToString()) || dtList.Rows[i]["Createdby"].ToString().Equals(Session["UserId"].ToString()) || Session["UserType"].ToString().ToLower().Equals("admin"))
                {
                    HtmlTableRow row = new HtmlTableRow();
                    HtmlTableCell cell = new HtmlTableCell();
                    LinkButton lb = new LinkButton();
                    lb.Text = dtList.Rows[i]["CombiName"].ToString();
                    lb.CommandArgument = dtList.Rows[i]["CombiId"].ToString();
                    lb.Style.Add("Text-Decoration", "none");
                    lb.Attributes.Add("Class", "ClsLinkButton");
                    lb.Click += new EventHandler(lb_Click);
                    cell.Controls.Add(lb);
                    row.Controls.Add(cell);
                    tblCombiList.Controls.Add(row);
                    break;

                }
            }
        }
        CombiListTD.Controls.Add(tblCombiList);
        //End

        



        //lblOrderby.Style.Add("visibility", "hidden");
        imgAdd.Attributes.Add("Onclick", "javascript: AddSelectedItem(lstAvailable,lstSelected);");
        this.imgDel.Attributes.Add("onclick", "RemoveSelectedItem(lstSelected)");
        this.imgDown.Attributes.Add("onclick", "MoveDownSelectedItem(lstSelected)");
        this.imgUp.Attributes.Add("onclick", "MoveUpSelectedItem(lstSelected)");
       // this.chkDisplayCmbo.Attributes.Add("onclick", "fnchkDisplayCmbo()");
        this.lstAvailable.Attributes.Add("onDblClick", "javascript: AddSelectedItem(lstAvailable,lstSelected);");
       // this.btnGo.Attributes.Add("Onclick", "JavaScript:if(!(SearchValidate())){return false;}");
        btnNext.Attributes.Add("onclick", "javascript: AddComboValuesToTextField('A');");
        this.btnGo.Attributes.Add("onclick", "javascript: ValidateAndPreserve(); if(!(SearchValidate())){return false;};");
        //this.btnGo.Attributes.Add("onclick", "javascript: ValidateAndPreserve();");
       // btnNext.Attributes.Add("onclick", "javascript:f11();");
        this.lstSelected.Attributes.Add("onclick", "javascript: fnMaintainStar2();");

        TblMainouter.Style.Add("Style", "height:200px");
        lblUser.Text = Session["Fullname"].ToString();

        if (!Page.IsPostBack)
        {

            //chkAddToCombo.Enabled = false;
            
        }

    }


    protected void btnGo_ServerClick(object sender, EventArgs e)
    {
        tblInner.Visible = true;
        tblInner.Style.Add("display", "inline");
        tdRunCmd.Style.Add("display", "none");

        lstAvailable.Items.Clear();
        aryList.Clear();
        LoadinglstAvailable();
    }

    protected void LoadinglstAvailable()
    {
        
        string strSearchValue = txtPageSearch.Value;
        string strQryUpOn= selQryUpOn.Value;    
        //Created By Murali
        strOrderBy = selOrderBy.Value;
        strOrderByVal = selOrderByVal.Value;
        if(selOrderBy.Value.ToString() == "n")
            strOrderBy = "Name";
        else
            strOrderBy = "CreatedOn";

        if (selOrderByVal.Value.ToString() == "a")
            strOrderByVal = "Asc";
        else
            strOrderByVal = "Desc";
        //End

        switch (strQryUpOn)
        {
                case "All":
                {
                     //strQry = "Select * from Subject where Name like '%" + strSearchValue + "%'";
                     //TrueAdding(strQry, "PF");


                    //strQry = "Select Name from Category where Name like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "CF");

                    //strQry = "Select Name from ContentBuilder where Name like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "P");

                    //strQry = "Select Name from CombiSet where CombiName like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "CS");



                    //Modified by Murali
                    SqlCommand cmdselect = new SqlCommand("sp_select_subject_ByName");
                    cmdselect.CommandType = CommandType.StoredProcedure;                    
                    cmdselect.Parameters.AddWithValue("@varSubname", strSearchValue);
                    TrueAdding(cmdselect, "PF");

                  
                    SqlCommand cmdselect1 = new SqlCommand("sp_select_category_ByName");
                    cmdselect1.CommandType = CommandType.StoredProcedure;
                    cmdselect1.Parameters.AddWithValue("@varCategoryname", strSearchValue);
                    TrueAdding(cmdselect1, "CF");
                  
                     SqlCommand cmdselect2 = new SqlCommand("sp_select_contentBuilder_ByName");
                     cmdselect2.CommandType = CommandType.StoredProcedure;
                     cmdselect2.Parameters.AddWithValue("@varContentname", strSearchValue);
                     TrueAdding(cmdselect2, "P");
                  
                     //SqlCommand cmdselect3 = new SqlCommand("sp_select_combiset_Byname");
                     //cmdselect3.CommandType = CommandType.StoredProcedure;
                     //cmdselect3.Parameters.AddWithValue("@varCombiname", strSearchValue);
                     //TrueAdding(cmdselect3, "CS");
                     //End


                }
                break;
            case "PF":
                {
                     //strQry = "Select * from Subject where Name like '%" + strSearchValue + "%'";
                     //TrueAdding(strQry,"PF");


                    //Modified by Murali
                    SqlCommand cmdselect = new SqlCommand("sp_select_subject_ByName");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    cmdselect.Parameters.AddWithValue("@varSubname", strSearchValue);
                    TrueAdding(cmdselect, "PF");
                    //End

                }
                break;
            case "CF":
                {

                    //strQry = "Select Name from Category where Name like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "CF");

                    //Modified by Murali
                    SqlCommand cmdselect = new SqlCommand("sp_select_category_ByName");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    cmdselect.Parameters.AddWithValue("@varCategoryname", strSearchValue);
                    TrueAdding(cmdselect, "CF");
                    //End
                }
                break;
            case "P":
                {
                    //strQry = "Select Name from ContentBuilder where Name like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "P");

                    //Modified by Murali
                    SqlCommand cmdselect = new SqlCommand("sp_select_contentBuilder_ByName");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    cmdselect.Parameters.AddWithValue("@varContentname", strSearchValue);
                    TrueAdding(cmdselect, "P");
                    //End

                }
                break;
            /* case "L":
                {

                }
                break;
            case "CS":
                {
                    //strQry = "Select Name from CombiSet where CombiName like '%" + strSearchValue + "%'";
                    //TrueAdding(strQry, "CS");

                    //Modified by Murali
                    SqlCommand cmdselect = new SqlCommand("sp_select_combiset_Byname");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    cmdselect.Parameters.AddWithValue("@varCombiname", strSearchValue);                                        
                    TrueAdding(cmdselect, "CS");
                    //End


                }
                break;*/
        }

      }

    //protected void TrueAdding(string strQry,string QryValue)

    protected void TrueAdding(SqlCommand strQry, string QryValue)
    {
        string strSearchValue = txtPageSearch.Value;

        if (QryValue == "PF")
        {
            DataTable dtlstSubj = new DataTable();
            DataTable dtlstChildFol = new DataTable();
            DataTable dtlstPage = new DataTable();
            DataTable dtlstPage2 = new DataTable();
            dtlstSubj = objCombi.ExecuteDTQuery(strQry);
                ///// To Add Parent Folder
            for (int i = 0; i < dtlstSubj.Rows.Count; i++)
            {
                ListItem lstItem = new ListItem("Parent Folder - " + dtlstSubj.Rows[i]["Name"].ToString(), dtlstSubj.Rows[i]["SubjectId"].ToString());
                lstAvailable.Items.Add(lstItem);
                lstAvailable.DataBind();
                aryList.Add(dtlstSubj.Rows[i]["SubjectId"].ToString());

                if (aryList.Contains("SU000001"))
                {
                    //Response.Write("hi i will win");
                }


                ////To ADD Child

                //string strChildQry = "Select * from Category where  SubJectId='" + dtlstSubj.Rows[i]["SubjectId"].ToString() + "'";
                //dtlstChildFol = objCombi.ExecuteDTQuery(strChildQry);

                //Modified by Murali
                SqlCommand cmdselect = new SqlCommand("sp_select_category_BysubID");
                cmdselect.CommandType = CommandType.StoredProcedure;
                cmdselect.Parameters.AddWithValue("@varSubjectID", dtlstSubj.Rows[i]["SubjectId"].ToString());
                dtlstChildFol = objCombi.ExecuteDTQuery(cmdselect);
                if (!strOrderBy.Equals(""))
                {
                    dtlstChildFol.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                    dtlstChildFol= dtlstChildFol.DefaultView.ToTable();
                }                
                //End



                if (dtlstChildFol.Rows.Count > 0)
                {
                    for (int j = 0; j < dtlstChildFol.Rows.Count; j++)
                    {
                        ListItem lstItemChild = new ListItem("-- Child Folder - " + dtlstChildFol.Rows[j]["Name"].ToString(), dtlstChildFol.Rows[j]["CatId"].ToString());
                        lstItemChild.Attributes.Add("style", "color:Blue");
                        lstAvailable.Items.Add(lstItemChild);
                        lstAvailable.DataBind();
                        
                        ////To Add Page from contentbuilder

                        //string strPageQry = "Select * from Contentbuilder where ParentId='" + dtlstSubj.Rows[i]["SubjectId"].ToString() + "' or ParentId='" + dtlstChildFol.Rows[j]["CatId"] + "'";
                        //dtlstPage = objCombi.ExecuteDTQuery(strPageQry);

                        //Modified by Murali
                        SqlCommand cmdselect1 = new SqlCommand("sp_select_contentBuilder_ByparentIDs");
                        cmdselect1.CommandType = CommandType.StoredProcedure;
                        cmdselect1.Parameters.AddWithValue("@varParentID1",dtlstSubj.Rows[i]["SubjectId"].ToString());
                        cmdselect1.Parameters.AddWithValue("@varParentID2", dtlstChildFol.Rows[j]["CatId"].ToString());
                        dtlstPage = objCombi.ExecuteDTQuery(cmdselect1);
                        if (!strOrderBy.Equals(""))
                        {
                            dtlstPage.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                            dtlstPage = dtlstPage.DefaultView.ToTable();
                        }                        
                        //End



                        for (int jj = 0; jj < dtlstPage.Rows.Count; jj++)
                        {
                            ListItem lstItemContent = new ListItem("-- -- Page - " + dtlstPage.Rows[jj]["Name"].ToString(), dtlstPage.Rows[jj]["DataId"].ToString());
                            lstItemContent.Attributes.Add("style", "color:Red");
                            lstAvailable.Items.Add(lstItemContent);
                            lstAvailable.DataBind();
                        }
                    }
                }
                else
                {

                }

                ////To Add Page from contentbuilder //If not execute child folder block then direct page excec
                //Exist Code
                //string strPageQry2 = "Select * from Contentbuilder where ParentId='" + dtlstSubj.Rows[i]["SubjectId"].ToString() + "'";
                //dtlstPage = objCombi.ExecuteDTQuery(strPageQry2);

                //Modified by Murali
                SqlCommand cmdselect2 = new SqlCommand("sp_select_contentBuilder_ByparentID");
                cmdselect2.CommandType = CommandType.StoredProcedure;
                cmdselect2.Parameters.AddWithValue("@varParentID", dtlstSubj.Rows[i]["SubjectId"].ToString());
                dtlstPage2 = objCombi.ExecuteDTQuery(cmdselect2);
                if (!strOrderBy.Equals(""))
                {
                    dtlstPage2.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                    dtlstPage2 = dtlstPage2.DefaultView.ToTable();
                }
                //End

                for (int ij = 0; ij < dtlstPage2.Rows.Count; ij++)
                {
                    ListItem lstItemContent = new ListItem("-- -- Page - " + dtlstPage2.Rows[ij]["Name"].ToString(), dtlstPage2.Rows[ij]["DataId"].ToString());
                    lstItemContent.Attributes.Add("style", "color:Red");
                    lstAvailable.Items.Add(lstItemContent);
                    lstAvailable.DataBind();
                }
            }
        }

        else if (QryValue == "CF")
        {
            DataTable dtCat = new DataTable();           //category
            DataTable dtSubject = new DataTable();       //Subject   
            DataTable dtCP = new DataTable();            //Content Page 

            //string strQryCF = "select * from category where Name like '%" + strSearchValue + "%'";
            //dtCat = objCombi.ExecuteDTQuery(strQryCF);

            //Modified by Murali
            SqlCommand cmdselect = new SqlCommand("sp_select_category_ByName");
            cmdselect.CommandType = CommandType.StoredProcedure;
            cmdselect.Parameters.AddWithValue("@varCategoryname", strSearchValue);
            dtCat = objCombi.ExecuteDTQuery(cmdselect);
            if (!strOrderBy.Equals(""))
            {
                dtCat.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                dtCat= dtCat.DefaultView.ToTable();
            }            
            //End

            //for loop needed :If More Than One Child FOlders in Category table.?
            for (int k = 0; k < dtCat.Rows.Count; k++)
            {
                ////To Add Parent Folder
                //Exist Code
                //string strQryGetSubjectId = "select Name,SubjectId from subject where subjectId='" + dtCat.Rows[k]["SubjectId"] + "'";
                //dtSubject = objCombi.ExecuteDTQuery(strQryGetSubjectId);

                //Modified by Murali
                SqlCommand cmdselect1 = new SqlCommand("sp_select_subject_ByID");
                cmdselect1.CommandType = CommandType.StoredProcedure;
                cmdselect1.Parameters.AddWithValue("@varSubjectID", dtCat.Rows[k]["SubjectId"]);
                dtSubject = objCombi.ExecuteDTQuery(cmdselect1);              
                //End
                for (int dtSubjectCnt = 0; dtSubjectCnt < dtSubject.Rows.Count; dtSubjectCnt++)
                {

                    if (!(aryList.Contains(dtSubject.Rows[dtSubjectCnt]["SubjectId"]))) //chk
                    {

                        ListItem lstItem = new ListItem("Parent Folder - " + dtSubject.Rows[0]["Name"].ToString(), dtSubject.Rows[0]["SubjectId"].ToString());
                        lstAvailable.Items.Add(lstItem);
                        lstAvailable.DataBind();
                        aryList.Add(dtSubject.Rows[dtSubjectCnt]["SubjectId"].ToString());

                        //To Add Child Folder
                        ListItem lstItemChld = new ListItem("-- Child Folder - " + dtCat.Rows[k]["Name"].ToString(), dtCat.Rows[k]["CatId"].ToString());
                        lstAvailable.Items.Add(lstItemChld);
                        lstItemChld.Attributes.Add("style", "color:Blue");
                        lstAvailable.DataBind();

                        //To ADD Content Page


                        //string strPageQry = "Select * from Contentbuilder where  ParentId='" + dtSubject.Rows[0]["SubjectId"].ToString() + "' or ParentId='" + dtCat.Rows[k]["CatId"].ToString() + "'";
                        //dtCP = objCombi.ExecuteDTQuery(strPageQry);

                        //Modified by Murali
                        SqlCommand cmdselect2 = new SqlCommand("sp_select_contentBuilder_ByparentIDs");
                        cmdselect2.CommandType = CommandType.StoredProcedure;
                        cmdselect2.Parameters.AddWithValue("@varParentID1", dtSubject.Rows[0]["SubjectId"].ToString());
                        cmdselect2.Parameters.AddWithValue("@varParentID2", dtCat.Rows[k]["CatId"].ToString());
                        dtCP = objCombi.ExecuteDTQuery(cmdselect2);
                        if (!strOrderBy.Equals(""))
                        {
                            dtCP.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                            dtCP = dtCP.DefaultView.ToTable();
                        }
                        //End

                        for (int j = 0; j < dtCP.Rows.Count; j++)
                        {
                            ListItem lstItemChild = new ListItem("-- -- Page - " + dtCP.Rows[j]["Name"].ToString(), dtCP.Rows[j]["DataId"].ToString());
                            lstItemChild.Attributes.Add("style", "color:Red");
                            lstAvailable.Items.Add(lstItemChild);
                            lstAvailable.DataBind();
                        }
                    }
                }
            }


        }
        else if (QryValue == "P")
        {

            DataTable dtPage = new DataTable();

            //string strQryPage = "Select ParentId,Name,DataId from Contentbuilder where Name like '%" + strSearchValue + "%'";
            //dtPage = objCombi.ExecuteDTQuery(strQryPage);

            //Modified by Murali
            SqlCommand cmdselect = new SqlCommand("sp_select_contentBuilder_ByName");
            cmdselect.CommandType = CommandType.StoredProcedure;
            cmdselect.Parameters.AddWithValue("@varContentname", strSearchValue);
            dtPage = objCombi.ExecuteDTQuery(cmdselect);
            if (!strOrderBy.Equals(""))
            {
                dtPage.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                dtPage = dtPage.DefaultView.ToTable();
            }

            //End

            for (int k = 0; k < dtPage.Rows.Count; k++)
            {
                DataTable dtPageC = new DataTable();
                DataTable dtPageSId = new DataTable();

                if (dtPage.Rows[k][0].ToString().StartsWith("CA"))
                {

                    //string strQryChild = "select SubjectId,Name,CatId from category where CatId='" + dtPage.Rows[k]["ParentId"] + "'";
                    //dtPageC = objCombi.ExecuteDTQuery(strQryChild);

                    //Modified by Murali
                    SqlCommand cmdselect1 = new SqlCommand("sp_select_category_BycatID");
                    cmdselect1.CommandType = CommandType.StoredProcedure;
                    cmdselect1.Parameters.AddWithValue("@varCategoryID", dtPage.Rows[k]["ParentId"].ToString());
                    dtPageC = objCombi.ExecuteDTQuery(cmdselect1);
                    if (!dtPageC.Equals(""))
                    {
                        dtPageC.DefaultView.Sort = strOrderBy + " " + strOrderByVal;
                        dtPageC = dtPageC.DefaultView.ToTable();
                    }
                    //End

                    //To Add Parent
                    for (int xy = 0; xy < dtPageC.Rows.Count; xy++)  //Always Only one come
                    {
                        //Exist Code
                        //string strQryGetSubjectName = "select * from subject where SubjectId='" + dtPageC.Rows[xy]["SubjectId"] + "'";
                        //dtPageSId = objCombi.ExecuteDTQuery(strQryGetSubjectName);


                        //Modified by Murali
                        SqlCommand cmdselect2 = new SqlCommand("sp_select_subject_ByID");
                        cmdselect2.CommandType = CommandType.StoredProcedure;
                        cmdselect2.Parameters.AddWithValue("@varSubjectID", dtPageC.Rows[xy]["SubjectId"].ToString());
                        dtPageSId = objCombi.ExecuteDTQuery(cmdselect2);
                        if (selOrderBy.Value.ToString() == "n")
                            strOrderBySub = "Name";
                        else
                            strOrderBySub = "DateCreated";

                        if (!strOrderBy.Equals(""))
                        {
                            dtPageSId.DefaultView.Sort = strOrderBySub + " " + strOrderByVal;
                            dtPageSId = dtPageSId.DefaultView.ToTable();
                        }
                        //End


                        if (!(aryList.Contains(dtPageSId.Rows[xy]["SubjectId"]))) //chk
                        {
                            ListItem lstItemP = new ListItem("Parent Folder - " + dtPageSId.Rows[xy]["Name"].ToString(), dtPageSId.Rows[xy]["SubjectId"].ToString());
                            lstAvailable.Items.Add(lstItemP);
                            lstAvailable.DataBind();
                        }
                    }

                    //To Add Child

                    if (!(aryList.Contains(dtPageSId.Rows[0]["SubjectId"]))) //chk
                    {
                        for (int j = 0; j < dtPageC.Rows.Count; j++)
                        {
                            ListItem lstItemChild = new ListItem("-- Child Folder - " + dtPageC.Rows[j]["Name"].ToString(), dtPageC.Rows[j]["CatId"].ToString());
                            lstItemChild.Attributes.Add("style", "color:Blue");
                            lstAvailable.Items.Add(lstItemChild);
                            lstAvailable.DataBind();
                        }

                        //To Add Content Page


                        ListItem lstItemCP = new ListItem("-- -- Page - " + dtPage.Rows[k]["Name"].ToString(), dtPage.Rows[k]["DataId"].ToString());
                        lstItemCP.Attributes.Add("style", "color:Red");
                        lstAvailable.Items.Add(lstItemCP);
                        lstAvailable.DataBind();


                        aryList.Add(dtPageSId.Rows[0]["SubjectId"].ToString());
                    }
                }

                    if (dtPage.Rows[k][1].ToString().StartsWith("SU"))
                    {
                        //string strQryChild = "select * from Subject where SubjectId='" + dtPage.Rows[k]["ParentId"] + "'";
                        // dtPageC = objCombi.ExecuteDTQuery(strQryPage);
                        //DataTable dtPageSId = new DataTable();

                        //To Add Parent

                        //Exist Coding
                        //string strQryGetSubjectName = "select * from subject where SubjectId='" + dtPage.Rows[k]["ParentId"] + "'";
                        //dtPageSId = objCombi.ExecuteDTQuery(strQryGetSubjectName);


                        //Modified by Murali
                        SqlCommand cmdselect3 = new SqlCommand("sp_select_subject_ByID");
                        cmdselect3.CommandType = CommandType.StoredProcedure;
                        cmdselect3.Parameters.AddWithValue("@varSubjectID", dtPage.Rows[k]["ParentId"].ToString());
                        dtPageSId = objCombi.ExecuteDTQuery(cmdselect3);
                        //End



                        int count = dtPageSId.Rows.Count;

                        if (!(aryList.Contains(dtPageSId.Rows[0]["SubjectId"]))) //chk
                        {

                            ListItem lstItemP = new ListItem("Parent Folder - " + dtPageSId.Rows[0]["Name"].ToString(), dtPageSId.Rows[0]["SubjectId"].ToString());
                            if (!lstAvailable.Items.Contains(lstItemP))
                            {
                                lstAvailable.Items.Add(lstItemP);
                                lstAvailable.DataBind();

                            }
                            

                            //To Add Content Page
                            ListItem lstItemPage = new ListItem("-- -- Page - " + dtPage.Rows[k]["Name"].ToString(), dtPage.Rows[k]["DataId"].ToString());
                            lstItemPage.Attributes.Add("style", "color:Red");
                            lstAvailable.Items.Add(lstItemPage);
                            lstAvailable.DataBind();
                        }
                    }
                }
            

                //ListItem lstItemChild = new ListItem("-- -- Page - " + dtlstPage.Rows[j]["Name"].ToString(), dtlstPage.Rows[j]["CatId"].ToString());
                //lstItemChild.Attributes.Add("style", "color:Red");
                //lstAvailable.Items.Add(lstItemChild);
                //lstAvailable.DataBind();
            }

            else if (QryValue == "CS")
            {
                DataTable dtCS = new DataTable();
                //Existing Code
                //string strQryCS = "select * from combiset where Combiname like '%" + strSearchValue + "%'";///
                //dtCS = objCombi.ExecuteDTQuery(strQryCS);


                //Modified by Murali
                SqlCommand cmdselect = new SqlCommand("sp_select_combiset_Byname");
                cmdselect.CommandType = CommandType.StoredProcedure;
                cmdselect.Parameters.AddWithValue("@varCombiname", strSearchValue);                                
                dtCS=objCombi.ExecuteDTQuery(cmdselect);
                if (selOrderBy.Value.ToString() == "n")
                    strOrderByCombi = "Combiname";
                else
                    strOrderByCombi = "CreatedOn";
                if (!strOrderBy.Equals(""))
                {
                    dtCS.DefaultView.Sort = strOrderByCombi + " " + strOrderByVal;
                    dtCS = dtCS.DefaultView.ToTable();
                }
                //End

                for (int i = 0; i < dtCS.Rows.Count; i++)
                {
                    ListItem lstItemCS = new ListItem("-- -- CombiSet - " + dtCS.Rows[i]["CombiName"].ToString(), dtCS.Rows[i]["CombiId"].ToString());
                    lstItemCS.Attributes.Add("style", "color:Red");
                    lstAvailable.Items.Add(lstItemCS);
                    lstAvailable.DataBind();
                }

            }
            //---------------------------------------------------------------------------------------------------

            //To Keep Preserve Operations


            string strPreserveText;
            string strPreserveValue;

            if (HideChkstatus.Value == "Set")
            {
                lstSelected.Items.Clear();

                if (HidePreserve.Value != "")
                {
                    strPreserveText = HidePreserve.Value;
                    strPreserveValue = HideValue.Value;
                    if (strPreserveValue != "")
                    {
                        string[] PreserveData = new string[50];
                        string[] PreserveValue = new string[50];

                        PreserveValue = strPreserveValue.Split('#');

                        PreserveData = strPreserveText.Split('#');

                        for (int kkk = 0; kkk < PreserveData.Length - 1; kkk++)
                        {
                            //selSelected.Items.Add(PreserveData[kkk]);
                            ListItem LDATAs = new ListItem("" + PreserveData[kkk], PreserveValue[kkk]);
                            //LDATAs.Attributes.Add("style","color: Red");
                            lstSelected.Items.Add(LDATAs);
                        }
                    }
                }

            }
            else if (HideChkstatus.Value == "ReSet")
            {
                lstSelected.Items.Clear();
            }
        }

   protected void rdYes_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void chkDisplayCmbo_CheckedChanged1(object sender, EventArgs e)
    {
        if (chkDisplayASCombo.Checked == true)
        {
            //lblOrderby.Style.Add("display", "inline");
            //lblOrderby.Style.Add("visibility", "");
            lblOrderby.Style.Add("visibility", "visbible");
            selOrderBy_Disp_cmbo.Style.Add("display", "inline");
        }
        else
        {
            lblOrderby.Style.Add("visibility", "hidden");
            //lblOrderby.Style.Add("display", "none");
           selOrderBy_Disp_cmbo.Style.Add("display", "none");
          
        }
     }
    protected void btnNext_ServerClick(object sender, EventArgs e)
    {
        if (chkDisplayASCombo.Checked)
        {
            Session["AddCombi_DispAscmbo"] = "Y";
        }
    }
    protected void chkDisplayASCombo_ServerChange(object sender, EventArgs e)
    {
        //Response.Write("ji");
        //lblOrderby.Style.Add("visibility", "hidden");
        //selOrderBy_Disp_cmbo.Style.Add("Visibility", "hidden");
       
    }
    protected void chkDisplayASCombo_ServerChange1(object sender, EventArgs e)
    {
        //Response.Write("ji");
        //lblOrderby.Style.Add("visibility", "hidden");
        //selOrderBy_Disp_cmbo.Style.Add("Visibility", "hidden");
    }
    protected void lstSelected_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(!(lstSelected.Text.StartsWith("*")))
        {
            ChkAddtoCmb.Checked = false;
        }
    }
  
    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);        
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }
      
    void lb_Click(object sender, EventArgs e)
    {
        string CombisetId = ((LinkButton)(sender)).CommandArgument.ToString();
        Response.Redirect("./view.aspx?CId=" + CombisetId + "&Mode=Preview&From=Index");
    }

    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        txtSearch.Text = "";
        Response.Redirect("./IndexCombi.aspx?SearchValue=");
    }

    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("./IndexCombi.aspx?SearchValue=" + txtSearch.Text);
    }
    protected string UserCombi() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = objCombi.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_CombiRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        CombiIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = objCombi.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        CombiIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (CombiIds.Length > 0) CombiIds = CombiIds.ToString().Remove(CombiIds.Length - 1, 1);
        return CombiIds;
    }

}
