using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 
using NGWS.CMPApplication;

public partial class CombiSet_IndexCombi : System.Web.UI.Page
{

    NGWS.CMPApplication.Combisets objCombi = new NGWS.CMPApplication.Combisets();

    string searchName="";
    Boolean add = false, mod = false, del = false;
    string CombiIds = "";
    string[] rangeData = new string[1000];

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        //Created By Murali
        //SiteInfo.ValidateSession();

        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End
        Page.Title = Session["SiteName"].ToString();
        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());
        //End

        //List Displaying in Left Panels
            lnkbtnAdd.Style.Add("text-decoration", "none"); 
            HtmlTable tblList = new HtmlTable();            
            tblList.Width = "100%";  
            tblList.Border = 0;
            DataTable dtCS = new DataTable();        
            dtCS=objCombi.GetAllCombisets();            
            int count = dtCS.Rows.Count;
            string range = UserCombi();

            rangeData = range.Split(',');
            for(int i = 0; i < count; i++)
	        {
                for (int j = 0; j < rangeData.Length; j++)
                {
                    if (rangeData[j].ToString().Equals(dtCS.Rows[i]["CombiId"].ToString()) || dtCS.Rows[i]["Createdby"].ToString().Equals(Session["UserId"].ToString()) || Session["UserType"].ToString().ToLower().Equals("admin"))
                    {
                        HtmlTableRow newRow = new HtmlTableRow();
                        HtmlTableCell newcell = new HtmlTableCell();
                        LinkButton newlb = new LinkButton();
                        newlb.Text = dtCS.Rows[i]["CombiName"].ToString();
                        newlb.CommandArgument = dtCS.Rows[i]["CombiId"].ToString();
                        //newlb.ID = dtCS.Rows[i]["CombiId"].ToString();
                        newlb.Style.Add("Text-Decoration", "none");
                        newlb.Attributes.Add("Class", "ClsLinkButton");
                        newlb.Click += new EventHandler(Button_Click);
                        newcell.Controls.Add(newlb);
                        newRow.Controls.Add(newcell);
                        tblList.Controls.Add(newRow);
                        break;
                    }
                }
	        }           
            CombiListTD.Controls.Add(tblList);

            
            HtmlTable tblCombiList = new HtmlTable();            
            tblCombiList.Border = 0;
            DataTable dtList = new DataTable();
            if (Request.QueryString["SearchValue"].ToString().Trim() != "")
            {
                searchName = Request.QueryString["SearchValue"];
            }
            if (txtSearch.Text.Trim() != "")
            {
                searchName = txtSearch.Text;
            }

            if (searchName == "")
            {
                dtList = objCombi.GetAllCombisets();
            }
            else
            {
                objCombi.CombisetName = searchName;
                dtList = objCombi.GetSearchCombisets();                    
            }

            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                for (int j = 0; j < rangeData.Length; j++)
                {
                    if (rangeData[j].ToString().Equals(dtList.Rows[i]["CombiId"].ToString()) || dtList.Rows[i]["Createdby"].ToString().Equals(Session["UserId"].ToString()) || Session["UserType"].ToString().ToLower().Equals("admin"))
                    {
                        HtmlTableRow row = new HtmlTableRow();
                        HtmlTableCell cell = new HtmlTableCell();
                        LinkButton lb = new LinkButton();
                        lb.Text = dtList.Rows[i]["CombiName"].ToString();
                        lb.CommandArgument = dtList.Rows[i]["CombiId"].ToString();
                        lb.Style.Add("Text-Decoration", "none");
                        lb.Attributes.Add("Class", "ClsLinkButton");
                        lb.Click += new EventHandler(lb_Click);
                        cell.Controls.Add(lb);
                        row.Controls.Add(cell);
                        tblCombiList.Controls.Add(row);
                        break;
                    }
                }
            }
            tdRunAsServer.Controls.Add(tblCombiList);
            if (!(Session["UserType"].ToString().ToLower().Equals("admin")))
            {
                CheckRights();
                if (add)
                {
                    lnkbtnAdd.Style.Add("display", "inline");
                }
                else
                {
                    lnkbtnAdd.Style.Add("display", "none");
                }
            }
    }

    void lb_Click(object sender, EventArgs e)
    {
        string CombisetId = ((LinkButton)(sender)).CommandArgument.ToString();
        Response.Redirect("./view.aspx?CId=" + CombisetId + "&Mode=Preview&From=Index");
    }

    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        txtSearch.Text = "";
        Response.Redirect("./IndexCombi.aspx?SearchValue=");
    }
   
    public void Button_Click(object sender, EventArgs e)
    {
        string CombisetId = ((LinkButton)(sender)).CommandArgument.ToString();
        Response.Redirect("./view.aspx?CId="+CombisetId+"&Mode=Preview&From=Index");
        
    }
    protected void lnkbtnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("./AddCombisets.aspx?From=Index");    
    }

    public void ShowBanner(string value)
    {
         tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }

    protected void CheckRights()
    {

        UserManager objUser = new UserManager();
        objUser.Userid = int.Parse(Session["UserId"].ToString());
        DataTable dtRights = new DataTable();
        dtRights  = objUser.CombiRights("", "");
        foreach (DataRow row in dtRights.Rows)
        {
            if (!row[1].ToString().Equals(""))
            {
                if (row[1].ToString().Substring(0, 1).Equals("1"))
                {
                    add = true;
                }
            }            
        }
    }
    protected string UserCombi() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = objCombi.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_CombiRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        CombiIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = objCombi.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        CombiIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (CombiIds.Length > 0) CombiIds = CombiIds.ToString().Remove(CombiIds.Length - 1, 1);
        return CombiIds;
    }

    
}

