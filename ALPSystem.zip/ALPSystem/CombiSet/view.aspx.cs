using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;

public partial class CombiSet_view : System.Web.UI.Page
{
    CombisetsExtended objCombi = new CombisetsExtended();
    Boolean add=false, mod = false, del = false;
    string NonCboDataIds = "";
    string strCboDataIds = "";
    string CombiIds = "";
    string[] rangeData = new string[1000];
    protected void Page_Load(object sender, EventArgs e)
    {
        
	//Added to avoid SQL Injection

		if ( !string.IsNullOrEmpty(Request.QueryString["Mode"]) && Request.QueryString["Mode"].ToString().Length > 11)
                {
                     Response.Redirect("../Index.aspx");
                }
                if ( !string.IsNullOrEmpty(Request.QueryString["CId"]) && Request.QueryString["CId"].ToString().Length > 10)
                {
                     Response.Redirect("../Index.aspx");
                }
                if ( !string.IsNullOrEmpty(Request.QueryString["From"]) && Request.QueryString["From"].ToString().Length > 10)
                {
                     Response.Redirect("../Index.aspx");
                }
                if ( !string.IsNullOrEmpty(Request.QueryString["DId"]) && Request.QueryString["DId"].ToString().Length > 10)
                {
                     Response.Redirect("../Index.aspx");
                }

		//End
        SiteInfo.SetSiteName(this);
        if (Request.QueryString["PageType"] == null)
        {

            btnSave.Attributes.Add("onclick", "javascript:{return (checkCombiName());}");
            lnkBtnDelete.Style.Add("display", "inline");
            lnkBtnModify.Style.Add("display", "inline");
            SiteInfo.ValidateSession();
            //Page.Title = Session["SiteName"].ToString();
            // Start Menu Displaying    
            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());
                divMenu.Controls.Add(SiteInfo.userValidation());

                // Top Banner Displaying            
                ShowBanner(Session["Banner"].ToString());

                //LeftPanel Displaying
                ShowPanel(Session["Panel"].ToString());
                //End
            }
            //End
            else
            {
                ShowBanner("none");
                ShowPanel("none");
                trHeader.Style.Add("display", "none");
                trHR.Style.Add("display", "none");
                trmain.Style.Add("display", "none");
                string CombisetID = Request.QueryString["CId"].ToString();
                string DataId="";

                //Modified on 09 Aug 07
                //if (Request.QueryString["DId"] != null)
                //    DataId = Request.QueryString["DId"].ToString();
                //else
                //    DataId = "";

                objCombi.CombisetId = CombisetID;
                objCombi.IsComboMarkerExists = false;
                DlstDisplayHeader.Visible = false;
                DataTable TempdtGettingAddToCombo = new DataTable();


                TempdtGettingAddToCombo = objCombi.GetAddToComboVAlues();
                string strSelectedItems = "";
                strSelectedItems = objCombi.GetSelectedItemsForCmbOnly();
                string[] strArySelectedItems = strSelectedItems.Split(',');
                string[] strAryAddToCmbVals = TempdtGettingAddToCombo.Rows[0]["AddToCombo"].ToString().Split(',');

                //Modified on 09 Aug 07
                if (Request.QueryString["DId"] != null)
                    DataId = Request.QueryString["DId"].ToString();
                else
                {
                    if (strArySelectedItems.Length > 0)
                        DataId = strArySelectedItems[0].ToString();

                }

                //  }
                for (int j = 0; j < strAryAddToCmbVals.Length - 1; j++)
                {
                    if (strAryAddToCmbVals[j].ToString() == "0")
                    {
                        objCombi.SelectedItems += strArySelectedItems[j].ToString() + ",";
                    }
                    else if (strAryAddToCmbVals[j].ToString() == "1")
                    {

                        if (!IsPostBack)
                        {
                            DataTable dtContentName = new DataTable();

                            objCombi.DataId = strArySelectedItems[j].ToString();
                            ListItem litm;
                            if (strArySelectedItems[j].ToString().StartsWith("CS"))
                            {
                                dtContentName = objCombi.GetCSNameforCombo();
                                litm = new ListItem(dtContentName.Rows[0]["CombiName"].ToString(), dtContentName.Rows[0]["CombiId"].ToString());
                            }
                            else
                            {
                                dtContentName = objCombi.GetContentName();
                                litm = new ListItem(dtContentName.Rows[0]["Name"].ToString(), dtContentName.Rows[0]["DataId"].ToString());
                            }
                            DlstDisplayHeader.Items.Add(litm);
                        }
                        DlstDisplayHeader.Visible = true;
                    }

                }

                if (DlstDisplayHeader.Items.Count > 0)
                    objCombi.SelectedItems += DlstDisplayHeader.Items[0].Value + ",";

                //strSelectedItems = objCombi.SelectedItems.ToString();
                strSelectedItems = objCombi.GetSelectedItemsForCmbOnly();
                strArySelectedItems = strSelectedItems.Split(',');
                for (int j = 0; j < strArySelectedItems.Length - 2; j++)
                {
                    if (objCombi.GetMarker(strArySelectedItems[j].ToString(), objCombi.CombisetId).ToString().IndexOf("##combo##", 0) > -1) 
                        objCombi.IsComboMarkerExists = true;
                }

              
                    

                if (DataId != "")
                    objCombi.SelectedItems = DataId + ",";

                if (objCombi.IsComboMarkerExists) 
                    tdViewCombo.Attributes.Add("style", "display:none");
                string Result1 = objCombi.GetCombiContent();
               
                TdSerPageContainer.InnerHtml = Result1;
                tdSaveBlock.Style.Add("display", "none");
                return;
            }

            

            //ClientScript.RegisterClientScriptBlock(Type.GetType("string"),"sa","alert('H')");
            //lnkBtnDelete.Attributes.Add("onclick", "javascript:fnDdelete()");

            lblUser.Text = Session["FullName"].ToString();
            //List Displaying in Left Panels
            HtmlTable tblCombiList = new HtmlTable();
            tblCombiList.Border = 0;
            DataTable dtList = new DataTable();
            if (txtSearch.Text.Trim() == "")
            {
                dtList = objCombi.GetAllCombisets();
            }
            else
            {
                objCombi.CombisetName = txtSearch.Text;
                dtList = objCombi.GetSearchCombisets();
            }
            string range = UserCombi();

            rangeData = range.Split(',');
            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                for (int j = 0; j < rangeData.Length; j++)
                {
                    if (rangeData[j].ToString().Equals(dtList.Rows[i]["CombiId"].ToString()) || dtList.Rows[i]["Createdby"].ToString().Equals(Session["UserId"].ToString()) || Session["UserType"].ToString().ToLower().Equals("admin"))
                    {
                        HtmlTableRow row = new HtmlTableRow();
                        HtmlTableCell cell = new HtmlTableCell();
                        LinkButton lb = new LinkButton();
                        lb.Text = dtList.Rows[i]["CombiName"].ToString();
                        lb.CommandArgument = dtList.Rows[i]["CombiId"].ToString();
                        lb.Style.Add("Text-Decoration", "none");
                        lb.Attributes.Add("Class", "ClsLinkButton");
                        lb.Click += new EventHandler(lb_Click);
                        cell.Controls.Add(lb);
                        row.Controls.Add(cell);
                        tblCombiList.Controls.Add(row);
                        break;
                    }
                }
            }
            CombiListTD.Controls.Add(tblCombiList);
            if (Request.QueryString["From"] == "ModCombi")
            {
                lnkBtnDelete.Style.Add("display", "none");
                lnkBtnModify.Style.Add("display", "none");
            }
            if (!Page.IsPostBack)
            {
                DlstDisplayHeader.Visible = false;
                DlstDisplayHeader.Items.Clear();
                lnkBtnDelete.Attributes.Add("onclick", "javascript: return !fnDdelete()");

                //// if coming from Delete fn--self redirecting
                //if (Request.QueryString["Mode"].ToString() == "Delete")
                //{

                //}
                //If coming from AddCombiSets


                if (Request.QueryString["From"].ToString() == "AddCombi")
                {
                    if (Request.QueryString["Mode"].ToString() == "PreviewSave")
                    {
                        string DataIds = Request.QueryString["DataIds"].ToString();

                        //  trHeader.Style.Add("display", "none");
                        //---------------For Handling cbo '*'
                        string[] aryIds = DataIds.Split(',');
                        for (int i = 0; i < aryIds.Length - 1; i++)
                        {     //Addnig to ComboHeader
                            if (aryIds[i].ToString().StartsWith("cbo"))
                            {
                                DataTable dtCName = new DataTable();
                                objCombi.DataId = aryIds[i].ToString().Substring(3, aryIds[i].ToString().Length - 3);
                                dtCName = objCombi.GetContentName();
                                for (int j = 0; j < dtCName.Rows.Count; j++)
                                {
                                    ListItem litm = new ListItem(dtCName.Rows[j]["Name"].ToString(), dtCName.Rows[j]["DataId"].ToString());
                                    DlstDisplayHeader.Visible = true;
                                    DlstDisplayHeader.Items.Add(litm);
                                }
                                DlstDisplayHeader.DataBind();
                                strCboDataIds += aryIds[i].ToString().Substring(3, aryIds[i].ToString().Length - 3) + ",";

                            }
                            else
                            {
                                NonCboDataIds += aryIds[i].ToString() + ",";
                            }
                        }

                        //------------------------------------Execution- for Add--------------------------------------------------------------------
                        //(1) CombiSet:
                        if (DataIds.StartsWith("CS"))
                        {
                            objCombi.CombisetId = DataIds;
                            objCombi.SelectedItems = "";
                            string Result1 = objCombi.GetCombiContent();
                            TdSerPageContainer.InnerHtml = Result1;
                        }
                        else
                        {
                            objCombi.CombisetId = "";
                            if (NonCboDataIds.Length > 0)
                            {
                                objCombi.SelectedItems = NonCboDataIds;

                                string Result1 = objCombi.GetCombiContent();
                                TdSerPageContainer.InnerHtml = Result1;
                            }
                            if (DlstDisplayHeader.Items.Count > 0)   //display first page defaultly *
                            {
                                objCombi.SelectedItems = DlstDisplayHeader.Items[0].Value + ",";
                                string Result1 = objCombi.GetCombiContent();
                                TdSerPageContainer.InnerHtml += Result1;
                            }
                            if (DlstDisplayHeader.Items.Count == 0)
                            {
                                tdViewCombo.Style.Add("visibility", "hidden");
                            }
                        }
                    }
                }
                //If Coming From Modify CombiSets

                if (Request.QueryString["From"] == "ModCombi")
                {
                    if (Request.QueryString["Mode"].ToString() == "PreviewSave")
                    {

                        SqlCommand cmdselect = new SqlCommand("sp_select_combiset_BycombiID");
                        cmdselect.CommandType = CommandType.StoredProcedure;
                        cmdselect.Parameters.AddWithValue("@varCombiID", Session["CID_View_Modify_View"].ToString());
                        DataTable dtName = objCombi.ExecuteDTQuery(cmdselect);
                        if (dtName.Rows.Count > 0)
                            txtCombiName.Text = dtName.Rows[0]["Combiname"].ToString();

                        string DataIds = Request.QueryString["DataIds"].ToString();

                        //  trHeader.Style.Add("display", "none");
                        //---------------For Handling cbo '*'
                        string[] aryIds = DataIds.Split(',');
                        for (int i = 0; i < aryIds.Length - 1; i++)
                        {     //Addnig to ComboHeader
                            if (aryIds[i].ToString().StartsWith("cbo"))
                            {
                                DataTable dtCName = new DataTable();
                                objCombi.DataId = aryIds[i].ToString().Substring(3, aryIds[i].ToString().Length - 3);
                                dtCName = objCombi.GetContentName();
                                for (int j = 0; j < dtCName.Rows.Count; j++)
                                {
                                    ListItem litm = new ListItem(dtCName.Rows[j]["Name"].ToString(), dtCName.Rows[j]["DataId"].ToString());
                                    DlstDisplayHeader.Visible = true;
                                    DlstDisplayHeader.Items.Add(litm);
                                }
                                DlstDisplayHeader.DataBind();
                                strCboDataIds += aryIds[i].ToString().Substring(3, aryIds[i].ToString().Length - 3) + ",";

                            }
                            else
                            {
                                NonCboDataIds += aryIds[i].ToString() + ",";
                            }
                        }
                        /////////////////////////////////////////////////////
                        /////--------------Excecution- for modify-------------------------------------------------------------------
                        if (DataIds.StartsWith("CS"))
                        {
                            objCombi.CombisetId = DataIds;
                            objCombi.SelectedItems = "";

                            string Result1 = objCombi.GetCombiContent();
                            TdSerPageContainer.InnerHtml = Result1;
                        }
                        else
                        {
                            objCombi.CombisetId = "";
                            if (NonCboDataIds.Length > 0)
                            {
                                objCombi.SelectedItems = NonCboDataIds;

                                string Result1 = objCombi.GetCombiContent();
                                TdSerPageContainer.InnerHtml = Result1;
                            }
                            if (DlstDisplayHeader.Items.Count > 0)   //display first page defaultly *     //else
                            {
                                objCombi.SelectedItems = DlstDisplayHeader.Items[0].Value + ",";
                                //objCombi.SelectedItems = "";
                                //for (int drpCnt = 0; drpCnt < DlstDisplayHeader.Items.Count; drpCnt++)
                                //{
                                //    objCombi.SelectedItems += DlstDisplayHeader.Items[drpCnt].Value + ",";
                                //}
                                string Result1 = objCombi.GetCombiContent();
                                TdSerPageContainer.InnerHtml += Result1;     //
                            }
                            if (DlstDisplayHeader.Items.Count == 0)
                            {
                                tdViewCombo.Style.Add("visibility", "hidden");
                            }
                        }
                    }
                    //string DataIds = Request.QueryString["DataIds"].ToString();
                    //objCombi.CombisetId = "";
                    //objCombi.SelectedItems = DataIds;               //Comma seperated ids

                    //string FinalResult = objCombi.GetCombiContent();
                    //TdSerPageContainer.InnerHtml = FinalResult;'

                }

                //iF COMNING FRM Index.aspx 
                if (Request.QueryString["From"].ToString() == "Index")
                {

                    DataTable dtGettingAddToCombo = new DataTable();
                    // string [] strAryAddToCmbVals;
                    string CombiSetid = Request.QueryString["Cid"];

                    objCombi.CombisetId = CombiSetid;
                    //objCombi.CombisetId="";
                    //cbo ops
                    dtGettingAddToCombo = objCombi.GetAddToComboVAlues();
                    string strSelectedItems = "";
                    strSelectedItems = objCombi.GetSelectedItemsForCmbOnly();
                    string[] strArySelectedItems = strSelectedItems.Split(',');

                    //if (dtGettingAddToCombo.Rows.Count > 0)
                    //  {
                    string[] strAryAddToCmbVals = dtGettingAddToCombo.Rows[0]["AddToCombo"].ToString().Split(',');
                    //  }
                    for (int j = 0; j < strAryAddToCmbVals.Length - 1; j++)
                    {
                        if (strAryAddToCmbVals[j].ToString() == "0")
                        {

                            {
                                objCombi.SelectedItems += strArySelectedItems[j].ToString() + ",";
                            }
                        }
                        else if (strAryAddToCmbVals[j].ToString() == "1")
                        {

                            DataTable dtContentName = new DataTable();

                            objCombi.DataId = strArySelectedItems[j].ToString();
                            ListItem litm;
                            if (strArySelectedItems[j].ToString().StartsWith("CS"))
                            {
                                dtContentName = objCombi.GetCSNameforCombo();
                                litm = new ListItem(dtContentName.Rows[0]["CombiName"].ToString(), dtContentName.Rows[0]["CombiId"].ToString());
                            }
                            else
                            {
                                dtContentName = objCombi.GetContentName();
                                litm = new ListItem(dtContentName.Rows[0]["Name"].ToString(), dtContentName.Rows[0]["DataId"].ToString());
                            }


                            DlstDisplayHeader.Visible = true;
                            DlstDisplayHeader.Items.Add(litm);




                        }
                        //else
                        //{
                        //    objCombi.SelectedItems += strArySelectedItems[0] + ",";
                        //}


                    }

                    //objCombi.CombisetId = "";
                    //display one record 
                    // objCombi.SelectedItems=
                    //objCombi.SelectedItems
                    if (DlstDisplayHeader.Items.Count > 0)
                        objCombi.SelectedItems += DlstDisplayHeader.Items[0].Value + ",";
                    string Result1 = objCombi.GetCombiContent();
                    TdSerPageContainer.InnerHtml = Result1;
                    tdSaveBlock.Style.Add("display", "none");

                }
            }
            //After Save then Preview
            if (Request.QueryString["From"].ToString() == "View")
            {

                trHeader.Style.Add("display", "none");
                trHR.Style.Add("display", "none");
                string CombisetID = Request.QueryString["CsId"].ToString();
                //CombisetID = Session["CID_View_Modify_View"].ToString();//---
                CombisetID = Session["Self_CID_frmSave"].ToString();
                objCombi.CombisetId = CombisetID;
                string Result1 = objCombi.GetCombiContent();
                TdSerPageContainer.InnerHtml = Result1;
                tdSaveBlock.Style.Add("display", "none");
            }

            if (!(Session["UserType"].ToString().ToLower().Equals("admin")))
            {
                if (Request.QueryString["CId"] != null)
                {
                    UserManager objUser = new UserManager();
                    DataTable dtCombiRights = new DataTable();
                    objUser.Userid = int.Parse(Session["UserId"].ToString());
                    dtCombiRights = objUser.CombiRights(Request.QueryString["CId"].ToString(), "");
                    if (dtCombiRights.Rows.Count > 0)
                    {
                        if (!dtCombiRights.Rows[0][0].ToString().Equals(""))
                        {
                            if (dtCombiRights.Rows[0][0].ToString().Substring(1, 1).Equals("1"))
                            {
                                lnkBtnModify.Style.Add("display", "inline");
                            }
                            else
                            {
                                lnkBtnModify.Style.Add("display", "none");
                            }
                            if (dtCombiRights.Rows[0][0].ToString().Substring(2, 1).Equals("1"))
                            {
                                lnkBtnDelete.Style.Add("display", "inline");
                            }
                            else
                            {
                                lnkBtnDelete.Style.Add("display", "none");
                            }
                        }
                        else
                        {
                            lnkBtnModify.Style.Add("display", "inline");
                            lnkBtnDelete.Style.Add("display", "inline");
                        }
                    }
                    else
                    {
                        lnkBtnModify.Style.Add("display", "none");
                        lnkBtnDelete.Style.Add("display", "none");
                    }
                }
                else
                {
                    lnkBtnModify.Style.Add("display", "none");
                    lnkBtnDelete.Style.Add("display", "none");
                }
            }
            else
            {
                if (!Request.QueryString["From"].ToString().Equals("ModCombi"))
                {
                    lnkBtnModify.Style.Add("display", "inline");
                    lnkBtnDelete.Style.Add("display", "inline");
                }
            }
        }
        else
        {
            if (Request.QueryString["PageType"].ToString().Equals("PUB"))
            {
                ShowBanner("none");
                ShowPanel("none");
                Session["UserId"] = "1";
                trHeader.Style.Add("display","none");
                trHR.Style.Add("display", "none");
                trmain.Style.Add("display","none");
                tblTop.Style.Add("display", "none");
                trunderline.Style.Add("display", "none");
                string CombisetID = Request.QueryString["CId"].ToString();                               
                objCombi.CombisetId = CombisetID;
                DlstDisplayHeader.Visible = false;
                DataTable TempdtGettingAddToCombo = new DataTable();
                

                TempdtGettingAddToCombo = objCombi.GetAddToComboVAlues();
                string strSelectedItems = "";
                strSelectedItems = objCombi.GetSelectedItemsForCmbOnly();
                string[] strArySelectedItems = strSelectedItems.Split(',');
                
                string[] strAryAddToCmbVals = TempdtGettingAddToCombo.Rows[0]["AddToCombo"].ToString().Split(',');
                //  }
                for (int j = 0; j < strAryAddToCmbVals.Length - 1; j++)
                {
                    if (strAryAddToCmbVals[j].ToString() == "0")
                    {
                        objCombi.SelectedItems += strArySelectedItems[j].ToString() + ",";                       
                    }
                    else if (strAryAddToCmbVals[j].ToString() == "1")
                    {

                        if (!IsPostBack)
                        {
                            DataTable dtContentName = new DataTable();

                            objCombi.DataId = strArySelectedItems[j].ToString();
                            ListItem litm;
                            if (strArySelectedItems[j].ToString().StartsWith("CS"))
                            {
                                dtContentName = objCombi.GetCSNameforCombo();
                                litm = new ListItem(dtContentName.Rows[0]["CombiName"].ToString(), dtContentName.Rows[0]["CombiId"].ToString());
                            }
                            else
                            {
                                dtContentName = objCombi.GetContentName();
                                litm = new ListItem(dtContentName.Rows[0]["Name"].ToString(), dtContentName.Rows[0]["DataId"].ToString());
                            }                            
                            DlstDisplayHeader.Items.Add(litm);
                        }
                        DlstDisplayHeader.Visible = true;
                    }

                }

                if (DlstDisplayHeader.Items.Count > 0)
                    objCombi.SelectedItems += DlstDisplayHeader.Items[0].Value + ",";

                string Result1 = objCombi.GetCombiContent();
                TdSerPageContainer.InnerHtml = Result1;
                tdSaveBlock.Style.Add("display", "none");
            }

        }

        
    }
    protected void btnSave_ServerClick(object sender, EventArgs e)
    {
        NGWS.CMPApplication.Combisets objCombi = new Combisets();

        // CSID=&DataIds="+document.getElementById('HideIndex').value+"&Mode=PreviewSave&SearchValue="+searchval+"&QryUpOn="+QryUpon+"&OrderBy="+OrderBy+"&OrderVal="+OrderbyVal+"&From=AddCombi";

        if (Request.QueryString["From"] == "ModCombi")
        {
            objCombi.CombisetId = Session["CID_View_Modify_View"].ToString();// Request.QueryString["CSId"].ToString();
            objCombi.CombisetName = txtCombiName.Text;
            //objCombi.CombisetId = "CS000011";
            objCombi.SelectedItems = Request.QueryString["DataIds"].ToString().Replace("cbo", ""); ;
            objCombi.SelectedIds = "";
           // objCombi.Approved = System.Convert.ToBoolean(Int32.Parse("1"));
            // objCombi.AutoUpdate = "1";
            objCombi.Criteria = CreateCriteria();
            objCombi.DisplayCombo = System.Convert.ToBoolean(Int32.Parse("1"));
            objCombi.SearchValue = Request.QueryString["SearchValue"].ToString();
            objCombi.AddToCombo = Generate_AddComboEntries();
            objCombi.DisplayType = "D";
            objCombi.updateLinks(objCombi.CombisetId, objCombi.SelectedItems, 'N');
            if (objCombi.UpdateCombiset())
            {
                Session["Self_CID_frmSave"] = Session["CID_View_Modify_View"].ToString();
                //Response.Redirect("./view.aspx?CsId=" + Session["CID_View_Modify_View"].ToString() + "&From=View&Mode=");
                //Edited By Murali
                Response.Redirect("./view.aspx?CId=" + Session["CID_View_Modify_View"].ToString() + "&Mode=Preview&From=Index");                
                //End

            }
            else
            {

            }
        }
        else if (Request.QueryString["From"] == "AddCombi")
        {
            //-------------------------------------------------------------------------------------------------------
            objCombi.CombisetName = txtCombiName.Text;
            //objCombi.CombisetId = "CS000011";
            objCombi.CreatedBy =Session["UserId"].ToString();
            objCombi.SelectedItems = Request.QueryString["DataIds"].ToString().Replace("cbo", "");
            objCombi.Approved = System.Convert.ToBoolean(Int32.Parse("1"));
            objCombi.AutoUpdate = "1";
            objCombi.Criteria = CreateCriteria();
            objCombi.DisplayCombo = System.Convert.ToBoolean(Int32.Parse("1"));
            objCombi.SearchValue = Request.QueryString["SearchValue"].ToString();
            objCombi.AddToCombo = Generate_AddComboEntries();
            objCombi.DisplayType = "D";

            try
            {
                objCombi.AddNewCombiset();
                
            }

                
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {

                NGWS.CMPApplication.Combisets ObjCombi = new Combisets();
                string CSID = objCombi.GetLastInsertedCombiSetId();
                Session["Self_CID_frmSave"] = CSID;

                //Response.Redirect("./view.aspx?CsId=" + CSID + "&From=View&Mode=");
                //Edited By Murali
                Response.Redirect("./view.aspx?CId=" + CSID + "&Mode=Preview&From=Index");                
                //End
            }
        }
    }

    protected string Generate_AddComboEntries()
    {
          string AddCmbValues = "";
          string strDataIds = Request.QueryString["DataIds"].ToString();
          string [] strAryDataIds=strDataIds.Split(',');
          for (int i = 0; i < strAryDataIds.Length-1; i++)
          {
              if (strAryDataIds[i].ToString().StartsWith("cbo"))
              {
                  AddCmbValues += "1" + ",";
              }
              else
              {
                  AddCmbValues += "0" + ",";
              }
          }
          return (AddCmbValues);
    }

    protected string CreateCriteria()
    {
        string strQryUpOn=Request.QueryString["QryUpOn"].ToString();
        string strOrderBy=Request.QueryString["OrderBy"].ToString();
        string strOrderVal=Request.QueryString["OrderByVal"].ToString();


        string strqryuponVal="";
        string strqryOrderby="";
        string strqryOrderVal="";
        string strCriteriaValue="";

        if (strQryUpOn.ToUpper() == "0")
        {
            strqryuponVal = "ALL";

        }
        else if (strQryUpOn == "1")
        {
            strqryuponVal = "PF";
        }
        else if (strQryUpOn == "2")
        {
            strqryuponVal = "CF";
        }
        else if (strQryUpOn == "3")
        {
            strqryuponVal = "P";
        }
        else if (strQryUpOn == "4")
        {
            strqryuponVal = "L";
        }
        else if (strQryUpOn == "5")
        {
            strqryuponVal = "CS";
        }

        if (strOrderBy == "0")
        {
            strqryOrderby = "N";
        }
        else if (strOrderBy == "1")
        {
            strqryOrderby = "D";
        }



        if (strOrderVal == "0")
        {
            strqryOrderVal = "A";
        }
        else if (strOrderVal == "1")
        {
            strqryOrderVal = "D";
        }

        strCriteriaValue = strqryuponVal + "/" + strqryOrderby + "/" + strqryOrderVal;
        return strCriteriaValue;
    }
   
    protected void btnBack_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["From"].ToString() == "AddCombi")
            Response.Redirect("./AddCombisets.aspx?From=Back");
        else
            Response.Redirect("./ModifyCombi.aspx?From=View&Mode=Mod&CSId=" + Session["CID_View_Modify_View"].ToString());

    }
    protected void lnkBtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("./IndexCombi.aspx?SearchValue=");
    }
    protected void lnkBtnModify_Click(object sender, EventArgs e)
    {
        string CombiSet = Request.QueryString["Cid"];
        Session["CID_View_Modify_View"] = CombiSet;
        Response.Redirect("./ModifyCombi.aspx?From=View&Mode=Mod&CSId=" + CombiSet);
    }
    protected void DlstDisplayHeader_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        //objCombi.CombisetId = Request.QueryString["Cid"];
        //objCombi.SelectedItems =  Hidden1.Value + DlstDisplayHeader.SelectedValue.ToString() + ",";
        //objCombi.DefaultItems = Hidden1.Value; 

        //Modified By Murali
        if (!Request.QueryString["From"].ToString().Equals("ModCombi"))
        {
            if (Request.QueryString["Cid"] != null)
            {
                objCombi.SelectedItems = "";
                string strSelectedItems = "";
                DataTable dtGettingAddToCombo = new DataTable();

                string CombiSetid = Request.QueryString["Cid"];
                objCombi.CombisetId = CombiSetid;
                dtGettingAddToCombo = objCombi.GetAddToComboVAlues();
                strSelectedItems = objCombi.GetSelectedItemsForCmbOnly();


                string[] strArySelectedItems = strSelectedItems.Split(',');
                string[] strAryAddToCmbVals = dtGettingAddToCombo.Rows[0]["AddToCombo"].ToString().Split(',');
                for (int j = 0; j < strAryAddToCmbVals.Length - 1; j++)
                {
                    if (strAryAddToCmbVals[j].ToString() == "0")
                    {
                        objCombi.SelectedItems += strArySelectedItems[j] + ",";
                    }
                    else if (strAryAddToCmbVals[j].ToString() == "1")
                    {
                        DataTable dtContentName = new DataTable();

                        //objCombi.DataId = strArySelectedItems[j].ToString();
                        //dtContentName = objCombi.GetContentName();
                        //ListItem litm = new ListItem(dtContentName.Rows[0]["Name"].ToString(), dtContentName.Rows[0]["DataId"].ToString());



                        objCombi.DataId = strArySelectedItems[j].ToString();
                        ListItem litm;
                        if (strArySelectedItems[j].ToString().StartsWith("CS"))
                        {
                            dtContentName = objCombi.GetCSNameforCombo();
                            litm = new ListItem(dtContentName.Rows[0]["CombiName"].ToString(), dtContentName.Rows[0]["CombiId"].ToString());
                        }
                        else
                        {
                            dtContentName = objCombi.GetContentName();
                            litm = new ListItem(dtContentName.Rows[0]["Name"].ToString(), dtContentName.Rows[0]["DataId"].ToString());
                        }
                        if (DlstDisplayHeader.SelectedValue.ToString() == strArySelectedItems[j].ToString())
                            objCombi.SelectedItems += strArySelectedItems[j].ToString() + ",";
                    }
                }

                tdSaveBlock.Style.Add("display", "none");
            }
            else
            {
                string IDs = Request.QueryString["DataIds"].ToString();
                objCombi.SelectedItems = "";
                string[] strArySelectedItems = IDs.Split(',');
                for (int itmcnt = 0; itmcnt < strArySelectedItems.Length - 1; itmcnt++)
                {
                    if (!strArySelectedItems[itmcnt].StartsWith("cbo"))
                    {
                        objCombi.SelectedItems += strArySelectedItems[itmcnt] + ",";
                    }
                }
                objCombi.SelectedItems += DlstDisplayHeader.SelectedValue.ToString() + ",";
            }
                //objCombi.CombisetId = "";
                string Result1 = objCombi.GetCombiContent();
                TdSerPageContainer.InnerHtml = Result1;
            
        }
        else
        {
            //if (DlstDisplayHeader.SelectedValue.ToString() == strArySelectedItems[j].ToString())
                string IDs = Request.QueryString["DataIds"].ToString();
                objCombi.SelectedItems = "";
                string[] strArySelectedItems = IDs.Split(',');
                for (int itmcnt = 0; itmcnt < strArySelectedItems.Length - 1; itmcnt++)
                {
                    if (!strArySelectedItems[itmcnt].StartsWith("cbo"))
                    {
                        objCombi.SelectedItems += strArySelectedItems[itmcnt] + ",";
                    }
                }
                
                objCombi.SelectedItems += DlstDisplayHeader.SelectedValue.ToString() + ",";
                tdSaveBlock.Style.Add("display", "inline");
                lnkBtnDelete.Style.Add("display", "none");
                lnkBtnModify.Style.Add("display", "none");
                objCombi.CombisetId = "";
                string Result1 = objCombi.GetCombiContent();
                TdSerPageContainer.InnerHtml = Result1;
        }
            
            
        
        //End
    }
    protected void lnkBtnDelete_Click(object sender, EventArgs e)
    {
        string CombiSet = Request.QueryString["Cid"];
        DataTable dtLinkedCombi = new DataTable();
        dtLinkedCombi = objCombi.ExecuteDTQuery("select * from Links where Linkto like '%" + CombiSet + "%'");
        if (dtLinkedCombi.Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>alert('Cannot delete the Combiset. The Combiset is linked to one or more Toolbar.');</script>");
        }
        else
        {
            objCombi.CombisetId = CombiSet;
            objCombi.LogicDelete();
            Response.Redirect("./Indexcombi.aspx?SearchValue=");
        }
    }

    protected void lnkBtnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("./Indexcombi.aspx?SearchValue=");
    }
    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }


    void lb_Click(object sender, EventArgs e)
    {
        string CombisetId = ((LinkButton)(sender)).CommandArgument.ToString();
        Response.Redirect("./view.aspx?CId=" + CombisetId + "&Mode=Preview&From=Index");
    }

    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        txtSearch.Text = "";
        Response.Redirect("./IndexCombi.aspx?SearchValue=");
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("./IndexCombi.aspx?SearchValue="+ txtSearch.Text);
    }
    protected void btnCancel_ServerClick(object sender, EventArgs e)
    {
        Response.Redirect("./IndexCombi.aspx?SearchValue=");
    }
    protected void CheckRights()
    {

        UserManager objUser = new UserManager();
        objUser.Userid = int.Parse(Session["UserId"].ToString());
        DataTable dtToolbars = new DataTable();
        DataTable dtRights = new DataTable();
        dtToolbars = objUser.AllToolBarViewRights("");
        foreach (DataRow row in dtToolbars.Rows)
        {
            string strRights = objUser.MultipleRights(row[0].ToString(), "All");
            if (strRights.Substring(0, 1).Equals("1"))
            {
                add = true;
            }
            if (strRights.Substring(1, 1).Equals("1"))
            {
                mod = true;
            }
            if (strRights.Substring(2, 1).Equals("1"))
            {
                del = true;
            }
        }
    }
    protected string UserCombi() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = objCombi.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_CombiRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        CombiIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = objCombi.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        CombiIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (CombiIds.Length > 0) CombiIds = CombiIds.ToString().Remove(CombiIds.Length - 1, 1);
        return CombiIds;
    }


    private class CombisetsExtended : Combisets
    {
        private bool isComboMarkerExists;

        public bool IsComboMarkerExists
        {
            get
            {
                return this.isComboMarkerExists;
            }
            set
            {
                this.isComboMarkerExists = value;
            }
        }
    }

}
