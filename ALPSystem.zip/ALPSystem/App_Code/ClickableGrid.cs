using System;
using System.Drawing;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NGWS.CMPApplication;

	public class Clickablegrid : DataGrid, IPostBackEventHandler
	{
		public event EventHandler ItemClicked; 

		protected virtual void OnItemClicked(object sender, EventArgs e)
		{
			if (ItemClicked != null) 
			{
				ItemClicked(sender, e);
			}
		}

		protected override void CreateControlHierarchy(bool useDataSource)
		{
			base.CreateControlHierarchy(useDataSource);
			for (int i = 0; i <= Items.Count - 1; i++) 
			{
				this.Items[i].Attributes.Add("onclick", Page.GetPostBackEventReference(this, i.ToString()));
			}
		}

		public void RaisePostBackEvent(string eventArgument)
		{
			if (!(eventArgument == null)) 
			{
				int i = Int32.Parse(eventArgument);
				OnItemClicked(this.Items[i], EventArgs.Empty);
			
			}
		}
	}
