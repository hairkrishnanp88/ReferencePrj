using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for FirstColumn
/// </summary>
public class FirstColumn:ITemplate 
{
	string colName;
    ListItemType tempType;
    Label lbl;
    public FirstColumn(string columnName, ListItemType templateType)
	{
		//
		// TODO: Add constructor logic here
		//
        colName = columnName;
        tempType = templateType;
	}

    public void InstantiateIn(Control container)
    {
        switch (tempType)
        {
            case ListItemType.Header:
                Literal lit = new Literal();
                lit.Text = colName;
                container.Controls.Add(lit);
                break;
            case ListItemType.Item:
                lbl = new Label();
                lbl.ID = "lblField";
                lbl.DataBinding += new EventHandler(this.BindLabelColumn);
                container.Controls.Add(lbl);
                break;
        }

    }

    public void BindLabelColumn(object sender, EventArgs e)
    {
        Label  lbl = ((Label)(sender));
        DataGridItem container = ((DataGridItem)(lbl.NamingContainer));
        lbl.CssClass = "clsLabel";
        lbl.Width = Unit.Percentage(100);
        lbl.Text = DataBinder.Eval(container.DataItem, colName) + "";
        
    }
}
