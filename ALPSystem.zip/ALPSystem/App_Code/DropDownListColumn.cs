using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DropDownListColumn
/// </summary>
public class DropDownListColumn : ITemplate
{
    string colName;
    ListItemType tempType;
    DropDownList ddl;


    public DropDownListColumn(string columnName, ListItemType TemplateType)
    {
        colName = columnName;
        tempType = TemplateType;
    }

    public void InstantiateIn(Control container)
    {
        if (tempType == ListItemType.Item)
        {
            ddl = new DropDownList();
            ddl.ID = "ddlType";
            ddl.Attributes.Add("Class", "ClsDropDown");
            ddl.Items.Add(new ListItem("ShortText", "0"));
            ddl.Items.Add(new ListItem("LongText", "1"));
            ddl.Items.Add(new ListItem("Price", "2"));
            ddl.Items.Add(new ListItem("Image", "3"));
            ddl.Items.Add(new ListItem("ThumbImage", "4"));
            ddl.Items.Add(new ListItem("Document", "5"));
            ddl.Items.Add(new ListItem("PopImage", "6"));
            ddl.DataBinding += new EventHandler(this.BindLabelColumn);
            container.Controls.Add(ddl);
        }
    }

    public void BindLabelColumn(object sender, EventArgs e)
    {
        DropDownList ddl = ((DropDownList)(sender));
        DataGridItem container = ((DataGridItem)(ddl.NamingContainer));
        ddl.Font.Name = "Verdana";
        ddl.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8);
        ddl.Width = System.Web.UI.WebControls.Unit.Percentage(100);
        
            if ((DataBinder.Eval(container.DataItem, colName) + "" == "cboCode") || (DataBinder.Eval(container.DataItem, colName) + "" == "cboCategory"))
            {
                ddl.SelectedIndex = 0;
                ddl.Enabled = false;
            }
            else if (DataBinder.Eval(container.DataItem, colName) + "" == "cboDesc")
            {
                ddl.SelectedIndex = 1;
                ddl.Enabled = false;
            }
            else if (DataBinder.Eval(container.DataItem, colName) + "" == "cboPrice")
            {
                ddl.SelectedIndex = 2;
                ddl.Enabled = false;
            }
            else if (DataBinder.Eval(container.DataItem, colName) + "" == "cboImage")
            {
                ddl.SelectedIndex = 3;
                ddl.Enabled = false;
            }
            else if (DataBinder.Eval(container.DataItem, colName) + "" == "cboThumbImage")
            {
                ddl.SelectedIndex = 4;
                ddl.Enabled = false;
            }
            else
            {
                if (HttpContext.Current.Request.QueryString["ACT"] == "MOD")
                {
                    ddl.Enabled = false;
                    ddl.SelectedIndex = ddl.Items.IndexOf(ddl.Items.FindByText(DataBinder.Eval(container.DataItem, colName) + "".Replace("cbo", "").ToUpper()));
                }
                else
                {
                    ddl.Enabled = true;
                }
            }
    }
}
