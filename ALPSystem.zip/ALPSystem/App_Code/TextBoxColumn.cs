using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for TextBoxColumn
/// </summary>
public class TextBoxColumn:ITemplate 
{
    string colName;
    ListItemType tempType;
    TextBox txt;
    public TextBoxColumn(string columnName, ListItemType templateType)
	{
		//
		// TODO: Add constructor logic here
		//
        colName = columnName;
        tempType = templateType;
	}

    public void InstantiateIn(Control container)
    {
        switch (tempType)
        {
            case ListItemType.Header:
                Literal lit = new Literal();
                lit.Text = colName;
                container.Controls.Add(lit);
                break;
            case ListItemType.Item:
                txt = new TextBox();
                txt.ID = "txtName";
                txt.DataBinding += new EventHandler(this.BindLabelColumn);
                container.Controls.Add(txt);
                break;
        }

    }

    public void BindLabelColumn(object sender, EventArgs e)
    {
        TextBox txt = ((TextBox)(sender));
        DataGridItem container = ((DataGridItem)(txt.NamingContainer));
        txt.CssClass = "clsTextBox";
        txt.Width = Unit.Percentage(100);
        txt.Text = DataBinder.Eval(container.DataItem, colName) + "";
        if (HttpContext.Current.Request.QueryString["ACT"] == "MOD")
            txt.ReadOnly = true;
        else if ((txt.Text == "Code") || (txt.Text == "Description") || (txt.Text == "Category") || (txt.Text == "Price") || (txt.Text == "Image") || (txt.Text == "ThumbNail"))
            txt.ReadOnly = true;
    }
}
