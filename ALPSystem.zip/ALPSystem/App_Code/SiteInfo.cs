using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;
using System.Web.SessionState;
/// <summary>
/// Summary description for ClsForum
/// </summary>
public class SiteInfo : DBFunctions
{
    #region Properties
    private string name, desc, subject, body, filenames, filetype, delforumID, delthreadID, smilename;
    private int forumID, typeID, parentID, threadID, threadcount, createdBy, editedby, viewcount, replycount, lastpostby, filesize, smileID;
    private Int16 uploadstatus, messagetype;
    private DateTime editedon;
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public string Desc
    {
        get { return desc; }
        set { desc = value; }
    }
    public string Subject
    {
        get { return subject; }
        set { subject = value; }
    }
    public string Body
    {
        get { return body; }
        set { body = value; }
    }
    public string Smilename
    {
        get { return smilename; }
        set { smilename = value; }
    }
    public string Filenames
    {
        get { return filenames; }
        set { filenames = value; }
    }
    public string Filetype
    {
        get { return filetype; }
        set { filetype = value; }
    }
    public string DelforumID
    {
        get { return delforumID; }
        set { delforumID = value; }
    }
    public string DelthreadID
    {
        get { return delthreadID; }
        set { delthreadID = value; }
    }

    public int Filesize
    {
        get { return filesize; }
        set { filesize = value; }
    }

    public int ForumID
    {
        get { return forumID; }
        set { forumID = value; }
    }
    public int TypeID
    {
        get { return typeID; }
        set { typeID = value; }
    }
    public int ParentID
    {
        get { return parentID; }
        set { parentID = value; }
    }
    public int ThreadID
    {
        get { return threadID; }
        set { threadID = value; }
    }
    public int Threadcount
    {
        get { return threadcount; }
        set { threadcount = value; }
    }
    public int Replycount
    {
        get { return replycount; }
        set { replycount = value; }
    }
    public int Viewcount
    {
        get { return viewcount; }
        set { viewcount = value; }
    }
    public int SmileID
    {
        get { return smileID; }
        set { smileID = value; }
    }
    public Int16 Uploadstatus
    {
        get { return uploadstatus; }
        set { uploadstatus = value; }
    }
    public Int16 Messagetype
    {
        get { return messagetype; }
        set { messagetype = value; }
    }
    public int Createdby
    {
        get { return createdBy; }
        set { createdBy = value; }
    }
    public int Editedby
    {
        get { return editedby; }
        set { editedby = value; }
    }
    public int Lastpostby
    {
        get { return lastpostby; }
        set { lastpostby = value; }
    }
    public DateTime Editedon
    {
        get { return editedon; }
        set { editedon = value; }
    }

    #endregion

    public SiteInfo()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static HtmlTable userValidation()
    {
        
        Skins objToolbar = new Skins();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Border = 0;        
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        String strQry = "";
        if (HttpContext.Current.Session["UserType"].ToString() == "Admin" || HttpContext.Current.Session["UserType"].ToString() == "Manager")
        {
            if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
            {
                strQry = "select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder";
                //Gk April 24 '07
                string sQry = "select EnableStaticpages from skindata";
                if (objToolbar.ExecuteScalar(sQry) == "True")
                    HttpContext.Current.Session["EnableStaticMenu"] = "true";
                else
                    HttpContext.Current.Session["EnableStaticMenu"] = "false";

            }
            else
                strQry = "select * from adminrights where amdrights=1 and menuoption='Main' and menuorder <> 8 order by menuorder";

           
            dtMenu = objToolbar.ExecuteDTQuery(strQry);
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    //cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("text-align", "center");
                    cell.Style.Add("color", "White");
                    //                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();


                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); ");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FullName=" + HttpContext.Current.Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Width = "70px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout'; document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Width = "80px";
                        cell.Attributes.Add("onclick", "javascript: ShowNewJob('../Skins/SkinSettings.aspx'); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Additions")
                    {
                      //  cell.Width = "55px";
                        //Gk April23

                        if (HttpContext.Current.Session["EnableStaticMenu"] == "true")
                        {
                            cell.Width = "75px";
                        }
                        else
                        {
                            cell.Width = "55px";
                        }
                       
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Management")
                    {
                        cell.Width = "100px";
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Approval Manager")
                    {
                        cell.Width = "100px";

                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Public")
                    {
                        cell.Width = "40px";
                        cell.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/DisplayPage.aspx?DispType=Public&DataId=" + System.Web.HttpContext.Current.Session["PublicIndex"].ToString() + "';document.forms[0].submit(); expand('sub');");

                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Private")
                    {
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/DisplayPage.aspx?DispType=Private&DataId=" + System.Web.HttpContext.Current.Session["CBId"].ToString() + "';document.forms[0].submit(); expand('sub');");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        //cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000'; expand('sub'); expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            //  cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            //cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';document.forms[0].submit(); expand('sub'); "); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {

                                if (HttpContext.Current.Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {

                                if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit();");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx';document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit();expand('sub');");
                            }
                            //Gk April 23
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Static Pages")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../MetaTag/MetaTag.aspx'; document.forms[0].submit();expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Combiset") // Changes for Combiset - 26 Dec 2006
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../CombiSet/IndexCombi.aspx?SearchValue='; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Product Publisher") // Changes for Products - 17 Jul 2007
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ProductPublisher/Mainpage.aspx'; document.forms[0].submit(); expand('sub');");
                            }

                            
                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);

                            //Gk April 24
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                if (HttpContext.Current.Session["EnableStaticMenu"] != "true")
                                    srow = dtSubMenu.Rows.Count;
                            }
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }
                    else
                    {
                        cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000'; expand('sub');");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            menuMain.Cells.Add(cell1);

        }
        else if (HttpContext.Current.Session["UserType"].ToString() == "Private")
        {

            //if (System.Web.HttpContext.Current.Session["ViewRightsOnly"].ToString().ToLower()  == "yes")
              //  dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (5,9) order by menuorder");
            //else
            if (System.Web.HttpContext.Current.Session["PublicIndex"].ToString() == "")
                dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (2,3,5,6,9) order by menuorder");
            else 
                dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,3,5,6,9) order by menuorder");
            
                

            if (dtMenu.Rows.Count > 0)
            {
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Attributes.Add("class", "ClsMainmenu");
                    cell.Style.Add("text-align", "center");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Width = "70px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Width = "70px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout';document.forms[0].submit();");
                    }
                    menuMain.Cells.Add(cell);
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Width = "70px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Width = "70px";
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout';document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Width = "110px";
                        cell.Attributes.Add("onclick", "javascript: ShowNewJob('../Skins/SkinSettings.aspx');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Additions")
                        cell.Width = "80px";
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Management")
                        cell.Width = "100px";
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Approval Manager")
                        cell.Width = "110px";
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Public")
                    {
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/DisplayPage.aspx?DispType=Public&DataId=" + System.Web.HttpContext.Current.Session["PublicIndex"].ToString() + "';document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Private")
                    {
                        cell.Width = "50px";
                        cell.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/DisplayPage.aspx?DispType=Private&DataId=" + System.Web.HttpContext.Current.Session["CBId"].ToString() + "';document.forms[0].submit(); expand('sub');");
                    }

                    menuSub.Cells.Add(cellSub);
                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000'; expand('sub'); expand('" + tblSub.ClientID + "');");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';  document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                                cellSub1.Style.Add("display", "none");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {

                                if (HttpContext.Current.Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + HttpContext.Current.Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (HttpContext.Current.Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx';document.forms[0].submit(); expand('sub');");
                            }                            
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Combiset") // Changes for Combiset - 26 Dec 2006
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../CombiSet/IndexCombi.aspx?SearchValue='; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Product Publisher") // Changes for Products - 17 Jul 2007
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ProductPublisher/MainPage.aspx.aspx'; document.forms[0].submit(); expand('sub');");
                                cellSub1.Style.Add("display", "none");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }
                    else
                    {
                        cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000'; expand('sub');");
                    }                  
                }
            }            
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            menuMain.Cells.Add(cell1);            
        }
        return menuTbl;

    }

    public static void ValidateSession()
    {
        if (HttpContext.Current.Session["UserId"] == null || HttpContext.Current.Session["Banner"] == "")
            HttpContext.Current.Response.Redirect("../Errors/SessionExpired.aspx");
        //else if (HttpContext.Current.Session["UserId"].ToString() == "")
        //    HttpContext.Current.Response.Redirect("../Errors/SessionExpired.aspx");
        
    }

    public static void ResetSession()
    {
        HttpContext.Current.Session["UserType"] = "Anonymous";
        HttpContext.Current.Session["UserId"] = "";
        HttpContext.Current.Session["UserName"] = "";
        HttpContext.Current.Session["FullName"] = "";
        HttpContext.Current.Session["CBId"] = "";
        HttpContext.Current.Session["MenuRights"] = "";
        HttpContext.Current.Session["DispType"] = "Public";
    }

    public static void SetSiteName(Page page)
    {
        Skins obj = new Skins();
        obj.LoadSkinSettings();
        if (HttpContext.Current.Application["SiteName"] != null)
        {
            page.Title = HttpContext.Current.Application["SiteName"].ToString().Replace("''", "'");
        }
        else
        {
            HttpContext.Current.Application["SiteName"] = obj.SiteName;
            page.Title = obj.SiteName;
        }
        HttpContext.Current.Application["BGcolor"] = obj.BGcolor;
        HttpContext.Current.Application["BGimage"] = obj.BGimage;
        HttpContext.Current.Application["BGrepeat"] = obj.BGrepeat;      
    
        
    }
    

}
