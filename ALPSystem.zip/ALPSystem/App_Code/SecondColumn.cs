using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for SecondColumn
/// </summary>
public class SecondColumn:ITemplate 
{
    string colName, DesColName;
    ListItemType tempType;
    TextBox txt;
    public SecondColumn(string columnName, ListItemType templateType,string DesColumnName)
	{
		//
		// TODO: Add constructor logic here
		//
        colName = columnName;
        tempType = templateType;
        DesColName = DesColumnName;
	}

    public void InstantiateIn(Control container)
    {
        switch (tempType)
        {
            case ListItemType.Header:
                Literal lit = new Literal();
                lit.Text = colName;
                container.Controls.Add(lit);
                break;
            case ListItemType.Item:
                txt = new TextBox();
                txt.ID = "txtEntry";
                txt.DataBinding += new EventHandler(this.BindLabelColumn);
                container.Controls.Add(txt);
                break;
        }

    }

    public void BindLabelColumn(object sender, EventArgs e)
    {
        TextBox txt = ((TextBox)(sender));
        DataGridItem container = ((DataGridItem)(txt.NamingContainer));
        txt.CssClass = "clsTextBox";
        txt.Width = Unit.Percentage(100);
        txt.Text = DataBinder.Eval(container.DataItem, colName) + "";
        
    }
}
