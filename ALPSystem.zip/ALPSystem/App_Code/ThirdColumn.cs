using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ThirdColumn
/// </summary>
public class ThirdColumn:ITemplate 
{
	string colName;
    ListItemType tempType;
    Image img;
    public ThirdColumn(string columnName, ListItemType templateType)
	{
		//
		// TODO: Add constructor logic here
		//
        colName = columnName;
        tempType = templateType;
	}

    public void InstantiateIn(Control container)
    {
        switch (tempType)
        {
            case ListItemType.Header:
                Literal lit = new Literal();
                lit.Text = colName;
                container.Controls.Add(lit);
                break;
            case ListItemType.Item:
                img = new Image ();
                img.ID = "img";
                img.Attributes.Add("onmouseover", "javascript:this.setAttribute('src','../Images/file_icon_over.gif');");
                img.Attributes.Add("onmouseout", "javascript:this.setAttribute('src','../Images/file_icon.gif');");
                img.DataBinding += new EventHandler(this.BindLabelColumn);
                container.Controls.Add(img);
                break;
        }

    }

    public void BindLabelColumn(object sender, EventArgs e)
    {
        Image img = ((Image)(sender));
        DataGridItem container = ((DataGridItem)(img.NamingContainer));
        img.ImageUrl = "~/Images/file_icon.gif";
        if ((DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(254)") || (DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(253)") || (DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(252)"))
        {
            if((DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(252)"))
                img.AlternateText = "Document";
            else if ((DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(254)"))
                img.AlternateText = "Image";
            else if ((DataBinder.Eval(container.DataItem, colName) + "".ToLower() == "varchar(253)"))
                img.AlternateText = "ThumbNail";
            img.Visible = true;
        }
        else
            img.Visible = false;
    }
}
