using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

public partial class Others_Alp_ContactForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Expires = -1;
        Response.AddHeader("pragma", "no-cache");
        Response.CacheControl = "no-cache"; 

        txtPhno.Attributes.Add("onkeypress", "return onKeyPress(event);");
        btnSubreq.Attributes.Add("onclick", "javascript: return validform();");
    }
    protected void btnSubreq_Click(object sender, EventArgs e)
    {
        MailMessage msg = new MailMessage();
        msg.To = "info@alp.ie";
        msg.From = txtYmail.Text;
        msg.Subject = "Online Enquiry from ALP Website";

        msg.Body += "<br> <span style='font-family:Arial;font-size:9pt;'> Hi,<br><br></span>";
        msg.Body += "<p style='font-family:Arial;font-size:9pt;' align='justify'><b>" + txtYname.Text + "</b>  has sent an Online Enquiry from the ALP Website. The following are his / her details." + " </p>";
        msg.Body += "<br>";
        msg.Body += "<table width='95%' cellpadding='3' cellspacing='0' border='0' style='font-family:Arial;font-size:8pt;'><tr><td align='left' ><b>Contact Details:</b><br><br></td><td  align='left' width='5%' valign='top'> : </td></tr></table>";
        msg.Body += "<table width='95%' cellpadding='8' cellspacing='3' border='0' style='font-family:Arial;font-size:8pt; border:0px solid #585858'>";
        msg.Body += "<tr colspan='3'><td width='35%' align='left' valign='top'> Name</td> <td  align='left' width='8%' valign='top'> : </td><td valign='top' align='left'><b>" + txtYname.Text + "</b></td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Company Name </td><td  align='left' valign='top'> : </td> <td valign='top' align='left'> " + txtYCmpName.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Address </td><td  align='left' valign='top'> : </td> <td valign='top' align='left'> " + TextBox1.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> County </td><td  align='left' valign='top'> : </td> <td valign='top' align='left'> " + txtCounty.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Postal Code</td><td  align='left'  valign='top'> : </td> <td valign='top' align='left'> " + txtPstcode.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Phone Number </td><td  align='left' valign='top'> : </td> <td valign='top' align='left'> " + txtPhno.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Fax</td><td  align='left'  valign='top'> : </td> <td valign='top' align='left'> " + txtFax.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Email</td><td  align='left'  valign='top'> : </td> <td valign='top' align='left'> " + txtYmail.Text + "</td></tr>";
        msg.Body += "<tr><td align='left' valign='top'> Enquiry </td><td  align='left' valign='top'> : </td> <td valign='top' align='left'> " +TextBox2.Text + "</td></tr>";
        
       
        

        msg.BodyFormat = MailFormat.Html;
        SmtpMail.Send(msg);
        string strScript = "<script language='javascript'>alert('Your email has been sent');location.href = './Alp_ContactForm.aspx';</script>";
        //string strScript = "<script language='javascript'>alert('Thank you for taking the time to fill out this form. We will send you a personalised itinerary within 48 hours.Your Travel Consultant.');</script>";
        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Script", strScript);
        
    }

    protected void txtclear()
    {
        
        txtYname.Text = "";
        txtYCmpName.Text = "";
        txtCounty.Text = "";
        txtFax.Text = "";
        txtPhno.Text = "";
        txtPstcode.Text = "";
        txtYmail.Text = "";
        TextBox1.Text = "";
        TextBox2.Text = "";

    }
    protected void btnClrfrm_Click(object sender, EventArgs e)
    {
        txtclear();
    }
}
