using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;
using System.Text;

public partial class Discussion : System.Web.UI.Page
{
    Forums DBobj = new Forums();
    DataTable dtForum = new DataTable();
    DataTable dtThread = new DataTable();
    DataTable dtTopics = new DataTable();
    public string varMainRoot = "Discussion";
    StringBuilder TypeIds = new StringBuilder();
    string typeIds="";
    string folderIds = "", groupIds = "", topicIds = "";
   
    Templates tmp = new Templates();
    DateTime dTime;    
    protected void Page_Load(object sender, EventArgs e)
    {

        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        //Code for Banner change starts
        tblBanner.Style.Add("display", "none");
        if (Session["UserType"].ToString() == "Admin")
            tdBanner.InnerHtml = tmp.GetTemplateContent("TM000001").Replace("<a href=\"../default.aspx?Act=Logout\">", "");
        else
            tdBanner.InnerHtml = tmp.GetTemplateContent("TM000001");
       
        try
        {
            // Visible False for All Controls                        
            tblReply.Visible = false;
            btnReply.Visible = false;
            btnCancel.Visible = false;
            tblNewforum.Visible = false;
            tblNewpost.Visible = false;
            tblnodata.Visible = false;
            btnNewPost.Visible = false;            
            lbluser1.Text = Session["FullName"].ToString();
            lbluser2.Text = Session["FullName"].ToString();            
            btnSaveForum.Attributes.Add("onclick", "javascript: return (Forumvalidation())");
            btnSend.Attributes.Add("onclick", "javascript: return (Postvalidation())");
            btnSearch.Attributes.Add("onclick", "javascript: return (Searchvalidation())");
            
            // Start Menu Displaying    
            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());
                divMenu.Controls.Add(SiteInfo.userValidation());
            }
            //End

            // Top Banner Displaying
            ShowBanner(Session["Banner"].ToString());
                
            if (!IsPostBack)
            {
                //TreeView Binding with Data Control
                BindTree();

                //User Type Checking for Visible the DELETE & ADD Buttons.
                if (Session["UserType"].ToString() == "Admin")
                {
                    gridForum.Columns[8].Visible = true;        // Forum Edit Column 
                    gridForum.Columns[9].Visible = true;        // Forum Delete Column
                    gridThread.Columns[7].Visible = true;       // Thread Edit column
                    gridThread.Columns[8].Visible = true;       // Thread Delete Column
                    btnDelete.Visible = true;
                    btnAdd.Visible = true;                   
        
                }
                else if (Session["UserType"].ToString() == "Manager")
                {
                    gridForum.Columns[8].Visible = true;        // Forum Edit Column 
                    gridForum.Columns[9].Visible = false;        // Forum Delete Column
                    gridThread.Columns[7].Visible = true;       // Thread Edit column
                    gridThread.Columns[8].Visible = false;       // Thread Delete Column
                    btnDelete.Visible = false;
                    btnAdd.Visible = false;
                }
                else
                {
                    gridForum.Columns[8].Visible = false;        // Forum Edit Column 
                    gridForum.Columns[9].Visible = false;        // Forum Delete Column
                    gridThread.Columns[7].Visible = false;       // Thread Edit column
                    gridThread.Columns[8].Visible = false;       // Thread Delete Column
                    btnDelete.Visible = false;
                    btnAdd.Visible = false;
                }

                if (Request.QueryString["TypeID"] == null)
                {
                    gridForum.Columns[7].Visible = false;
                    gridForum.Width = Unit.Percentage(80); 
                }
                else if (int.Parse(Request.QueryString["TypeID"].ToString()) == 0)
                {
                    gridForum.Columns[7].Visible = false;
                    gridForum.Width = Unit.Percentage(80);
                }
                else
                {
                    gridForum.Columns[7].Visible = true;                    
                    gridForum.Width = Unit.Percentage(100); 
                }



                // Display the Grid For correspondence Forum ID..
                if (Request.QueryString["ForumID"] != null)
                {
                    hforumID.Value = Request.QueryString["ForumID"].ToString();
                    BindGrid(int.Parse(hforumID.Value));
                    if (Request.QueryString["TypeID"] != null)
                    {
                        htypeID.Value = Request.QueryString["TypeID"].ToString();
                        if (int.Parse(htypeID.Value) > 1)
                            btnNewPost.Visible = true;

                    }
                    // Display the Select Item in LblHeading
                    DisplayHeading();
                }
                else
                {
                    if (Session["UserType"].ToString() == "Admin")
                    {
                        SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                        cmdselect.CommandType = CommandType.StoredProcedure;
                        dtForum = DBobj.ExecuteDTQuery(cmdselect);
                    }
                    else
                    {
                      string range = UserTopics();
                      //string sql = " select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount" +
                      //             " From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0"+                       
                      //             " And ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))";      
                      string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                        dtForum = DBobj.ExecuteDTQuery(sql);
                    }
                    gridForum.DataSource = dtForum; 
                    gridForum.DataBind();
                    if (gridForum.Rows.Count > 0)
                    {                    
                        ForumGridVisible();                                                
                        hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
                    }
                    else
                    {
                        NoDataVisible();                        
                    }
                                       
                    // Label Heading Display
                    lblHeading.Text = varMainRoot;
                }
                
            }

            if (newpost.InnerHtml != "Edit" && newpost.InnerHtml != "Edit Post")
            {
                // Funcation to Load the Dynamic Tables for Post and Replies
                LoadTable();
            }
            else if (newpost.InnerHtml == "Edit Post")
            {
                //Response.Redirect("Discussion.aspx?ForumID=" + hforumID.Value + "&TypeID=" + htypeID.Value);
                BindGrid(int.Parse(hforumID.Value));

            }

            string msg;
              
            if (htypeID.Value == "0")
                msg = "Deleting this Group will Clear the Topic(s) in this Group.";
            else if (htypeID.Value == "1")
                msg = "Deleting this Topic will Clear the Post(s) in this Topic.";
            else
                msg = "Deleting this Folder will Clear the Group(s) in this Folder.";


            
            if (gridForum.Visible == true)
            {
                btnDelete.Attributes.Add("onclick", "javascript: return (IsCheckBoxSelected('gridForum','chkDelete1','" + msg + "'))");
            }
            else if (gridThread.Visible == true)
            {
                msg = "Deleting this Post will Clear the Replies in this Post.";
                btnDelete.Attributes.Add("onclick", "javascript: return (IsCheckBoxSelected('gridThread','chkDelete2','" + msg + "'))");
            }
            
            //Searching Code Start            
            //hdelete.Value == "" &&  
            if (txtForumSearch.Text.Trim() != "")
            {             
                   Session["Thread"] = "Yes";
                   Session["Searcword"] = txtForumSearch.Text;
                   Forumsearch(txtForumSearch.Text);
                   txtForumSearch.Text = "";                        
            }
            //Search Coding End

            trvForum.Focus();
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }
    }

    
    protected void trvForum_SelectedNodeChanged(object sender, EventArgs e)
    {
        bool bex = false;
        try
        {
            newpost.InnerHtml = "Edit";
            lblHeading.Text = trvForum.SelectedNode.Text;
            lblID.Text = trvForum.SelectedNode.Value;
            if (trvForum.SelectedNode.Text != varMainRoot)
            {
                htypeID.Value = GetTypeID(lblID.Text);
                hforumID.Value = GetForumID(lblID.Text);                    
                Session["ParentID"] = GetParentID(lblID.Text);
                bex = true;
                Response.Redirect("Discussion.aspx?ForumID=" + hforumID.Value + "&TypeID=" + htypeID.Value);
            }
            else
            {
                Response.Redirect("Discussion.aspx");
            }            

        }
        catch (Exception ex)
        {
            if (bex == false)               
                lblError.Text = ex.Message;
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            hdelete.Value = "";
            if (gridForum.Visible == true)
            {
                for (int i = 0; i < gridForum.Rows.Count; i++)
                {
                    GridViewRow row = gridForum.Rows[i];
                    bool ForumChecked = ((CheckBox)(row.FindControl("chkDelete1"))).Checked;                    
                    if (ForumChecked)
                    {
                        Label lb = (Label)row.FindControl("lblDelete1");
                        DBobj.DelforumID = lb.Text; 
                        DBobj.DeleteForum();
                    }
                }        

            }
            else if (gridThread.Visible == true)
            {
                if (hforumID.Value != "")
                {
                    DBobj.ForumID = int.Parse(hforumID.Value);
                    for (int i = 0; i < gridThread.Rows.Count; i++)
                    {
                        GridViewRow row = gridThread.Rows[i];
                        bool ThreadChecked = ((CheckBox)(row.FindControl("chkDelete2"))).Checked;
                        //bool ThreadChecked = ((CheckBox)(gridThread.Rows[i].Cells[9].FindControl("chkDelete2"))).Checked;
                        //int test = int.Parse(row.Cells[5].Text);

                        if (ThreadChecked)
                        {
                            Label lb = (Label)row.FindControl("lblDelete2");
                            DBobj.DelthreadID = lb.Text;
                            DBobj.DeleteThread();
                        }
                    }
                }
            }
            BindTree();
            trvForum.ExpandAll();

            if (hforumID.Value != "")
                BindGrid(int.Parse(hforumID.Value));
            else
            {
                if (Session["UserType"].ToString() == "Admin")
                {
                    SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    dtForum = DBobj.ExecuteDTQuery(cmdselect);
                }
                else
                {
                    string range = UserTopics();
                    string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                   
                    dtForum = DBobj.ExecuteDTQuery(sql);
                }
                //SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                //cmdselect.CommandType = CommandType.StoredProcedure;
                //dtForum = DBobj.ExecuteDTQuery(cmdselect);
                gridForum.DataSource = dtForum;
                gridForum.DataBind();
                if (gridForum.Rows.Count > 0)
                {
                    ForumGridVisible();
                    hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
                }
                else
                    NoDataVisible();
            }

            if (htypeID.Value != "")
            {
                if (int.Parse(htypeID.Value) > 1)
                    btnNewPost.Visible = true;
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (htypeID.Value != "")
            {
                if (int.Parse(htypeID.Value) == 0)
                    newforum.InnerHtml = "Add New Group";
                else
                    newforum.InnerHtml = "Add New Topic";
            }

            else
            {
                newforum.InnerHtml = "Add New Folder";
            }

            tblNewforum.Visible = true;
            gridForum.Visible = false;
            gridThread.Visible = false;
            tblReply.Visible = false;
            btnReply.Visible = false;
            btnCancel.Visible = false;
            tblnodata.Visible = false;
            btnAdd.Visible = false;
            btnNewPost.Visible = false;
            btnDelete.Visible = false;
            btnCancel.Visible = false;
            txtTitle.Text = "";
            txtDesc.Text = "";
            txtTitle.Focus();
        }
        catch (Exception ex)
        {
           lblError.Text = ex.Message;
        }


    }

    protected void btnReply_ServerClick(object sender, EventArgs e)
    {
        newpost.InnerHtml = "Reply";
        NewPostVisible();        
        txtMsg.Text = "";
        SqlCommand cmdselect = new SqlCommand("sp_select_ThreadSub");
        cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(hthreadID.Value));
        cmdselect.CommandType = CommandType.StoredProcedure;
        txtSub.Text = "Re : " + DBobj.ExecuteScalar(cmdselect);
        txtMsg.Focus();
    }

    protected void btnNewPost_Click(object sender, EventArgs e)
    {
        hthreadID.Value = "";
        newpost.InnerHtml = "Add New Post";
        NewPostVisible();        
        txtMsg.Text = "";
        txtSub.Text = "";
        txtSub.Focus();
    }

    protected void BindGrid(int forumID)
    {
        Session["Thread"] = "No";
        SqlCommand cmdselect = new SqlCommand("sp_select_ForumParentID");
        cmdselect.CommandType = CommandType.StoredProcedure;
        cmdselect.Parameters.AddWithValue("@varForumID", forumID.ToString());        
        dtForum = DBobj.ExecuteDTQuery(cmdselect);
        gridForum.DataSource = dtForum;
        gridForum.DataBind();
        // Changes by Karthik to display user based topics on the Grid
        if (Session["UserType"].ToString() != "Admin")
        {
            string range = UserTopics();
            string sql = "";
            if (Request.QueryString["TypeID"].ToString() == "0")
            {
                sql = " select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount" +
                       " From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and cast(ParentId as nvarchar(100)) in (" + forumID.ToString() + ")";

                //DataTable dtcheck = DBobj.ExecuteDTQuery("select ForumId From Forum  Where isDelete=0 and ParentId in (" + forumID.ToString() + ")");
                //string flag="No";
                //for (int i=0;i< dtcheck.Rows.Count;i++)
                //{
                //    if (range.Contains(dtcheck.Rows[i][0].ToString()))
                //        flag = "Yes";
                //}                
                //if (flag == "Yes")
                //      sql += " And ForumId in (select ParentId From Forum  Where isDelete=0 and (Forumid in ("+ range +") or Parentid in ("+ range +")))";
                //  else
                //      sql += " And ForumId in (select ParentId From Forum  Where isDelete=0 and (Forumid in (" + range + ") or Parentid in (" + range + ")))";

                if (!range.Contains(forumID.ToString()))
                        sql += " And ForumId in (select ParentId From Forum  Where isDelete=0 and (Forumid in (" + range + ") or Parentid in (" + range + ")))";

                  sql += " Order by A.CreatedOn";

            }
            else if (Request.QueryString["TypeID"].ToString() == "1")
            {
                sql = "Select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount " +
                               " From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID " +
                               " And CAST(ParentID AS nvarchar(100)) in ( " + forumID.ToString() + ") ";
                // Parent Id checking 
                string pidcheck = DBobj.ExecuteScalar("select ParentId From Forum  Where isDelete=0 and ForumId in (" + forumID.ToString() + ")");
                     if (!range.Contains(forumID.ToString()) && !range.Contains(pidcheck.ToString()))
                              sql += " And CAST(ForumId  as nvarchar(2000)) in (" + range + ")" ;
                     sql += " Order by A.CreatedOn";
            }
            else if (Request.QueryString["TypeID"].ToString() == "2")
            {
                sql = " Select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount " +
                         " From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID " +
                         " And CAST(ParentID AS nvarchar(100)) in ( " + forumID.ToString() + ") " +
                    //" And CAST(ForumId  as nvarchar(2000)) in (" + range + ") " +
                         " Order by A.CreatedOn  ";
            }
            //else
            //{
            //    sql = " select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount" +
            //          " From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0" +
            //          " And ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + "))";                

            //}

            DataTable dtUserForum = new DataTable();
            SqlCommand command = new SqlCommand(sql);
            command.CommandType = CommandType.Text;
            dtUserForum = DBobj.ExecuteDTQuery(command);
            gridForum.DataSource = dtUserForum;
            gridForum.DataBind();

        }  //Changes ends here
        if (gridForum.Rows.Count > 0)
        {
            ForumGridVisible();          
            hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
        }
        else
        {
            SqlCommand cmdselect1 = new SqlCommand("sp_select_Thread");
            cmdselect1.CommandType = CommandType.StoredProcedure;
            cmdselect1.Parameters.AddWithValue("@varForumID", forumID);
            dtThread = DBobj.ExecuteDTQuery(cmdselect1);
            gridThread.DataSource = dtThread;
            gridThread.DataBind();
            if (gridThread.Rows.Count > 0)
            {
                ThreadGridVisible();                
                hpage.Value = gridThread.BottomPagerRow.Visible.ToString();
            }
            else
            {
                NoDataVisible();                
            }
        }

    }

    protected void BindTree()
    {
        trvForum.Nodes.Clear();        
        TreeNode MainRoot = new TreeNode();
        trvForum.CssClass = "ClsTreeviewLeaf";
        MainRoot.Text = varMainRoot;
        trvForum.Nodes.Add(MainRoot);        
        SqlCommand cmdselect;
        if (Session["UserType"].ToString() == "Admin")
        {
            cmdselect = new SqlCommand("sp_select_AllForum");
            cmdselect.CommandType = CommandType.StoredProcedure;
            DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
        }
        else //changes by karthik for user based forum listings on treeview
        {
            
           //if (!IsPostBack)
            //{
            //    if (Request.QueryString["ForumID"] != null)
            //    {
            //        if (Session["Count"] != "1")
            //        {
            //            hdnFId.Value = Request.QueryString["ForumID"];
            //            hdnType.Value = Request.QueryString["TypeID"];
            //            //Session["Count"] = "1";
            //            Session["Fid"] = hdnFId.Value;
            //        }
            //        else
            //        {
            //            hdnFId.Value = Session["Fid"].ToString();
            //            hdnType.Value = Request.QueryString["TypeID"];
            //            Session["Count"] = "0";
            //        }

            //    }
            //    else
            //    {
            //        if (Request.QueryString.Count > 1)
            //        {
            //            hdnFId.Value = Session["Fid"].ToString();
            //            hdnType.Value = Request.QueryString["TypeID"];
            //        }
            //        else
            //        {
            //            //hdnFId.Value = "0";
            //            //hdnType.Value = "0";
            //        }
            //        if (Request.QueryString["ThreadID"] != null)
            //        {
            //            hdnFId.Value = Session["Fid"].ToString();
            //            hdnType.Value = "2";
            //        }

            //        Session["Count"] = "0";
            //    }
            //}

            
            //if (hdnType.Value == "0")
            //{

            //    /*sql = " select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0  and Forumid in (" + range + ") or (cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "" +
            //          " or (ForumId in  (select Distinct ParentID from Forum where isdelete = 0  and cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "))" +
            //          " or cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + ")) "+
            //          " union select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and cast(ForumID as nvarchar(100)) in (select ParentId From Forum where ForumID = " + hdnFId.Value + ")";
            //    */
            //    sql = " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and Forumid in ("+ hdnFId.Value +") union"+
            //          " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + ") and forumId in (Select ParentID from Forum where ForumId in (select Distinct ForumID From Forum where ParentID in ( select ForumID from Forum where isdelete = 0   and cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + ")))  and Forumid in (" + range + "))" +
            //          " union Select ForumID, Name, TypeID, ParentID from Forum where ForumId in ( select Distinct ForumID From Forum where ParentID in ( select ForumID from Forum where isdelete = 0 and cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + "))) and Forumid in (" + range + ")";
            //}
            //else if (hdnType.Value == "1")
            //{

            //    /*sql = " select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0  and Forumid in (" + range + ") and (cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "" +
            //          " or (ForumId in  (select Distinct ParentID from Forum where isdelete = 0  and cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "))" +
            //          " or cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + ")) " +
            //          " union select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and cast(ForumID as nvarchar(100)) in (select ParentId From Forum where ForumID = " + hdnFId.Value + ")";
            //    */
            //    sql = " select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0  and (Forumid in (" + range + ") and cast(ParentId as nvarchar(100)) in (" + hdnFId.Value + ")) or cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "" +
            //          " union select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and cast(ForumID as nvarchar(100)) in (select ParentId From Forum where ForumID = " + hdnFId.Value + ")";
            //}
            //else if (hdnType.Value == "2")
            //{
            //    sql = "Select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and Forumid in (" + range + ") and cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + "" +
            //          " and cast(TypeID AS nvarchar(100)) = (select TypeID from Forum where cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + ")" +
            //          " union Select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and cast(ForumID AS nvarchar(100)) = (select ParentID from Forum where cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + ")" +
            //          " union Select ForumID, Name, TypeID, ParentID from Forum where isdelete = 0 and cast(ParentID AS nvarchar(100)) = 0 and cast(ForumID AS nvarchar(100)) =" +
            //          " (Select ParentID from Forum where isdelete = 0 and ForumId = ( select ParentID from Forum where cast(ForumID AS nvarchar(100)) = " + hdnFId.Value + " ))";
            //}
            //    //For Discussion Root Node
            //else
            //{
            //    sql = " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and forumId in (Select ParentID from Forum where  Forumid in (" + range + ")) union Select ForumID, Name, TypeID, ParentID from Forum where ForumId in (" + range + ") union Select ForumID, Name, TypeID, ParentID from Forum where ForumId in ( select ParentID  from Forum where isdelete = 0   and forumId in (Select ParentID from Forum where  Forumid in (" + range + ")) and Typeid=1) union Select  ForumID, Name, TypeID, ParentID from Forum where ForumId in (" + range + ")";
            //}

            string sql = "";            
            string range = UserTopics();
            string[] rangeData = new string[1000];
            string[] typeIdsData = new string[1000];
            rangeData = range.Split(',');
            typeIdsData = typeIds.Split(',');
            for (int i = 0; i <= rangeData.Length -1; i++)
            {
                if (typeIdsData[i] == "0")
                {
                     folderIds += rangeData[i] +",";
                }
                else if (typeIdsData[i] == "1")
                {
                     groupIds += rangeData[i] +",";
                }
                else if (typeIdsData[i] == "2")
                {
                     topicIds += rangeData[i] +",";
                }
            }
            if (folderIds.Length >0)  
            {
                folderIds = folderIds.Remove(folderIds.Length -1);
                sql = " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (" + folderIds + ")" +
                      " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ParentId in (" + folderIds + ")" +
                      " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ParentId in (select ForumID from Forum where isdelete = 0  and ParentId in (" + folderIds + "))";

            }
            if (groupIds.Length >0)
            {
                groupIds  = groupIds.Remove(groupIds.Length -1);
                if (sql != "") sql += " Union ";
                sql += " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (" + groupIds + ")" +
                       " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ParentId in (" + groupIds + ") " +
                       " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + groupIds + "))"; 

            }
            if (topicIds.Length >0) 
            {
                topicIds  = topicIds.Remove(topicIds.Length -1);
                if (sql != "") sql += " Union ";
                sql += " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (" + topicIds + ")" +
                     " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + topicIds + "))" +
                     " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and ForumId in (select ParentId from Forum where isdelete = 0  and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + topicIds + ")))";

            }

            //sql = " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and forumId in (Select ParentID from Forum where  Forumid in (" + range + ")) union Select ForumID, Name, TypeID, ParentID from Forum where ForumId in (" + range + ") union Select ForumID, Name, TypeID, ParentID from Forum where ForumId in ( select ParentID  from Forum where isdelete = 0   and forumId in (Select ParentID from Forum where  Forumid in (" + range + ")) and Typeid=1) union Select  ForumID, Name, TypeID, ParentID from Forum where ForumId in (" + range + ")";
            sql += "Order by ForumId";
            DBobj.mydt = DBobj.ExecuteDTQuery(sql);

        }
        
        for (int i = 0; i < DBobj.mydt.Rows.Count; i++)
        {
            if (int.Parse(DBobj.mydt.Rows[i][2].ToString()) == 0)
            {
                TreeNode Root = new TreeNode();
                Root.Text = DBobj.mydt.Rows[i][1].ToString();
                Root.Value = DBobj.mydt.Rows[i][0] + "/" + DBobj.mydt.Rows[i][2] + "/" + DBobj.mydt.Rows[i][3];
                MainRoot.ChildNodes.Add(Root);
                for (int j = 0; j < DBobj.mydt.Rows.Count; j++)
                {
                    if (int.Parse(DBobj.mydt.Rows[i][0].ToString()) == int.Parse(DBobj.mydt.Rows[j][3].ToString()))
                    {
                        TreeNode Child = new TreeNode();
                        Child.Text = DBobj.mydt.Rows[j][1].ToString();
                        Child.Value = DBobj.mydt.Rows[j][0] + "/" + DBobj.mydt.Rows[j][2] + "/" + DBobj.mydt.Rows[j][3];
                        Root.ChildNodes.Add(Child);
                        for (int k = 0; k < DBobj.mydt.Rows.Count; k++)
                        {
                            if (int.Parse(DBobj.mydt.Rows[j][0].ToString()) == int.Parse(DBobj.mydt.Rows[k][3].ToString()))
                            {
                                TreeNode SubChild = new TreeNode();
                                SubChild.Text = DBobj.mydt.Rows[k][1].ToString();
                                SubChild.Value = DBobj.mydt.Rows[k][0] + "/" + DBobj.mydt.Rows[k][2] + "/" + DBobj.mydt.Rows[k][3];
                                Child.ChildNodes.Add(SubChild);
                            }
                        }
                    }

                }
            }
        }
    }


    protected Table TableCreation(string tdthreadID, string username, string postdate, string subject, string message, string messagetype, string attachfile, string smile)
    {
        Table tbl = new Table();
        tbl.Width = Unit.Percentage(98);
        tbl.CellPadding = 0;
        tbl.CellSpacing = 0;
        tbl.CssClass = "ClsTdPost";
        Panel2.Controls.Add(tbl);

        TableRow tr1 = new TableRow();
        tbl.Rows.Add(tr1);
        TableCell td1 = new TableCell();
        td1.ColumnSpan = 2;
        td1.Width = Unit.Percentage(25);
        td1.Height = Unit.Pixel(25);
        td1.CssClass = "ClsTDDate";         
        dTime = Convert.ToDateTime(postdate);
        td1.Text = DBobj.GetDBDateFormatUK(dTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
        tr1.Cells.Add(td1);

        if (Session["UserType"].ToString() == "Admin")
        {
            TableCell td = new TableCell();
            td.CssClass = "ClsTDButton";
            td.Height = Unit.Pixel(25);
            td.Width = Unit.Percentage(75);
            Button tdbtnEdit = new Button();
            Button tdbtnDelete = new Button();
            tdbtnEdit.CssClass = "ClsButton";
            tdbtnDelete.CssClass = "ClsButton";
            tdbtnEdit.Text = "Edit";
            tdbtnDelete.Text = "Delete";            
            tdbtnEdit.CommandArgument = tdthreadID;
            tdbtnDelete.CommandArgument = tdthreadID;   
            
            tdbtnEdit.Click += new EventHandler(tdbtnEdit_Click);
            tdbtnDelete.Click += new EventHandler(tdbtnDelete_Click);            
            tdbtnDelete.Attributes.Add("onclick", "javascript: return (DeleteCon())");
            td.Controls.Add(tdbtnEdit);
            td.Controls.Add(tdbtnDelete);
            tr1.Cells.Add(td);
        }
        else if (Session["UserType"].ToString() == "Manager")
        {

            TableCell td = new TableCell();
            td.CssClass = "ClsTDButton";
            td.Height = Unit.Pixel(25);
            td.Width = Unit.Percentage(75);
            Button tdbtnEdit = new Button();
            tdbtnEdit.CssClass = "ClsButton";
            tdbtnEdit.Text = "Edit";
            tdbtnEdit.ID = "E" + tdthreadID;
            tdbtnEdit.Click += new EventHandler(tdbtnEdit_Click);
            td.Controls.Add(tdbtnEdit);
            tr1.Cells.Add(td);
        }
        else
        {
            TableCell td = new TableCell();
            td.CssClass = "ClsTDButton";
            td.Height = Unit.Pixel(25);
            td.Width = Unit.Percentage(75);
            tr1.Cells.Add(td);
        }


        TableRow tr2 = new TableRow();
        tbl.Rows.Add(tr2);
        TableCell td2 = new TableCell();
        td2.Width = Unit.Percentage(25);
        td2.RowSpan = 3;
        td2.CssClass = "ClsTDUser";
        td2.Text = username;
        tr2.Cells.Add(td2);

        TableCell td3 = new TableCell();
        td3.CssClass = "ClsTDSubject";
        td3.Width = Unit.Percentage(75);
        td3.Height = Unit.Pixel(20);
        td3.ColumnSpan = 2;
        if (smile != "" &&  smile != "z2")
        { td3.Text = String.Format("<img src='{0}'>", "../Images/Forum/smiles/" + smile + ".gif") + "    " + subject; }
        else
        { td3.Text = subject; }
        tr2.Cells.Add(td3);

        TableRow tr3 = new TableRow();
        tbl.Rows.Add(tr3);
        TableCell td5 = new TableCell();
        td5.ColumnSpan = 2;
        td5.Height = Unit.Pixel(100);
        td5.Width = Unit.Percentage(75);
        if (messagetype == "P")
        { td5.CssClass = "ClsTDMessagePost"; }
        else
        { td5.CssClass = "ClsTDMessageReply"; }

        HtmlTable htmltb = new HtmlTable();
        HtmlTableRow htmlrow = new HtmlTableRow();
        HtmlTableCell htmlcell = new HtmlTableCell();
        htmlcell.Attributes.Add("class", "ClsLabel");        
        htmlcell.InnerHtml = message.Replace("\n", "<br>");                
        htmltb.Rows.Add(htmlrow);
        htmlrow.Cells.Add(htmlcell);
        td5.Controls.Add(htmltb);   
        tr3.Cells.Add(td5);
        if (attachfile != "")
        {
            TableRow tr4 = new TableRow();
            TableCell td6 = new TableCell();
            tbl.Rows.Add(tr4);
            td6.Width = Unit.Percentage(15);
            td6.Height = Unit.Pixel(12);
            td6.CssClass = "ClsTDAttach";
            td6.Text = "Attachment:";
            tr4.Cells.Add(td6);

            TableCell td7 = new TableCell();
            td7.CssClass = "ClsTDAttachfile";
            td7.Width = Unit.Percentage(60);
            td3.Height = Unit.Pixel(12);
            LinkButton lnkbtn = new LinkButton();
            lnkbtn.Text = attachfile;
            lnkbtn.Click += new EventHandler(lnkbtn_Click);
            td7.Controls.Add(lnkbtn);
            tr4.Cells.Add(td7);
        }
        else
        {
            TableRow tr4 = new TableRow();
            tbl.Rows.Add(tr4);
            TableCell td6 = new TableCell();
            td6.ColumnSpan = 2;
            td6.CssClass = "ClsTDEmpty";
            td6.Width = Unit.Percentage(75);
            td6.Height = Unit.Pixel(12);
            tr4.Cells.Add(td6);
        }

        TableRow trb = new TableRow();
        trb.Height = Unit.Pixel(15);
        tbl.Rows.Add(trb);

        return tbl;
    }
    void tdbtnDelete_Click(object sender, EventArgs e)
    {
        bool bex = false;
        try
        {
            //Button bt = (Button)(sender);
            //DBobj.ThreadID = int.Parse(bt.ID.Substring(1));
            string bt = ((Button)(sender)).CommandArgument.ToString();
            DBobj.ThreadID = int.Parse(bt);
            SqlCommand cmdselect = new SqlCommand("sp_select_ThreadParentIDOnly");
            cmdselect.CommandType = CommandType.StoredProcedure;
            cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(bt));
            DBobj.ForumID = int.Parse(hforumID.Value.ToString());
            DBobj.ParentID = int.Parse(DBobj.ExecuteScalar(cmdselect).ToString());
            DBobj.DeleteReplyThread();
            if (DBobj.ParentID != 0)
            {
                bex = true;
                Response.Redirect("Discussion.aspx?ThreadID=" + Request.QueryString["ThreadID"]);
            }
            else
            {
                SqlCommand cmdselect1 = new SqlCommand("sp_select_ForumName");
                cmdselect1.Parameters.AddWithValue("@numForumID", int.Parse(hforumID.Value));
                cmdselect1.CommandType = CommandType.StoredProcedure;
                htypeID.Value = DBobj.ExecuteScalar(cmdselect1);
                bex = true;
                Response.Redirect("Discussion.aspx?ForumID=" + hforumID.Value + "&TypeID=" + htypeID.Value);
            }            
        }
        catch (Exception ex)
        {
            if (bex == false)                
                lblError.Text = ex.Message;
        }

    }

    void tdbtnEdit_Click(object sender, EventArgs e)
    {
        string bt = ((Button)(sender)).CommandArgument.ToString();
        ThreadEdit(int.Parse(bt));
        newpost.InnerHtml = "Edit";
    }


    void lnkbtn_Click(object sender, EventArgs e)
    {
        string sl = Server.MapPath("../Images/Forum/Uploads/" + ((LinkButton)(sender)).Text);
        System.IO.FileInfo file = new System.IO.FileInfo(sl);
        if (file.Exists)
        {
            Response.AddHeader("Content-Disposition", "attachment; filename =" + file.Name);
            Response.AddHeader("Content-Length", file.Length.ToString());
            Response.ContentType = "application/octet-stream";
            Response.WriteFile(file.FullName);
            Response.End();
        }
        else
        {
            Response.Write("<script langauge='javascript'> alert('File Does Not Exist'); </script>");
        }
    }


    protected void gridForum_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (e.NewPageIndex != -1)
        {
            e.Cancel = true;
            gridForum.PageIndex = e.NewPageIndex;
            if (hforumID.Value != "")
            {
                SqlCommand cmdselect = new SqlCommand("sp_select_ForumParentID");
                cmdselect.CommandType = CommandType.StoredProcedure;
                cmdselect.Parameters.AddWithValue("@varForumID", hforumID.Value);                
                dtForum = DBobj.ExecuteDTQuery(cmdselect);
            }
            else
            {
                //SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                //cmdselect.CommandType = CommandType.StoredProcedure;
                //dtForum = DBobj.ExecuteDTQuery(cmdselect);    
                if (Session["UserType"].ToString() == "Admin")
                {
                    SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    dtForum = DBobj.ExecuteDTQuery(cmdselect);
                }
                else
                {
                    string range = UserTopics();
                    string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                    dtForum = DBobj.ExecuteDTQuery(sql);
                }
            }
            gridForum.DataSource = dtForum;
            gridForum.DataBind();      
            hpage.Value = gridForum.BottomPagerRow.Visible.ToString();                 
        }

    }

    protected string GetForumID(string str)
    {
        string forumID = "";
        for (int i = 0; i < (str.Length); i++)
        {
            if (str[i] != '/')
                forumID = forumID + str[i];
            else
                break;
        }
        return forumID;
    }

    protected string GetTypeID(string str)
    {
        int count = 0;
        string typeID = "";
        for (int i = 0; i < (str.Length); i++)
        {
            if (str[i] == '/')
            {
                count++;
                i++;
            }
            if (count == 1)
                typeID = typeID + str[i];
        }
        return typeID;
    }

    protected string GetParentID(string str)
    {
        int count = 0;
        string parentID = "";
        for (int i = 0; i < (str.Length); i++)
        {
            if (str[i] == '/')
            {
                count++;
                i++;
            }
            if (count > 1)
                parentID = parentID + str[i];
        }
        return parentID;
    }

    protected void gridThread_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        if (e.NewPageIndex != -1)
        {
            e.Cancel = true;
            gridThread.PageIndex = e.NewPageIndex;
            if (Session["Thread"].ToString() == "Yes")
            {
                //SqlCommand cmdselect1 = new SqlCommand("sp_select_Thread_Search");
                //cmdselect1.CommandType = CommandType.StoredProcedure;
                //cmdselect1.Parameters.AddWithValue("@varSearch", Session["Searcword"]);
                //dtThread = DBobj.ExecuteDTQuery(cmdselect1);
                Forumsearch(Session["Searcword"].ToString());
            }
            else
            {

                SqlCommand cmdselect = new SqlCommand("sp_select_Thread");
                cmdselect.CommandType = CommandType.StoredProcedure;
                cmdselect.Parameters.AddWithValue("@varForumID", hforumID.Value);
                dtThread = DBobj.ExecuteDTQuery(cmdselect);
            }
            gridThread.DataSource = dtThread;
            gridThread.DataBind();
            hpage.Value = gridThread.BottomPagerRow.Visible.ToString();       
        }

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        try
        {
            txtForumSearch.Text = ""; 
            if (Session["UserId"].ToString() != "")
            {
                if (newforum.InnerHtml != "Edit")
                {
                    if (htypeID.Value != "")
                    {
                        if (int.Parse(htypeID.Value) == 0 || int.Parse(htypeID.Value) == 1)
                        {
                            DBobj.TypeID = (int.Parse(htypeID.Value) + 1);
                            DBobj.ParentID = int.Parse(hforumID.Value);
                        }
                        else
                        {
                            DBobj.TypeID = (int.Parse(htypeID.Value));                           
                            DBobj.ParentID = int.Parse(Session["ParentID"].ToString());
                        }
                        
                    }
                    else
                    {
                        DBobj.TypeID = 0;
                        DBobj.ParentID = 0;
                        DBobj.ForumID = 0;
                    }
                    DBobj.Name = txtTitle.Text;
                    DBobj.Desc = txtDesc.Text;
                    DBobj.Threadcount = 0;
                    DBobj.Createdby = int.Parse(Session["UserId"].ToString());
                    DBobj.Editedby = int.Parse(Session["UserId"].ToString());
                    DBobj.CreateForum();
                    txtDesc.Text = "";
                    txtTitle.Text = "";
                    if (hforumID.Value != "")
                    {BindGrid(int.Parse(hforumID.Value));}                    
                }
                else
                {
                    DBobj.Name = txtTitle.Text;
                    DBobj.Desc = txtDesc.Text;
                    DBobj.ForumID = (int.Parse(hforumID.Value));
                    DBobj.TypeID = (int.Parse(htypeID.Value));
                    DBobj.ParentID = int.Parse(Session["ParentID"].ToString());
                    DBobj.Editedby = int.Parse(Session["UserId"].ToString());
                    DBobj.Editedon = System.DateTime.Now;
                    DBobj.UpdateForum();
                    txtDesc.Text = "";
                    txtTitle.Text = "";
                    if (hforumID.Value != "")
                    { BindGrid(int.Parse(hforumID.Value)); }
                }
                BindTree();
                trvForum.ExpandAll();

                if (Request.QueryString["ForumID"] != null)
                {
                    hforumID.Value = Request.QueryString["ForumID"].ToString();
                    BindGrid(int.Parse(hforumID.Value));
                    if (int.Parse(htypeID.Value) > 1) btnNewPost.Visible = true;
                    // Display the Select Item in LblHeading
                    DisplayHeading();

                }
                else if (Request.QueryString["ThreadID"] != null)
                {
                    SqlCommand cmdselect = new SqlCommand("sp_select_ThreadForumID");
                    cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(Request.QueryString["ThreadID"].ToString()));
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    hforumID.Value = DBobj.ExecuteScalar(cmdselect);
                    BindGrid(int.Parse(hforumID.Value));
                    DisplayHeading();
                    btnNewPost.Visible = true;
                }
                else
                {
                    //SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                    //cmdselect.CommandType = CommandType.StoredProcedure;
                    //dtForum = DBobj.ExecuteDTQuery(cmdselect);
                    if (Session["UserType"].ToString() == "Admin")
                    {
                        SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                        cmdselect.CommandType = CommandType.StoredProcedure;
                        dtForum = DBobj.ExecuteDTQuery(cmdselect);
                    }
                    else
                    {
                        string range = UserTopics();
                        string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                        dtForum = DBobj.ExecuteDTQuery(sql);
                    }
                    gridForum.DataSource = dtForum;
                    gridForum.DataBind();
                    if (gridForum.Rows.Count > 0)
                    {
                        ForumGridVisible();
                        hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
                    }
                    else
                    {
                        NoDataVisible();                        
                    }
                    // Label Heading Display
                    lblHeading.Text = varMainRoot;
                }
                

            }

        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        bool bex = false;
        try
        {
            Int16 uploadStatus, messageType, rCount = 0, vCount = 0;
            string threadID;
            txtForumSearch.Text = "";
            if (Session["UserId"].ToString() != "")
            {
                if (newpost.InnerHtml != "Edit" && newpost.InnerHtml != "Edit Post")
                {
                    if (fileAttach.Value.Trim() == "")     // File attachment 0 - No, 1 - Yes 
                        uploadStatus = 0;
                    else
                    {
                        uploadStatus = 1;
                        fileAttach.PostedFile.SaveAs(Server.MapPath("../Images/Forum/Uploads") + fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\")));
                        //fileAttach.PostedFile.SaveAs(fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\")));
                    }

                    if (hthreadID.Value != "")         // Message type 0 - New Post, 1 - Reply
                    {
                        messageType = 1;
                        DBobj.ParentID = int.Parse(hthreadID.Value);
                    }
                    else
                    {
                        messageType = 0;
                        DBobj.ParentID = 0;
                    }

                    DBobj.ForumID = int.Parse(hforumID.Value);
                    DBobj.Subject = txtSub.Text;
                    DBobj.Body = txtMsg.Text;
                    DBobj.Uploadstatus = uploadStatus;
                    DBobj.Messagetype = messageType;
                    if (rdobtnSmile.SelectedItem != null)
                        DBobj.SmileID = int.Parse(rdobtnSmile.SelectedItem.Value);
                    else
                        DBobj.SmileID = 0;
                    DBobj.Createdby = int.Parse(Session["UserId"].ToString());
                    DBobj.Lastpostby = int.Parse(Session["UserId"].ToString());
                    DBobj.Replycount = rCount;
                    DBobj.Viewcount = vCount;
                    DBobj.CreateThread();
                    DBobj.LastDateUpdate();
                    if (messageType == 1)
                    {
                        DBobj.ThreadID = int.Parse(hthreadID.Value);
                        DBobj.FnReplyCount();
                        DBobj.LastPostUpdate();
                        MailSend(int.Parse(hthreadID.Value));
                        hthreadID.Value = "";
                    }
                    else
                    {
                        DBobj.ForumID = int.Parse(hforumID.Value);
                        DBobj.FnThreadCount();
                    }

                    // if upload file is yes Store the Data
                    if (uploadStatus == 1)
                    {
                        threadID = DBobj.ExecuteScalar("Select max(ThreadID) from Forumthread");
                        DBobj.ThreadID = int.Parse(threadID);
                        //DBobj.Filenames = "uploads/" + fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\") + 1);
                        DBobj.Filenames = fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\") + 1);
                        DBobj.Filesize = fileAttach.PostedFile.ContentLength;
                        DBobj.Filetype = fileAttach.PostedFile.ContentType;
                        DBobj.Createdby = int.Parse(Session["UserId"].ToString());
                        DBobj.CreateUpload();
                    }
                    txtMsg.Text = "";
                    txtSub.Text = "";
                    if (newpost.InnerHtml == "Reply")
                    {
                        bex = true;
                        Response.Redirect("Discussion.aspx?ThreadID=" + Request.QueryString["ThreadID"]);
                    }
                    else
                    {
                        bex = true;
                        Response.Redirect("Discussion.aspx?ForumID=" + Request.QueryString["ForumID"] + "&TypeID=" + Request.QueryString["TypeID"]);
                    }
                }
                else
                {
                    if (fileAttach.Value.Trim() == "")     // File attachment 0 - No, 1 - Yes 
                        uploadStatus = 0;
                    else
                    {
                        uploadStatus = 1;
                        fileAttach.PostedFile.SaveAs(Server.MapPath("uploads") + fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\")));
                        //fileAttach.PostedFile.SaveAs(fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\")));
                    }

                    if (hthreadID.Value != "")         // Message type 0 - New Post, 1 - Reply
                    {
                        messageType = 1;
                        DBobj.ParentID = int.Parse(hthreadID.Value);
                    }
                    else
                    {
                        messageType = 0;
                        DBobj.ParentID = 0;
                    }
                    DBobj.ThreadID = int.Parse(hthreadID.Value);
                    DBobj.ForumID = int.Parse(hforumID.Value);
                    DBobj.Createdby = int.Parse(Session["UserId"].ToString());
                    DBobj.Lastpostby = int.Parse(Session["UserId"].ToString());
                    DBobj.Subject = txtSub.Text;
                    DBobj.Body = txtMsg.Text;
                    DBobj.Uploadstatus = uploadStatus;
                    DBobj.Messagetype = messageType;
                    if (rdobtnSmile.SelectedItem != null)
                        DBobj.SmileID = int.Parse(rdobtnSmile.SelectedItem.Value);
                    else
                        DBobj.SmileID = 0;

                    DBobj.UpdateThread();
                    DBobj.LastDateUpdate();
                    DBobj.LastPostUpdate();

                    // if upload file is yes Store the Data
                    SqlCommand cmdselect = new SqlCommand("sp_select_UploadID");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(hthreadID.Value));
                    DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
                    if (DBobj.mydt.Rows.Count > 0)
                        DBobj.UploadID = Convert.ToInt32(DBobj.mydt.Rows[0][0].ToString());
                    else
                        DBobj.UploadID = 0;

                    if (uploadStatus == 1)
                    {
                        DBobj.ThreadID = int.Parse(hthreadID.Value);
                        //DBobj.Filenames = "uploads/" + fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\") + 1);
                        DBobj.Filenames = fileAttach.PostedFile.FileName.Substring(fileAttach.PostedFile.FileName.LastIndexOf("\\") + 1);
                        DBobj.Filesize = fileAttach.PostedFile.ContentLength;
                        DBobj.Filetype = fileAttach.PostedFile.ContentType;
                        DBobj.Createdby = int.Parse(Session["UserId"].ToString());
                        DBobj.Editedby = int.Parse(Session["UserId"].ToString());
                        DBobj.Editedon = System.DateTime.Now;
                        if (DBobj.mydt.Rows.Count > 0)
                            DBobj.UpdateUpload();
                        else
                            DBobj.CreateUpload();
                    }
                    else
                    {
                        DBobj.DeleteUpload();
                    }
                    txtMsg.Text = "";
                    txtSub.Text = "";
                    if (newpost.InnerHtml == "Edit")
                    {
                        LoadTable();
                    }
                    else
                    {
                        bex = true;
                        Response.Redirect("Discussion.aspx?ForumID=" + hforumID.Value + "&TypeID=" + htypeID.Value);
                    }
                    newpost.InnerHtml = "New Post";
                }
            }

        }
        catch (Exception ex)
        {
            if (bex == false)
                lblError.Text = ex.Message;
        }
    }

    protected void SmilesLoad()
    {
        rdobtnSmile.Items.Clear();
        rdobtnSmile.RepeatDirection = RepeatDirection.Horizontal;
        rdobtnSmile.RepeatLayout = RepeatLayout.Table;
        rdobtnSmile.RepeatColumns = 9;
        DBobj.mydt = DBobj.ExecuteDTQuery("Select SmileName, SmileID from ForumSmile Order by SmileID");
        foreach (DataRow dr in DBobj.mydt.Rows)
        {
            this.rdobtnSmile.Items.Add(new ListItem(String.Format("<img src='{0}'>", "../Images/Forum/smiles/" + dr["SmileName"].ToString() + ".gif"), dr["SmileID"].ToString()));
        }

    }

    protected void btnCancel_ServerClick(object sender, EventArgs e)
    {
        bool bex = false;
        try
        {
            
            btnNewPost.Visible = true;
            newpost.InnerHtml = "Edit";
            if (Session["UserType"].ToString() == "Admin")
            {
                btnAdd.Visible = true;
                btnForumCancel.Visible = true;
            }

            if (hforumID.Value != "")
            {
                SqlCommand cmdselect = new SqlCommand("sp_select_ForumName");
                cmdselect.Parameters.AddWithValue("@numForumID", int.Parse(hforumID.Value));
                cmdselect.CommandType = CommandType.StoredProcedure;
                DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
                htypeID.Value = DBobj.mydt.Rows[0][0].ToString();
                bex = true;
                Response.Redirect("Discussion.aspx?ForumID=" + hforumID.Value + "&TypeID=" + htypeID.Value);

            }

        }
        catch (Exception ex)
        {
            if (bex == false)                                
                lblError.Text = ex.Message;
        }
    }

    protected void btnForumCancel_ServerClick(object sender, EventArgs e)
    {
        try
        {
            txtForumSearch.Text = "";
            // Display the Grid For correspondence Forum ID..
            if (Request.QueryString["ForumID"] != null)
            {
                hforumID.Value = Request.QueryString["ForumID"].ToString();
                BindGrid(int.Parse(hforumID.Value));
                if (int.Parse(htypeID.Value) > 1) btnNewPost.Visible = true;
                // Display the Select Item in LblHeading
                DisplayHeading();

            }
            else if (Request.QueryString["ThreadID"] != null)
            {
                SqlCommand cmdselect = new SqlCommand("sp_select_ThreadForumID");
                cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(Request.QueryString["ThreadID"].ToString()));
                cmdselect.CommandType = CommandType.StoredProcedure;
                hforumID.Value = DBobj.ExecuteScalar(cmdselect);
                BindGrid(int.Parse(hforumID.Value));
                DisplayHeading();
                btnNewPost.Visible = true;
            }
            else
            {
                //SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                //cmdselect.CommandType = CommandType.StoredProcedure;
                //dtForum = DBobj.ExecuteDTQuery(cmdselect);
                if (Session["UserType"].ToString() == "Admin")
                {
                    SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                    cmdselect.CommandType = CommandType.StoredProcedure;
                    dtForum = DBobj.ExecuteDTQuery(cmdselect);
                }
                else
                {
                    string range = UserTopics();
                    string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                    dtForum = DBobj.ExecuteDTQuery(sql);
                }
                gridForum.DataSource = dtForum;
                gridForum.DataBind();
                if (gridForum.Rows.Count > 0)
                {
                    ForumGridVisible();
                    hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
                }
                else
                {
                    NoDataVisible();                    
                }
                // Label Heading Display
                lblHeading.Text = varMainRoot;
            }

        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }

    }
    protected void btnPostCancel_ServerClick(object sender, EventArgs e)
    {
        bool bex = false; 
        try
        {
            txtForumSearch.Text = "";
            if (newpost.InnerHtml == "Add New Post" || newpost.InnerHtml == "Edit Post")
            {
                btnNewPost.Visible = true;
                btnForumCancel.Visible = true;
                BindGrid(int.Parse(hforumID.Value));
                DisplayHeading();
                trvForum.Focus();
            }
            else if (newpost.InnerHtml == "Edit")
            {
                //LoadTable();
                bex = true;
                Response.Redirect("Discussion.aspx?ThreadID=" + Request.QueryString["ThreadID"]);
            }
        }
        catch (Exception ex)
        {
            if(bex == false)            
                lblError.Text = ex.Message;
        }

    }

    protected void btnEdit1_Click(object sender, EventArgs e)
    {
        ImageButton img = (ImageButton)(sender);
        DBobj.ForumID = int.Parse(img.CommandName.ToString());
        DBobj.GetForumInfo();
        newforum.InnerHtml = "Edit";
        tblNewforum.Visible = true;
        gridForum.Visible = false;
        gridThread.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnCancel.Visible = false;
        btnDelete.Visible = false;
        btnAdd.Visible = false;
        tblnodata.Visible = false;
        txtTitle.Text = DBobj.Name;
        txtDesc.Text = DBobj.Desc;
        hforumID.Value = DBobj.ForumID.ToString();
        htypeID.Value = DBobj.TypeID.ToString();
        Session["ParentID"] = DBobj.ParentID.ToString();
        txtTitle.Focus();
    }

    protected void btnEdit2_Click(object sender, EventArgs e)
    {
        ImageButton img = (ImageButton)(sender);
        ThreadEdit(int.Parse(img.CommandName.ToString()));
        newpost.InnerHtml = "Edit Post";
        btnDelete.Visible = false;
        btnAdd.Visible = false;
    }

    protected void ThreadEdit(int threadid)
    {
        DBobj.ThreadID = threadid;
        DBobj.GetThreadInfo();
        tblNewpost.Visible = true;
        tblNewforum.Visible = false;
        gridForum.Visible = false;
        gridThread.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnCancel.Visible = false;
        tblnodata.Visible = false;
        txtSub.Text = DBobj.Subject;
        txtMsg.Text = DBobj.Body;
        hthreadID.Value = DBobj.ThreadID.ToString();
        hforumID.Value = DBobj.ForumID.ToString();
        SmilesLoad();        
        if(DBobj.SmileID >0)
        rdobtnSmile.Items[DBobj.SmileID-1].Selected = true;
        //if (DBobj.Filenames != "")
        //fileAttach.Value = DBobj.Filenames;                 
        txtSub.Focus();
    }

    protected void LoadTable()
    {
        if (Request.QueryString["ThreadID"] != null)
        {
            Panel2.Controls.Clear(); 
            hthreadID.Value = Request.QueryString["ThreadID"].ToString();
            SqlCommand cmdselect = new SqlCommand("sp_select_ThreadID");
            cmdselect.Parameters.AddWithValue("@numThreadID", int.Parse(Request.QueryString["ThreadID"].ToString()));
            cmdselect.CommandType = CommandType.StoredProcedure;
            DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
            if (DBobj.mydt.Rows.Count > 0)
            {
                //TableCreation(DBobj.mydt.Rows[0][0].ToString(), DBobj.mydt.Rows[0][2].ToString(), DBobj.mydt.Rows[0][3].ToString(), DBobj.mydt.Rows[0][4].ToString(), DBobj.mydt.Rows[0][5].ToString(), "P", DBobj.mydt.Rows[0][6].ToString(), DBobj.mydt.Rows[0][7].ToString());
                TableCreation(DBobj.mydt.Rows[0]["ThreadID"].ToString(), DBobj.mydt.Rows[0]["UserName"].ToString(), DBobj.mydt.Rows[0]["PostedOn"].ToString(), DBobj.mydt.Rows[0]["Subject"].ToString(), DBobj.mydt.Rows[0]["Body"].ToString(), "P", DBobj.mydt.Rows[0]["Filenames"].ToString(), DBobj.mydt.Rows[0]["SmileName"].ToString());
                hforumID.Value = DBobj.mydt.Rows[0][1].ToString();

                // Label Heading Display
                SqlCommand cmdhead = new SqlCommand("sp_select_ForumNameOnly");
                cmdhead.Parameters.AddWithValue("@numForumID", int.Parse(hforumID.Value));
                cmdhead.CommandType = CommandType.StoredProcedure;
                lblHeading.Text = "Topic : " + DBobj.ExecuteScalar(cmdhead) + "&nbsp&raquo&nbsp" + DBobj.mydt.Rows[0][4].ToString();

                SqlCommand cmdselect1 = new SqlCommand("sp_select_ThreadParentID");
                cmdselect1.Parameters.AddWithValue("@numThreadID", int.Parse(Request.QueryString["ThreadID"]));
                cmdselect1.CommandType = CommandType.StoredProcedure;
                DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect1);
                
                for (int k = 0; k < DBobj.mydt.Rows.Count; k++)
                {
                    //TableCreation(DBobj.mydt.Rows[k][0].ToString(), DBobj.mydt.Rows[k][1].ToString(), DBobj.mydt.Rows[k][2].ToString(), DBobj.mydt.Rows[k][3].ToString(), DBobj.mydt.Rows[k][4].ToString(), "R", DBobj.mydt.Rows[k][5].ToString(), DBobj.mydt.Rows[k][6].ToString());                    
                    TableCreation(DBobj.mydt.Rows[k]["ThreadID"].ToString(), DBobj.mydt.Rows[k]["UserName"].ToString(), DBobj.mydt.Rows[k]["PostedOn"].ToString(), DBobj.mydt.Rows[k]["Subject"].ToString(), DBobj.mydt.Rows[k]["Body"].ToString(), "R", DBobj.mydt.Rows[k]["Filenames"].ToString(), DBobj.mydt.Rows[k]["SmileName"].ToString());
                }                    
                
                if (!IsPostBack)
                {
                    DBobj.ThreadID = int.Parse(Request.QueryString["ThreadID"]);
                    DBobj.FnViewCount();
                }
                tblReply.Visible = true;
                btnReply.Visible = true;
                btnCancel.Visible = true;
                gridThread.Visible = false;
                gridForum.Visible = false;
                tblnodata.Visible = false;
                btnAdd.Visible = false;
                btnDelete.Visible = false;
                //tdsearch.Style.Add("display", "none"); 
            }
            else
            {
                ThreadGridVisible();                
            }
        }

    }

    protected void ForumGridVisible()
    {
        for (int irow = 0; irow < gridForum.Rows.Count; irow++)
        {
            if (gridForum.Rows[irow].Cells[4].Text != "")
            {
                dTime = Convert.ToDateTime(gridForum.Rows[irow].Cells[4].Text);
                gridForum.Rows[irow].Cells[5].Text = DBobj.GetDBDateFormatUK(dTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
            }
        }
        gridForum.Visible = true;
        gridThread.Visible = false;
        tblNewpost.Visible = false;
        tblnodata.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnCancel.Visible = false;
        tblNewforum.Visible = false;
        if (Session["UserType"].ToString() == "Admin")
        {
            btnAdd.Visible = true;
            btnDelete.Visible = true;
        }
    }

    protected void ThreadGridVisible()
    {
        for (int irow = 0; irow < gridThread.Rows.Count; irow++)
        {
            if (gridThread.Rows[irow].Cells[3].Text != "")
            {
                dTime = Convert.ToDateTime(gridThread.Rows[irow].Cells[3].Text);
                gridThread.Rows[irow].Cells[4].Text = DBobj.GetDBDateFormatUK(dTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
            }
        }
        gridThread.Visible = true;
        gridForum.Visible = false;
        tblNewpost.Visible = false;
        tblnodata.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnCancel.Visible = false;
        tblNewforum.Visible = false;
        if (Session["UserType"].ToString() == "Admin")
        {
            btnAdd.Visible = true;
            btnDelete.Visible = true;
        }
    }

    protected void NoDataVisible()
    {
        tblnodata.Visible = true;
        gridForum.Visible = false;
        gridThread.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnCancel.Visible = false;
        tblNewpost.Visible = false;
        tblNewpost.Visible = false;
        if (Session["UserType"].ToString() == "Admin")
        {
            btnAdd.Visible = true;
            btnDelete.Visible = false;
        }
    }
    protected void NewPostVisible()
    {
        SmilesLoad();
        tblNewpost.Visible = true;
        txtMsg.Text = "";
        gridForum.Visible = false;
        gridThread.Visible = false;
        tblReply.Visible = false;
        btnReply.Visible = false;
        btnAdd.Visible = false;
        btnDelete.Visible = false;
        btnCancel.Visible = false;
        tblnodata.Visible = false;
        btnNewPost.Visible = false;       

    }
       
    protected void DisplayHeading()
    {
        // Label Heading Display
        SqlCommand cmdselect = new SqlCommand("sp_select_ForumName");
        cmdselect.Parameters.AddWithValue("@numForumID", int.Parse(hforumID.Value));
        cmdselect.CommandType = CommandType.StoredProcedure;
        DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
        htypeID.Value = DBobj.mydt.Rows[0][0].ToString();
        if (int.Parse(htypeID.Value) == 0)
            lblHeading.Text = "Folder : ";
        else if (int.Parse(htypeID.Value) == 1)
            lblHeading.Text = "Group : ";
        else
            lblHeading.Text = "Topic : ";
        lblHeading.Text = lblHeading.Text + DBobj.mydt.Rows[0][1].ToString();
    }
    protected void MailSend(int threadID)
    {
        System.Web.Mail.MailMessage msg = new System.Web.Mail.MailMessage(); 
        SqlCommand cmdselect = new SqlCommand("sp_select_UserFrom");       
        cmdselect.Parameters.AddWithValue("@numUserID", int.Parse(Session["UserId"].ToString()));
        cmdselect.CommandType = CommandType.StoredProcedure;
        DBobj.mydt = DBobj.ExecuteDTQuery(cmdselect);
        if (DBobj.mydt.Rows.Count > 0)
        {
            msg.From = DBobj.mydt.Rows[0]["EMail"].ToString(); // Email ID        
            //msg.From = DBobj.mydt.Rows[0][1].ToString() + DBobj.mydt.Rows[0][2].ToString() + " "+ DBobj.mydt.Rows[0][3].ToString(); // User Name            
            SqlCommand cmdselect1 = new SqlCommand("sp_select_ThreadSub");
            cmdselect1.Parameters.AddWithValue("@numThreadID", threadID);
            cmdselect1.CommandType = CommandType.StoredProcedure;
            string title = DBobj.ExecuteScalar(cmdselect1).ToString();
            msg.Subject = "Topic Reply Notification - " + title; // Title Name                

            DataTable tempdt = new DataTable();
            SqlCommand cmdselect2 = new SqlCommand("sp_select_UserTo");
            cmdselect2.Parameters.AddWithValue("@numThreadID", threadID);
            cmdselect2.CommandType = CommandType.StoredProcedure;
            tempdt = DBobj.ExecuteDTQuery(cmdselect2);
            for (int i = 0; i < tempdt.Rows.Count; i++)
            {
                if (tempdt.Rows[i][1].ToString() != "")
                {
                    if (tempdt.Rows[i]["UserID"].ToString() != DBobj.mydt.Rows[0]["UserID"].ToString())
                    {
                        msg.To = tempdt.Rows[i]["EMail"].ToString();
                        string str = "Dear " + tempdt.Rows[i]["Title"].ToString() + tempdt.Rows[i]["Name"].ToString() + " " + tempdt.Rows[i]["SurName"].ToString() + ",\n\n"; // Dear User Full name                                        
                        str += "The thread you have subscribed to, entitled " + title;
                        str += " has been modified by " + DBobj.mydt.Rows[0]["Name"].ToString() + DBobj.mydt.Rows[0]["Surname"].ToString() + " " + DBobj.mydt.Rows[0]["EMail"].ToString();
                        str += " On " + System.DateTime.Now.ToString()  + ". You can visit the forum to view the updates.";
                        msg.Body = str;
                        System.Web.Mail.SmtpMail.Send(msg);

                    }
                }
            }
        }

    }
    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);         
    }
    
    protected void btnViewAll_Click(object sender, EventArgs e)
    {
        txtForumSearch.Text = "";
        // Display the Grid For correspondence Forum ID..
        if (Request.QueryString["ForumID"] != null)
        {
            hforumID.Value = Request.QueryString["ForumID"].ToString();
            BindGrid(int.Parse(hforumID.Value));
            if (Request.QueryString["TypeID"] != null)
            {
                htypeID.Value = Request.QueryString["TypeID"].ToString();
                if (int.Parse(htypeID.Value) > 1)
                    btnNewPost.Visible = true;

            }
            // Display the Select Item in LblHeading
            DisplayHeading();
        }
        else if (lblHeading.Text == varMainRoot)
        {
            //SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
            //cmdselect.CommandType = CommandType.StoredProcedure;
            //dtForum = DBobj.ExecuteDTQuery(cmdselect);
            if (Session["UserType"].ToString() == "Admin")
            {
                SqlCommand cmdselect = new SqlCommand("sp_Select_Forum");
                cmdselect.CommandType = CommandType.StoredProcedure;
                dtForum = DBobj.ExecuteDTQuery(cmdselect);
            }
            else
            {
                string range = UserTopics();
                string sql = "select ForumID, A.Name as TopicName, TypeID,  ParentID, LastPostOn, B.Name as UserName, ThreadCount From Forum A, Users B  Where isDelete=0 And A.Createdby = B.UserID and TypeId = 0 and (ForumId in (" + range + ")" +
                                   " or ForumId in (Select ParentId From Forum Where isDelete=0 and Forumid in (" + range + "))" +
                                   " or ForumId in (Select ParentId from Forum where ForumId in (select ParentId From Forum  Where isDelete=0 and Forumid in (" + range + ")))) Order by A.CreatedOn";
                dtForum = DBobj.ExecuteDTQuery(sql);
            }
            gridForum.DataSource = dtForum;
            gridForum.DataBind();
            if (gridForum.Rows.Count > 0)
            {
                ForumGridVisible();
                hpage.Value = gridForum.BottomPagerRow.Visible.ToString();
            }
            else
            {
                NoDataVisible();
            }

            // Label Heading Display
            lblHeading.Text = varMainRoot;
        }
        else if (hthreadID.Value != "")
        {
            Panel2.Controls.Clear(); 
            LoadTable(); 
        }
        
    }
    protected void gridThread_RowDataBound(object sender, GridViewRowEventArgs e)
    {
              
        if (e.Row.RowType == DataControlRowType.Header || e.Row.RowIndex >= 0)
            e.Row.Cells[3].Style.Add("display", "none");

        if (Session["Thread"] == "Yes")
        {
            string[] subject = new string[3];
            if (e.Row.RowType != DataControlRowType.Header && e.Row.RowIndex != -1)
            {        
                subject = dtThread.Rows[e.Row.RowIndex]["Subject"].ToString().Split('|');
                e.Row.Cells[1].Text = subject[0] + "<br><hr style='height=1px; width=95%;'></hr><a class='ClsLinkButton' href=discussion.aspx?ThreadId=" + dtThread.Rows[e.Row.RowIndex]["ThreadId"].ToString() + ">" + subject[1] + "</a>";
            }
        }
        
    }

    protected void gridForum_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header || e.Row.RowIndex >= 0)
            e.Row.Cells[4].Style.Add("display", "none");
        
    }
    protected string UserTopics() // Function to display user based topics...Karthik
    {
        StringBuilder forumID = new StringBuilder();
        string lnkID = "";        
        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = DBobj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_forumrights");        
        cmdLinks.CommandType = CommandType.StoredProcedure;
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = DBobj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        string id = linkrow["Link"].ToString();
                        forumID.Append(id.Substring(0, id.IndexOf("-")) + ",");
                        TypeIds.Append(id.Substring(id.IndexOf("-")+1, 1) + ",");
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        lnkID = forumID.ToString().Remove(forumID.Length - 1, 1);
        typeIds = TypeIds.ToString().Remove(TypeIds.Length - 1, 1);
        return lnkID;
    }

    protected void gridForum_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //Checking Threads are Available or Not
        if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowIndex >= 0)
        {
            if (e.Row.Cells[7].Text == "0")
            {
                e.Row.Cells[6].Text = "";
                e.Row.Cells[4].Text = "";
            }
        }
    }
    private void Forumsearch(string searchtext)
    {
        if (Session["UserType"].ToString() == "Admin")
                   {
                       SqlCommand cmdselect1 = new SqlCommand("sp_select_Thread_Search");
                       cmdselect1.CommandType = CommandType.StoredProcedure;
                       cmdselect1.Parameters.AddWithValue("@varSearch", searchtext);
                       dtThread = DBobj.ExecuteDTQuery(cmdselect1);
                       if (dtThread.Rows.Count > 0)
                       {
                           gridThread.DataSource = dtThread;
                           gridThread.DataBind();
                           ThreadGridVisible();
                           btnNewPost.Visible = false;
                           btnAdd.Visible = false;
                           btnDelete.Visible = false;
                           gridThread.Columns[7].Visible = false;       // Thread Edit column
                           gridThread.Columns[8].Visible = false;       // Thread Delete Column
                           hpage.Value = gridThread.BottomPagerRow.Visible.ToString();
                       }
                       else
                       {
                            NoDataVisible();
                       }
                   }
                   else
                   {
                       string sql = "";
                       string range = UserTopics();
                       string[] rangeData = new string[1000];
                       string[] typeIdsData = new string[1000];
                       rangeData = range.Split(',');
                       typeIdsData = typeIds.Split(',');
                       for (int i = 0; i <= rangeData.Length - 1; i++)
                       {
                           if (typeIdsData[i] == "0")
                           {
                               folderIds += rangeData[i] + ",";
                           }
                           else if (typeIdsData[i] == "1")
                           {
                               groupIds += rangeData[i] + ",";
                           }
                           else if (typeIdsData[i] == "2")
                           {
                               topicIds += rangeData[i] + ",";
                           }
                       }
                        if (folderIds.Length > 0)
                        {
                            folderIds = folderIds.Remove(folderIds.Length - 1);
                            sql = " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and TypeId=2 and ForumId in (" + folderIds + ")" +
                                  " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and TypeId=2 and ParentId in (" + folderIds + ")" +
                                  " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0  and TypeId=2 and ParentId in (select ForumID from Forum where isdelete = 0  and ParentId in (" + folderIds + "))";

                        }
                        if (groupIds.Length > 0)
                        {
                            groupIds = groupIds.Remove(groupIds.Length - 1);
                            if (sql != "") sql += " Union ";
                            sql += " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and TypeId=2  and ForumId in (" + groupIds + ")" +
                                   " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and TypeId=2 and ParentId in (" + groupIds + ")" +
                                   " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0and TypeId=2 and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + groupIds + "))";

                        }
                        if (topicIds.Length > 0)
                        {
                            topicIds = topicIds.Remove(topicIds.Length - 1);
                            if (sql != "") sql += " Union ";
                            sql += " select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and TypeId=2  and ForumId in (" + topicIds + ")" +
                                 " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and TypeId=2 and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + topicIds + "))" +
                                 " union select ForumID, Name, TypeID, ParentID  from Forum where isdelete = 0 and TypeId=2 and ForumId in (select ParentId from Forum where isdelete = 0  and ForumId in (select ParentId from Forum where isdelete = 0  And ForumId in  (" + topicIds + ")))";

                        }
                        DataTable dtRightIds = DBobj.ExecuteDTQuery(sql);
                        string rightsIds = "";
                        for (int row = 0; row < dtRightIds.Rows.Count; row++)
                        {
                            rightsIds += dtRightIds.Rows[row][0].ToString() + ",";
                        }
                        if (rightsIds.Length > 0)
                        {
                            rightsIds = rightsIds.Remove(rightsIds.Length - 1, 1);
                            //sql = "select ThreadID, (FL.Name + ' >> ' + GR.Name + ' >> ' + TP.Name + + '|' + Subject) as Subject, CASE When DATALENGTH(body) > 150 Then Substring(Body,1,150)+ '...' Else Body End as Body, TH.LastPoston, ViewCount, ReplyCount from Forum FL inner join Forum GR on FL.ForumId = GR.ParentId inner join Forum TP on GR.ForumID= TP.ParentID, ForumThread TH where FL.IsDelete=0 and GR.IsDelete=0 and TP.IsDelete=0 and TH.IsDelete=0 and TH.Messagetype=0 And TP.ForumID = TH.ForumID and TP.ForumId in (Select Distinct B.ForumID from Forum A, ForumThread B Where A.ForumID = B.ForumID And A.isDelete=0 And B.isDelete=0 And (Subject like '%" + searchtext + "%' OR BODY like '%" + searchtext + "%')) And TP.ForumId in (" + rightsIds + ") Order By TH.LastPoston";
                            sql = "select ThreadID, (FL.Name + ' >> ' + GR.Name + ' >> ' + TP.Name + + '|' + Subject) as Subject, CASE When DATALENGTH(body) > 150 Then Substring(Body,1,150)+ '...' Else Body End as Body, TH.LastPoston, ViewCount, ReplyCount from Forum FL inner join Forum GR on FL.ForumId = GR.ParentId inner join Forum TP on GR.ForumID= TP.ParentID, ForumThread TH where FL.IsDelete=0 and GR.IsDelete=0 and TP.IsDelete=0 and TH.IsDelete=0 and TH.Messagetype=0 And TP.ForumID = TH.ForumID and (Subject like '%" + searchtext + "%' OR BODY like '%" + searchtext + "%') And TP.ForumId in (" + rightsIds + ") Order By TH.LastPoston";
                            dtThread = DBobj.ExecuteDTQuery(sql);
                            if (dtThread.Rows.Count > 0)
                            {
                                gridThread.DataSource = dtThread;
                                gridThread.DataBind();
                                ThreadGridVisible();
                                btnNewPost.Visible = false;
                                btnAdd.Visible = false;
                                btnDelete.Visible = false;
                                gridThread.Columns[7].Visible = false;       // Thread Edit column
                                gridThread.Columns[8].Visible = false;       // Thread Delete Column
                                hpage.Value = gridThread.BottomPagerRow.Visible.ToString();
                            }
                            else
                            {
                                NoDataVisible();
                            }
                        }
                        else
                        {
                            NoDataVisible();
                        }
                   }
    }
}