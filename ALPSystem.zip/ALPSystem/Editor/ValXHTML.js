// To rectify the XHTML errors in ACE 
function ValidateXHTML(content) {
	var tagstart, tagend, attstart, attend, attvalue, attvalues, i,s=0;
	var testHTML = content;
	var outHTML = "";
	extra="no"
	lengthHTML = testHTML.length;
	// Checking whether the Content doen't contain any Tags
	if (testHTML.indexOf("<",s) < 0) return testHTML;
	// Checks whether there is content after the end of tags
	if (testHTML.lastIndexOf(">")<lengthHTML-1) {
		extra = "yes"
		remText = testHTML.substring(testHTML.lastIndexOf(">")+1,lengthHTML)
		testHTML = testHTML.substring(0,testHTML.lastIndexOf(">")+1)
	}
	
	
	//Conversion to XHTML
	lengthHTML = testHTML.length;
	tempend = -1
	for (i=0; i<lengthHTML; i++) {
		tagstart = testHTML.indexOf("<",s)+1
		if (testHTML.substring(tagstart, tagstart+1) == "!") {
			s = testHTML.indexOf("-->",tagstart + 3) + 3
			i = s
			continue
		} else {
			tagend = testHTML.indexOf(">",tagstart)
		}
		if (tagstart-1 == 0) outHTML = testHTML.substring(0,tagstart-2);
		lowHTML=testHTML.substring(tagstart,tagend)
		attvalues = lowHTML.split(" ");
		for (var jLoop=0; jLoop<attvalues.length; jLoop++) {
			if (attvalues[jLoop].indexOf("/")==0) 
				attvalues[jLoop]=attvalues[jLoop].toLowerCase(); 
			else {
				attr=attvalues[jLoop].substring(0,attvalues[jLoop].indexOf("=",0)).toLowerCase();
				switch(attr) {
					case "!":
						break;
						
					case "class" :
						if (attvalues[jLoop].indexOf("=")>0) {
							attvalue=attvalues[jLoop].substr(attvalues[jLoop].indexOf("=")+1)
							if (attvalue.indexOf('"')<0) { 
								attvalue='"'+attvalue+'"'
								attvalues[jLoop]=attvalues[jLoop].substring(0,attvalues[jLoop].indexOf("=")+1).toLowerCase()+attvalue
							}
						}
						break;
						
					case "id" :
						if (attvalues[jLoop].indexOf("=")>0) {
							attvalue=attvalues[jLoop].substr(attvalues[jLoop].indexOf("=")+1)
							if (attvalue.indexOf('"')<0) { 
								attvalue='"'+attvalue+'"'
								attvalues[jLoop]=attvalues[jLoop].substring(0,attvalues[jLoop].indexOf("=")+1).toLowerCase()+attvalue
							}
						}
						break;
						
					case "name" :
						if (attvalues[jLoop].indexOf("=")>0) {
							attvalue=attvalues[jLoop].substr(attvalues[jLoop].indexOf("=")+1)
							if (attvalue.indexOf('"')<0) { 
								attvalue='"'+attvalue+'"'
								attvalues[jLoop]=attvalues[jLoop].substring(0,attvalues[jLoop].indexOf("=")+1).toLowerCase()+attvalue
							}
						}
						break;
										
					default :
						if (attvalues[jLoop].indexOf("=")<0) 
							attvalues[jLoop]=attvalues[jLoop].toLowerCase();
						else if (attvalues[jLoop].indexOf("=")>0) {
							if (attr=="align") {
								if (attvalues[jLoop].indexOf('middle')>0) attvalues[jLoop]=replace(attvalues[jLoop],"middle","center");
							}
							attvalue=attvalues[jLoop].substr(attvalues[jLoop].indexOf("=")+1)
							if (attvalue.indexOf('"')<0) { 
								attvalue='"'+attvalue+'"'
								attvalues[jLoop]=attvalues[jLoop].substring(0,attvalues[jLoop].indexOf("=")+1).toLowerCase()+attvalue.toLowerCase()
							}
						}
						break;
				}
			}
		}
		
		// Assembling the Tag with its Attributes
		if (attvalues.length==1) {
			lowHTML = "<" + attvalues[0] + ">"
		} else {
			lowHTML = "<";
			for (k=0; k<attvalues.length; k++) {
				lowHTML = lowHTML + attvalues[k] + " ";
			}
			lowHTML = lowHTML.substring(0,lowHTML.length - 1)+">"
		}

		switch(attvalues[0]) {
			case "br" :
				lowHTML = replace(lowHTML,">","/>");
				break;
			
			case "hr" :
				lowHTML = replace(lowHTML,">","/>");
				break;
				
			case "input" :
				lowHTML = replace(lowHTML,">","/>");
				break;
				
			case "img" :
				lowHTML = replace(lowHTML,">","/>");
				break;
		}
		
		//-------------------------------------------
		//Generating Output HTML
		if (tagend == lengthHTML-1)
			outHTML = outHTML + lowHTML;
		else
			outHTML = outHTML + lowHTML + testHTML.substring(tagend+1,testHTML.indexOf("<",tagend));
		s=tagend;
		i=tagend;
	}
	if (extra == "yes") {
		outHTML = outHTML + remText 
	}
	outHTML= replace(outHTML,"mm_swapimgrestore","MM_swapImgRestore")
	return outHTML;
}
