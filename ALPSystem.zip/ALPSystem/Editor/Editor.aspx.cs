using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;


public partial class Editor_Editor : System.Web.UI.Page
{
    string type, id, i;
    Templates tempObj = new Templates();
    Lists lstObj = new Lists();

    //string OnceGetinforSubmit = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.ValidateSession();

        Response.Expires = -1;
        Response.AddHeader("pragma", "no-cache");
        Response.CacheControl = "no-cache";

        if (!Convert.ToString(Session["UserType"]).Equals("Manager") && !Convert.ToString(Session["UserType"]).Equals("Admin"))
        {
            Response.Redirect("../Errors/SessionExpired.aspx", true);
        }
        //New Changes 15Mar07 
        if (Request.QueryString["TYPE"].ToString() == "CB")
        {
            if(oEdit1.Content != null)
            oEdit1.Content = oEdit1.Content.Replace("vAlign=center", "vAlign=middle").Replace("align=middle", "align=center");
            
            hidNewContent.Value = oEdit1.Content;
            oEdit1.Content = hidOldContent.Value;

            if (Convert.ToInt16(hidTempValue.Value) == 2)
            {
                hidOldContent.Value = oEdit1.Content;
            }
        }
        //

        //-----------------
        //gk feb22
        Session["Coming_From_TemplManag"] = "Set";

        //gk Feb26 07

        //gk march15
        if (Request.QueryString["DEdit"] != null)
        {
            if (Request.QueryString["DEdit"] == "true")
            {
                Session["FlagForEditor"] = null;
            }
        }
        if (Session["FlagForEditor"] != null)     //if coming from templatemanager Particularly From SAVEAS
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["ID"].ToString().StartsWith("TM"))
                {
                    Session["HitCountForThisFunction"] = null;
                }
            }

            if (Session["HitCountForThisFunction"] == null)  //Ist Time Load  Only its null
            {
                Session["HitcountForSubmit"] = "OnceGetin";
                //OnceGetinforSubmit = "getin";
                Session["HitCountForThisFunction"] = "1";
            }

            if (!Page.IsPostBack)
            {


                string strCaptureValues = @"<script language='javascript'>
                                                //alert(window.opener.document.getElementById('txtTemplateName').value);
                                                document.getElementById('hTemplName').value=window.opener.document.getElementById('txtTemplateName').value;
                                                document.getElementById('hTemplType').value=window.opener.document.getElementById('drpTempType').selectedIndex;
                                                document.getElementById('hTemplLoc').value=window.opener.document.getElementById('txtTemplateLocation').value;
                                                document.getElementById('hBulletImgLoc').value=window.opener.document.getElementById('txtBulletImgLocation').value;
                                                document.getElementById('hTemplDescr').value=window.opener.document.getElementById('txtTemplateDesc').value;
                                               </script>";
                //RegisterClientScriptBlock("key", strCaptureValues);
                RegisterStartupScript("key", strCaptureValues);
            }




            if (Session["HitCountForThisFunction"] == "1")   //This is for first time
            {
                Session["HitCountForThisFunction"] = "2";


                type = Request.QueryString["TYPE"];
                id = Request.QueryString["ID"];      //gk Template Manager Id  
                i = "Content" + Request.QueryString["Contents"];
                if (!IsPostBack)
                    if (type == "Temp")
                    {
                        tblSubmit.Visible = true;
                        tblSave.Visible = false;
                        tblListSave.Visible = false;
                        if (id != "")
                        {
                            oEdit1.Content = tempObj.GetTemplateContent(id);
                        }
                        //else
                        //{
                        //    //Response.Write("<script language=javascript> if(window.opener.document.getElementById('hcontent').value != '') document.getElementById('oEdit1').value = window.opener.document.getElementById('hcontent').value; </script>");
                        //}
                    }
                    else if (type == "CB")
                    {
                        //New Changes 15Mar07 
                        hidNewContent.Value = oEdit1.Content;
                        oEdit1.Content = hidOldContent.Value;

                        if (Convert.ToInt16(hidTempValue.Value) == 2)
                        {
                            hidOldContent.Value = oEdit1.Content;
                        }
                        //

                        //Response.Write("CB");
                        tblSubmit.Visible = false;
                        tblListSave.Visible = false;
                        tblSave.Visible = true;
                        //if (i == "Content1")
                        //    oEdit1.Content = ContentReader.content1;
                        //if (i == "Content2")
                        //    oEdit1.Content = ContentReader.content2;
                        //if (i == "Content3")
                        //    oEdit1.Content = ContentReader.content3;
                        //if (i == "Content4")
                        //    oEdit1.Content = ContentReader.content4;
                        //if (i == "Content5")
                        //    oEdit1.Content = ContentReader.content5;
                        //if (i == "Content6")
                        //    oEdit1.Content = ContentReader.content6;
                        //if (i == "Content7")
                        //    oEdit1.Content = ContentReader.content7;
                        //if (i == "Content8")
                        //    oEdit1.Content = ContentReader.content8;
                        //if (i == "Content9")
                        //    oEdit1.Content = ContentReader.content9;
                        //if (i == "Content10")
                        //    oEdit1.Content = ContentReader.content10;
                        //if (i == "Content11")
                        //    oEdit1.Content = ContentReader.content11;
                        //if (i == "Content12")
                        //    oEdit1.Content = ContentReader.content12;

                        //Response.Write(ContentReader.content1.ToString());
                    }
                    else if (type == "List")
                    {
                        tblListSave.Visible = true;
                        tblSave.Visible = false;
                        tblSubmit.Visible = false;
                        hdnId.Value = Request.QueryString["Id"].ToString();
                        //string fn = "<script language='javascript'>" +
                        //    "alert('testvalue');" +
                        //    "var testvalue=window.opener.document.getElementById('" + Request.QueryString["Id"].ToString() + "').value;" +
                        //    "alert(testvalue);" +
                        //    "alert(document.getElementById('hdnValue'));" +
                        //    "document.getElementById('hdnValue').value=testvalue;" +
                        //    "document.getElementById('oEdit1').value=document.getElementById('hdnValue').value;" +

                        //    //"alert(document.getElementById(\'oEdit1\').value);"+
                        //    "</script>";


                        //oEdit1.Content = Request.QueryString["Txt"].ToString();
                        if (!Request.QueryString["Txt"].ToString().Equals("New"))
                        {
                            string content = "";
                            string qry = "";
                            int cnt;

                            if (hdnId.Value.StartsWith("hdn"))
                            {
                                cnt = int.Parse(hdnId.Value.Substring(hdnId.Value.IndexOf('n') + 1)) + 1;
                                qry = "select field" + cnt + " from Listitems where rowid=" + Request.QueryString["Row"].ToString() + " and listbuilderid='" + Request.QueryString["LBID"].ToString() + "'";

                            }
                            else
                            {
                                cnt = int.Parse(Request.QueryString["Col"].ToString());
                                qry = "select field" + cnt + " from Listitems where listitemid='" + Request.QueryString["ListID"].ToString() + "'";

                            }

                            content = lstObj.ExecuteScalar(qry);
                            if (content.Length >= 5)
                            {
                                if (content.StartsWith("~RTF~"))
                                    content = content.Remove(0, 5);
                            }

                            oEdit1.Content = content;
                            //oEdit1.Focus();
                        }

                    }

            }//end
            else  //if More than Ones  
            {

                type = Request.QueryString["TYPE"];
                id = Request.QueryString["ID"];      //gk Template Manager Id  
                i = "Content" + Request.QueryString["Contents"];
                if (!IsPostBack)
                    if (type == "Temp")
                    {
                        tblSubmit.Visible = true;
                        tblSave.Visible = false;
                        tblListSave.Visible = false;

                        tempObj.SourceId = id;
                        if (id != "")
                            oEdit1.Content = tempObj.getcontentwithTPID();  //getcontent

                    }
                    else if (type == "CB")
                    {
                        //New Changes 15Mar07 
                        hidNewContent.Value = oEdit1.Content;
                        oEdit1.Content = hidOldContent.Value;

                        if (Convert.ToInt16(hidTempValue.Value) == 2)
                        {
                            hidOldContent.Value = oEdit1.Content;
                        }
                        //
                        //Response.Write("CB");
                        tblSubmit.Visible = false;
                        tblListSave.Visible = false;
                        tblSave.Visible = true;
                        //if (i == "Content1")
                        //    oEdit1.Content = ContentReader.content1;
                        //if (i == "Content2")
                        //    oEdit1.Content = ContentReader.content2;
                        //if (i == "Content3")
                        //    oEdit1.Content = ContentReader.content3;
                        //if (i == "Content4")
                        //    oEdit1.Content = ContentReader.content4;
                        //if (i == "Content5")
                        //    oEdit1.Content = ContentReader.content5;
                        //if (i == "Content6")
                        //    oEdit1.Content = ContentReader.content6;
                        //if (i == "Content7")
                        //    oEdit1.Content = ContentReader.content7;
                        //if (i == "Content8")
                        //    oEdit1.Content = ContentReader.content8;
                        //if (i == "Content9")
                        //    oEdit1.Content = ContentReader.content9;
                        //if (i == "Content10")
                        //    oEdit1.Content = ContentReader.content10;
                        //if (i == "Content11")
                        //    oEdit1.Content = ContentReader.content11;
                        //if (i == "Content12")
                        //    oEdit1.Content = ContentReader.content12;

                        //Response.Write(ContentReader.content1.ToString());
                    }
                    else if (type == "List")
                    {
                        tblListSave.Visible = true;
                        tblSave.Visible = false;
                        tblSubmit.Visible = false;
                        hdnId.Value = Request.QueryString["Id"].ToString();
                        //string fn = "<script language='javascript'>" +
                        //    "alert('testvalue');" +
                        //    "var testvalue=window.opener.document.getElementById('" + Request.QueryString["Id"].ToString() + "').value;" +
                        //    "alert(testvalue);" +
                        //    "alert(document.getElementById('hdnValue'));" +
                        //    "document.getElementById('hdnValue').value=testvalue;" +
                        //    "document.getElementById('oEdit1').value=document.getElementById('hdnValue').value;" +

                        //    //"alert(document.getElementById(\'oEdit1\').value);"+
                        //    "</script>";


                        //oEdit1.Content = Request.QueryString["Txt"].ToString();
                        if (!Request.QueryString["Txt"].ToString().Equals("New"))
                        {
                            string content = "";
                            string qry = "";
                            int cnt;

                            if (hdnId.Value.StartsWith("hdn"))
                            {
                                cnt = int.Parse(hdnId.Value.Substring(hdnId.Value.IndexOf('n') + 1)) + 1;
                                qry = "select field" + cnt + " from Listitems where rowid=" + Request.QueryString["Row"].ToString() + " and listbuilderid='" + Request.QueryString["LBID"].ToString() + "'";

                            }
                            else
                            {
                                cnt = int.Parse(Request.QueryString["Col"].ToString());
                                qry = "select field" + cnt + " from Listitems where listitemid='" + Request.QueryString["ListID"].ToString() + "'";

                            }

                            content = lstObj.ExecuteScalar(qry);
                            if (content.Length >= 5)
                            {
                                if (content.StartsWith("~RTF~"))
                                    content = content.Remove(0, 5);
                            }

                            oEdit1.Content = content;
                            //oEdit1.Focus();
                        }

                    }

            }


        }



        else  //if not come from Template module
        {

            //----------------------------------

            type = Request.QueryString["TYPE"];
            id = Request.QueryString["ID"];      //gk Template Manager Id  
            i = "Content" + Request.QueryString["Contents"];
            if (!IsPostBack)
                if (type == "Temp")
                {
                    tblSubmit.Visible = true;
                    tblSave.Visible = false;
                    tblListSave.Visible = false;
                    if (id != "")
                    {
                        oEdit1.Content = tempObj.GetTemplateContent(id);
                    }
                    //else
                    //{
                    //    //Response.Write("<script language=javascript> if(window.opener.document.getElementById('hcontent').value != '') document.getElementById('oEdit1').value = window.opener.document.getElementById('hcontent').value; </script>");
                    //}
                }
                else if (type == "CB")
                {
                    //Response.Write("CB");

                    //New Changes 15Mar07 
                    hidNewContent.Value = oEdit1.Content;
                    oEdit1.Content = hidOldContent.Value;

                    if (Convert.ToInt16(hidTempValue.Value) == 2)
                    {
                        hidOldContent.Value = oEdit1.Content;
                    }
                    //

                    tblSubmit.Visible = false;
                    tblListSave.Visible = false;
                    tblSave.Visible = true;
                    //if (i == "Content1")
                    //    oEdit1.Content = ContentReader.content1;
                    //if (i == "Content2")
                    //    oEdit1.Content = ContentReader.content2;
                    //if (i == "Content3")
                    //    oEdit1.Content = ContentReader.content3;
                    //if (i == "Content4")
                    //    oEdit1.Content = ContentReader.content4;
                    //if (i == "Content5")
                    //    oEdit1.Content = ContentReader.content5;
                    //if (i == "Content6")
                    //    oEdit1.Content = ContentReader.content6;
                    //if (i == "Content7")
                    //    oEdit1.Content = ContentReader.content7;
                    //if (i == "Content8")
                    //    oEdit1.Content = ContentReader.content8;
                    //if (i == "Content9")
                    //    oEdit1.Content = ContentReader.content9;
                    //if (i == "Content10")
                    //    oEdit1.Content = ContentReader.content10;
                    //if (i == "Content11")
                    //    oEdit1.Content = ContentReader.content11;
                    //if (i == "Content12")
                    //    oEdit1.Content = ContentReader.content12;

                    //Response.Write(ContentReader.content1.ToString());
                }
                else if (type == "List")
                {
                    tblListSave.Visible = true;
                    tblSave.Visible = false;
                    tblSubmit.Visible = false;
                    hdnId.Value = Request.QueryString["Id"].ToString();
                    //string fn = "<script language='javascript'>" +
                    //    "alert('testvalue');" +
                    //    "var testvalue=window.opener.document.getElementById('" + Request.QueryString["Id"].ToString() + "').value;" +
                    //    "alert(testvalue);" +
                    //    "alert(document.getElementById('hdnValue'));" +
                    //    "document.getElementById('hdnValue').value=testvalue;" +
                    //    "document.getElementById('oEdit1').value=document.getElementById('hdnValue').value;" +

                    //    //"alert(document.getElementById(\'oEdit1\').value);"+
                    //    "</script>";


                    //oEdit1.Content = Request.QueryString["Txt"].ToString();
                    if (!Request.QueryString["Txt"].ToString().Equals("New"))
                    {
                        string content = "";
                        string qry = "";
                        int cnt;

                        if (hdnId.Value.StartsWith("hdn"))
                        {
                            cnt = int.Parse(hdnId.Value.Substring(hdnId.Value.IndexOf('n') + 1)) + 1;
                            qry = "select field" + cnt + " from Listitems where rowid=" + Request.QueryString["Row"].ToString() + " and listbuilderid='" + Request.QueryString["LBID"].ToString() + "'";

                        }
                        else
                        {
                            cnt = int.Parse(Request.QueryString["Col"].ToString());
                            qry = "select field" + cnt + " from Listitems where listitemid='" + Request.QueryString["ListID"].ToString() + "'";

                        }

                        content = lstObj.ExecuteScalar(qry);
                        if (content.Length >= 5)
                        {
                            if (content.StartsWith("~RTF~"))
                                content = content.Remove(0, 5);
                        }

                        oEdit1.Content = content;
                        //oEdit1.Focus();
                    }

                }
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (id != "")
        {
            oEdit1.Content = oEdit1.Content.Replace("vAlign=center", "vAlign=middle").Replace("align=middle", "align=center");
            if (Session["FlagForEditor"] != null)     //for split functions for templManger and others
            {
                //if (Session["FlagForEditor"] != "Set")
                //{
                
                if (Session["HitcountForSubmit"] == "OnceGetin")
                {
                    Templates tempObj = new Templates();

                    //Add new Template
                    tempObj.HTML_DFlag = "0";
                    tempObj.HTML_UserId = Session["UserId"].ToString();
                    string tId = "TP" + tempObj.GetMaxValueString("templates", "TempId");
                    tempObj.HTML_Content = oEdit1.Content;
                    tempObj.HTML_Name = hTemplLoc.Value;//hTemplName.Value;

                    tempObj.AddNewTemplate(tId);

                    Session["HitcountForSubmit"] = "More Than Once";

                    Session["TID_fromEditor"] = tId;
                    Session["AddNewTemplate"] = "Added";
                    Response.Write(oEdit1.Content);


                    //string Capturevalues = "<script language ='javascript'>";
                    //Capturevalues += "'<%=Session['NameFrmEdit']%>' = window.opener.document.getElementById('txtTemplateName').value;";
                    //Capturevalues += "</script>";

                    //RegisterClientScriptBlock("kay", Capturevalues);
                    Session["TName"] = hTemplName.Value;
                    Session["TType"] = hTemplType.Value;
                    Session["TLoc"] = hTemplLoc.Value;
                    Session["TImgLoc"] = hBulletImgLoc.Value;
                    Session["TDesc"] = hTemplDescr.Value;

                    Session["Content"] = oEdit1.Content;
                    Session["FlagForEditor"] = null;
                    Response.Write("<script language='javascript'>window.opener.location.href = window.opener.location.href;window.close();</script>");

                    //Response.Write("<script language='javascript'>window.opener.document.getElementById('txtTemplateLocation').value = window.opener.document.getElementById('txtTemplateName').value;window.opener.document.forms(0).submit();window.close();</script>");
                    // }
                }
                else  //If more Than Once
                {
                    SqlCommand cmd = new SqlCommand("sp_update_templates");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@content", SqlDbType.Text);
                    cmd.Parameters["@content"].Value = oEdit1.Content;

                    Response.Write(oEdit1.Content);
                    DataTable data = new DataTable();

                    //data = tempObj.getDataTable(id);  //Coming From Template Manager
                    cmd.Parameters.Add("@id", SqlDbType.Text);
                    cmd.Parameters["@id"].Value = id;    //data.Rows[0]["sourceid"].ToString();
                    tempObj.ExecuteNonQuery(cmd);
                    Session["Content"] = oEdit1.Content;
                    Response.Write("<script language='javascript'>window.opener.location.href = window.opener.location.href; window.close();</script>");
                }
            }

            else
            {
                SqlCommand cmd = new SqlCommand("sp_update_templates");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@content", SqlDbType.Text);
                
                cmd.Parameters["@content"].Value = oEdit1.Content;

                //March16 Gk
                Session["TName"] = null;
                Session["TType"] = null;
                Session["TLoc"] = null;

                Response.Write(oEdit1.Content);
                DataTable data = new DataTable();

                data = tempObj.getDataTable(id);  //Coming From Template Manager
                cmd.Parameters.Add("@id", SqlDbType.Text);
                cmd.Parameters["@id"].Value = data.Rows[0]["sourceid"].ToString();
                tempObj.ExecuteNonQuery(cmd);
                Session["Content"] = oEdit1.Content;
                //March16 GK
                // Response.Write("<script language='javascript'>window.opener.location.href = window.opener.location.href; window.close();</script>");
                Response.Write("<script language='javascript'> window.opener.location.href =window.opener.location.href+'&DEdit=True' ; window.close();</script>");
            }

        }
        else
        {            
            Session["Content"] = oEdit1.Content;
            Response.Write("<script language='javascript'>window.opener.document.getElementById('txtTemplateLocation').value = window.opener.document.getElementById('txtTemplateName').value ;window.opener.document.forms(0).submit();window.close();</script>");
            //Response.Write("<script language=javascript>window.opener.document.getElementById('hcontent').value = escape('" + oEdit1.Content.ToString() + "'); window.close();</script>");

        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //New Changes 15Mar07
        hidSetValue.Value = "Save";

        //if ( i=="Content1")
        //    ContentReader.content1 = oEdit1.Content;
        //if (i == "Content2")
        //    ContentReader.content2 = oEdit1.Content;
        //if (i == "Content3")
        //    ContentReader.content3 = oEdit1.Content;
        //if (i == "Content4")
        //    ContentReader.content4 = oEdit1.Content;
        //if (i == "Content5")
        //    ContentReader.content5 = oEdit1.Content;
        //if (i == "Content6")
        //    ContentReader.content6 = oEdit1.Content;
        //if (i == "Content7")
        //    ContentReader.content7 = oEdit1.Content;
        //if (i == "Content8")
        //    ContentReader.content8 = oEdit1.Content;
        //if (i == "Content9")
        //    ContentReader.content9 = oEdit1.Content;
        //if (i == "Content10")
        //    ContentReader.content10 = oEdit1.Content;
        //if (i == "Content11")
        //    ContentReader.content11 = oEdit1.Content;
        //if (i == "Content12")
        //    ContentReader.content12 = oEdit1.Content;

        //Response.Write("<script language='javascript'>");
        //Response.Write("window.close();");
        //Response.Write("</script>");
    }

    protected void btnLstSave_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'>");
        //Response.Write("SaveList('" + oEdit1.Content + "');");
        oEdit1.Content = oEdit1.Content.Replace("vAlign=center", "vAlign=middle").Replace("align=middle", "align=center");
        string content = oEdit1.Content;
        content = content.Replace("\r\n", "\\r\\n");
        string fun = "window.opener.document.getElementById('" + Request.QueryString["Id"].ToString() + "').value='" + content + "';window.close();";
        Response.Write(fun);
        Response.Write("</script");
    }

}
