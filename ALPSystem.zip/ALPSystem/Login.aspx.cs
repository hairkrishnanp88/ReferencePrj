using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Login : System.Web.UI.Page
{
    NGWS.CMPApplication.UserManager user = new NGWS.CMPApplication.UserManager();
    NGWS.CMPApplication.Skins skin = new NGWS.CMPApplication.Skins();
    protected void Page_Load(object sender, EventArgs e)
    {

        SiteInfo.SetSiteName(this);
        //if (action == "Logout")
        {
            Session["UserType"] = "Anonymous";
            Session["UserId"] = "";
            Session["UserName"] = "";
            Session["FullName"] = "";
            Session["PPSNumber"] = "";
            Session["EmployeerId"] = "";
            Session["CBId"] = "";
            Session["MenuRights"] = "";
            Session["DispType"] = "Public";
            //Response.Redirect("index.aspx");
        }
        //Page.Title = Session["SiteName"].ToString();
        //NGWS.CMPApplication.Templates tmp = new NGWS.CMPApplication.Templates();
        //tdLoginBanner.InnerHtml = tmp.GetTemplateContent("TM000007").Replace("../Images/", "./Images/");
        ShowBanner("none");
        ShowPanel("none");
        trMenuDisplay.Style.Add("display", "none");

        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
            tblControls.Style.Add("display", "none");
            trMenuDisplay.Style.Add("display", "inline");
            ReplaceMenuURL();
            ShowBanner(Session["Banner"].ToString());
            ShowPanel(Session["Panel"].ToString());
        }
        else
            loginBody.Attributes.Add("onload", "document.getElementById('txtUsername').focus();");
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (user.ValidateUser(txtUsername.Text.Trim(), txtPassword.Text.Trim()))
        {
            Session["Act"] = "";
            Session["UserName"] = user.Username;
            Session["UserId"] = user.Userid;
            Session["FullName"] = user.Title + " " + user.Name + " " + user.SurName;
            Session["UserType"] = user.UserType;
            skin.LoadSkinSettings();
            Session["Banner"] = skin.BannerStyle.ToString();
            Session["Panel"] = skin.PanelStyle.ToString();
            Session["SiteName"] = skin.SiteName.ToString();
            DataTable ToolbarAddRights = user.AllToolBarRights("Add");
            DataTable ToolbarModRights = user.AllToolBarRights("Mod");
            if (ToolbarAddRights.Rows.Count > 0 || ToolbarModRights.Rows.Count > 0)
            {
                Session["MenuRights"] = "inline";
            }
            else if (Session["UserType"].ToString().ToLower() == "admin" || Session["UserType"].ToString().ToLower() == "manager")
                Session["MenuRights"] = "inline";
            else
            {
                Session["MenuRights"] = "none";
            }

            if (user.UserType == "Anonymous")
            {
                Session.Abandon();
                Response.Redirect("Index.aspx");
            }
            else
            {
                DataTable pageIndex = new DataTable();
                pageIndex = user.GetPageIndex();
                user.IndexType = pageIndex.Rows[0][0].ToString();
                user.IndexPage = pageIndex.Rows[0][1].ToString();
                if (user.IndexType == "UL")
                {
                    string url = "";
                    Session["CBId"] = user.IndexPage;
                    url = user.IndexPage;
                    Response.Redirect(url.Replace("../", ""));
                }
                else
                {
                    Session["CBId"] = user.IndexPage;
                    if (user.IndexPage == "" || user.IndexPage == null)
                        Session["CBId"] = System.Configuration.ConfigurationManager.AppSettings["PrivateHome"];

                    //user.Userid = Convert.ToInt32(Session["UserId"].ToString());
                    DataTable dtRights = user.BuilderRights(user.IndexPage, "");
                    //Response.Redirect("Default.aspx");
                    // if(dtRights.Rows[0]["Rights"].ToString()=="")

                    if (user.UserType == "Private")
                        SetPublicPage();

                    if (dtRights.Rows.Count > 0)
                        Response.Redirect("ContentBuilder/Displaypage.aspx?DataId=" + user.IndexPage + "&BtnRights=" + dtRights.Rows[0]["Rights"].ToString());
                    else
                        Response.Redirect("ContentBuilder/Displaypage.aspx?DataId=" + user.IndexPage + "&BtnRights=0001");
                }
            }
        }
        else
            Response.Redirect("Errors/LoginFail.aspx");
    }

    void ReplaceMenuURL()
    {
        // First for loop for changing the main menu's 'onclick' event. i.e replacing ../ with ./
        // inner for loop for changing the sub menu's 'onclick' event. i.e replacing ../ with ./
        for (int menuCell=0;menuCell<(divMenu.Controls[1].Controls[0].Controls.Count-1);menuCell++)
        {
            if (((HtmlTableCell)(divMenu.Controls[1].Controls[0].Controls[menuCell])).Attributes["onclick"] != null)
                ((HtmlTableCell)(divMenu.Controls[1].Controls[0].Controls[menuCell])).Attributes["onclick"] = ((HtmlTableCell)(divMenu.Controls[1].Controls[0].Controls[menuCell])).Attributes["onclick"].ToString().Replace("../", "./");
            else if (divMenu.Controls[1].Controls[1].Controls[menuCell].Controls.Count > 0)
            {
                for (int menuSubCell = 0; menuSubCell< divMenu.Controls[1].Controls[1].Controls[menuCell].Controls[0].Controls.Count; menuSubCell++)
                    ((HtmlTableCell)(divMenu.Controls[1].Controls[1].Controls[menuCell].Controls[0].Controls[menuSubCell].Controls[0])).Attributes["onclick"] = ((HtmlTableCell)(divMenu.Controls[1].Controls[1].Controls[menuCell].Controls[0].Controls[menuSubCell].Controls[0])).Attributes["onclick"].ToString().Replace("../", "./");
            }
        }
    }

    void SetPublicPage()
    {
        bool hasPublicRights = false;
        DataTable publicUserIndex = new DataTable();
        publicUserIndex = user.GetPublicUserIndex();
        if (user.UserType == "Private")
        {
            if (publicUserIndex.Rows.Count > 0)
            {
                DataTable toolbarRights = new DataTable();
                toolbarRights = user.AllToolBarViewRights("");
                if (toolbarRights.Rows.Count > 0)
                {
                    // If public page has no toolbars, then public menu should not be displayed.
                    if (publicUserIndex.Rows[0][0].ToString() == "" | publicUserIndex.Rows[0][0].ToString() == null)
                        Session["PublicIndex"] = "";
                    else
                    {
                        hasPublicRights = false;
                        for (int i = 0; i < toolbarRights.Rows.Count; i++)
                        {
                            if ((toolbarRights.Rows[i][0].ToString() == publicUserIndex.Rows[0][0].ToString()) |
                                (toolbarRights.Rows[i][0].ToString() == publicUserIndex.Rows[0][1].ToString()) |
                                (toolbarRights.Rows[i][0].ToString() == publicUserIndex.Rows[0][2].ToString()) |
                                (toolbarRights.Rows[i][0].ToString() == publicUserIndex.Rows[0][3].ToString()))
                            {
                                hasPublicRights = true;
                                i = toolbarRights.Rows.Count;
                            }
                        }
                        if (hasPublicRights == false)
                            Session["PublicIndex"] = "";
                    }
                }
                else
                    Session["PublicIndex"] = "";
            }
            else
                Session["PublicIndex"] = "";
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        //Response.Redirect("UserManager/UserProfile.aspx?UserId=&FromPref=Yes&Act=New");
        Response.Redirect("UserManager/UserProfile.aspx?UserId=&FromPref=No&Act=New");

    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }


    public void ShowPanel(string value)
    {
        tdLeftPane.Style.Add("display", value);
    }


    //protected HtmlTable userValidation()
    //{
    //    HtmlTable menuTbl = new HtmlTable();
    //    HtmlTableRow menuMain = new HtmlTableRow();
    //    HtmlTableRow menuSub = new HtmlTableRow();
    //    menuTbl.Rows.Add(menuMain);
    //    menuTbl.Rows.Add(menuSub);

    //    if (Session["UserType"].ToString() == "Admin")
    //    {
    //        DataTable dtMenu;
    //        DataTable dtSubMenu;

    //        dtMenu = user.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
    //        if (dtMenu.Rows.Count > 0)
    //            for (int row = 0; row < dtMenu.Rows.Count; row++)
    //            {
    //                HtmlTableCell cell = new HtmlTableCell();
    //                HtmlTableCell cellSub = new HtmlTableCell();
    //                cellSub.VAlign = "Top";
    //                cell.Width = "140px";
    //                cell.Height = "24px";
    //                cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
    //                cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
    //                cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
    //                if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
    //                {
    //                    if (Session["UserType"].ToString() == "Admin")
    //                        cell.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='Toolbar/ToolBarHome.aspx?Type=none'; expand('sub');");
    //                }
    //                else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
    //                {
    //                    cell.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; expand('sub');");
    //                }
    //                else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
    //                {
    //                    cell.Attributes.Add("onclick", "javascript: document.forms[0].action='default.aspx?Act=Logout'; document.forms[0].submit();");
    //                }

    //                menuMain.Cells.Add(cell);
    //                menuSub.Cells.Add(cellSub);

    //                dtSubMenu = user.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
    //                if (dtSubMenu.Rows.Count > 0)
    //                {
    //                    HtmlTable tblSub = new HtmlTable();
    //                    tblSub.CellPadding = 0;
    //                    tblSub.CellSpacing = 0;
    //                    tblSub.Border = 0;
    //                    tblSub.Width = cell.Width;
    //                    tblSub.ID = "sub" + row;
    //                    cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
    //                    //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
    //                    for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
    //                    {
    //                        HtmlTableRow rowSub = new HtmlTableRow();
    //                        HtmlTableCell cellSub1 = new HtmlTableCell();
    //                        cellSub1.BgColor = "#666666";
    //                        cellSub1.Height = "20px";
    //                        cellSub1.Style.Add("font-family", "Tahoma");
    //                        cellSub1.Style.Add("font-size", "8pt");
    //                        cellSub1.Style.Add("font-weight", "bold");
    //                        cellSub1.Style.Add("color", "White");
    //                        cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
    //                        cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
    //                        cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
    //                        // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
    //                        if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
    //                        {
    //                            cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
    //                        {
    //                            if (Session["UserType"].ToString() == "Private")
    //                                cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; expand('sub');");
    //                            else if (Session["UserType"].ToString() == "Admin")
    //                                cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UsersList.aspx'; expand('sub');");
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
    //                        {
    //                            if (Session["UserType"].ToString() == "Admin")
    //                                cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='GroupManager/AddGroup.aspx?Act=View'; expand('sub');");
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
    //                        {
    //                            cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='ContentBuilder/ContentBuilderPage.aspx'; expand('sub');");
    //                            //cellSub1.InnerHtml=http
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
    //                        {
    //                            cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='Forum/Discussion.aspx'; expand('sub');");
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
    //                        {
    //                            cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='TemplateManager/AddTemplates.aspx?Type=All'; expand('sub');");
    //                        }
    //                        else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
    //                        {
    //                            cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='ListBuilder/MainPage.aspx?SEARCH='; expand('sub');");
    //                        }

    //                        rowSub.Cells.Add(cellSub1);
    //                        tblSub.Rows.Add(rowSub);
    //                    }


    //                    cellSub.Controls.Add(tblSub);
    //                    //tblSub.Visible = false;
    //                    tblSub.Style.Add("visibility", "hidden");
    //                }

    //            }
    //        HtmlTableCell cell1 = new HtmlTableCell();
    //        cell1.InnerText = "�";
    //        // cell1.Width = "40%";
    //        menuMain.Cells.Add(cell1);
    //        //frmMain.Attributes.Add("src", "login.aspx");
    //        //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
    //        return menuTbl;
    //    }

    //    else
    //    {
    //        //frmMain.Style.Add("height", "100%");
    //        ////if (Session["CBId"] != null) tdMain.ResolveClientUrl("ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
    //        //tblMainMenu.Style.Add("visibility", "hidden");
    //        //trOuter.Visible = false;
    //        ////tblMainMenu.Attributes.Add("Visible", "false");
    //        ////tblMainMenu.Parent.Style.Add("visibility", "hidden");            
    //        //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
    //        //tdContent.InnerHtml = combi.GetPageContent(Session["CBId"].ToString()).Replace("../Images/", "Images/");
    //        // Response.Write(Session["CBId"].ToString());

    //        return menuTbl;
    //    }

    //}
}
