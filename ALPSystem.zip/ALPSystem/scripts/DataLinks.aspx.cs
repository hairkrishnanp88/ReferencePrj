using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;

public partial class scripts_DataLinks : System.Web.UI.Page
{
    ContentReader Obj = new ContentReader();
    Combisets Cobj = new Combisets();
    Lists Lobj = new Lists();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            Loadlinktypes();

        if (ddlLinktype.SelectedIndex >= 0)
        {
            if (ddlLinktype.SelectedValue  == "Pages")
            {
                lbList.Items.Clear();
                DataTable dtPageList = Obj.GetContentBuilderNamesAll();
                lbList.DataSource = dtPageList;
                lbList.DataValueField = "Dataid";
                lbList.DataTextField = "Name";
                lbList.DataBind();
            }
            else if(ddlLinktype.SelectedValue == "Pop Image")
            {
                lbList.Items.Clear();
                lbList.Items.Add("Add Image");                
                DataTable dtPoplist = Obj.ExecuteDTQuery("Select Distinct ImageNo, ImageDesc, Alt , width, Height from PopImages Order by ImageNo, ImageDesc");
                for (int i = 0; i < dtPoplist.Rows.Count; i++)
                {   int wd = int.Parse(dtPoplist.Rows[i]["Width"].ToString()) + 20;
                    int ht = int.Parse(dtPoplist.Rows[i]["Height"].ToString()) + 50;
                    lbList.Items.Add(new ListItem(dtPoplist.Rows[i]["Imagedesc"].ToString(), dtPoplist.Rows[i]["ImageNo"].ToString() + "#" + dtPoplist.Rows[i]["Alt"].ToString() + "#" + wd.ToString() + "#" + ht.ToString()));                    
                }
            }
            else if (ddlLinktype.SelectedValue == "Combiset")
            {
                lbList.Items.Clear();
                DataTable dtCombiList = Cobj.GetAllCombisets();
                lbList.DataSource = dtCombiList;
                lbList.DataValueField = "CombiId";
                lbList.DataTextField = "Combiname";
                lbList.DataBind();
            }
            else
            {
                lbList.Items.Clear();
                DataTable dtList = Lobj.GetAllListName();
                lbList.DataSource = dtList;
                lbList.DataValueField = "LBId";
                lbList.DataTextField = "Listname";
                lbList.DataBind();
            }

        }

        btnExit.Attributes.Add("onclick", "javascript: return OnExit();");
        btnSelect.Attributes.Add("onclick", "javascript: return OnSelect();");
        lbList.Attributes.Add("onclick", "javascript: Listclick();");
    }
    protected void Loadlinktypes()
    {
        ddlLinktype.Items.Add("Pages");
        ddlLinktype.Items.Add("Pop Image");
        ddlLinktype.Items.Add("Combiset");
        ddlLinktype.Items.Add("List Builder");

    }
}
