function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML-koodi";
    document.getElementById("btnClose").value = "Sulje";
    }
function writeTitle()
    {
    document.write("<title>Erikoismerkit</title>")
    }