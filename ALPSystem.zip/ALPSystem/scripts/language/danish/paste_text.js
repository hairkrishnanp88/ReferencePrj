function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Paste text content here (CTRL-V) ";
    document.getElementById("btnCancel").value = "Annuller";
    document.getElementById("btnOk").value = " Ok ";   
	}
function writeTitle()
	{
	document.write("<title>Paste Text</title>")
	}
