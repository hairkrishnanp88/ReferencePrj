﻿
function buttonmouseover(idvalue,textovercolor,bgovercolor)
{
    document.getElementById(idvalue).style.font.fontColor=textovercolor;
    document.getElementById(idvalue).style.backgroundColor=bgovercolor;

}

function buttonmouseout(idvalue,outtextcolor, outbgcolor)
{
    document.getElementById(idvalue).style.font.fontColor=outtextcolor;
    document.getElementById(idvalue).style.backgroundColor=outbgcolor;

}

function buttonfontstyle(idvalue,fonttype,fontsize,fontbold,fontcolor)
{
    document.getElementById(idvalue).style.fontFamily=fonttype;
    document.getElementById(idvalue).style.fontSize=fontsize+"pt";
    document.getElementById(idvalue).style.fontWeight=fontbold;
    document.getElementById(idvalue).style.font.fontColor=fontcolor;
}

function toolbarstyle(idvalue,bwidth,bordercolor,bgcolor)
{
    document.getElementById(idvalue).style.borderWidth=bwidth;
    document.getElementById(idvalue).style.borderColor=bordercolor;
    document.getElementById(idvalue).style.backgroundColor=bgcolor;
}