//					ContentPAL .Net
//					----------------
//
//					Version 1.0.0.1
//
//
//					�2006 Nextgen Web Services (India) Pvt. Ltd.
//
//

//Contentbuilder Login Template Javascripts
	 function EnterKeyLogin()
	    {
		 var btnName = "Submit";
		 if (Reg == 4)
		 {
		     document.onkeypress = function KeypressHandler()
		     {
			if (window.event.keyCode==13)
			    {
					 document.getElementById("RegImage").click();
				    }
			    }
		 }
		 else if (Reg == 3)
		 {
		     document.onkeypress = function KeypressHandler()
		      {
				   if (window.event.keyCode==13)
				    {
				       document.getElementById("SubmitImage").click();
				    }
				}
			}
			else
			{
			  for(var i=0;i<=document.all.length-1;i++)
		  {
		     if (document.all.item(i).id.substring(0,6)==btnName)
		     {
		      document.onkeypress = function KeypressHandler()
		       {
				    if (window.event.keyCode==13)
				    {
				       document.getElementById("SubmitImage").click();
				    }
				  }
			    }
			  }
		    }
	     }
	     function Pass(i)
	     {
	       Reg = i;
	    }
	    function Focus()
	    {
		var btnName = "txtUserName";
		for(var i=0;i<=document.all.length-1;i++)
		    {
		    if (document.all.item(i).id.substring(0,12)==btnName)
		    {
			document.getElementById('txtUserName').focus();
		    }
		}
	    }   

//End


//Adjust aspx page screen width and height
        var iframeids=["myframe"]

        //Should script hide iframe from browsers that don't support this script (non IE5+/NS6+ browsers. Recommended):
        var iframehide="yes"

        var getFFVersion=navigator.userAgent.substring(navigator.userAgent.indexOf("Firefox")).split("/")[1]
        var FFextraHeight=parseFloat(getFFVersion)>=0.1? 16 : 0 //extra height in px to add to iframe in FireFox 1.0+ browsers

        function resizeCaller()
        {
        var dyniframe=new Array()
        for (i=0; i<iframeids.length; i++){
        if (document.getElementById)
        resizeIframe(iframeids[i])
        //reveal iframe for lower end browsers? (see var above):
        if ((document.all || document.getElementById) && iframehide=="no"){
        var tempobj=document.all? document.all[iframeids[i]] : document.getElementById(iframeids[i])
        tempobj.style.display="block"
        }
        }
        }

        function resizeIframe(frameid)
        {
        var currentfr=document.getElementById(frameid)
        if (currentfr && !window.opera){
        currentfr.style.display="block"
        if (currentfr.contentDocument && currentfr.contentDocument.body.offsetHeight) //ns6 syntax
        currentfr.height = currentfr.contentDocument.body.offsetHeight+FFextraHeight; 
        else if (currentfr.Document && currentfr.Document.body.scrollHeight) //ie5+ syntax
        currentfr.height = currentfr.Document.body.scrollHeight;
        if (currentfr.addEventListener)
        currentfr.addEventListener("load", readjustIframe, false)
        else if (currentfr.attachEvent){
        currentfr.detachEvent("onload", readjustIframe) // Bug fix line
        currentfr.attachEvent("onload", readjustIframe)
        }
        }
        }

        function readjustIframe(loadevt) {
        var crossevt=(window.event)? event : loadevt
        var iframeroot=(crossevt.currentTarget)? crossevt.currentTarget : crossevt.srcElement
        if (iframeroot)
        resizeIframe(iframeroot.id);
        }

        function loadintoIframe(iframeid, url){
        if (document.getElementById)
        document.getElementById(iframeid).src=url
        }

        if (window.addEventListener)
        window.addEventListener("load", resizeCaller, false)
        else if (window.attachEvent)
        window.attachEvent("onload", resizeCaller)
        else
        window.onload=resizeCaller

//End

//Add BookMark
	function addBookmark(title,url)

	{if (window.sidebar) { window.sidebar.addPanel(title, url,"");
	 } 

	else if( document.all ) 
	{window.external.AddFavorite( url, title);
	}

	 else if( window.opera && window.print )
	 {return true;}
	}
//End

//Script for View images in New popup window        
    function MM_openBrWindow(theURL,winName,features) 
    { 
        window.open(theURL,winName,features);
    }
//end
    
//Script for Swap images
    <!--
    function MM_preloadImages() { //v3.0
      var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
        var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
        if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
    }

    function MM_swapImgRestore() { //v3.0
      var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
    }

    function MM_findObj(n, d) { //v4.01
      var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
        d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
      if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
      for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
      if(!x && d.getElementById) x=d.getElementById(n); return x;
    }

    function MM_swapImage() { //v3.0
      var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
       if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
    }
    
function Loginclear()
{
    document.frmpaylogin.txtEmpname.value="";
	document.frmpaylogin.txtEmpname.focus();
	return false;
}	
function Loginvalid()
{
    if(document.frmpaylogin.txtEmpname.value.replace(/^\s*|\s*$/g,"") == "")
    {
        alert('Please Enter the PPS Number');
        document.frmpaylogin.txtEmpname.focus();
        return false;
    }
    else
    {
        return true;
    }
    
}
function onMouseChange(id,file)
     {
      var v = document.getElementById(id);
      v.src =file;
      }

function Validate()
		{
			
			if (document.frmSave.txtTemplateName.value == "")
			{	
				alert("Please enter the Template Name");		
				return false;
			}
					
			if(document.frmSave.txtTemplateLocation.value == "")
			{
				alert("Please select Template Location");		
				return false;
			}
			if(document.frmSave.txtBulletImgLocation.value == "")
			{
			   alert("Please select Bullet Image Location");		
				return false;
			}			
			else
			    return true;
			
			
		}	
		function val()
		{
		    if(document.frmadd.txtTemplateName.value=="")
		    {
		        alert("Please enter the Template Name");
		        return false;
		    }
		    else
		        return true;    
		     
		}
function ShowPopupWindow(URL,Title)
{
	var ivlWidth = screen.width - 500
	var ivlHeight = screen.height - 110
	var ivlTop=(screen.height-ivlHeight)/2 - 25;
	var ivlLeft=(screen.width-ivlWidth)/2;
	var sFeatures ="height=" + ivlHeight + ", width=" + ivlWidth + ", left=" + ivlLeft + ", top=" + ivlTop + ",scrollbars=0, status=0,resizable=yes" ;
	window.open(URL,Title,sFeatures);
}

function ConverDateUStoUK(strDate)
{
	var arrDate;
	var stDate=strDate;
		
	if(strDate.indexOf("/")!=-1)
	{
		arrDate=strDate.split("/");		
	}
	else if(stDate.indexOf("-")!=-1)
	{
		arrDate=strDate.split("-");
	}
	else
	{
		alert("Check date format");
	}
	return (arrDate[1]+ "-" + arrDate[0] + "-" + arrDate[2]);
}

function ShowEditor(urlValue) {
var ivlWidth = 755;
	var ivlHeight =550;
	var ivlTop=(screen.height-ivlHeight)/2 - 25;
	var ivlLeft=(screen.width-ivlWidth)/2;
	var sFeatures ="height=" + ivlHeight + ", width=" + ivlWidth + ", left=" + ivlLeft + ", top=" + ivlTop + ",scrollbars=0, status=0,resizable=yes" ;
	window.open(urlValue,"Editor",sFeatures);
}
function Validate()
		{
			
			if (document.frmSave.txtTemplateName.value == "")
			{	
				alert("Please enter the Template Name");		
				return false;
			}
			else if(document.frmSave.txtTemplateLocation.value == "")
			{
				alert("Please select Template Location");		
				return false;
			}
			else if(document.frmSave.txtBulletImgLocation.value=="")
			{
			   alert("Please select Bullet Image Location");		
				return false;
			}
			else
			    return true;
			
			
		}	

function filldata()
	{
		
		
		if(document.frmFileUpload.hideEventId.value=="TempLoc")
	    { 
			
			window.opener.document.all.txtTemplateLocation.value=document.frmFileUpload.hideFileName.value;
			
			window.open("ShowAttachments.aspx?IMGURL="+document.frmFileUpload.hideImgLoc.value,null,'top=300, left=300, height=250, width=500,status= no, resizable= no, scrollbars=no, toolbar=no,location=no,menubar=no');
			window.close();
		}
		else
		{
		    
			window.opener.document.all.txtBulletImgLocation.value =document.frmFileUpload.hideFileName.value;
			
			window.close();
		}
	}

function open_markers(type)
{
    
    var ivlWidth = 755;
	var ivlHeight =550;
	var ivlTop=(screen.height-ivlHeight)/2 - 25;
	var ivlLeft=(screen.width-ivlWidth)/2;
	var sFeatures ="height=" + ivlHeight + ", width=" + ivlWidth + ", left=" + ivlLeft + ", top=" + ivlTop + ",scrollbars=0, status=0,resizable=yes" ;
	
    if((type=="Page")||(type=="Ebook"))
        window.open("./PageMarkers.aspx","Markers",sFeatures);
       else if(type=="Shopping")
            window,open("./ShoppingMarkers.aspx","Markers",sFeatures);
       else if(type=="Business")
            window,open("BusinessMarkers.aspx","Markers",sFeatures);
       else if(type=="Product")
            window,open("ProductMarkers.aspx","Markers",sFeatures);
       else if(type=="Form")
            window,open("FormMarkers.aspx","Markers",sFeatures);
       else 
            window,open("EmailMarkers.aspx","Markers",sFeatures);
}

function del()
{
	if(confirm("Do you want to remove the template?"))
	    return false;
	else 
		return true;
}	

function expand() 
{
	window.moveTo(0,0);
	window.resizeTo(screen.availWidth, screen.availHeight);
}

function hide()
{
   for(var i=0;i<=document.all.length-1;i++)
	{
		if (document.all.item(i).id.substring(0,3)=="fly")
    		document.all.item(i).style.display='none';
					
		if (document.all.item(i).id.substring(0,3)=="img")
			document.all.item(i).src='../Images/plus.gif';
					
					
	}
			
}


function BrValidate()
{
    if (document.getElementById('txtTempname').value == "")
	{	
		alert("Please select the Template Name.");	
		document.getElementById('txtTempname').focus();	
		return false;
	}
	else if (document.getElementById('txtPageName').value == "")
	{
	   alert("Please enter the Page Name.");	
	   document.getElementById('txtPageName').focus();	
	   return false;
	}
	return true;
}	

function FoValidate()
{
    if(document.getElementById('txtname').value == "")
    {
        alert("Please enter the Folder Name.");
        return false;
    }
    else
    {
        return true;
    }
}

function AddValidate()
{
    if(document.getElementById('Fid').value == "")
    {
        alert("Cannot add under this node,select its parent to add");
        return false;
    }
    else
    {
        return true;
    }
}

function ModifyValidate()
{
    if(document.getElementById('txtModifyname').value == "")
    {
        alert("Please enter the Folder Name.");
        return false;
    }
    else
    {
        return true;
    }
}

function delet()
{
	if(confirm("Do you want to remove the template?"))
	    return false;
	else 
		return true;
}	
function ToolBarLocationChange()
{
    var pval = document.getElementById('DropToolLocation').options[document.getElementById('DropToolLocation').selectedIndex].value ;
    var svlToolBarContent = ""
    pval="txt" + pval;
    document.getElementById('DropSelectTool').selectedIndex = 0;
    for(i=0;i<document.getElementById('DropSelectTool').length;i++) 
    {
	    svlToolBarContent=document.getElementById(pval).value;
	    var ddlObj=document.getElementById('DropSelectTool');
	    if(ddlObj[i].value==svlToolBarContent)
	    {
	        document.getElementById('DropSelectTool').selectedIndex=i;
	    }
    }
}

function ToolBarchange()
{
	var id;
	id=document.getElementById('DropToolLocation').selectedIndex+1;
	//alert(document.getElementById('DropSelectTool').options[document.getElementById('DropSelectTool').selectedIndex].value);
	document.getElementById('txtToolBar'+ id).value=document.getElementById('DropSelectTool').options[document.getElementById('DropSelectTool').selectedIndex].value;
	
}

//function ShowPreviewScreen(svlMode,svlDataId,svlTempId,svlMod,svlTool1,svlTool2,svlTool3,svlTool4)
//{
//    if(BrValidate())
//    {
//        var svlTooll1=document.getElementById('txtToolBar1').value;
//        var svlTooll2=document.getElementById('txtToolBar2').value;
//        var svlTooll3=document.getElementById('txtToolBar3').value;
//        var svlTooll4=document.getElementById('txtToolBar4').value;
//        //alert(svlTempId);
//        //alert(svlTooll1);
//        window.open("PreviewPage.aspx?Mode=" + svlMode + "&DataId=" + svlDataId + "&Tempid=" + svlTempId + "&Mod1 = " + svlMod  + "&Tool1=" + svlTooll1 + "&Tool2=" + svlTooll2 + "&Tool3=" + svlTooll3 + "&Tool4=" + svlTooll4 ,'','scrollbars=1,resizable=1,status=0,center=1,left=0, top=0;');
//        return false;
//    }
//   
//}


function ShowPreviewScreen(svlMode,svlDataId,svlTempId,svlMod,svlTool1,svlTool2,svlTool3,svlTool4,svlList1,svlList2,svlList3,svlList4,svlList5,svlList6)
{
    if(BrValidate())
    {
        var svlTooll1=document.getElementById('txtToolBar1').value;
        var svlTooll2=document.getElementById('txtToolBar2').value;
        var svlTooll3=document.getElementById('txtToolBar3').value;
        var svlTooll4=document.getElementById('txtToolBar4').value;
        
        var svlList1=document.getElementById('txtList1').value;
        var svlList2=document.getElementById('txtList2').value;
        var svlList3=document.getElementById('txtList3').value;
        var svlList4=document.getElementById('txtList4').value;
        var svlList5=document.getElementById('txtList5').value;
        var svlList6=document.getElementById('txtList6').value;        
        var aspxpage = document.getElementById('txtFilename').value;
        
               
      //  txtLists
        //alert(svlTempId);
        //alert(svlTooll1);
       // alert(svlLists);
        window.open("PreviewPage.aspx?Mode=" + svlMode + "&DataId=" + svlDataId + "&Tempid=" + svlTempId + "&Mod1 = " + svlMod  + "&Tool1=" + svlTooll1 + "&Tool2=" + svlTooll2 + "&Tool3=" + svlTooll3 + "&Tool4=" + svlTooll4 +"&List1=" + svlList1 + "&List2=" + svlList2 + "&List3=" + svlList3 + "&List4=" + svlList4 +"&List5=" + svlList5 + "&List6=" + svlList6 +"&aspxpage="+ aspxpage,'','scrollbars=1,resizable=1,status=0,center=1,left=0, top=0;');
        
        return false;
    }
   
}

function Listchange()
{
    var id;
   
	var ddlvalue=document.getElementById("DropSelectList").value;
	var len;
	len = ddlvalue.substring(4,5);
	document.getElementById('txtList'+ len).value=document.getElementById('DropListName').options[document.getElementById('DropListName').selectedIndex].value;
}

function ListLocationChange()
{
    //alert("List");
    var pval = document.getElementById('DropSelectList').options[document.getElementById('DropSelectList').selectedIndex].value ;
    var svlListContent = ""
    
    pval="txt" + pval;
    //alert (pval);
    document.getElementById('DropListName').selectedIndex = 0;
    for(i=0;i<document.getElementById('DropListName').length;i++) 
    {
	    svlListContent=document.getElementById(pval).value;
	    var ddlObj=document.getElementById('DropListName');
//	    alert(svlListContent);
//	    alert(ddlObj[i].value);
	    if(ddlObj[i].value==svlListContent)
	    {
	        document.getElementById('DropListName').selectedIndex=i;
	    }
    }
}

// Menu Bar Display Coding
function expand(idval)
{
var mnu=0;
for(mnu=0;mnu<10;mnu++)
{
if(document.getElementById("sub"+mnu)!=null && document.getElementById("sub"+mnu).id==idval)
{
if(document.getElementById(idval).style.display == "inline")
    document.getElementById(idval).style.display = "none";
else
    document.getElementById(idval).style.display="inline";

}
else if(document.getElementById("sub"+mnu)!=null)
document.getElementById("sub"+mnu).style.display="none";
}
}
		
function collapse(idval)
{
    var mnu=0;
    for(mnu=0;mnu<10;mnu++)
    {
   if(document.getElementById("sub"+mnu)!=null && document.getElementById("sub"+mnu)!=idval)
	document.getElementById("sub"+mnu).style.display="none";
   }
}
// skin window
function ShowNewJob(url)
{
	var windowW=400; // wide
	var windowH=200; // high
	var windowX = (screen.width/2)-(windowW/2);
	var windowY = (screen.height/2)-(windowH/2);
	var sFeatures = "height=" + windowH + ", width=" + windowW + ", left=" + windowX + ", top=" + windowY + "; status=no; toolbar=no; menubar=no; scrollbars=0" 	
	window.open(url,"Menu",sFeatures);
}

function scrollMsg(myMsg) 
{
			window.status = myMsg.substring(i,myMsg.length) + myMsg.substring(0,i-1)
			if (i < myMsg.length) 
			{
				i++
			}
			else
			{
				i = 0
			}
			setTimeout("scrollMsg()",100)
}

function Combi_onChange(CombiId, DataId)
{
    document.form1.action = "./View.aspx?CId=" + CombiId + "&Mode=Preview&From=Index&DId=" + DataId
    document.form1.submit();
}