﻿// JScript File
  function SearchValidate()
{
   if(document.getElementById('txtPageSearch').value=="" || document.getElementById('txtPageSearch').value.charAt(0)==" ")
	{
		alert("Please make a valid entry!");
		return false;
	}
	else
	{			
	return true;
	}
}

function fnDdelete()
{
			//alert("HideValue"+document.Form1.HideFolderId.value);
//			alert("kartik");
//			if(confirm("Are You Sure to Delete This Set?"))
//			{
//				document.form1.action="view.aspx?From=&Mode=Delete&CSID="+document.getElementById('HideCSIDIndelet').value;
//					//alert(document.Form1.action);
//				document.Form1.submit();
//				return;
//			}
			
	
	   if(confirm("Do you want to remove the CombiSet?"))
	           return false;
	     else 
		return true;
   
			//document.getElementById("Atagdel").setAttribute('href','ListingBrouchSet.aspx?Mode=Delete&FolderId+document.Form1.HideFolderId.value);
}

function ValidateAndPreserve()
{
	if(document.getElementById('txtPageSearch').value=="")
	{
		return false;
	}
	    document.getElementById('HidePreserve').value="";
		document.getElementById('HideValue').value="";
	
	
	var l=document.getElementById('lstSelected').length;
	//alert(document.Form1.selSelected.options[0].text);
	for(var i=0;i<l;i++)
	{
	 //document.Form1.HidePreserve.value="Gkarthkeyan";
	 document.getElementById('HidePreserve').value+=document.getElementById('lstSelected').options[i].text+"#";
	 document.getElementById('HideValue').value+=document.getElementById('lstSelected').options[i].value+"#";
	}
	
}

function Add()
{
	//document.getElementById("lstAvailable").
	//alert("fg");
	//form.List2.options[form.List2.selectedIndex].value;
	//alert(Select1.selectedIndex);
	//alert(document.Form1.Select1.options[document.Form1.Select1.selectedIndex].value);
}

//---------------------


function fnMaintainStar()
{
    if(document.getElementById('lstSelected').selectedIndex != -1)
    {
        if(document.getElementById('ChkAddtoCmb').checked==false)
        {
            var l=document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text.length;
            //alert(document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(1,l));
            document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text=document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(1,l) ;            
            var idx=document.getElementById('lstSelected').length-(document.getElementById('lstSelected').selectedIndex);//+1).selected=true;
            //alert(idx);
            //document.getElementById('lstSelected').selectedIndex=document.getElementById('lstSelected').selectedIndex+1;// idx;
            //alert(document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(0,1));            
            //if(document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(0,1)=='*')
            //{
              //  document.getElementById('ChkAddtoCmb').checked=true;
            //}
            
        
        }
        else if(document.getElementById('ChkAddtoCmb').checked==true)
        {
         document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text="*"+document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text ;
        }
    }
    
    
//  else if(document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text.substring(0,1)!="*")   //document.getElementById('ChkAddtoCmb').checked==true)
//   {
//    
//     document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text="*"+document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text;
//     document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex+1].selected=true;
//     
//   }
    
//   if(document.getElementById('lstSelected').options[ document.getElementById('lstSelected').selectedIndex].text.substring(0,1)!='*')
//   {
//     document.getElementById('ChkAddtoCmb').checked=false;
//   }
}

function fnMaintainStar2()  //firing from asp listbox.click
{
   if(document.getElementById('lstSelected').selectedIndex != -1)
   { 
        if(document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(0,1)!='*')    
        {
            document.getElementById('ChkAddtoCmb').checked=false;
        }
        else if(document.getElementById('lstSelected').options[document.getElementById('lstSelected').selectedIndex].text.substring(0,1)=='*')
        {
            document.getElementById('ChkAddtoCmb').checked=true;
        }
    }
}

function AddSelectedItem(objSourceCombo, objTargetCombo) {

var txt,val;
		
	if (objSourceCombo.selectedIndex >= 0 )  {  
	    if(document.getElementById('chkDisplayASCombo').checked)
	    {
	    document.getElementById('ChkAddtoCmb').checked=true; 
	    
	            		
		txt = "*"+objSourceCombo.options[objSourceCombo.selectedIndex].text;
		val = objSourceCombo.options[objSourceCombo.selectedIndex].value;
		}
		else if(document.getElementById('chkDisplayASCombo').checked==false)
		{
		txt = objSourceCombo.options[objSourceCombo.selectedIndex].text;
		val = objSourceCombo.options[objSourceCombo.selectedIndex].value;
		}
		//alert(val);
		for(var j=0; j<objTargetCombo.length;j++) {
            if(objTargetCombo.options[j].text == txt) {
                alert("You have selected this match already");
                return
            }
        }
        
       // alert(objTargetCombo.options[objTargetCombo.length]);
       
        objTargetCombo.options[objTargetCombo.length] = new Option(txt,val);
        
        var k = objSourceCombo.length - 1
        if (objSourceCombo.selectedIndex < k) {
			objSourceCombo.options[objSourceCombo.selectedIndex+1].selected = true;
		}
	 }
    
}

function RemoveSelectedItem(objTargetCombo) {	
	len = objTargetCombo.length
	if(len == 0) {
        alert("No match has been selected for removal");
        return
    }
    if(objTargetCombo.selectedIndex == -1) {
        alert("please select a match to remove");
        return
    }
    objTargetCombo.options[objTargetCombo.selectedIndex] = null;
    if(objTargetCombo.length > 0) {
        objTargetCombo.options[objTargetCombo.length-1].selected = true;
    }
}

function MoveDownSelectedItem(objCombo) {
    indx = objCombo.selectedIndex;
    if (indx == -1 && objCombo.length > 0) 
		indx=0
    if(indx==objCombo.length-1) {
        return;
    }
    temptxt = objCombo.options[indx+1].text;
    tempval = objCombo.options[indx+1].value;
    txt = objCombo.options[indx].text;
    val = objCombo.options[indx].value;
    //alert(val);
    objCombo.options[indx+1] = new Option(txt,val);
    objCombo.options[indx] = new Option(temptxt,tempval);
    objCombo.options[indx+1].selected = true;
}

function MoveUpSelectedItem(objCombo) {
    indx = objCombo.selectedIndex;
    if(indx<1) {
        return;
    }
    temptxt = objCombo.options[indx-1].text;
    tempval = objCombo.options[indx-1].value;
    txt = objCombo.options[indx].text;
    val = objCombo.options[indx].value;
    objCombo.options[indx-1] = new Option(txt,val);
    objCombo.options[indx] = new Option(temptxt,tempval);
    objCombo.options[indx-1].selected = true;
}

function AddComboValuesToTextField(objVar)
{
debugger;
//alert(objVar);
if(document.getElementById('lstSelected').length>0)
{
	document.getElementById('HideIndex').value = "";
	for (var ivlToAddressLoop=0; ivlToAddressLoop<document.getElementById('lstSelected').length; ivlToAddressLoop++) 
	{
		if (document.getElementById('HideIndex').value != "")
			document.getElementById('HideIndex').value = document.getElementById('HideIndex').value + ","
			if(document.getElementById('lstSelected').options[ivlToAddressLoop].text.substring(0,1)=="*")
			{
			    document.getElementById('HideIndex').value = document.getElementById('HideIndex').value +"cbo"+document.getElementById('lstSelected').options[ivlToAddressLoop].value;
			}
			else
			{
			    document.getElementById('HideIndex').value = document.getElementById('HideIndex').value + document.getElementById('lstSelected').options[ivlToAddressLoop].value;
			}
			var SelValue=document.getElementById('lstSelected').options[ivlToAddressLoop].text;
			if((SelValue.substring(0,15)=="Parent Folder -")||(SelValue.substring(0,15)=="-- Child Folder"))// Folder")
			{
				alert("Please Select Data Only..");
				return false;
			}
	}
	

	
	//alert(document.Form1.HideFolderId.value);
	//alert(document.Form1.HideIndex.value );
	document.getElementById('HideIndex').value=document.getElementById('HideIndex').value+","
	
	
	while(''+document.getElementById('txtPageSearch').value.charAt(0)==' ')
	{
	document.getElementById('txtPageSearch').value=document.getElementById('txtPageSearch').value.substring(1,document.getElementById('txtPageSearch').value.length);
	}
	
	while(''+document.getElementById('txtPageSearch').value.charAt(document.getElementById('txtPageSearch').value.length-1)=='')
	{
		document.getElementById('txtPageSearch').value=document.getElementById('txtPageSearch').value.substring(0,document.getElementById('txtPageSearch').value.length-1)
	}
	
	var searchval= document.getElementById('txtPageSearch').value;
	var QryUpon=document.getElementById('selQryUpOn').selectedIndex;
	var OrderBy=document.getElementById('selOrderBy').selectedIndex;
	var OrderbyVal=document.getElementById('selOrderByVal').selectedIndex;
	var temp;

    if(objVar=='A')
    {

        temp ="./view.aspx?CSID=&DataIds="+document.getElementById('HideIndex').value+"&Mode=PreviewSave&SearchValue="+searchval+"&QryUpOn="+QryUpon+"&OrderBy="+OrderBy+"&OrderByVal="+OrderbyVal+"&From=AddCombi";
        //alert(temp);
        //window.location="./ShowSetOfData.aspx?DataIds='+document.Form1.HideIndex.value+'&Mode=PreviewSave&FolderId='+document.Form1.HideFolderId.value+'&SearchValue='+searchval+'&QryUpOn='+QryUpon+'&OrderBy='+OrderBy+'&OrderValue="+OrderbyVal;
        //window.location=temp;//"./ShowSetOfData.aspx?DataIds="+document.Form1.HideIndex.value+"&Mode=PreviewSave&FolderId="+document.Form1.HideFolderId.value+"&SearchValue="+searchval+"&QryUpOn="+QryUpon+"&OrderBy="+OrderBy+"&OrderValue="+OrderbyVal;
    	
    	
        //alert(document.getElementById('HideIndex').value);
        form1.action=temp;
        form1.submit();
    }
    else if(objVar=='M')
    {
        temp ="./view.aspx?CSID=&DataIds="+document.getElementById('HideIndex').value+"&Mode=PreviewSave&SearchValue="+searchval+"&QryUpOn="+QryUpon+"&OrderBy="+OrderBy+"&OrderByVal="+OrderbyVal+"&From=ModCombi";
        //alert(temp);
        //window.location="./ShowSetOfData.aspx?DataIds='+document.Form1.HideIndex.value+'&Mode=PreviewSave&FolderId='+document.Form1.HideFolderId.value+'&SearchValue='+searchval+'&QryUpOn='+QryUpon+'&OrderBy='+OrderBy+'&OrderValue="+OrderbyVal;
        //window.location=temp;//"./ShowSetOfData.aspx?DataIds="+document.Form1.HideIndex.value+"&Mode=PreviewSave&FolderId="+document.Form1.HideFolderId.value+"&SearchValue="+searchval+"&QryUpOn="+QryUpon+"&OrderBy="+OrderBy+"&OrderValue="+OrderbyVal;
    	
    	
        //alert(document.getElementById('HideIndex').value);
        form1.action=temp;
        form1.submit();
    
    }	
}
else
{
    alert("Please Select Atleast One Data!");
}
			
}

function ViewHideIndex()
{
	//alert("hi script");
	//alert(document.Form1.HideIndex.value);
	
}


function ChkChange()
{

	if(document.getElementById('chkPreserve').checked==1)
	{
		document.getElementById('HideChkstatus').value="Set";
		
	}
	else
	{
		document.getElementById('HideChkstatus').value="Reset";
	}
}

function fnfocus()
{
	document.getElementById('txtPageSearch').focus();
}



function Swap(Objimg,ObjStatus)
{   
//alert(Objimg.id);
//alert(ObjStatus);
    var theImg;
    theImg=document.getElementById(Objimg.id);
    
   if(ObjStatus=="In")
    {   
        switch(Objimg.id)
            {
            case "imgAdd":
                theImg.setAttribute("src","../Images/Combiset/Add_over.gif");
            break;
            case "imgDel":
                theImg.setAttribute("src","../Images/Combiset/Del_over.gif");
            break;
            case "imgUp":
                theImg.setAttribute("src","../Images/Combiset/up_over.gif");
            break;
            case "imgDown":
                theImg.setAttribute("src","../Images/Combiset/down_over.gif");
            break;
            }
    }
    
    else
    {
      switch(Objimg.id)
            {
            case "imgAdd":
                theImg.setAttribute("src","../Images/Combiset/Add.gif");
            break;
            case "imgDel":
                theImg.setAttribute("src","../Images/Combiset/del.gif");
            break;
            case "imgUp":
                theImg.setAttribute("src","../Images/Combiset/up.gif");
            break;
            case "imgDown":
                theImg.setAttribute("src","../Images/Combiset/down.gif");
            break;
            }
        
    }
   
}