using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;



public partial class _Default : System.Web.UI.Page 
{
    NGWS.CMPApplication.UserManager user = new NGWS.CMPApplication.UserManager();
    NGWS.CMPApplication.Combisets combi = new NGWS.CMPApplication.Combisets();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        Page.Title = Session["SiteName"].ToString();
        string action=Request.QueryString["Act"];
        if (action == "Logout")
        {
            Session["UserType"] = "Anonymous";
            Session["UserId"] = "";
            Session["UserName"] = "";
            Session["FullName"] = "";
            Session["CBId"] = "";
            Response.Redirect("index.aspx");
        }

        if (Session["UserType"].ToString() == "Admin")
        {
            DataTable dtMenu;
            DataTable dtSubMenu;

            dtMenu = user.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");

            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        if (Session["UserType"].ToString() == "Admin")
                            cell.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='Toolbar/ToolBarHome.aspx?Type=none'; expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='default.aspx?Act=Logout'; document.forms[0].submit();");
                    }

                    trMainMenu.Cells.Add(cell);
                    trSubMenu.Cells.Add(cellSub);

                    dtSubMenu = user.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");

                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='UserManager/UsersList.aspx'; expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='GroupManager/AddGroup.aspx?Act=View'; expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.getElementById('frmMain').src='ContentBuilder/ContentBuilderPage.aspx'; expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='Forum/Discussion.aspx'; expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='TemplateManager/AddTemplates.aspx?Type=All'; expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.getElementById('frmMain').src='ListBuilder/MainPage.aspx?SEARCH='; expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("visibility", "hidden");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            trMainMenu.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
        }
        else
        {
            frmMain.Style.Add("height", "100%");
            ////if (Session["CBId"] != null) tdMain.ResolveClientUrl("ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
            //tblMainMenu.Style.Add("visibility", "hidden");
            trOuter.Visible = false;
            ////tblMainMenu.Attributes.Add("Visible", "false");
            ////tblMainMenu.Parent.Style.Add("visibility", "hidden");            
            if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());
            //tdContent.InnerHtml = combi.GetPageContent(Session["CBId"].ToString()).Replace("../Images/", "Images/");
            // Response.Write(Session["CBId"].ToString());

        }
        
    }
     
}
