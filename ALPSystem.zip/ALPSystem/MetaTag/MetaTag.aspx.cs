/// Written By gk April 24

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class TemplateManager_MetaTag : System.Web.UI.Page
{
    MetaTag objMetaTag = new MetaTag();
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.ValidateSession();
       // Page.Title = Session["SiteName"].ToString();
        //Gk April 25
        if (Application["SiteName"] != null)
        {
            Page.Title = Application["SiteName"].ToString();
        }
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End


        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());
        
        //-------------------------------------------------
        //April 24
        if (!Page.IsPostBack)
        {
            ToolbarRunAt.Visible = false;
        }
      
    }
    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    protected void ddlModuletype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlModuletype.SelectedIndex == 2)
        {
            ToolbarRunAt.Visible = true;
            BindDdlToolbar();
            txtAuthor.Text = "";
            txtemail.Text = "";
            txtCopyRight.Text = "";
            txtDesc.Text = "";
            txtemail.Text = "";
            txtFilename.Text = "";
            txtHeading.Text = "";
            txtkeywords.Text = "";
            txtLanguage.Text = "";
            txtTitle.Text = "";
            ddlPages.Items.Clear();
            ddlPages.Items.Insert(0, "None");
        }
        else if(ddlModuletype.SelectedIndex >0)
        {
           BindDdlPage(ddlModuletype.SelectedIndex);
           ToolbarRunAt.Visible = false;
        }
        else if (ddlModuletype.SelectedIndex == 0)
        {
            ToolbarRunAt.Visible = false;
            clearFunction();

        }

        if (ddlPages.SelectedIndex == 0)
        {
            txtAuthor.Text = "";
            txtemail.Text = "";
            txtCopyRight.Text = "";
            txtDesc.Text = "";
            txtemail.Text = "";
            txtFilename.Text = "";
            txtHeading.Text = "";
            txtkeywords.Text = "";
            txtLanguage.Text = "";
            txtTitle.Text = "";
        }
           
    }

    private void clearFunction()
    {
        txtAuthor.Text = "";
        txtemail.Text = "";
        txtCopyRight.Text = "";
        txtDesc.Text = "";
        txtemail.Text = "";
        txtFilename.Text = "";
        txtHeading.Text = "";
        txtkeywords.Text = "";
        txtLanguage.Text = "";
        txtTitle.Text = "";
        ddlPages.Items.Clear();
        ddlPages.Items.Insert(0, "None");
        ddlToolbar.Items.Clear();
        ddlToolbar.Items.Insert(0, "None");
        chkLogo.Checked = false;
        ddlToolbar.SelectedIndex = 0;
    }

    private void clearFunctionForPage()
    {
        txtAuthor.Text = "";
        txtemail.Text = "";
        txtCopyRight.Text = "";
        txtDesc.Text = "";
        txtemail.Text = "";
        txtFilename.Text = "";
        txtHeading.Text = "";
        txtkeywords.Text = "";
        txtLanguage.Text = "";
        txtTitle.Text = "";
        ddlPages.Items.Clear();
        ddlPages.Items.Insert(0, "None");
        //ddlToolbar.Items.Clear();
        //ddlToolbar.Items.Insert(0, "None");
        chkLogo.Checked = false;
        ddlToolbar.SelectedIndex = 0;
    }

    private void BindDdlPage(int Idx)
    {
        objMetaTag.idx = Idx;
        DataTable dtPage=objMetaTag.LoadDdlPage();
        ddlPages.DataSource = dtPage;
        ddlPages.DataTextField = dtPage.Columns[1].ToString();
        ddlPages.DataValueField = dtPage.Columns[0].ToString();
        ddlPages.DataBind();
        ddlPages.Items.Insert(0, "None");
    }

    private void BindTextBoxes(string objId)
    {
        objMetaTag.cmp_ObjectId = objId;
        DataTable dtContent=objMetaTag.GetContentMeta();

        if (dtContent.Rows.Count > 0)
        {
            txtTitle.Text = dtContent.Rows[0]["Title"].ToString();
            txtHeading.Text = dtContent.Rows[0]["Heading"].ToString();
            txtFilename.Text = dtContent.Rows[0]["SaveAsFileName"].ToString();
            txtDesc.Text = dtContent.Rows[0]["Description"].ToString();
            txtAuthor.Text = dtContent.Rows[0]["Author"].ToString();
            txtemail.Text = dtContent.Rows[0]["AuthorEmail"].ToString();
            txtkeywords.Text = dtContent.Rows[0]["Keywords"].ToString();
        }

    }

    private void BindDdlToolbar()
    {
        DataTable dt = new DataTable();
        dt=objMetaTag.LoadToolbar();
        ddlToolbar.DataSource = dt;
        ddlToolbar.DataTextField = dt.Columns[1].ToString();
        ddlToolbar.DataValueField = dt.Columns[0].ToString();
        ddlToolbar.DataBind();
        ddlToolbar.Items.Insert(0, "None");
       
     }
    protected void ddlToolbar_SelectedIndexChanged(object sender, EventArgs e)
    {
        objMetaTag.toolBarId = ddlToolbar.SelectedValue.ToString();
        BindDdlPage(2);
        if (ddlToolbar.SelectedIndex == 0)
        {
            ToolbarRunAt.Visible = false;
            ddlModuletype.SelectedIndex = 0;
            clearFunction();
        }
        
    }
    protected void ddlPages_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindTextBoxes(ddlPages.SelectedValue);
        if(ddlPages.SelectedIndex==0)
            clearFunctionForPage();
    }
    protected void btnSaves_Click(object sender, EventArgs e)
    {
        objMetaTag.cmp_ObjectId = ddlPages.SelectedValue.ToString();
        objMetaTag.ModuleType = GetModuleType();
        objMetaTag.Title = txtTitle.Text.ToString().Trim().Replace("'","''");

        if (txtTitle.Text.ToString().Trim().Replace("'", "''") == "")
        {
           objMetaTag.Title=objMetaTag.GetSiteTitle();

        }
        objMetaTag.Heading = txtHeading.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.FileName = txtFilename.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.Description = txtDesc.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.Author = txtAuthor.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.AuhtorMail = txtemail.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.KeyWords = txtkeywords.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.Category = ddlCategory.SelectedItem.Text;
        objMetaTag.Rating = ddlRating.SelectedItem.Text;
        objMetaTag.Language = txtLanguage.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.Robots = ddlRobots.SelectedItem.Text.Replace("'", "''");
        objMetaTag.CopyRight = txtCopyRight.Text.ToString().Trim().Replace("'", "''");
        objMetaTag.ContentPALLOGO = (chkLogo.Checked) ? 'y' : 'n';
        objMetaTag.Status = 'M';
        objMetaTag.DoSaveMetaTag();
    }
    private string GetModuleType()
    {
        if (ddlModuletype.SelectedIndex > 0)
        {
            if (ddlModuletype.SelectedIndex == 1)
                return "DA";
            else if (ddlModuletype.SelectedIndex == 2)
                return "DA";
            else if (ddlModuletype.SelectedIndex == 3)
                return "DA";
            else if (ddlModuletype.SelectedIndex == 4)
                return "CS";
            else if (ddlModuletype.SelectedIndex == 5)
                return "LB";
            else
                return "";
        }
        else
        {
            return "";
        }
    }
}


