using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;


public partial class FileUpload : System.Web.UI.Page
{
    private long lngMaxFileSize;
    string qryStringVar;
    string strFileDir;
    Templates dbf = new Templates();
    protected void Page_Load(object sender, EventArgs e)
    {
        qryStringVar = Request.QueryString["value"];
        hideEventId.Value = qryStringVar;
        if (qryStringVar == "ImgLoc")
            tblHeader.InnerText = "Image Upload";
        else
            tblHeader.InnerText = "Template Upload";
        
    }
    

    private string  findimageurl(string templatecontent)
    {
        string none="";
        if (templatecontent.Length > 0)
        {
            String strSource = templatecontent;
			String imgurls="";
			Int32 Arraylength,lastIndex1,lastIndex2,arrLength,arrPrevious;
			String strResult,strPattern,strFinal;

			strPattern = "";
			
			
			String[] strTest = new String[100];
			strTest = strSource.Split('.');

			String[] strImageType = {"jpg","gif","bmp","ico","png","wmf","jpe"};
						
			Arraylength = strTest.Length;

			for(int i=1;i<Arraylength;i++)
			{

                if (strTest[i].Length >= 3)
                {
                    strPattern = strTest[i].Substring(0, 3).Trim();
                }
                else
                    strPattern = "";
				

				for(int image=0;image<strImageType.Length;image++)
				{

					if(strPattern == strImageType[image])
					{

						arrPrevious = i-1;
                        string  test=strTest[arrPrevious];
						lastIndex1 = strTest[arrPrevious].LastIndexOf("(");
						lastIndex2 = strTest[arrPrevious].LastIndexOf('"');
                        if (lastIndex1 < 0)
                            lastIndex1 = 0;
                        if (lastIndex2 < 0)
                            lastIndex2 = 0;
						
						if(lastIndex1 > lastIndex2)
						{

							arrLength = strTest[arrPrevious].Length;

							int total = arrLength - lastIndex1;

							strFinal = strTest[arrPrevious].Substring(lastIndex1,total).Replace("(","");;

							strResult = String.Concat(strFinal,"."+strPattern);

							imgurls+=strResult+"%";
						}
						else
						{
							
							arrLength = strTest[arrPrevious].Length;

							int total = arrLength - lastIndex2;

							strFinal = strTest[arrPrevious].Substring(lastIndex2,total).Replace('"'.ToString(),"");

							strResult = String.Concat(strFinal,"."+strPattern);

							imgurls+=strResult+"%";
						}
                    }
                       

                    }

                }
            
            return imgurls;
        }
        else
            return none;

    }

    
    private void fnUpload()
    {
        if ((FileUploader.PostedFile != null) && (FileUploader.PostedFile.ContentLength != 0))
        {
            string strFileName = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);
            try
            {
                lngMaxFileSize =FileUploader.PostedFile.ContentLength;
                //save file in the local disk
                bool chk = System.IO.File.Exists(strFileDir + "\\" + strFileName);
                if (!chk)
                FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);
                hideFileName.Value = strFileName;
            }
            catch (Exception ex)
            {
                Response.Write("Error Occured" + ex.Message.ToString());
                Response.End();
                //Response.Write("Error Occured");
            }
        }
    }
    public string GetPageHTML(string pageUrl)
    {
        System.Net.WebResponse response = null;

        try
        {

            // Setup our Web request
            System.Net.WebRequest request = System.Net.WebRequest.Create(pageUrl);

            // Retrieve data from request
            response = request.GetResponse();

            System.IO.Stream streamReceive = response.GetResponseStream();
            System.Text.Encoding encoding = System.Text.Encoding.GetEncoding("utf-8");
            System.IO.StreamReader streamRead = new System.IO.StreamReader(streamReceive, encoding);

            // return the retrieved HTML
            return streamRead.ReadToEnd();
        }
        catch (Exception ex)
        {
            // Error occured grabbing data, return empty string.
            //MessageBox.Show(this, "An error occurred while retrived the HTML content. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Response.Write("<script language='javascript'>alert('" + "Error: " + ex.Message + "');</script>");
            return "";
        }
        finally
        {
            // Check if exists, then close the response.
            if (response != null)
            {
                response.Close();
            }
        }
    }


    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string varFileType;
        varFileType = FileUploader.PostedFile.ContentType;
        //Response.Write(varFileType);
        if (qryStringVar == "ImgLoc")
        {
            tblHeader.InnerText = "Image Upload";
            if ((varFileType == "image/gif") || (varFileType == "image/pjpeg") || (varFileType == "image/x-png") || (varFileType == "image/bmp") || (varFileType == "application/octet-stream"))
            {
                //Response.Write("in image");
                strFileDir = Server.MapPath("../Images/ToolBar");

                fnUpload();
            }
        }
        else
        {
            if ((varFileType == "text/html") || (varFileType == "text/plain"))
            {


                string templatelocation = FileUploader.PostedFile.FileName;
                hideFileName.Value = templatelocation;
                string templatecontent = GetPageHTML(FileUploader.PostedFile.FileName);
                Session["html"] = templatecontent;
                hideImgLoc.Value = findimageurl(templatecontent);


            }
        }
    }
}
