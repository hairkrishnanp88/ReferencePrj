using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class GroupManager_AddRights : System.Web.UI.Page
{
    DataTable toolBarTable = new DataTable(); // To Store records of toolbar table for the selected main toolbar id.

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel("none");

        GroupManager group = new GroupManager();
        DataTable dTable = new DataTable();
        if (!Page.IsPostBack)
        {
            lblToolBar.Text = "ToolBar Rights" + " for Group : " + Request.QueryString["GroupName"].ToString();
            dTable = group.GetToolBars("Main");
            ddlToolBars.Items.Clear();
            ddlToolBars.DataSource = dTable;
            ddlToolBars.DataTextField = "ButtonText";
            ddlToolBars.DataValueField = "ButtonID";
            ddlToolBars.DataBind();
            if (dTable.Rows.Count > 0)
            {
                ddlToolBars.SelectedIndex = 0; // Default first element must be selected;
                toolBarTable = group.GetToolBars(ddlToolBars.SelectedValue.ToString());
                FillToolBars(toolBarTable);

            }

        }
        else
        {
            if (ddlToolBars.SelectedIndex != -1)
            {
                //toolBarTable = group.GetToolBars(ddlToolBars.SelectedValue.ToString());
                toolBarTable = group.GetToolBars(ddlToolBars.SelectedValue.ToString());
                FillToolBars(toolBarTable);
            }
        }
        lblFullName.Text = Session["FullName"].ToString();
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {

    }
    #endregion

    protected void btnRightsSave_Click(object sender, EventArgs e)
    {
        GroupManager group = new GroupManager();

        toolBarTable = group.GetToolBars(ddlToolBars.SelectedValue.ToString());

        Table updateRights = (Table)Session["tblRigths"]; //this.FindControl("TBRights");

        if (updateRights.Rows.Count > 0)
        {
            group.GroupName = Request.QueryString["GroupName"].ToString();
            group.RemoveRights(ddlToolBars.SelectedValue, "delete");

            for (int i = 0; i < toolBarTable.Rows.Count; i++)
            {
                String Rights = "";
                Rights = (((CheckBox)(updateRights.Rows[i].Cells[1].Controls[0])).Checked) ? "1" : "0";
                Rights += (((CheckBox)(updateRights.Rows[i].Cells[2].Controls[0])).Checked) ? "1" : "0";
                Rights += (((CheckBox)(updateRights.Rows[i].Cells[3].Controls[0])).Checked) ? "1" : "0";
                Rights += (((CheckBox)(updateRights.Rows[i].Cells[4].Controls[0])).Checked) ? "1" : "0";
                group.SaveRights(updateRights.Rows[i].Cells[1].ID, Rights);
                //Response.Write(Rights);
            }
        }
    }

    //void FillToolBars(DataTable dTable)
    //{
    //    if (dTable.Rows.Count > 0)
    //    {
    //        pnlRights.Controls.Clear();
    //        Table tbl = new Table();                        // Table Creation
    //        tbl.Width = Unit.Percentage(100);
    //        tbl.CssClass = "ClsTdtext";
    //        tbl.ID = "TBRights";
    //        //tbl.EnableViewState = false;

    //        if (Session["tbl"] != null)
    //            Session.Remove("tbl");

    //        for (int i = 0; i < dTable.Rows.Count; i++)
    //        {
    //            TableRow tr = new TableRow();

    //            TableCell td0 = new TableCell();
    //            td0.Width = 50;
    //            tr.Cells.Add(td0);

    //            TableCell td1 = new TableCell();
    //            td1.ID = dTable.Rows[i][0].ToString();
    //            tbl.Rows.Add(tr);

    //            CheckBox c1 = new CheckBox();
    //            c1.EnableViewState = true;
    //            c1.ID = Convert.ToString(i)+ Convert.ToString(1) + dTable.Rows[i][0].ToString();
    //            if (DRights.Rows.Count > i)
    //            {
    //                if (Convert.ToInt32(DRights.Rows[i][2].ToString().Substring(0, 1)) == 1)
    //                    c1.Checked = true;
    //                else
    //                    c1.Checked = false;
    //            }
    //            td1.Controls.Add(c1);
    //            tr.Cells.Add(td1);

    //            TableCell td2 = new TableCell();
    //            CheckBox c2 = new CheckBox();
    //            c2.EnableViewState = true;
    //            c2.ID = Convert.ToString(i) + Convert.ToString(2) + dTable.Rows[i][0].ToString();
    //            if (DRights.Rows.Count > i)
    //            {
    //                if (Convert.ToInt32(DRights.Rows[i][2].ToString().Substring(1, 1)) == 1)
    //                    c2.Checked = true;
    //                else
    //                    c2.Checked = false;
    //            }
    //            td2.Controls.Add(c2);
    //            tr.Cells.Add(td2);

    //            TableCell td3 = new TableCell();
    //            CheckBox c3 = new CheckBox();
    //            c3.EnableViewState = true;
    //            c3.ID = Convert.ToString(i) + Convert.ToString(3) + DTable.Rows[i][0].ToString();
    //            if (DRights.Rows.Count > i)
    //            {
    //                if (Convert.ToInt32(DRights.Rows[i][2].ToString().Substring(2, 1)) == 1)
    //                    c3.Checked = true;
    //                else
    //                    c3.Checked = false;
    //            }
    //            td3.Controls.Add(c3);
    //            tr.Cells.Add(td3);

    //            TableCell td4 = new TableCell();
    //            CheckBox c4 = new CheckBox();
    //            c4.EnableViewState = true;
    //            c4.ID = Convert.ToString(i) + Convert.ToString(4) + DTable.Rows[i][0].ToString();
    //            if (DRights.Rows.Count > i)
    //            {
    //                if (Convert.ToInt32(DRights.Rows[i][2].ToString().Substring(3, 1)) == 1)
    //                    c4.Checked = true;
    //                else
    //                    c4.Checked = false;
    //            }
    //            td4.Controls.Add(c4);
    //            tr.Cells.Add(td4);

    //            TableCell td5 = new TableCell();
    //            td5.Width = 50;
    //            tr.Cells.Add(td5);

    //            TableCell td6 = new TableCell();
    //            td6.Width = 306;
    //            //td6.BorderStyle = BorderStyle.Solid;
    //            if (i == 0)
    //                td6.Text = DTable.Rows[i][1].ToString();
    //            else
    //                td6.Text = "------" + DTable.Rows[i][1].ToString();
    //            tr.Cells.Add(td6);
    //            pnlRights.Controls.Add(tbl);
    //        }
    //        Session.Add("tbl", tbl);
    //    }
    //}

    void FillToolBars(DataTable dTable)
    {
        if (dTable.Rows.Count > 0)
        {
            pnlRights.Controls.Clear();
            Table tblRigths = new Table();                        // Table Creation
            tblRigths.Width = Unit.Percentage(100);
            tblRigths.ID = "TBRights";
            //tblRigths.EnableViewState = false;

            GroupManager group = new GroupManager();
            DataTable dRights = new DataTable();
            dRights = group.GetRights(Request.QueryString["GroupName"].ToString(), ddlToolBars.SelectedValue, "select");

            if (Session["tblRigths"] != null)
                Session.Remove("tblRigths");

            //---- In this procedure, rows are added dynamically based on the DB. Each row will
            //---- consists of one label and 4 check boxes. Label is for holding the button id as text.

            for (int i = 0; i < dTable.Rows.Count; i++)
            {
                TableRow tr = new TableRow();

                TableCell td0 = new TableCell();
                td0.Width = 50;
                Label lblButtonId = new Label();
                lblButtonId.ID = "L" + Convert.ToString(i);
                lblButtonId.Text = dTable.Rows[i][0].ToString();
                lblButtonId.Style.Add("display", "none");
                td0.Controls.Add(lblButtonId);
                tr.Cells.Add(td0);

                // Add
                TableCell td1 = new TableCell();
                td1.ID = dTable.Rows[i][0].ToString();
                tblRigths.Rows.Add(tr);

                CheckBox chkAdd = new CheckBox();
                chkAdd.EnableViewState = true;
                chkAdd.ID = "chkAdd" + Convert.ToString(i) + dTable.Rows[i][0].ToString();
                chkAdd.Checked = false;
                chkAdd.Attributes.Add("Onclick", "javascript:return chkParent('" + "chkAdd0" + ddlToolBars.SelectedValue.ToString() + "',this.id,'" + dTable.Rows.Count + "','" + "chkAdd" + "');");
                if (dRights.Rows.Count > i)
                    if (Convert.ToInt32(dRights.Rows[i][2].ToString().Substring(0, 1)) == 1)
                        chkAdd.Checked = true;
                td1.Controls.Add(chkAdd);
                tr.Cells.Add(td1);

                // Mod
                TableCell td2 = new TableCell();
                CheckBox chkMod = new CheckBox();
                chkMod.EnableViewState = true;
                chkMod.ID = "chkMod" + Convert.ToString(i) + dTable.Rows[i][0].ToString();
                chkMod.Checked = false;
                chkMod.Attributes.Add("Onclick", "javascript:return chkParent('" + "chkMod0" + ddlToolBars.SelectedValue.ToString() + "',this.id,'" + dTable.Rows.Count + "','" + "chkMod" + "');");
                if (dRights.Rows.Count > i)
                {
                    if (Convert.ToInt32(dRights.Rows[i][2].ToString().Substring(1, 1)) == 1)
                        chkMod.Checked = true;
                    else
                        chkMod.Checked = false;
                }
                td2.Controls.Add(chkMod);
                tr.Cells.Add(td2);

                // Delete
                TableCell td3 = new TableCell();
                CheckBox chkDel = new CheckBox();
                chkDel.EnableViewState = true;
                chkDel.ID = "chkDel" + Convert.ToString(i) + dTable.Rows[i][0].ToString();
                chkDel.Checked = false;
                chkDel.Attributes.Add("Onclick", "javascript:return chkParent('" + "chkDel0" + ddlToolBars.SelectedValue.ToString() + "',this.id,'" + dTable.Rows.Count + "','" + "chkDel" + "');");
                if (dRights.Rows.Count > i)
                {
                    if (Convert.ToInt32(dRights.Rows[i][2].ToString().Substring(2, 1)) == 1)
                        chkDel.Checked = true;
                    else
                        chkDel.Checked = false;
                }
                td3.Controls.Add(chkDel);
                tr.Cells.Add(td3);

                // View
                TableCell td4 = new TableCell();
                CheckBox chkView = new CheckBox();
                chkView.EnableViewState = true;
                chkView.ID = "chkView" + Convert.ToString(i) + dTable.Rows[i][0].ToString();
                chkView.Checked = false;
                chkView.Attributes.Add("Onclick", "javascript:return chkParent('" + "chkView0" + ddlToolBars.SelectedValue.ToString() + "',this.id,'" + dTable.Rows.Count + "','" + "chkView" + "');");
                if (dRights.Rows.Count > i)
                {
                    if (Convert.ToInt32(dRights.Rows[i][2].ToString().Substring(3, 1)) == 1)
                        chkView.Checked = true;
                    else
                        chkView.Checked = false;
                }
                td4.Controls.Add(chkView);
                tr.Cells.Add(td4);

                TableCell td5 = new TableCell();
                td5.Width = 50;
                tr.Cells.Add(td5);

                TableCell td6 = new TableCell();
                td6.Width = 306;
                //td6.BorderStyle = BorderStyle.Solid;
                if (i == 0)
                {
                    TableCell tdBullets = new TableCell();
                    tdBullets.Width = 25;
                    Image bulletImg = new Image();
                    bulletImg.ImageUrl = "../images/Bullet.gif";
                    tdBullets.Controls.Add(bulletImg);
                    tr.Cells.Add(tdBullets);
                    td6.CssClass = "ClsLabel";
                    td6.Text = dTable.Rows[i][1].ToString();
                }
                else if (dTable.Rows[i][0].ToString().Length == 7) // For Buttons
                {
                    Table subTable = new Table(); // To Show the sub tools bars seperatly.
                    TableRow subTRow = new TableRow();
                    TableCell subTCell1 = new TableCell();
                    TableCell subTCell2 = new TableCell();

                    subTCell1.Width = 25;
                    subTCell2.Width = 281;

                    TableCell tdBullets = new TableCell();
                    tdBullets.Width = 25;
                    tr.Cells.Add(tdBullets);

                    Image bulletImg = new Image();
                    bulletImg.ImageUrl = "../images/Bullet.gif";
                    subTCell1.Controls.Add(bulletImg);

                    subTable.Rows.Add(subTRow);
                    subTRow.Cells.Add(subTCell1);
                    subTRow.Cells.Add(subTCell2);

                    if (dTable.Rows[i][2].ToString() == "Text")
                    {
                        subTCell2.CssClass = "ClsLabel";
                        subTCell2.Text = dTable.Rows[i][1].ToString();
                    }
                    else
                    {
                        Image toolBarImg = new Image();
                        toolBarImg.ImageUrl = "../images/Toolbar/" + dTable.Rows[i][3].ToString();
                        toolBarImg.AlternateText = dTable.Rows[i][4].ToString();
                        toolBarImg.Style.Add("Width", dTable.Rows[i][5].ToString());
                        toolBarImg.Style.Add("Height", dTable.Rows[i][6].ToString());
                        subTCell2.Controls.Add(toolBarImg);
                    }
                    td6.Controls.Add(subTable);
                }
                else if (dTable.Rows[i][0].ToString().Length == 11) // For Sub Buttons
                {
                    Table subTable = new Table(); // To Show the sub tools bars seperatly.
                    TableRow subTRow = new TableRow();
                    TableCell subTCell1 = new TableCell();
                    TableCell subTCell2 = new TableCell();
                    TableCell subTCell3 = new TableCell();

                    subTCell1.Width = 25;
                    subTCell2.Width = 25;
                    subTCell3.Width = 256;

                    TableCell tdBullets = new TableCell();
                    tdBullets.Width = 25;
                    tr.Cells.Add(tdBullets);

                    Image bulletImg = new Image();
                    bulletImg.ImageUrl = "../images/Bullet.gif";
                    subTCell2.Controls.Add(bulletImg);

                    subTable.Rows.Add(subTRow);
                    subTRow.Cells.Add(subTCell1);
                    subTRow.Cells.Add(subTCell2);
                    subTRow.Cells.Add(subTCell3);

                    if (dTable.Rows[i][2].ToString() == "Text")
                    {
                        subTCell3.CssClass = "ClsLabel";
                        subTCell3.Text = dTable.Rows[i][1].ToString();
                    }
                    else
                    {
                        Image toolBarImg = new Image();
                        toolBarImg.ImageUrl = "../images/Toolbar/" + dTable.Rows[i][3].ToString();
                        toolBarImg.AlternateText = dTable.Rows[i][4].ToString();
                        toolBarImg.Style.Add("Width", dTable.Rows[i][5].ToString());
                        toolBarImg.Style.Add("Height", dTable.Rows[i][6].ToString());
                        subTCell3.Controls.Add(toolBarImg);
                    }
                    td6.Controls.Add(subTable);
                }

                tr.Cells.Add(td6);
                pnlRights.Controls.Add(tblRigths);
            }
            Session.Add("tblRigths", tblRigths);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["FromPage"].ToString() == "GroupList")
            Response.Redirect("AddGroup.aspx?Act=View");
        else if (Request.QueryString["FromPage"].ToString() == "GroupMod")
            Response.Redirect("AddGroup.aspx?GroupId=" + Request.QueryString["GroupId"].ToString() + "&GroupName=" + Request.QueryString["GroupName"].ToString() + "&Act=Mod");
    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }

    protected HtmlTable userValidation()
    {
        Toolbar objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout'; document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript: ShowNewJob(); expand('sub');");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            //cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit();");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx';document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit();expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout';document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';  document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }

}