using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class GroupManager_AddUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel("none");

        try
        {
            if (!Page.IsPostBack)
            {
                GroupManager group = new GroupManager();
                DataTable dTable = new DataTable();

                if (Request.QueryString["GroupId"] == null)
                    throw new Exception("Group Id must be passed as Query String");

                if (Request.QueryString["GroupName"] == null)
                    throw new Exception("Group Name must be passed as Query String");


                lblUserinfo.Text = "Users for Group : " + Request.QueryString["GroupName"].ToString();

                group.GroupName = Request.QueryString["GroupName"].ToString();

                dTable = group.GetSelectedUsersList();
                grdSelectedUsers.DataSource = dTable;
                grdSelectedUsers.DataBind();

                if (dTable.Rows.Count == 0)
                {
                    lblSelectedUsers.Text = "No user Selected";
                    lnkRemove.Style.Add("display", "none");
                    trSelectedUsersGrid.Style.Add("display", "none");
                }
                else
                {
                    lblSelectedUsers.Text = "Selected Users";
                    lnkRemove.Style.Add("display", "inline");
                    trSelectedUsersGrid.Style.Add("display", "inline");
                }

                FillListDetails(grdSelectedUsers);

                dTable = group.GetAvailableUsersList();
                grdAvailableUsers.DataSource = dTable;
                grdAvailableUsers.DataBind();

                if (dTable.Rows.Count ==0)
                {
                    lblAvailableUsers.Text = "No user(s) to Add";
                    lnkAdd.Style.Add("display","none");
                    trAvailableUsersGrid.Style.Add("display", "none");
                }
                    else
                {
                    lblAvailableUsers.Text = "Available Users";
                    lnkAdd.Style.Add("display","inline");
                    trAvailableUsersGrid.Style.Add("display", "inline");
                }
                FillListDetails(grdAvailableUsers);
            }
            lblFullName.Text = Session["FullName"].ToString();
            lnkRemove.Attributes.Add("OnClick", "javascript:return (IsCheckBoxSelected('grdSelectedUsers','chkSelected','Remove'))");
            lnkAdd.Attributes.Add("OnClick", "javascript:return (IsCheckBoxSelected('grdAvailableUsers','chkAvailable','Add'))");

        }
        catch (Exception ex)
        {
            Response.Write("<script language='javascript'>alert('" + ex.Message + "')</script>");
        }
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {

    }
    #endregion

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["FromPage"].ToString() == "GroupList")
            Response.Redirect("AddGroup.aspx?Act=View");
        else if (Request.QueryString["FromPage"].ToString() == "GroupMod")
            Response.Redirect("AddGroup.aspx?GroupId=" + Request.QueryString["GroupId"].ToString() + "&GroupName=" + Request.QueryString["GroupName"].ToString() + "&Act=Mod");
    }

    public void grdSelectedUsers_OnRowCreated(Object sender, GridViewRowEventArgs e)
    {

        e.Row.Cells[1].Visible = false;     //UserId
        e.Row.Cells[3].Visible = false;     //FullName
        e.Row.Cells[4].Visible = false;     //CreatedOn
        e.Row.Cells[7].Visible = false;     //Approved
        e.Row.Cells[9].Visible = false;     //Date of Approval
        e.Row.Cells[11].Visible = false;    //Disabled
        e.Row.Cells[13].Visible = false;    //Disabled
    }

    public void grdAvailableUsers_OnRowCreated(Object sender, GridViewRowEventArgs e)
    {

        e.Row.Cells[1].Visible = false;     //UserId
        e.Row.Cells[3].Visible = false;     //FullName
        e.Row.Cells[4].Visible = false;     //CreatedOn
        e.Row.Cells[7].Visible = false;     //Approved
        e.Row.Cells[9].Visible = false;     //Date of Approval
        e.Row.Cells[11].Visible = false;    //Disabled
        e.Row.Cells[13].Visible = false;    //Disabled
    }

    void FillListDetails(GridView grdView)
    {
        UtilFunctions utils = new UtilFunctions();
        String slNo = "0";
        for (int i = 0; i < grdView.Rows.Count; i++)
        {
            DateTime dTime;

            slNo = Convert.ToString(i + 1);
            grdView.Rows[i].Cells[0].Text = slNo;

            dTime = Convert.ToDateTime(grdView.Rows[i].Cells[4].Text);
            grdView.Rows[i].Cells[5].Text = utils.GetDBDateFormatUK(dTime.ToString("dd-MM-yyyy"));

            if (Convert.ToBoolean((grdView.Rows[i].Cells[7].Text)) == true)
                grdView.Rows[i].Cells[8].Text = "Yes";
            else
                grdView.Rows[i].Cells[8].Text = "No";

            if (grdView.Rows[i].Cells[9].Text != "&nbsp;")
            {
                dTime = Convert.ToDateTime(grdView.Rows[i].Cells[9].Text);
                grdView.Rows[i].Cells[10].Text = utils.GetDBDateFormatUK(dTime.ToString("dd-MM-yyyy"));
            }

            if (Convert.ToBoolean((grdView.Rows[i].Cells[11].Text)) == true)
                grdView.Rows[i].BackColor = System.Drawing.Color.Tan;

            if (Convert.ToBoolean((grdView.Rows[i].Cells[11].Text)) == true)
                grdView.Rows[i].Cells[12].Text = "Yes";
            else
                grdView.Rows[i].Cells[12].Text = "No";
        }
    }

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        Boolean recordFoundforAdd = false;
        String strSelectedUsers = "";
        for (int i = 0; i < grdAvailableUsers.Rows.Count; i++)
        {
            if (((CheckBox)(grdAvailableUsers.Rows[i].Cells[14].FindControl("chkAvailable"))).Checked)
            {
                recordFoundforAdd = true;
                strSelectedUsers = strSelectedUsers + grdAvailableUsers.Rows[i].Cells[1].Text + ",";
            }
        }
        if (recordFoundforAdd == false)
        {
            Response.Write("<script language='javascript'>alert('" + "Please select any user(s) to add" + "')</script>");
            FillListDetails(grdSelectedUsers);
            FillListDetails(grdAvailableUsers);
        }
        else
        {
            GroupManager group = new GroupManager();

            if (strSelectedUsers.Length != 0)
                strSelectedUsers = strSelectedUsers.Substring(0, strSelectedUsers.Length - 1);

            group.GroupID = int.Parse(Request.QueryString["GroupId"].ToString());
            group.SaveGroupUsers(strSelectedUsers, "Add");
            Response.Redirect("AddUsers.aspx?GroupId=" + Request.QueryString["GroupId"].ToString() + "&GroupName=" + Request.QueryString["GroupName"].ToString() + "&FromPage=" + Request.QueryString["FromPage"].ToString() + "&Act=Mod");
        }

        
    }

    protected void lnkRemove_Click(object sender, EventArgs e)
    {
        Boolean recordFoundforRemove = false;
        String strSelectedUsers = "";
        
        for (int i = 0; i < grdSelectedUsers.Rows.Count; i++)
        {
            if (((CheckBox)(grdSelectedUsers.Rows[i].Cells[14].FindControl("chkSelected"))).Checked)
                recordFoundforRemove = true;
            else
                strSelectedUsers = strSelectedUsers + grdSelectedUsers.Rows[i].Cells[1].Text + ",";
        }

        if (recordFoundforRemove == false)
        {
            Response.Write("<script language='javascript'>alert('" + "Please select any user(s) to Remove" + "')</script>");
            FillListDetails(grdSelectedUsers);
            FillListDetails(grdAvailableUsers);
        }
        else
        {
            GroupManager group = new GroupManager();

            if (strSelectedUsers.Length != 0)
                strSelectedUsers = strSelectedUsers.Substring(0, strSelectedUsers.Length - 1);

            group.GroupID = int.Parse(Request.QueryString["GroupId"].ToString());
            group.SaveGroupUsers(strSelectedUsers, "Mod");
            Response.Redirect("AddUsers.aspx?GroupId=" + Request.QueryString["GroupId"].ToString() + "&GroupName=" + Request.QueryString["GroupName"].ToString() + "&FromPage=" + Request.QueryString["FromPage"].ToString() + "&Act=Mod");
        }
    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }

    // User Validation for Menu
    protected HtmlTable userValidation()
    {
        Toolbar objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout'; document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript: ShowNewJob(); expand('sub');");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            //cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit();");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx';document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit();expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout';document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';  document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }


}