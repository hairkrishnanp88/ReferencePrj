using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class GroupManager_AddGroup : System.Web.UI.Page
{
    GroupManager group = new GroupManager();
    Boolean reDirect = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel("none");

        if (Request.QueryString["Act"].ToString() == "New")
            SetLink();

        lblError.Text = "";

        try
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["Act"] == null)
                {
                    tdSave.Style.Add("display", "none");
                    grdGroup.Style.Add("display","inline");// .Visible = true;
                    tblGroupAdd.Style.Add("display", "none");// Visible = false;
                    throw new Exception("Act must be passed as Query String");
                }

                if (Session["UserType"].ToString() == "Admin")
                {
                    DataTable dTable = new DataTable();

                    if (Request.QueryString["Act"].ToString() == "View")
                    {
                        tdSave.Style.Add("display", "none");
                        grdGroup.Style.Add("display", "inline");// Visible = true;
                        tblGroupAdd.Style.Add("display", "none");// Visible = false;
                        dTable = group.GetGroup("", true);
                        if (dTable.Rows.Count > 0)
                        {
                            grdGroup.DataSource = dTable;
                            grdGroup.DataBind();
                            grdGroup.Style.Add("display", "inline");// Visible = true;
                            tblGroupAdd.Style.Add("display", "none");// Visible = false;
                        }
                        else
                            lblError.Text = "No Group Found. Click Add to create new Group";
                    }
                    else
                    {
                        btnGroupSave.Style.Add("display", "inline");// Visible = true;
                        btnCancel.Style.Add("display", "inline");// Visible = true;
                        tblGroupAdd.Style.Add("display", "inline");// Visible = true;
                        grdGroup.Style.Add("display", "none");// Visible = false;
                        tblGroupList.Style.Add("display", "none");// Visible = false;
                        Add.Style.Add("display", "none");
                        lnkbtnGroupDelete.Style.Add("display", "none");
                        tdSave.Style.Add("display", "inline");

                        if (Request.QueryString["Act"].ToString() == "New")
                        {
                            FillCombo(false);
                            btnGroupUsers.Style.Add("display", "none");
                            btnGroupRights.Style.Add("display", "none");
                        }
                        else if (Request.QueryString["Act"].ToString() == "Edit")
                        {
                            group.GroupID = int.Parse(Request.QueryString["GroupId"].ToString());
                            group.GetGroupInfo();
                            txtGroupName.Text = group.GroupName;
                            FillCombo(true);
                            if (group.Manager != 0)
                                ddlManagers.SelectedIndex = ddlManagers.Items.IndexOf(ddlManagers.Items.FindByValue(group.Manager.ToString()));
                            if (group.Manager == -1)
                                ddlManagers.SelectedIndex = ddlManagers.Items.IndexOf(ddlManagers.Items.FindByValue("None"));

                            btnGroupUsers.Style.Add("display", "inline");
                            btnGroupRights.Style.Add("display", "inline");
                        }
                    }
                }
            }

            if (Session["UserType"].ToString() == "Admin")
            {
                if (Request.QueryString["Act"].ToString() == "Mod")
                {
                    if (Request.QueryString["GroupId"] == null)
                        throw new Exception("Group Id must be passed as Query String");

                    reDirect = true;
                    Response.Redirect("AddGroup.aspx?GroupId=" + Request.QueryString["GroupId"].ToString() + "&Act=Edit");
                }
                else if (Request.QueryString["Act"].ToString() == "View")
                    FillGroupDetails();

                lnkbtnGroupDelete.Attributes.Add("OnClick", "javascript:return (IsCheckBoxSelected('grdGroup','DeleteGroupCheck'))");
                btnGroupSave.Attributes.Add("OnClick", "javascript:return ValidData()");
                lblFullName.Text = Session["FullName"].ToString();
            }
        }
        catch (Exception ex)
        {
            if (reDirect == false)
            {
                Response.Write("<script language='javascript'>alert('" + ex.Message + "')</script>");
                FillGroupDetails();
            }
        }
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {

    }
    #endregion

    protected void btnGroupSave_Click(object sender, EventArgs e)
    {
        Boolean reDirect = false; // This bool is to avoid the error : Unable to evaluate expression because the code is optimized or a native frame is on top of the call stack.
        try
        {
            if (txtGroupName.Text == "")
            {
                throw new Exception("Group Name should not be blank.");
            }

            if (Request.QueryString["Act"].ToString() == "New")
            {
                DataTable dTable = new DataTable();
                dTable = group.GetGroup(txtGroupName.Text, false);
                if ((Int32)dTable.Rows[0][0] > 0)
                    throw new Exception("Group Name already Found");
                group.SelectedUser = "";
            }

            group.GroupName = txtGroupName.Text;
            group.Manager = -1;
            group.IndexType = ddlLinkType.Items[ddlLinkType.SelectedIndex].Value;
            group.IndexPage = getlink();

            if (ddlManagers.SelectedIndex > 0)
            {
                group.Manager = Convert.ToInt32(ddlManagers.SelectedItem.Value);
            }

            if (Request.QueryString["Act"].ToString() == "New")
                group.CreateGroup();
            else
            {
                group.GroupID = int.Parse(Request.QueryString["GroupId"].ToString());
                group.UpdateGroup();
            }
            //Response.Redirect("AddUsers.aspx?Act=View");
            reDirect = true;

            if (Request.QueryString["Act"].ToString() == "New")
            {
                int GroupId = group.GetGroupId(txtGroupName.Text);
                Response.Redirect("AddUsers.aspx?GroupID=" + GroupId.ToString()+"&GroupName="+txtGroupName.Text+"&FromPage=GroupMod");
            }
            else
                Response.Redirect("AddGroup.aspx?Act=View");
        }
        catch (Exception ex)
        {
            if (reDirect == false)
                Response.Write("<script language='javascript'>alert('" + ex.Message + "')</script>");
        }
    }

    void FillGroupDetails()
    {
        for (int i = 0; i < grdGroup.Rows.Count; i++)
        {
            grdGroup.Rows[i].Cells[0].Text = ((Int32)(i + 1)).ToString();

            //Group Name - Modification
            LinkButton linkGroup = new LinkButton();
            linkGroup.CssClass = "ClsLinkButton";
            linkGroup.ID = "GroupId" + grdGroup.Rows[i].Cells[1].Text;
            linkGroup.Text = grdGroup.Rows[i].Cells[2].Text;
            linkGroup.PostBackUrl = "AddGroup.aspx?GroupId=" + grdGroup.Rows[i].Cells[1].Text.ToString() + "&Act=Mod";
            grdGroup.Rows[i].Cells[2].Controls.Add(linkGroup);

            //Users
            LinkButton linkUser = new LinkButton();
            linkUser.CssClass = "ClsLinkButton";
            linkUser.ID = "Users" + grdGroup.Rows[i].Cells[1].Text;
            linkUser.Text = "Users";
            linkUser.PostBackUrl = "AddUsers.aspx?GroupId=" + grdGroup.Rows[i].Cells[1].Text.ToString() + "&GroupName=" + grdGroup.Rows[i].Cells[2].Text.ToString() + "&FromPage=GroupList&Act=Mod";
            grdGroup.Rows[i].Cells[4].Controls.Add(linkUser);

            //Rigths
            LinkButton linkRights = new LinkButton();
            linkRights.CssClass = "ClsLinkButton";
            linkRights.ID = "Rights" + grdGroup.Rows[i].Cells[1].Text;
            linkRights.Text = "Rights";
            linkRights.PostBackUrl = "AddRights.aspx?GroupId=" + grdGroup.Rows[i].Cells[1].Text.ToString() + "&GroupName=" + grdGroup.Rows[i].Cells[2].Text.ToString() + "&FromPage=GroupList&Act=Mod";
            grdGroup.Rows[i].Cells[5].Controls.Add(linkRights);

            if (grdGroup.Rows[i].Cells[7].Text == "&nbsp;")
                grdGroup.Rows[i].Cells[6].Enabled = true;
            else
            {
                grdGroup.Rows[i].Cells[6].ToolTip = "This group cannot be deleted because user(s) exists in this group";
                grdGroup.Rows[i].Cells[6].Enabled = false;
            }
            
        }

    }

    public void grdGroup_OnRowCreated(Object sender, GridViewRowEventArgs e)
    {

        e.Row.Cells[1].Style.Add("display","none");    //GroupId
        e.Row.Cells[7].Style.Add("display","none");    //SelectedUsers
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddGroup.aspx?Act=View");
    }
 
    void FillCombo(Boolean SelectIndex)
    {
        //## For Manager
        DataTable dTable = new DataTable();
        dTable = group.GetManagersList();
        ddlManagers.Items.Clear();
        ddlManagers.Items.Add("None");
        ddlManagers.Items[0].Value = "None";
        if (dTable.Rows.Count > 0)
        {
            for (int i = 0; i < dTable.Rows.Count; i++)
            {
                ddlManagers.Items.Add(dTable.Rows[i][0].ToString());
                ddlManagers.Items[i + 1].Value = dTable.Rows[i][1].ToString();
            }
        }

        //## For Data Piece
        Toolbar tbar = new Toolbar();
        DataTable contentBuilderTable = tbar.getContentBuilder();
        ddlDataPiece.Items.Clear();
        foreach (DataRow row in contentBuilderTable.Rows)
        {
            ListItem item = new ListItem(row["Name"].ToString(), row["DataID"].ToString());
            ddlDataPiece.Items.Add(item);
        }

        //## To fill Link Type
        ddlLinkType.Items.Clear();
        ddlLinkType.Items.Add("None");
        ddlLinkType.Items[0].Value = "NL";
        ddlLinkType.Items.Add("Page Link");
        ddlLinkType.Items[1].Value = "PL";
        ddlLinkType.Items.Add("URL Link");
        ddlLinkType.Items[2].Value = "UL";

        if (SelectIndex)
        {
            ddlLinkType.SelectedIndex = ddlLinkType.Items.IndexOf(ddlLinkType.Items.FindByValue(group.IndexType));
            if (ddlLinkType.SelectedIndex == 1)
                ddlDataPiece.SelectedIndex = ddlDataPiece.Items.IndexOf(ddlDataPiece.Items.FindByValue(group.IndexPage));
            else if (ddlLinkType.SelectedIndex == 2)
                txtURLLink.Text = group.IndexPage;
         }
         else
            ddlLinkType.SelectedIndex = 0;

        SetLink();
    }

    String getlink()
    {
        if (ddlLinkType.SelectedIndex == 0)
            return "";
        else if (ddlLinkType.SelectedIndex == 1)
            return ddlDataPiece.Items[ddlDataPiece.SelectedIndex].Value;
        else if (ddlLinkType.SelectedIndex == 2)
            return txtURLLink.Text;
        else
            return "";
    }

    void SetLink()
    {
        if (ddlLinkType.SelectedIndex == 0)
        {
            PageLink.Style.Add("display", "none");
            URLLink.Style.Add("display", "none");
        }
        else if (ddlLinkType.SelectedIndex == 1)
        {
            PageLink.Style.Add("display", "inline");
            URLLink.Style.Add("display", "none");
        }
        else if (ddlLinkType.SelectedIndex == 2)
        {
            PageLink.Style.Add("display", "none");
            URLLink.Style.Add("display", "inline");
        }
    }

    protected void btnGroupUsers_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["Act"].ToString() == "Edit")
            Response.Redirect("AddUsers.aspx?GroupName=" + txtGroupName.Text + "&GroupId=" + Request.QueryString["GroupId"].ToString()+ "&FromPage=GroupMod&Act=Mod");
    }
    protected void btnGroupRights_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["Act"].ToString() == "Edit")
            Response.Redirect("AddRights.aspx?GroupName=" + txtGroupName.Text + "&GroupId=" + Request.QueryString["GroupId"].ToString() + "&FromPage=GroupMod&Act=Mod");

    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }

    protected void lnkbtnGroupDelete_Click(object sender, EventArgs e)
    {
        GroupManager group = new GroupManager();
        Boolean recordFoundforDelete = false;

        for (int i = 0; i < grdGroup.Rows.Count; i++)
        {
            if (((CheckBox)(grdGroup.Rows[i].Cells[6].FindControl("DeleteGroupCheck"))).Checked)
            {
                recordFoundforDelete = true;
                group.GroupID = Convert.ToInt32(grdGroup.Rows[i].Cells[1].Text.ToString());
                group.DeleteGroup();
            }
        }

        if (recordFoundforDelete == false)
            Response.Write("<script language='javascript'>alert('" + "Please select any user(s) to delete" + "')</script>");
        else
            Response.Redirect("../GroupManager/AddGroup.aspx?Act=View");
        FillGroupDetails();
    }

    protected HtmlTable userValidation()
    {
        Toolbar objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout'; document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript: ShowNewJob(); expand('sub');");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            //cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit();");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx';document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit();expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../index.aspx?Act=Logout';document.forms[0].submit();");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Skin")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objToolbar.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All';  document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FromPref=Yes&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx';document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }
}