function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Vil du slette denne mappe?";

    document.getElementById("btnClose").value = "Annuler";
    document.getElementById("btnDelete").value = "Slet";
    }
function writeTitle()
    {
    document.write("<title>Slet mappe</title>")
    }
