function loadTxtContent()
    {
   var txtMediaLang = document.getElementsByName("txtMediaLang");
//    txtMediaLang[0].innerHTML = "Source";
    txtMediaLang[0].innerHTML = "Width";
    txtMediaLang[1].innerHTML = "Height";    
    txtMediaLang[2].innerHTML = "Auto Start";    
    txtMediaLang[3].innerHTML = "Show Controls";
    txtMediaLang[4].innerHTML = "Show Status Bar";   
    txtMediaLang[5].innerHTML = "Show Display";
    txtMediaLang[6].innerHTML = "Auto Rewind";   

/*    document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnInsert").value = "insert";
    document.getElementById("btnApply").value = "apply";
    document.getElementById("btnOk").value = " ok ";*/
    }
function writeTitle()
    {
    document.write("<title>Media</title>")
    }
