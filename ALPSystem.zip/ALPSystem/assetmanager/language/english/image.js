function loadTxtContent()
    {
    var txtImageLang = document.getElementsByName("txtImageLang");
   /// txtImageLang[0].innerHTML = "Source";
    txtImageLang[0].innerHTML = "Title";
    txtImageLang[1].innerHTML = "Spacing";
    txtImageLang[2].innerHTML = "Alignment";
    txtImageLang[3].innerHTML = "Top";
    txtImageLang[4].innerHTML = "Border";
    txtImageLang[5].innerHTML = "Bottom";
    txtImageLang[6].innerHTML = "Width";
    txtImageLang[7].innerHTML = "Left";
    txtImageLang[8].innerHTML = "Height";
    txtImageLang[9].innerHTML = "Right";
    
    var optImageLang = document.getElementsByName("optImageLang");
    optImageLang[0].text = "absBottom";
    optImageLang[1].text = "absMiddle";
    optImageLang[2].text = "baseline";
    optImageLang[3].text = "bottom";
    optImageLang[4].text = "left";
    optImageLang[5].text = "middle";
    optImageLang[6].text = "right";
    optImageLang[7].text = "textTop";
    optImageLang[8].text = "top";
 
    document.getElementById("btnBorder").value = " Border Style ";
    document.getElementById("btnReset").value = "reset"
    
  /*  document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnInsert").value = "insert";
    document.getElementById("btnApply").value = "apply";
    document.getElementById("btnOk").value = " ok "; */
    }
function writeTitle()
    {
    document.write("<title>Image</title>")
    }