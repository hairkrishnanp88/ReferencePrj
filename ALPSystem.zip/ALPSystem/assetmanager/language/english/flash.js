function loadTxtContent()
    {
    var txtFlashLang = document.getElementsByName("txtFlashLang");
   // txtFlashLang[0].innerHTML = "Source";
    txtFlashLang[0].innerHTML = "Background";
    txtFlashLang[1].innerHTML = "Width";
    txtFlashLang[2].innerHTML = "Height";    
    txtFlashLang[3].innerHTML = "Quality";   
    txtFlashLang[4].innerHTML = "Align";
    txtFlashLang[5].innerHTML = "Loop";
    txtFlashLang[6].innerHTML = "Yes";
    txtFlashLang[7].innerHTML = "No";
    
    txtFlashLang[8].innerHTML = "Class ID";
    txtFlashLang[9].innerHTML = "CodeBase";
    txtFlashLang[10].innerHTML = "PluginsPage";

    var optFlashLang = document.getElementsByName("optFlashLang");
    optFlashLang[0].text = "Low"
    optFlashLang[1].text = "High"
    optFlashLang[2].text = "<Not Set>"
    optFlashLang[3].text = "Left"
    optFlashLang[4].text = "Right"
    optFlashLang[5].text = "Top"
    optFlashLang[6].text = "Bottom"
    
    document.getElementById("btnPick").value = "Pick";
    
  /*  document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnOk").value = " ok ";*/
    }
function getTxt(s)
    {
    switch(s)
        {
        case "Custom Colors": return "Custom Colors";
        case "More Colors...": return "More Colors...";
        default: return "";
        }
    }    
function writeTitle()
    {
    document.write("<title>Insert Flash</title>")
    }