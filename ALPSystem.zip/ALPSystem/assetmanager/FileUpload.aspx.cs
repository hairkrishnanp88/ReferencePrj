using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class assetmanager_FileUpload : System.Web.UI.Page
{
    private long lngMaxFileSize;
    string qryStringVar;
    string strFileDir;
    Templates dbf = new Templates();
    protected void Page_Load(object sender, EventArgs e)
    {
        qryStringVar = Request.QueryString["rnd"];
        //hideEventId.Value = qryStringVar;
        //if (qryStringVar == "ImgLoc")
        //    tblHeader.InnerText = "Image Upload";
        //else
        //    tblHeader.InnerText = "Template Upload";

        if (qryStringVar != null)
        {
            if (!Convert.ToString(Session["UserType"]).Equals("Manager") && !Convert.ToString(Session["UserType"]).Equals("Admin"))
            {
                Response.Redirect("../Errors/SessionExpired.aspx", true);
            }
        }
        else
        {
            Response.Redirect("../Errors/SessionExpired.aspx", true);
        }
    }

    private void fnUpload()
    {
        if ((FileUploader.PostedFile != null) && (FileUploader.PostedFile.ContentLength != 0))
        {
            string strFileName = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);
            try
            {
                lngMaxFileSize = FileUploader.PostedFile.ContentLength;

                //save file in the local disk
                bool chk = System.IO.File.Exists(strFileDir + "\\" + strFileName);

                FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);
                hideFileName.Value = strFileName;
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Script", "ErrorMessage('File uploaded successfully.');", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            string varFileType;
            varFileType = FileUploader.PostedFile.ContentType;
            strFileDir = Server.MapPath("../assets");
            if (FileUploader.HasFile && FileUploader.PostedFile != null)
            {
                string strExtension = System.IO.Path.GetExtension(FileUploader.PostedFile.FileName);

                if (!string.IsNullOrEmpty(strExtension))
                {
                    if (strExtension.ToLower().Equals(".doc") || strExtension.ToLower().Equals(".docx") || strExtension.ToLower().Equals(".xls") ||
                        strExtension.ToLower().Equals(".xlsx") || strExtension.ToLower().Equals(".pps") || strExtension.ToLower().Equals(".ppt") ||
                        strExtension.ToLower().Equals(".pdf") || strExtension.ToLower().Equals(".gif") || strExtension.ToLower().Equals(".jpeg") ||
                        strExtension.ToLower().Equals(".jpg") || strExtension.ToLower().Equals(".png") || strExtension.ToLower().Equals(".bmp") ||
                        strExtension.ToLower().Equals(".mpg") || strExtension.ToLower().Equals(".mpeg") || strExtension.ToLower().Equals(".mov") ||
                        strExtension.ToLower().Equals(".mp4") || strExtension.ToLower().Equals(".avi") || strExtension.ToLower().Equals(".wmv") ||
                        strExtension.ToLower().Equals(".flv") || strExtension.ToLower().Equals(".zip") || strExtension.ToLower().Equals(".swf") ||
                        strExtension.ToLower().Equals(".txt") || strExtension.ToLower().Equals(".mid"))
                    {
                        fnUpload();
                    }
                    else
                    {
                        //Response.Write("<script language='javascript'>window.onload = alert('The File Type is not allowed.');</script>");
                        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Script", "ShowMessage();", true);
                    }
                }
            }

        }
        catch (Exception ex)
        {
            //Response.Write("<script language='javascript'>alert('" + "Error: " + ex.Message.Replace("'","''") + "');</script>");
            string strMsg = "Error:" + ex.Message.Replace("'", "''");
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Script", "ErrorMessage(" + strMsg + ");", true);
        }
    }
}
