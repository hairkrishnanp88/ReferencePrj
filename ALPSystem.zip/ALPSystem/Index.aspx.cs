using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class Index : System.Web.UI.Page
{
    Skins skin = new Skins();
    public string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        Application["SiteName"] = skin.SiteName; 
        action = Request.QueryString["Act"];        
        skin.LoadSkinSettings();        
        ContentReader CR = new ContentReader();
        DataTable dtPublicIndex = CR.ExecuteDTQuery("select Link from publicindex where publicindex=0 and linktype <> 'NL'");
        //String BuildID = CR.ExecuteScalar("select Link from publicindex where publicindex=0 and linktype <> 'NL'");
        string BuildID = "";
        if (dtPublicIndex.Rows.Count>0)
            BuildID = dtPublicIndex.Rows[0][0].ToString();
        //Session["PublicIndex"] = BuildID;
        if(BuildID=="") Response.Redirect("login.aspx");
        //Session["UserId"] = "1";
        //Session["PublicIndex"] = BuildID;
        //tdContent.InnerHtml = CR.GetPageContent(BuildID).Replace("../ContentBuilder", "./ContentBuilder").Replace("../images/", "./Images/").Replace("../assets/", "assets/");
        if (action == "Logout")
        {
            Session["Act"] = action;
            Session["UserType"] = "Anonymous";
            Session["UserId"] = "";
            Session["UserName"] = "";
            Session["FullName"] = "";
            Session["PPSNumber"] = "";
            Session["EmployeerId"] = "";
            Session["CBId"] = "";
            Session["MenuRights"] = "";
            Session["DispType"] = "Public";         
        }        
        Random rnd = new Random();
        Response.Redirect("./ContentBuilder/DisplayPage.aspx?PageType=PUB&DataId=" + BuildID + "&Rnd="+ rnd.Next());        
        dtPublicIndex.Dispose();
       
    }

   
}
