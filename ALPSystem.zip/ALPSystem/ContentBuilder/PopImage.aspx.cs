using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ContentBuilder_Pop : System.Web.UI.Page
{
    ContentReader DBobj = new ContentReader();
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        string imgid = Request.QueryString["imgname"].ToString();
        DataTable dtimg = DBobj.ExecuteDTQuery("Select ImageDesc, ImageURL, Alt, width, height from PopImages where ImageNo=" + imgid +"");
        if (dtimg.Rows.Count > 0)
        {
            Page.Title = dtimg.Rows[0]["ImageDesc"].ToString();
            popimg.Src = "../Images/PopImages/" + dtimg.Rows[0]["ImageURL"].ToString();
            popimg.Alt = dtimg.Rows[0]["Alt"].ToString();
            popimg.Width = dtimg.Rows[0]["width"].ToString().Trim().Equals("") ? 0 : int.Parse(dtimg.Rows[0]["width"].ToString());
            popimg.Height = dtimg.Rows[0]["height"].ToString().Trim().Equals("") ? 0 : int.Parse(dtimg.Rows[0]["height"].ToString());
            /*int bleft = (popimg.Width / 2);
            int btop = popimg.Height - 150;
            closediv.Style.Add("margin-top", bleft.ToString());
            closediv.Style.Add("margin-left", btop.ToString());*/
        }
        
    }
}
