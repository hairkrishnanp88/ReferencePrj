using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;
public partial class ContentBuilder_AddContent : System.Web.UI.Page
{
    string IDs, Mode, PageFind, dataid, Mod, BtnRights;
    ContentReader Obj = new ContentReader();
    DataTable Catids = new DataTable();
    DataTable Subids = new DataTable();
    public Table tblContentList;
    public TableRow trContentList;
    public TableCell[] tdContentList;
    public LinkButton[] BtnContentPage;
    public DataTable DTContentPage = new DataTable();
    DataTable dtRights = new DataTable();
    DataTable DTLike = new DataTable();
    int c;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        try
        {
            ShowBanner(Session["Banner"].ToString());
            ShowPanel(Session["Panel"].ToString());

            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());
                divMenu.Controls.Add(SiteInfo.userValidation());
            }
            UserManager user = new UserManager();
            user.Userid = Convert.ToInt32(Session["UserId"].ToString());
            dtRights = user.BuilderRights("", "");
            AddChildRow.Style.Add("display", "none");

            if (IsPostBack == false)
            {
                ContentDrop.Items.Add("Page");
                ContentDrop.Items.Add("Parent Folder");
                ContentDrop.Items.Add("Child Folder");
            }

        /*    c = 0;
            DTContentPage = Obj.GetAllContentBuilderNames();
            
            //ContentDrop.Items.Add("Page");
            //  ContentDrop.Items.Add("Child Folder");
            ContentDrop.Items.Add("Parent Folder");

            tblContentList = new Table();
            trContentList = new TableRow();
            BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
            tdContentList = new TableCell[DTContentPage.Rows.Count];

            foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
            {
                trContentList = new TableRow();
                BtnContentPage[c] = new LinkButton();
                tdContentList[c] = new TableCell();

                BtnContentPage[c].Text = rowValues["name"].ToString();
                BtnContentPage[c].ID = rowValues["dataid"].ToString();
                BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                BtnContentPage[c].Font.Name = "Tahoma";
                BtnContentPage[c].Font.Size = 8;
                BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
                BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                tdContentList[c].Controls.Add(BtnContentPage[c]);
                trContentList.Cells.Add(tdContentList[c]);
                tblContentList.Rows.Add(trContentList);
                c++;
            }
            ContentPagesListTd.Controls.Add(tblContentList);*/

            if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")//21-09-06 05:35 begin
            {
                tblBanner.Visible = true;
                tblLeftPanel.Visible = true;
                c = 0;
                DTContentPage = Obj.GetAllContentBuilderNames();             

                tblContentList = new Table();
                trContentList = new TableRow();
                BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
                tdContentList = new TableCell[DTContentPage.Rows.Count];

                foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
                {
                    trContentList = new TableRow();
                    BtnContentPage[c] = new LinkButton();
                    tdContentList[c] = new TableCell();

                    BtnContentPage[c].Text = rowValues["name"].ToString();
                    BtnContentPage[c].ID = rowValues["dataid"].ToString();
                    BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                    BtnContentPage[c].Font.Name = "Tahoma";
                    BtnContentPage[c].Font.Size = 8;
                    BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                    BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                    BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                    BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
                    BtnContentPage[c].Click += new EventHandler(ContentPage_Click);

                    tdContentList[c].Controls.Add(BtnContentPage[c]);
                    trContentList.Cells.Add(tdContentList[c]);
                    tblContentList.Rows.Add(trContentList);
                    c++;
                }

                ContentPagesListTd.Controls.Add(tblContentList);
            }
            else
            {
                if (dtRights.Rows.Count != 0)
                {
                    //ContentDrop.Style.Add("display", "none");
                    //txtContentSearch.Style.Add("display", "none");
                    //BtnSearch.Style.Add("display", "none");
                    //BtnFullList.Style.Add("display", "none");

                    tblContentList = new Table();
                    trContentList = new TableRow();
                    BtnContentPage = new LinkButton[dtRights.Rows.Count];
                    tdContentList = new TableCell[dtRights.Rows.Count];
                    foreach (System.Data.DataRow rowValues in dtRights.Rows)
                    {
                        if (rowValues["Rights"].ToString() == "" || rowValues["Rights"].ToString().Substring(3, 1) == "1")
                        {
                            DTContentPage = Obj.GetAllcontentbuilder(rowValues["BuilderId"].ToString());
                            if (DTContentPage.Rows.Count > 0)
                            {
                                trContentList = new TableRow();
                                BtnContentPage[c] = new LinkButton();
                                tdContentList[c] = new TableCell();

                                BtnContentPage[c].Text = DTContentPage.Rows[0]["name"].ToString();
                                BtnContentPage[c].ID = DTContentPage.Rows[0]["dataid"].ToString();
                                BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                                BtnContentPage[c].Font.Name = "Tahoma";
                                BtnContentPage[c].Font.Size = 8;
                                BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                                BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                                BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                                BtnContentPage[c].CommandArgument = DTContentPage.Rows[0]["dataid"].ToString();
                                BtnContentPage[c].Click += new EventHandler(ContentPage_Click);

                                tdContentList[c].Controls.Add(BtnContentPage[c]);
                                trContentList.Cells.Add(tdContentList[c]);
                                tblContentList.Rows.Add(trContentList);
                                c++;
                            }
                        }
                    }
                }
                ContentPagesListTd.Controls.Add(tblContentList);
            }  //21-09-06 05:35 end
         
            IDs = Request.QueryString["Foldid"];
            Mode = Request.QueryString["Mode"];
            if (Mode == "Add")
            {
                if (IDs.StartsWith("CA"))
                {
                    AddChildRow.Style.Add("display", "none");
                    AddParentRow.Style.Add("display", "none");    
                    //AddPageRow.Style.Add("display", "inline");
                    PageFind = "ChildPage";
                    Response.Redirect("AddPageContent.aspx?Foldid=" + IDs + "&FromName=" + PageFind + "&Mode=" + Mode);
                }
                if (IDs.StartsWith("SU"))
                {
                    Catids = Obj.GetAllcategory(IDs);
                    Subids = Obj.GetAllConSubject(IDs);                    
                    if (Catids.Rows.Count > 0)
                    {
                        AddParentRow.Style.Add("display", "inline");
                        AddChildRow.Style.Add("display", "inline");
                        AddPageRow.Style.Add("display", "none");
                    }
                    else if (Subids.Rows.Count > 0)
                    {
                        AddParentRow.Style.Add("display", "inline");
                        AddChildRow.Style.Add("display", "none");
                        AddPageRow.Style.Add("display", "inline");
                    }
                    else
                    {
                        AddParentRow.Style.Add("display", "inline");
                        AddChildRow.Style.Add("display", "inline");
                        AddPageRow.Style.Add("display", "inline");
                    }                    
                }
                if (IDs == "")
                {
                    AddPageRow.Style.Add("display", "none");
                }
            }
        }
        catch (System.Exception ex)
        {
            Response.Write("<script language='javascript'>alert('" + ex.Message + "');</script>");
        }
           
    }
    protected void RAddChildFolder_CheckedChanged(object sender, EventArgs e)
    {
        PageFind = "AddPage";
        Mod = "Child";
        Response.Redirect("AddFolder.aspx?Foldid=" + IDs + "&FromName=" + PageFind + "&Mode=" + Mode + "&Mod=" + Mod);
    }
    protected void RAddParent_CheckedChanged(object sender, EventArgs e)
    {
        PageFind = "AddPage";
        Mod ="Parent";
        Response.Redirect("AddFolder.aspx?Foldid=" + IDs + "&FromName=" + PageFind + "&Mode=" + Mode +"&Mod="+ Mod);
    }
    protected void RAddPage_CheckedChanged(object sender, EventArgs e)
    {
        PageFind = "AddPage";
        Response.Redirect("AddPageContent.aspx?Foldid=" + IDs + "&FromName=" + PageFind + "&Mode=" + Mode);
    }
    protected void BtnBackAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }
    protected void ContentPage_Click(object sender, EventArgs e)
    {
        dataid = (((LinkButton)(sender)).CommandArgument).ToString();

        for (int i = 0; i < dtRights.Rows.Count; i++)
        {
            if (dtRights.Rows[i]["BuilderId"].ToString() == dataid)
            {
                BtnRights = dtRights.Rows[i]["Rights"].ToString();
            }

            if (dtRights.Rows[i]["Rights"].ToString() == "" && dtRights.Rows[i]["BuilderId"].ToString() == dataid) //21-09-06
            {
                BtnRights = "1111";
            }
        }
        Response.Redirect("DisplayPage.aspx?DataId=" + dataid + "&BtnRights=" + BtnRights);

        //Response.Redirect("DisplayPage.aspx?DataId=" + dataid);

    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx?Subname=" + txtContentSearch.Text + "&Dropname=" + ContentDrop.SelectedItem.Text);
    }
    protected void BtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }

    //userValidation

    protected HtmlTable userValidation()
    {
        //  objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = Obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }



                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = Obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub'); ");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = Obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        // if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = Obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //tdLeftPanel.Style.Add("display", value);
       tblLeftPanel.Style.Add("display", value);
        //trLeft1.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
    }
    protected void txtContentSearch_TextChanged(object sender, EventArgs e)
    {

    }
}

