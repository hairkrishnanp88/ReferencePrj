using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ContentBuilder_ContentBuilderPage : System.Web.UI.Page
{
    public DataTable dt = new DataTable();
    public DataTable dt1 = new DataTable();
    public DataTable dt2 = new DataTable();
    public DataTable dt3 = new DataTable();
    public DataTable dtCategory = new DataTable();
    public string str, str1, str2, str3, SubId, BtnRights, rhtView;
    public int i, f, k, x, y, cou, pre, l, r, r1, rightsAdd, notEqual, subCount;
    public string id, Ar, strQur, pas, Anew, svlRecord, Foldid, Mode, Subname="", Dropname="";
    public Table tblMt1;
    public TableRow[] tblMr1;
    public TableRow[] tblMrow;
    public TableRow tblMr2;
    public TableCell tblMc1;
    public TableCell tblMc2;
    public TableCell[] tblMc3;
    public TableCell tblMc4;

    // Edit by Murali
    public Table ctblMt1;
    public TableRow[] ctblMr1;
    public TableRow[] ctblMrow, tblPageRow;
    public TableRow ctblMr2;
    public TableCell ctblMc1;
    public TableCell ctblMc2;
    public TableCell[] ctblMc3;
    public TableCell ctblMc4;
    public string cstr, cstr1, cstr2, cstr3,cid;
    public int ci, cf;
    

    public Table ctblFt;
    public TableRow ctblFr;
    public TableCell ctblFc;

    public LinkButton[] chybu;
    public HtmlImage[] cimag;
    public Label[] cFoldername;

    public DataTable cdt1 = new DataTable();
    public System.Web.UI.WebControls.Image[] cimg;
    //End

    public LiteralControl lit;

    public System.Web.UI.WebControls.Image[] img;
    public LinkButton[] hybu;
    public HtmlImage[] imag;
    public Label[] Foldername;

    public HtmlImage leafimage;
    public LinkButton[] Ylink;
    public HtmlImage subimag;

    public Table tblFt;
    public TableRow tblFr;
    public TableCell tblFc;

    public Table tblContentList;
    public TableRow trContentList;
    public TableCell[] tdContentList;
    public LinkButton[] BtnContentPage;
    public DataTable DTContentPage = new DataTable();
    DataTable DTLike = new DataTable();
    DataTable dtRights = new DataTable();
    //Label lblSub;
    public int check, c;
    ContentReader objFolder = new ContentReader();
    Boolean add = false, mod = false, del = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        Session["DispType"] = "SiteManagement";

        ShowBanner(Session["Banner"].ToString());
        ShowPanel(Session["Panel"].ToString());
        if (Session["UserType"].ToString() == "Public")
        {
            BtnConAdd.Visible = false;
            BtnConModify.Visible = false;
        }
        //BtnConcopy.Attributes.Add("style", "display:none");
        tdCopy.Style.Add("display", "none");

        if (Session["UserId"].ToString() != "")
        {

            UserManager user = new UserManager();
            user.Userid = Convert.ToInt32(Session["UserId"].ToString());
            dtRights = user.BuilderRights("", "");
        }

        //Response.Write(dtRights.Rows[0][1].ToString());
        // Response.Write(dtRights.Rows[0][0].ToString());

        //if (dtRights.Rows.Count != 0)
        //{
        //    string Rights = dtRights.Rows[0][1].ToString();

        //    string rAdd = Rights.Substring(0, 1);
        //    Response.Write(rAdd);
        //    string rMod = Rights.Substring(1, 1);
        //    Response.Write(rMod);
        //    string rDel = Rights.Substring(2, 1);
        //    Response.Write(rDel);
        //    string rView = Rights.Substring(3, 1);
        //    Response.Write(rView);

        //    if (rAdd == "1")
        //        BtnConAdd.Visible = true;
        //    else
        //        BtnConAdd.Visible = false;

        //    if (rMod == "1")
        //        BtnConModify.Visible = true;
        //    else
        //        BtnConModify.Visible = false;

        //    if (rDel == "1")
        //        BtnConDelete.Visible = true;
        //    else
        //        BtnConDelete.Visible = false;
        //}

        // BtnConModify.Attributes.Add("onclick", "javascript:if(!AddValidate()){return false;};");
        try
        {
            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());
                divMenu.Controls.Add(SiteInfo.userValidation());
            }
            if (IsPostBack == false)
            {
                ContentDrop.Items.Add("Page");
                ContentDrop.Items.Add("Parent Folder");
                ContentDrop.Items.Add("Child Folder");
            }
            if (Request.QueryString["Subname"] != null)
            {
                Subname = Request.QueryString["Subname"].ToString();
            }
            if (Request.QueryString["Dropname"] != null)
            {
                Dropname = Request.QueryString["Dropname"].ToString();
            }

            if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
            {
                c = 0;
                DTContentPage = objFolder.GetAllContentBuilderNames();
              
                tblContentList = new Table();
                trContentList = new TableRow();
                BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
                tdContentList = new TableCell[DTContentPage.Rows.Count];

                foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
                {
                    trContentList = new TableRow();
                    BtnContentPage[c] = new LinkButton();
                    tdContentList[c] = new TableCell();

                    BtnContentPage[c].Text = rowValues["name"].ToString();
                    BtnContentPage[c].ID = rowValues["dataid"].ToString();
                    BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                    BtnContentPage[c].Font.Name = "Tahoma";
                    BtnContentPage[c].Font.Size = 8;
                    BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                    BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                    BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                    BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
                    BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                    tdContentList[c].Controls.Add(BtnContentPage[c]);
                    trContentList.Cells.Add(tdContentList[c]);
                    tblContentList.Rows.Add(trContentList);
                    c++;
                }

                ContentPagesListTd.Controls.Add(tblContentList);
                
                //Search a Particulare Parent Folder or Child Folder or Page
             /*   if (Dropname != "" && Dropname != null)
                {
                    //f = 0;
                    DTLike = objFolder.GetLikeSubject(Subname, Dropname);                    
                    tblMt1 = new Table();                    
                    img = new System.Web.UI.WebControls.Image[DTLike.Rows.Count];
                    Foldername = new Label[DTLike.Rows.Count];
                    tblMr1 = new TableRow[DTLike.Rows.Count];
                    tblMc3 = new TableCell[DTLike.Rows.Count];
                    tblPageRow = new TableRow[DTLike.Rows.Count];

                    string cursubjectid = "",presubjectid = "" ;
                    string curcatid = "", precatid = "";
                    int count = 0;
                    f = 0;
                    cf = 0;
                    for(int i=0; i< DTLike.Rows.Count; i++)//Folders
                    {
                        cursubjectid = DTLike.Rows[i]["subjectid"].ToString();
                        int scount = 0, ccount = 0;
                        tblFr = new TableRow();
                        tblFc = new TableCell();
                        tblMr1[i] = new TableRow();
                        tblPageRow[i] = new TableRow();
                        tblMc3[i] = new TableCell();
                        tblMr2 = new TableRow();
                        tblMc1 = new TableCell();
                        tblMc2 = new TableCell();
                        img[i] = new System.Web.UI.WebControls.Image();
                        Foldername[i] = new Label();
                        tblFt = new Table();
                        if (cursubjectid != presubjectid)
                        {
                            scount++;    
                            tblMc3[i].ID = "fly" + i;
                            tblMc3[i].Attributes.Add("runat", "server");
                            tblMc3[i].Style.Add("display", "none");

                            img[i].ImageUrl = "../Images/plus.gif";
                            img[i].ID = "img" + i;
                            tblMr1[i].ID = DTLike.Rows[i]["subjectid"].ToString();
                            presubjectid = DTLike.Rows[i]["subjectid"].ToString();
                            Foldername[i].Text = DTLike.Rows[i]["subname"].ToString();
                            tblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                            tblMc1.Controls.Add(img[i]);
                        }
                        else
                        {
                            count++;
                        }
                        if (!DTLike.Rows[i]["catid"].ToString().Equals(""))
                        {
                                curcatid = DTLike.Rows[i]["catid"].ToString();                                
                                if (curcatid != precatid)
                                {
                                    ccount++;
                                    ctblFr = new TableRow();
                                    ctblFc = new TableCell();
                                    ci = 0;
                                    ctblMt1 = new Table();
                                    cimg = new System.Web.UI.WebControls.Image[DTLike.Rows.Count];
                                    cFoldername = new Label[DTLike.Rows.Count];
                                    ctblMr1 = new TableRow[DTLike.Rows.Count];

                                    ctblMr1[ci] = new TableRow();
                                    ctblMr2 = new TableRow();
                                    ctblMc1 = new TableCell();
                                    ctblMc3 = new TableCell[DTLike.Rows.Count];
                                    ctblMc3[ci] = new TableCell();
                                    cimg[ci] = new System.Web.UI.WebControls.Image();
                                    cFoldername[ci] = new Label();
                                    ctblFt = new Table();

                                    cimg[ci].ImageUrl = "../Images/plus.gif";
                                    cimg[ci].ID = "cimg" + i + ci;

                                    ctblMr1[ci].ID = DTLike.Rows[i]["catid"].ToString();
                                    precatid = DTLike.Rows[i]["catid"].ToString();
                                    ctblMc3[ci].ID = "cfly" + i + ci;

                                    ctblMc3[ci].Attributes.Add("runat", "server");
                                    ctblMc3[ci].Style.Add("display", "none");

                                    cFoldername[ci].Text = DTLike.Rows[i]["catname"].ToString();
                                    ctblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                    ctblMc1.Controls.Add(cimg[ci]);
                                    if (DTLike.Rows[i]["dataid"].ToString() != "")
                                    {
                                        cimg[ci].Attributes.Add("style", "display: inline");
                                    }
                                    else
                                    {
                                        cimg[ci].Attributes.Add("style", "display: none");
                                    }
                                }
                                    
                                    
                                    chybu = new LinkButton[DTLike.Rows.Count];
                                    cimag = new HtmlImage[DTLike.Rows.Count];
                                    ctblFr = new TableRow();
                                    ctblFc = new TableCell();
                                    if (!DTLike.Rows[i]["dataid"].ToString().Equals("")) //Pages
                                    {
                                        chybu[cf] = new LinkButton();
                                        cimag[cf] = new HtmlImage();
                                        cimag[cf].Src = "../Images/Black_Leaf.jpg";
                                        cimag[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        cimag[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");
                                        chybu[cf].ID = "ChildFolder" + k++;
                                        chybu[cf].Font.Size = 8;
                                        chybu[cf].Font.Name = "Verdana";
                                        chybu[cf].ForeColor = System.Drawing.Color.Black;
                                        chybu[cf].Text = DTLike.Rows[i]["pagename"].ToString();
                                        chybu[cf].Attributes.Add("style", "text-decoration: none");
                                        chybu[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                        chybu[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        ctblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                        ctblFc.Controls.Add(cimag[cf]);
                                        ctblFc.Controls.Add(chybu[cf]);
                                        ctblFc.Controls.Add(new LiteralControl("<br>"));

                                        cid = DTLike.Rows[i][3].ToString();
                                        chybu[cf].CommandArgument = DTLike.Rows[i]["dataid"].ToString();
                                        chybu[cf].Click += new EventHandler(Select_Click);
                                        cf++;
                                    }
                                    else
                                    {
                                        leafimage = new HtmlImage();
                                        leafimage.Src = "../Images/Black_Leaf.jpg";
                                        ctblMc1.Controls.Add(leafimage);                                        
                                    }                                    
                                    if (ccount == 1)
                                    {

                                        ctblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                        ctblMc1.Style.Add("FONT-SIZE", "8pt");
                                        ctblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                        ctblMc1.Controls.Add(cFoldername[ci]);


                                        ctblMr1[ci].Cells.Add(ctblMc1);
                                        ctblFr.Cells.Add(ctblFc);
                                        ctblFt.Rows.Add(ctblFr);

                                        ctblMc3[ci].ColumnSpan = 2;
                                        ctblMc3[ci].Controls.Add(ctblFt);
                                        ctblMr2.Cells.Add(ctblMc3[ci]);

                                        cimg[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        cimg[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        cFoldername[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                        cFoldername[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                        //ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){hide();" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){hide();" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                        ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                        ctblMr1[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        ctblMr1[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        ctblMt1.Rows.Add(ctblMr1[ci]);
                                        ctblMt1.Rows.Add(ctblMr2);

                                        tblFc.Controls.Add(ctblMt1);
                                        tblFr.Cells.Add(tblFc);
                                        tblFt.Rows.Add(tblFr);
                                        
                                    }
                                    else
                                    {
                                        ctblFr.Cells.Add(ctblFc);
                                        ctblFt.Rows.Add(ctblFr);
                                        tblFc.Controls.Add(ctblFt);
                                    }
                                    ci++;
                            }
                            if (!DTLike.Rows[i]["dataid"].ToString().Equals("") && DTLike.Rows[i]["catid"].ToString().Equals(""))
                            {

                                hybu = new LinkButton[DTLike.Rows.Count];
                                imag = new HtmlImage[DTLike.Rows.Count];
                                tblFr = new TableRow();
                                tblFc = new TableCell();
                                hybu[f] = new LinkButton();
                                imag[f] = new HtmlImage();

                                imag[f].Src = "../Images/Black_Leaf.jpg";
                                imag[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                imag[f].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                hybu[f].ID = "Folder" + k++;
                                hybu[f].Font.Size = 8;
                                hybu[f].Font.Name = "Verdana";
                                hybu[f].ForeColor = System.Drawing.Color.Black;
                                hybu[f].Text = DTLike.Rows[i]["pagename"].ToString();
                                hybu[f].Attributes.Add("style", "text-decoration: none");
                                hybu[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                hybu[f].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                tblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                tblFc.Controls.Add(imag[f]);
                                tblFc.Controls.Add(hybu[f]);
                                tblFc.Controls.Add(new LiteralControl("<br>"));

                                id = DTLike.Rows[i]["dataid"].ToString();
                                hybu[f].CommandArgument = DTLike.Rows[i]["dataid"].ToString();
                                hybu[f].Click += new EventHandler(Select_Click);
                                f++;

                            }
                            else if (DTLike.Rows[i]["dataid"].ToString().Equals("") && DTLike.Rows[i]["catid"].ToString().Equals(""))
                            {
                                leafimage = new HtmlImage();
                                leafimage.Src = "../Images/Black_Leaf.jpg";
                                tblMc1.Controls.Add(leafimage);
                                img[i].ImageUrl = "../Images/Black_Leaf.jpg";
                                img[i].Attributes.Add("style", "display: none");
                            }

                            if (scount == 1)
                            {
                                tblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                tblMc1.Style.Add("FONT-SIZE", "8pt");
                                tblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                tblMc1.Controls.Add(Foldername[i]);
                                tblMr1[i].Cells.Add(tblMc1);

                                tblFr.Cells.Add(tblFc);
                                tblFt.Rows.Add(tblFr);
                                //tblPageRow[i].Cells.Add(tblFc);
                                //tblFt.Rows.Add(tblPageRow[i]);
                                tblMc3[i].ColumnSpan = 2;
                                tblMc3[i].Controls.Add(tblFt);
                                tblMr2.Cells.Add(tblMc3[i]);

                                img[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                img[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                Foldername[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                Foldername[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                tblMr1[i].Attributes.Add("OnClick", "javascript:if(" + tblMc3[i].ID + ".style.display == 'none'){hide();" + tblMc3[i].ID + ".style.display = 'block';" + img[i].ID + ".src='../Images/minus.gif';Fid.value='" + tblMr1[i].ID + "';}else if(" + tblMc3[i].ID + ".style.display == 'block'){hide();" + tblMc3[i].ID + ".style.display = 'none';" + img[i].ID + ".src='../Images/plus.gif';}");
                                tblMr1[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                tblMr1[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                tblMt1.Rows.Add(tblMr1[i]);
                                tblMt1.Rows.Add(tblMr2);
                                tblMain.Controls.Add(tblMt1);                                

                            }
                            else
                            {
                                //tblFr.Cells.Add(tblFc);
                                //tblFt.Rows.Add(tblFr);
                                //tblMain.Controls.Add(tblFt);

                                tblMc1.Controls.Add(Foldername[i]);
                                tblMr1[i].Cells.Add(tblMc1);
                                tblFr.Cells.Add(tblFc);
                                tblFt.Rows.Add(tblFr);

                                //tblPageRow[i - count + 1].Cells.Add(tblFc);
                                //tblFt.Rows.Add(tblPageRow[i - count + 1]);
                                tblMc3[i].ColumnSpan = 2;
                                tblMc3[i].Controls.Add(tblFt);
                                tblMr2.Cells.Add(tblMc3[i]);
                                tblMt1.Rows.Add(tblMr1[i]);
                                tblMt1.Rows.Add(tblMr2);                    
                            }
                        
                    }
                    
                    DTLike.Clear();
                    //End by Murali
                }
               */
                //else
                {
                    i = 0;
                    f = 0;
                    k = 0;
                    r = 0; r1 = 0;
                    check = 0;
                    tblMt1 = new Table();
                    if (Dropname != "" && Subname != "")
                    {
                        dt = objFolder.GetLikeSubject(Subname, Dropname);
                    }
                    else
                    {
                        dt = objFolder.GetAllsubject();
                    }

                    img = new System.Web.UI.WebControls.Image[dt.Rows.Count];
                    Foldername = new Label[dt.Rows.Count];
                    tblMr1 = new TableRow[dt.Rows.Count];
                    foreach (System.Data.DataRow row in dt.Rows)//Folders
                    {
                        tblMr1[i] = new TableRow();
                        tblMr2 = new TableRow();
                        tblMc1 = new TableCell();
                        tblMc2 = new TableCell();
                        tblMc3 = new TableCell[dt.Rows.Count];
                        tblMc3[i] = new TableCell();
                        img[i] = new System.Web.UI.WebControls.Image();
                        Foldername[i] = new Label();

                        tblFt = new Table();

                        img[i].ImageUrl = "../Images/plus.gif";
                        img[i].ID = "img" + i;
                        tblMr1[i].ID = row[1].ToString();
                        tblMc3[i].ID = "fly" + i;
                        tblMc3[i].Attributes.Add("runat", "server");
                        tblMc3[i].Style.Add("display", "none");

                        Foldername[i].Text = row[0].ToString();
                        tblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                        tblMc1.Controls.Add(img[i]);
                        str = row[1].ToString();
                        tblFr = new TableRow();
                        tblFc = new TableCell();

                        //Edit By Murali
                        if (Subname != "" && (Dropname == "Child Folder" || Dropname == "Page"))
                        {

                            dtCategory = objFolder.GetLikeCategory(Subname, Dropname, str); 
                        }
                        else
                        {
                            dtCategory = objFolder.GetAllcategory(str); // Child Folder
                        }
                        if (dtCategory.Rows.Count > 0)
                        {

                            tblMc1.Style.Add("FONT-FAMILY", "Verdana");
                            tblMc1.Style.Add("FONT-SIZE", "8pt");
                            tblMc1.Controls.Add(new LiteralControl("&nbsp"));
                            tblMc1.Controls.Add(Foldername[i]);

                            tblMr1[i].Cells.Add(tblMc1);

                            tblFr.Cells.Add(tblFc);
                            tblFt.Rows.Add(tblFr);
                            tblMc3[i].ColumnSpan = 2;
                            tblMc3[i].Controls.Add(tblFt);
                            tblMr2.Cells.Add(tblMc3[i]);

                            img[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                            img[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                            Foldername[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                            Foldername[i].Attributes.Add("onmouseout", "this.style.color='#000000';");
                            tblMr1[i].Attributes.Add("OnClick", "javascript:if(" + tblMc3[i].ID + ".style.display == 'none'){hide();" + tblMc3[i].ID + ".style.display = 'block';" + img[i].ID + ".src='../Images/minus.gif';Fid.value='" + tblMr1[i].ID + "';}else if(" + tblMc3[i].ID + ".style.display == 'block'){hide();" + tblMc3[i].ID + ".style.display = 'none';" + img[i].ID + ".src='../Images/plus.gif';}");
                            tblMr1[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                            tblMr1[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                            tblMt1.Rows.Add(tblMr1[i]);
                            tblMt1.Rows.Add(tblMr2);

                            ctblFr = new TableRow();
                            ctblFc = new TableCell();
                            ci = 0;
                            ctblMt1 = new Table();
                            cimg = new System.Web.UI.WebControls.Image[dtCategory.Rows.Count];
                            cFoldername = new Label[dtCategory.Rows.Count];
                            ctblMr1 = new TableRow[dtCategory.Rows.Count];
                            foreach (System.Data.DataRow crow in dtCategory.Rows)//Child Folders
                            {
                                ctblMr1[ci] = new TableRow();
                                ctblMr2 = new TableRow();
                                ctblMc1 = new TableCell();
                                //ctblMc2 = new TableCell();
                                ctblMc3 = new TableCell[dtCategory.Rows.Count];
                                ctblMc3[ci] = new TableCell();
                                cimg[ci] = new System.Web.UI.WebControls.Image();
                                cFoldername[ci] = new Label();
                                ctblFt = new Table();

                                cimg[ci].ImageUrl = "../Images/plus.gif";
                                cimg[ci].ID = "cimg" +  i + ci;
                                
                                ctblMr1[ci].ID = crow[1].ToString();
                                ctblMc3[ci].ID = "cfly" + i + ci;
                                ctblMc3[ci].Attributes.Add("runat", "server");
                                ctblMc3[ci].Style.Add("display", "none");

                                cFoldername[ci].Text = crow[2].ToString();
                                ctblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                
                                cstr = crow[1].ToString();
                                if (Subname != "" &&  Dropname == "Page")
                                {
                                    cdt1 = objFolder.GetLikeBuilder(Subname, cstr); 
                                }
                                else
                                {
                                    cdt1 = objFolder.GetAllConSubject(cstr);
                                }
                                ctblMc1.Controls.Add(cimg[ci]);
                                if (cdt1.Rows.Count > 0)
                                {
                                    cimg[ci].Attributes.Add("style", "display: inline");
                                }
                                else
                                {
                                    cimg[ci].Attributes.Add("style", "display: none");
                                }
                                cf = 0;
                                chybu = new LinkButton[cdt1.Rows.Count];
                                cimag = new HtmlImage[cdt1.Rows.Count];
                                ctblFr = new TableRow();
                                ctblFc = new TableCell();
                                if (cdt1.Rows.Count > 0)
                                {
                                    
                                    foreach (System.Data.DataRow crow1 in cdt1.Rows)//Flyers
                                    {
                                        chybu[cf] = new LinkButton();
                                        cimag[cf] = new HtmlImage();

                                        cimag[cf].Src = "../Images/Black_Leaf.jpg";
                                        cimag[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        cimag[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        chybu[cf].ID = "ChildFolder" + k++;
                                        chybu[cf].Font.Size = 8;
                                        chybu[cf].Font.Name = "Verdana";
                                        chybu[cf].ForeColor = System.Drawing.Color.Black;
                                        chybu[cf].Text = crow1[0].ToString();
                                        chybu[cf].Attributes.Add("style", "text-decoration: none");
                                        chybu[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                        chybu[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        ctblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                        ctblFc.Controls.Add(cimag[cf]);
                                        ctblFc.Controls.Add(chybu[cf]);
                                        ctblFc.Controls.Add(new LiteralControl("<br>"));

                                        cstr1 = chybu[cf].Text;
                                        cstr2 = crow1[1].ToString();
                                        cstr3 = crow1[2].ToString();
                                        cid = crow1[3].ToString();
                                        chybu[cf].CommandArgument = crow1[1].ToString();
                                        chybu[cf].Click += new EventHandler(Select_Click);
                                        cf++;
                                    }
                                    
                                }
                                else
                                {
                                    leafimage = new HtmlImage();
                                    leafimage.Src = "../Images/Black_Leaf.jpg";
                                    ctblMc1.Controls.Add(leafimage);
                                    //cimg[cf].ImageUrl = "../Images/Black_Leaf.jpg";
                                    //cimg[cf].Attributes.Add("style", "display: none");
                                    //cimg[ci].Attributes.Add("style", "display: none");
                                }
                                cdt1.Clear();
                                ctblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                ctblMc1.Style.Add("FONT-SIZE", "8pt");
                                ctblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                ctblMc1.Controls.Add(cFoldername[ci]);


                                ctblMr1[ci].Cells.Add(ctblMc1);
                                ctblFr.Cells.Add(ctblFc);
                                ctblFt.Rows.Add(ctblFr);

                                ctblMc3[ci].ColumnSpan = 2;
                                ctblMc3[ci].Controls.Add(ctblFt);
                                ctblMr2.Cells.Add(ctblMc3[ci]);

                                cimg[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                cimg[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                cFoldername[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                cFoldername[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                //ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){hide();" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){hide();" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                ctblMr1[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                ctblMr1[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");
                                
                                ctblMt1.Rows.Add(ctblMr1[ci]);
                                ctblMt1.Rows.Add(ctblMr2);

                                tblFc.Controls.Add(ctblMt1);
                                tblFr.Cells.Add(tblFc);
                                tblFt.Rows.Add(tblFr);      
                                ci++;
                            }
                        }                        
                        else
                        {
                            if (Subname !="" && Dropname == "Page")
                            {
                                dt1 = objFolder.GetLikeBuilder(Subname, str); 
                            }
                            else
                            {
                                dt1 = objFolder.GetAllConSubject(str);
                            }
                            f = 0;
                            hybu = new LinkButton[dt1.Rows.Count];
                            imag = new HtmlImage[dt1.Rows.Count];
                            //tblFr = new TableRow();
                            //tblFc = new TableCell();
                            if (dt1.Rows.Count > 0)
                            {
                                foreach (System.Data.DataRow row1 in dt1.Rows)//Flyers
                                {
                                    hybu[f] = new LinkButton();
                                    imag[f] = new HtmlImage();

                                    imag[f].Src = "../Images/Black_Leaf.jpg";
                                    imag[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                    imag[f].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                    hybu[f].ID = "Folder" + k++;
                                    hybu[f].Font.Size = 8;
                                    hybu[f].Font.Name = "Verdana";
                                    hybu[f].ForeColor = System.Drawing.Color.Black;
                                    hybu[f].Text = row1[0].ToString();
                                    hybu[f].Attributes.Add("style", "text-decoration: none");
                                    hybu[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                    hybu[f].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                    tblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                    tblFc.Controls.Add(imag[f]);
                                    tblFc.Controls.Add(hybu[f]);
                                    tblFc.Controls.Add(new LiteralControl("<br>"));

                                    str1 = hybu[f].Text;
                                    str2 = row1[1].ToString();
                                    str3 = row1[2].ToString();
                                    id = row1[3].ToString();
                                    hybu[f].CommandArgument = row1[1].ToString();
                                    hybu[f].Click += new EventHandler(Select_Click);
                                    f++;
                                }
                                dt1.Clear();
                            }
                            else
                            {
                                leafimage = new HtmlImage();
                                leafimage.Src = "../Images/Black_Leaf.jpg";
                                tblMc1.Controls.Add(leafimage);
                                img[i].ImageUrl = "../Images/Black_Leaf.jpg";
                                img[i].Attributes.Add("style", "display: none");
                            }

                            tblMc1.Style.Add("FONT-FAMILY", "Verdana");
                            tblMc1.Style.Add("FONT-SIZE", "8pt");
                            tblMc1.Controls.Add(new LiteralControl("&nbsp"));
                            tblMc1.Controls.Add(Foldername[i]);


                            tblMr1[i].Cells.Add(tblMc1);
                            tblFr.Cells.Add(tblFc);
                            tblFt.Rows.Add(tblFr);
                            tblMc3[i].ColumnSpan = 2;
                            tblMc3[i].Controls.Add(tblFt);
                            tblMr2.Cells.Add(tblMc3[i]);

                            img[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                            img[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                            Foldername[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                            Foldername[i].Attributes.Add("onmouseout", "this.style.color='#000000';");
                            tblMr1[i].Attributes.Add("OnClick", "javascript:if(" + tblMc3[i].ID + ".style.display == 'none'){hide();" + tblMc3[i].ID + ".style.display = 'block';" + img[i].ID + ".src='../Images/minus.gif';Fid.value='" + tblMr1[i].ID + "';}else if(" + tblMc3[i].ID + ".style.display == 'block'){hide();" + tblMc3[i].ID + ".style.display = 'none';" + img[i].ID + ".src='../Images/plus.gif';}");
                            tblMr1[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                            tblMr1[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                            tblMt1.Rows.Add(tblMr1[i]);
                            tblMt1.Rows.Add(tblMr2);
                       }
                       i++;
                       tblMain.Controls.Add(tblMt1);
                       dtCategory.Clear();
                     
                        //End by Murali
                    }
                    
                }
            }
            else //User Rights....
            {
                //ContentDrop.Visible = false;
                //txtContentSearch.Visible = false;
                //BtnSearch.Visible = false;
                //BtnFullList.Visible = false;
                if (dtRights.Rows.Count != 0)
                {
                    for (int j = 0; j <= dtRights.Rows.Count - 1; j++)
                    {
                        if (dtRights.Rows[j]["Rights"].ToString() != "")
                        {
                            string Rights = dtRights.Rows[j]["Rights"].ToString();
                            string rAdd = Rights.Substring(0, 1);
                            string rMod = Rights.Substring(1, 1);
                            string rDel = Rights.Substring(2, 1);
                            string rView = Rights.Substring(3, 1);

                            if (rAdd == "1")
                            {
                                rightsAdd = rightsAdd + 1;
                            }
                            else
                            {
                                rightsAdd = rightsAdd + 0;
                            }
                        }
                    }

                    c = 0;
                    if (rightsAdd > 0)
                    {
                        tdAdd.Style.Add("display", "inline");
                    }
                    else
                    {
                        tdAdd.Style.Add("display", "none");
                    }
                    tdModify.Style.Add("display", "none");
                    tdDelete.Style.Add("display", "none");

                    tblContentList = new Table();
                    trContentList = new TableRow();
                    BtnContentPage = new LinkButton[dtRights.Rows.Count];
                    tdContentList = new TableCell[dtRights.Rows.Count];

                    //Foldid = dtRights.Rows[0]["parentid"].ToString();
                    if (dtRights.Rows.Count != 0)
                    {
                        foreach (System.Data.DataRow rowValues in dtRights.Rows)
                        {
                            if (rowValues["Rights"].ToString() == "" || rowValues["Rights"].ToString().Substring(3, 1) == "1")
                            {
                                DTContentPage = objFolder.GetAllcontentbuilder(rowValues["BuilderId"].ToString());
                                // hidRights.Value = rowValues["Rights"].ToString();
                                if (DTContentPage.Rows.Count > 0)
                                {
                                    trContentList = new TableRow();
                                    BtnContentPage[c] = new LinkButton();
                                    tdContentList[c] = new TableCell();

                                    BtnContentPage[c].Text = DTContentPage.Rows[0]["name"].ToString();
                                    BtnContentPage[c].ID = DTContentPage.Rows[0]["dataid"].ToString();
                                    BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                                    BtnContentPage[c].Font.Name = "Tahoma";
                                    BtnContentPage[c].Font.Size = 8;
                                    BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                                    BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                                    BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                                    BtnContentPage[c].CommandArgument = DTContentPage.Rows[0]["dataid"].ToString();
                                    BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                                    tdContentList[c].Controls.Add(BtnContentPage[c]);
                                    trContentList.Cells.Add(tdContentList[c]);
                                    tblContentList.Rows.Add(trContentList);
                                    c++;
                                }
                            }
                        }
                    }
                    ContentPagesListTd.Controls.Add(tblContentList);
                    DataTable dtFold1 = new DataTable();
                    DataTable dtFold = new DataTable();
                    //dtFold = dt.r
                    i = 0;
                    f = 0;
                    k = 0;
                    check = 0;
                    tblMt1 = new Table();

                    if (Dropname != "" && Subname != "")
                    {
                        dt = objFolder.GetLikeSubject(Subname, Dropname);
                    }
                    else
                    {
                        dt = objFolder.GetAllsubject();
                    }

                    //dt = objFolder.GetAllsubject();
                    img = new System.Web.UI.WebControls.Image[dt.Rows.Count];
                    Foldername = new Label[dt.Rows.Count];
                    tblMr1 = new TableRow[dt.Rows.Count];

                    //array values
                    string[] aryParent = new string[dtRights.Rows.Count];
                    string[] aryData = new string[dtRights.Rows.Count];
                    string[] aryDataName = new string[dtRights.Rows.Count];

                    for (int rights = 0; rights <= dtRights.Rows.Count - 1; rights++)
                    {
                        dt1 = objFolder.GetAllConSubject(dtRights.Rows[rights]["parentid"].ToString());

                        for (int j = 0; j <= dt1.Rows.Count - 1; j++)
                        {
                            if (dtRights.Rows[rights]["parentid"].ToString() == dt1.Rows[j]["parentid"].ToString() && dtRights.Rows[rights]["builderid"].ToString() == dt1.Rows[j]["dataid"].ToString())
                            {
                                aryParent[rights] = dt1.Rows[j]["parentid"].ToString();
                                aryData[rights] = dt1.Rows[j]["dataid"].ToString();
                                aryDataName[rights] = dt1.Rows[j]["name"].ToString();
                            }
                        }


                    }

                    //User Rights.... Apply to TreeView
                    string subjectId = "", parentid = "", fname = "";                   
                    for (int cnt = 0; cnt <= dtRights.Rows.Count-1; cnt++)                    
                    {
                        parentid = "";
                        if (dtRights.Rows[cnt]["Rights"].ToString() == "" || dtRights.Rows[cnt]["Rights"].ToString().Substring(3, 1) == "1")
                        {
                          for (i = 0; i <= dt.Rows.Count - 1; i++) //add 27-Sep-06  display the UserRights Flyers only
                          {
                                if (Dropname == "Parent Folder" && Subname != "")
                                {
                                    if (dtRights.Rows[cnt]["parentid"].ToString().StartsWith("CA"))
                                    {
                                        DataTable dtsub = new DataTable();
                                        dtsub = objFolder.GetCategorySubject(dtRights.Rows[cnt]["parentid"].ToString(), Subname);
                                        if (dtsub.Rows.Count > 0)
                                        {
                                            if (dtsub.Rows[0]["Subjectid"].ToString() == dt.Rows[i]["subjectid"].ToString())
                                            {
                                                //parentid = dt.Rows[i]["subjectid"].ToString();
                                                parentid = dtRights.Rows[cnt]["parentid"].ToString();
                                            }
                                        }
                                    }
                                    else
                                    {

                                        if (dtRights.Rows[cnt]["parentid"].ToString() != dt.Rows[i]["subjectid"].ToString())
                                        {
                                            break;
                                        }

                                    }
                                }
                                
                                
                                if (dtRights.Rows[cnt]["parentid"].ToString().StartsWith("CA"))
                                {
                                      
                                        DataTable dtcat = new DataTable();
                                        if (Dropname == "Child Folder" && Subname != "")
                                        {
                                            dtcat = objFolder.GetCategoryNameLike(dtRights.Rows[cnt]["parentid"].ToString(), Subname);
                                            for (int j = 0; j < dtcat.Rows.Count; j++)
                                            {
                                                if (dtRights.Rows[cnt]["parentid"].ToString() != dtcat.Rows[j]["Catid"].ToString())
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    parentid = dtcat.Rows[j]["Catid"].ToString();
                                                    break;
                                                }
                                            }
                                        }
                                        else if (Dropname == "Parent Folder" && Subname != "")
                                        {
                                            DataTable dtsub = new DataTable();
                                            dtsub = objFolder.GetCategorySubject(dtRights.Rows[cnt]["parentid"].ToString(), Subname);
                                            if (dtsub.Rows.Count > 0)
                                            {
                                                if (dtsub.Rows[0]["Subjectid"].ToString() == dt.Rows[i]["subjectid"].ToString())
                                                {
                                                    parentid = dtRights.Rows[cnt]["parentid"].ToString();
                                                }
                                            }

                                        }
                                        else if (Dropname == "Page" && Subname != "")
                                        {
                                            DataTable dtpage = new DataTable();
                                            dtpage = objFolder.GetBuilderNameLike(dtRights.Rows[cnt]["parentid"].ToString(), Subname);
                                            for (int p = 0; p < dtpage.Rows.Count; p++)
                                            {
                                                if (dtRights.Rows[cnt]["builderid"].ToString() != dtpage.Rows[p]["dataid"].ToString())
                                                {
                                                    //break;
                                                    continue;
                                                }
                                                else
                                                {
                                                    dtcat = objFolder.GetCategoryName(dtRights.Rows[cnt]["parentid"].ToString());
                                                    parentid = dtcat.Rows[0]["Catid"].ToString();
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dtcat = objFolder.GetCategoryName(dtRights.Rows[cnt]["parentid"].ToString());
                                            parentid = dtcat.Rows[0]["Catid"].ToString();
                                        }
                                    
                                }
                                else
                                {
                                    if (Dropname == "Parent Folder" && Subname != "")
                                    {
                                        if (dtRights.Rows[cnt]["parentid"].ToString() != dt.Rows[i]["subjectid"].ToString())
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            parentid = dt.Rows[i]["subjectid"].ToString();
                                            fname = dt.Rows[i]["Name"].ToString();
                                        }
                                    }
                                    else if (Dropname == "Page" && Subname != "")
                                    {
                                        DataTable dtpage = new DataTable();
                                        dtpage = objFolder.GetBuilderNameLike(dtRights.Rows[cnt]["parentid"].ToString(), Subname);
                                        for (int p = 0; p < dtpage.Rows.Count; p++)
                                        {
                                            if (dtRights.Rows[cnt]["builderid"].ToString() != dtpage.Rows[p]["dataid"].ToString())
                                            {
                                                //break;
                                                continue;
                                            }
                                            else
                                            {
                                                parentid = dt.Rows[i]["subjectid"].ToString();
                                                fname = dt.Rows[i]["Name"].ToString();
                                            }
                                        }
                                    }
                                    else
                                    {
                                        parentid = dt.Rows[i]["subjectid"].ToString();
                                        fname = dt.Rows[i]["Name"].ToString();
                                    }
                                }

                            if (parentid == dtRights.Rows[cnt]["parentid"].ToString())
                            {
                                
                                if (dtRights.Rows[cnt]["parentid"].ToString().StartsWith("CA"))
                                {
                                    DataTable dtcat = new DataTable();
                                    dtcat = objFolder.GetCategorySubject(dtRights.Rows[cnt]["parentid"].ToString(),"");
                                    subjectId = dtcat.Rows[0]["Subjectid"].ToString();
                                    fname = dtcat.Rows[0]["Name"].ToString();
                                }
                                else
                                {
                                    subjectId = dt.Rows[i]["subjectid"].ToString();
                                    fname = dt.Rows[i]["Name"].ToString();
                                }
                                
                                    tblMr1[i] = new TableRow();
                                    tblMr2 = new TableRow();
                                    tblMc1 = new TableCell();
                                    tblMc2 = new TableCell();
                                    tblMc3 = new TableCell[dt.Rows.Count];
                                    tblMc3[i] = new TableCell();
                                    img[i] = new System.Web.UI.WebControls.Image();
                                    Foldername[i] = new Label();

                                    tblFt = new Table();

                                    img[i].ImageUrl = "../Images/plus.gif";
                                    img[i].ID = "img" + cnt+ i;
                                    //tblMr1[i].ID = dt.Rows[i]["subjectid"].ToString();
                                    tblMr1[i].ID = subjectId; 
                                    tblMc3[i].ID = "fly" + cnt + i;
                                    tblMc3[i].Attributes.Add("runat", "server");
                                    tblMc3[i].Style.Add("display", "none");

                                    //Foldername[i].Text = dt.Rows[i]["name"].ToString();
                                    Foldername[i].Text = fname;
                                    tblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                    tblMc1.Controls.Add(img[i]);
                                    
                                    
                                    tblFr = new TableRow();
                                    tblFc = new TableCell();

                                    //Edit By Murali
                                    if (Subname != "" && (Dropname == "Child Folder" || Dropname == "Page"))
                                    {
                                        dtCategory = objFolder.GetLikeCategory(Subname, Dropname, subjectId);
                                    }
                                    else
                                    {
                                        dtCategory = objFolder.GetAllcategory(subjectId); // Child Folder
                                    }

                                    //dtCategory = objFolder.GetAllcategory(subjectId); // Child Folder
                                    if (dtCategory.Rows.Count > 0)
                                    {

                                        tblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                        tblMc1.Style.Add("FONT-SIZE", "8pt");
                                        tblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                        tblMc1.Controls.Add(Foldername[i]);

                                        tblMr1[i].Cells.Add(tblMc1);

                                        tblFr.Cells.Add(tblFc);
                                        tblFt.Rows.Add(tblFr);
                                        tblMc3[i].ColumnSpan = 2;
                                        tblMc3[i].Controls.Add(tblFt);
                                        tblMr2.Cells.Add(tblMc3[i]);

                                        img[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        img[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        Foldername[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                        Foldername[i].Attributes.Add("onmouseout", "this.style.color='#000000';");
                                        tblMr1[i].Attributes.Add("OnClick", "javascript:if(" + tblMc3[i].ID + ".style.display == 'none'){hide();" + tblMc3[i].ID + ".style.display = 'block';" + img[i].ID + ".src='../Images/minus.gif';Fid.value='" + tblMr1[i].ID + "';}else if(" + tblMc3[i].ID + ".style.display == 'block'){hide();" + tblMc3[i].ID + ".style.display = 'none';" + img[i].ID + ".src='../Images/plus.gif';}");
                                        tblMr1[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        tblMr1[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        tblMt1.Rows.Add(tblMr1[i]);
                                        tblMt1.Rows.Add(tblMr2);

                                        ctblFr = new TableRow();
                                        ctblFc = new TableCell();
                                        ci = 0;
                                        ctblMt1 = new Table();
                                        cimg = new System.Web.UI.WebControls.Image[dtCategory.Rows.Count];
                                        cFoldername = new Label[dtCategory.Rows.Count];
                                        ctblMr1 = new TableRow[dtCategory.Rows.Count];
                                        foreach (System.Data.DataRow crow in dtCategory.Rows)//Child Folders
                                        {
                                            for (int cfcnt = 0; cfcnt <= dtRights.Rows.Count - 1; cfcnt++)
                                            {
                                                if (crow[1].ToString() == dtRights.Rows[cfcnt]["parentid"].ToString() || crow[0].ToString() == dtRights.Rows[cfcnt]["parentid"].ToString())
                                                {

                                                    ctblMr1[ci] = new TableRow();
                                                    ctblMr2 = new TableRow();
                                                    ctblMc1 = new TableCell();
                                                    //ctblMc2 = new TableCell();
                                                    ctblMc3 = new TableCell[dtCategory.Rows.Count];
                                                    ctblMc3[ci] = new TableCell();
                                                    cimg[ci] = new System.Web.UI.WebControls.Image();
                                                    cFoldername[ci] = new Label();
                                                    ctblFt = new Table();

                                                    cimg[ci].ImageUrl = "../Images/plus.gif";
                                                    cimg[ci].ID = "cimg" + cnt + i + ci;

                                                    ctblMr1[ci].ID = crow[1].ToString();
                                                    ctblMc3[ci].ID = "cfly" + cnt + i + ci;
                                                    ctblMc3[ci].Attributes.Add("runat", "server");
                                                    ctblMc3[ci].Style.Add("display", "none");

                                                    cFoldername[ci].Text = crow[2].ToString();
                                                    ctblMc1.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));

                                                    cstr = crow[1].ToString();
                                                    //cdt1 = objFolder.GetAllConSubject(cstr);
                                                    if (Subname != "" && Dropname == "Page")
                                                    {
                                                        cdt1 = objFolder.GetLikeBuilder(Subname, cstr);
                                                    }
                                                    else
                                                    {
                                                        cdt1 = objFolder.GetAllConSubject(cstr);
                                                    }
                                                    ctblMc1.Controls.Add(cimg[ci]);
                                                    if (cdt1.Rows.Count > 0)
                                                    {
                                                        cimg[ci].Attributes.Add("style", "display: inline");
                                                    }
                                                    else
                                                    {
                                                        cimg[ci].Attributes.Add("style", "display: none");
                                                    }
                                                    cf = 0;
                                                    chybu = new LinkButton[cdt1.Rows.Count];
                                                    cimag = new HtmlImage[cdt1.Rows.Count];
                                                    ctblFr = new TableRow();
                                                    ctblFc = new TableCell();
                                                    if (cdt1.Rows.Count > 0)
                                                    {
                                                        foreach (System.Data.DataRow crow1 in cdt1.Rows)//Flyers
                                                        {
                                                            for (int ccnt = 0; ccnt < dtRights.Rows.Count; ccnt++)
                                                            {
                                                                if (crow1[1].ToString() == dtRights.Rows[ccnt]["builderid"].ToString())
                                                                {
                                                                    //if (parentid == dtRights.Rows[ccnt]["parentid"].ToString())//&& r1 <= dtRights.Rows.Count - 1)
                                                                    if(crow[1].ToString() == dtRights.Rows[cfcnt]["parentid"].ToString() || crow[0].ToString() == dtRights.Rows[cfcnt]["parentid"].ToString())

                                                                    {
                                                                        if (dtRights.Rows[ccnt]["Rights"].ToString() == "" || dtRights.Rows[ccnt]["Rights"].ToString().Substring(3, 1) == "1")
                                                                        {
                                                                            chybu[cf] = new LinkButton();
                                                                            cimag[cf] = new HtmlImage();

                                                                            cimag[cf].Src = "../Images/Black_Leaf.jpg";
                                                                            cimag[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                                                            cimag[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                                            chybu[cf].ID = "ChildFolder" + k++;
                                                                            chybu[cf].Font.Size = 8;
                                                                            chybu[cf].Font.Name = "Verdana";
                                                                            chybu[cf].ForeColor = System.Drawing.Color.Black;
                                                                            chybu[cf].Text = crow1[0].ToString();
                                                                            chybu[cf].Attributes.Add("style", "text-decoration: none");
                                                                            chybu[cf].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                                                            chybu[cf].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                                            ctblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                                                            ctblFc.Controls.Add(cimag[cf]);
                                                                            ctblFc.Controls.Add(chybu[cf]);
                                                                            ctblFc.Controls.Add(new LiteralControl("<br>"));

                                                                            cstr1 = chybu[cf].Text;
                                                                            cstr2 = crow1[1].ToString();
                                                                            cstr3 = crow1[2].ToString();
                                                                            cid = crow1[3].ToString();
                                                                            chybu[cf].CommandArgument = crow1[1].ToString();
                                                                            chybu[cf].Click += new EventHandler(Select_Click);
                                                                            cf++;
                                                                            if (ccnt > 0) cnt++;
                                                                        }
                                                                        else if (dtRights.Rows[ccnt]["Rights"].ToString().Substring(0, 1) == "1" || dtRights.Rows[ccnt]["Rights"].ToString().Substring(1, 1) == "1" || dtRights.Rows[ccnt]["Rights"].ToString().Substring(2, 1) == "1")
                                                                        {
                                                                            if (ccnt > 0) cnt++;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        cf++;
                                                                    }
                                                                }

                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        leafimage = new HtmlImage();
                                                        leafimage.Src = "../Images/Black_Leaf.jpg";
                                                        ctblMc1.Controls.Add(leafimage);                                                        
                                                    }
                                                    cdt1.Clear();
                                                    ctblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                                    ctblMc1.Style.Add("FONT-SIZE", "8pt");
                                                    ctblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                                    ctblMc1.Controls.Add(cFoldername[ci]);


                                                    ctblMr1[ci].Cells.Add(ctblMc1);
                                                    ctblFr.Cells.Add(ctblFc);
                                                    ctblFt.Rows.Add(ctblFr);

                                                    ctblMc3[ci].ColumnSpan = 2;
                                                    ctblMc3[ci].Controls.Add(ctblFt);
                                                    ctblMr2.Cells.Add(ctblMc3[ci]);

                                                    cimg[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                                    cimg[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                    cFoldername[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                                    cFoldername[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                                    //ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){hide();" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){hide();" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                                    ctblMr1[ci].Attributes.Add("OnClick", "javascript:if(" + ctblMc3[ci].ID + ".style.display == 'none'){" + ctblMc3[ci].ID + ".style.display = 'block';" + cimg[ci].ID + ".src='../Images/minus.gif';Fid.value='" + ctblMr1[ci].ID + "';}else if(" + ctblMc3[ci].ID + ".style.display == 'block'){" + ctblMc3[ci].ID + ".style.display = 'none';" + cimg[ci].ID + ".src='../Images/plus.gif';}");
                                                    ctblMr1[ci].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                                    ctblMr1[ci].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                    ctblMt1.Rows.Add(ctblMr1[ci]);
                                                    ctblMt1.Rows.Add(ctblMr2);

                                                    tblFc.Controls.Add(ctblMt1);
                                                    tblFr.Cells.Add(tblFc);
                                                    tblFt.Rows.Add(tblFr);
                                                    ci++;
                                                    break;
                                                    //if (cfcnt > 0) cnt++;
                                                }
                                            }

                                        }
                                    }
                                    //End
                                    else
                                    {
                                        if (Dropname == "Page" && Subname != "")
                                        {
                                            dt1 = cdt1 = objFolder.GetLikeBuilder(Subname, subjectId);
                                        }
                                        else
                                        {
                                            dt1 = objFolder.GetAllConSubject(subjectId);
                                        }

                                        f = 0;
                                        hybu = new LinkButton[dt1.Rows.Count];
                                        imag = new HtmlImage[dt1.Rows.Count];
                                        tblFr = new TableRow();
                                        tblFc = new TableCell();
                                        if (dt1.Rows.Count > 0)
                                        {
                                            foreach (System.Data.DataRow row1 in dt1.Rows)//Flyers
                                            {
                                                if (r1 <= dtRights.Rows.Count - 1)
                                                {
                                                    for (int fcnt = 0; fcnt < dtRights.Rows.Count; fcnt++)
                                                    {
                                                        if (row1[1].ToString() == dtRights.Rows[fcnt]["builderid"].ToString())
                                                        {
                                                            if (dt.Rows[i]["subjectid"].ToString() == dtRights.Rows[fcnt]["parentid"].ToString())//&& r1 <= dtRights.Rows.Count - 1)
                                                            {
                                                                if (dtRights.Rows[fcnt]["Rights"].ToString() == "" || dtRights.Rows[fcnt]["Rights"].ToString().Substring(3, 1) == "1")
                                                                {
                                                                    hybu[f] = new LinkButton();
                                                                    imag[f] = new HtmlImage();

                                                                    imag[f].Src = "../Images/Black_Leaf.jpg";
                                                                    imag[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                                                    imag[f].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                                    hybu[f].ID = "Folder" + k++;
                                                                    hybu[f].Font.Size = 8;
                                                                    hybu[f].Font.Name = "Verdana";
                                                                    hybu[f].ForeColor = System.Drawing.Color.Black;
                                                                    hybu[f].Text = row1[0].ToString();
                                                                    hybu[f].Attributes.Add("style", "text-decoration: none");
                                                                    hybu[f].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9F2409'");
                                                                    hybu[f].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                                                    tblFc.Controls.Add(new LiteralControl("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"));
                                                                    tblFc.Controls.Add(imag[f]);
                                                                    tblFc.Controls.Add(hybu[f]);
                                                                    tblFc.Controls.Add(new LiteralControl("<br>"));

                                                                    str1 = hybu[f].Text;
                                                                    str2 = row1[1].ToString();
                                                                    str3 = row1[2].ToString();
                                                                    id = row1[3].ToString();
                                                                    hybu[f].CommandArgument = row1[1].ToString();
                                                                    hybu[f].Click += new EventHandler(Select_Click);
                                                                    if (f >0) cnt++;
                                                                    f++;
                                                                    if (r1 != dtRights.Rows.Count - 1)
                                                                        r1++;
                                                                    // r1 = (r1 == dtRights.Rows.Count - 1) ? 0 : r1++;
                                                                }
                                                                else if (dtRights.Rows[fcnt]["Rights"].ToString().Substring(0, 1) == "1" || dtRights.Rows[fcnt]["Rights"].ToString().Substring(1, 1) == "1" || dtRights.Rows[fcnt]["Rights"].ToString().Substring(2, 1) == "1")
                                                                {
                                                                    if (f > 0) cnt++;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                f++;

                                                            }
                                                        }

                                                    }
                                                }
                                            }
                                            dt1.Clear();
                                        }
                                        else
                                        {
                                            leafimage = new HtmlImage();
                                            leafimage.Src = "../Images/Black_Leaf.jpg";
                                            tblMc1.Controls.Add(leafimage);
                                            img[i].ImageUrl = "../Images/Black_Leaf.jpg";
                                            img[i].Attributes.Add("style", "display: none");
                                        }

                                        tblMc1.Style.Add("FONT-FAMILY", "Verdana");
                                        tblMc1.Style.Add("FONT-SIZE", "8pt");
                                        tblMc1.Controls.Add(new LiteralControl("&nbsp"));
                                        tblMc1.Controls.Add(Foldername[i]);

                                        tblMr1[i].Cells.Add(tblMc1);

                                        tblFr.Cells.Add(tblFc);
                                        tblFt.Rows.Add(tblFr);
                                        tblMc3[i].ColumnSpan = 2;
                                        tblMc3[i].Controls.Add(tblFt);
                                        tblMr2.Cells.Add(tblMc3[i]);

                                        img[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        img[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        Foldername[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#9f2409'");
                                        Foldername[i].Attributes.Add("onmouseout", "this.style.color='#000000';");


                                        tblMr1[i].Attributes.Add("OnClick", "javascript:if(" + tblMc3[i].ID + ".style.display == 'none'){hide();" + tblMc3[i].ID + ".style.display = 'block';" + img[i].ID + ".src='../Images/minus.gif';Fid.value='" + tblMr1[i].ID + "';}else if(" + tblMc3[i].ID + ".style.display == 'block'){hide();" + tblMc3[i].ID + ".style.display = 'none';" + img[i].ID + ".src='../Images/plus.gif';}");
                                        tblMr1[i].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                        tblMr1[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                        tblMt1.Rows.Add(tblMr1[i]);
                                        tblMt1.Rows.Add(tblMr2);

                                    }                                    
                                    tblMain.Controls.Add(tblMt1);
                                    dtCategory.Clear();
                                    break;
                                    //End
                                }
                            }
                    }
                        }
                    }
                }
         }
        catch (System.Exception ex)
        {
            Response.Write("<script language='javascript'>alert('" + ex.Message + "');</script>");
        }
        //}  
        //if (dt.Rows.Count == 0)
        //    BtnConModify.Visible = false;
        //else
        //    BtnConModify.Visible = true;
        //BtnConDelete.Attributes.Add("onclick", "javascript:if(document.getElementById('Fid').value=='') {alert('Select the Folder to delete'); return false;}");
        BtnConDelete.Attributes.Add("Onclick", "javascript:return confirmDelete();");
        BtnConModify.Attributes.Add("onclick", "javascript:if(document.getElementById('Fid').value=='') {alert('Select the Folder to modify'); return false;}");
        if (!(Session["UserType"].ToString().ToLower().Equals("admin")))
        {
            //CheckRights();

            //if (add)
            //{
            //    tdAdd.Style.Add("display", "inline");
            //}
            //else
            //{
                tdAdd.Style.Add("display", "none");
            //}

            //if (mod)
            //{

            //    tdModify.Style.Add("display", "inline");
            //}
            //else
            //{
                tdModify.Style.Add("display", "none");
            //}
            //if (del)
            //{
            //    tdDelete.Style.Add("display", "inline");
            //}
            //else
            //{
                tdDelete.Style.Add("display", "none");
            //}

        }
    }


    protected void ContentPage_Click(object sender, EventArgs e)
    {
        str2 = (((LinkButton)(sender)).CommandArgument).ToString();
        // Response.Redirect("DisplayPage.aspx?DataId=" + str2);


        for (int i = 0; i < dtRights.Rows.Count; i++)
        {
            if (dtRights.Rows[i]["BuilderId"].ToString() == str2)
            {
                BtnRights = dtRights.Rows[i]["Rights"].ToString();
            }

            if (dtRights.Rows[i]["Rights"].ToString() == "" && dtRights.Rows[i]["BuilderId"].ToString() == str2) //21-09-06
            {
                BtnRights = "1111";
            }
        }
        Response.Redirect("DisplayPage.aspx?DataId=" + str2 + "&BtnRights=" + BtnRights);
    }
    protected void Select_Click(object sender, EventArgs e)
    {
        str2 = (((LinkButton)(sender)).CommandArgument).ToString();
        dt3 = objFolder.GetAllcontentbuilder(str2);

        for (int i = 0; i < dtRights.Rows.Count; i++)
        {
            if (dtRights.Rows[i]["BuilderId"].ToString() == str2)
            {
                BtnRights = dtRights.Rows[i]["Rights"].ToString();
            }
            if (dtRights.Rows[i]["Rights"].ToString() == "") //21-09-06
            {
                BtnRights = "1111";
            }
        }
        Response.Redirect("DisplayPage.aspx?DataId=" + str2 + "&BtnRights=" + BtnRights);
    }

    protected void BtnConAdd_Click(object sender, EventArgs e)
    {
        Foldid = Fid.Value;
        Mode = "Add";
        Response.Redirect("AddContent.aspx?Foldid=" + Foldid + "&Mode=" + Mode);
    }
    protected void BtnConModify_Click(object sender, EventArgs e)
    {
        Foldid = Fid.Value;
        Mode = "modify";
        Response.Redirect("ModifyName.aspx?Foldid=" + Foldid + "&Mode=" + Mode);
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {

        Response.Redirect("ContentBuilderPage.aspx?Subname=" + txtContentSearch.Text + "&Dropname=" + ContentDrop.SelectedItem.Text);

    }
    protected void BtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }
    protected void BtnConDelete_Click(object sender, EventArgs e)
    {
        SubId = Fid.Value;
        objFolder.ConParentID = SubId;
        int count = objFolder.CountSubjectIds();
        int catcount = objFolder.CountCategoryIds(); 
        if (count == 0 && catcount == 0)
        {
            //Response.Write("<script language=javascript> alert('This Folder cannot be deleted '); </script>");
            objFolder.ConParentID = SubId;
            objFolder.DeleteSubject();
            Response.Redirect("ContentBuilderPage.aspx");
        }
        else 
        {
            Response.Write("<script language='javascript'>");
            if (count > 0)
                Response.Write("alert('This Folder cannot be deleted since it has Page(s)');");
            else if (catcount > 0)
                Response.Write("alert('This Folder cannot be deleted since it has ChildFolder(s)');");
            Response.Write("</script>");        
        }

    }

    //userValidation
    protected HtmlTable userValidation()
    {
        //  objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = objFolder.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objFolder.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub'); ");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = objFolder.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        // if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = objFolder.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;
    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //tdLeftPanel.Style.Add("display", value);
        leftPanel.Style.Add("display", value);        
        //trLeft1.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
    }
    protected void CheckRights()
    {

        UserManager objUser = new UserManager();
        objUser.Userid = int.Parse(Session["UserId"].ToString());
        DataTable dtToolbars = new DataTable();
        dtToolbars = objUser.BuilderRights("", "");
        foreach (DataRow row in dtToolbars.Rows)
        {
            //string strRights = objUser.MultipleRights(row[0].ToString(), "All");
            string strRights = row[2].ToString();
            if (strRights.Length > 0)
            {
                if (strRights.Substring(0, 1).Equals("1"))
                {
                    add = true;
                }
                if (strRights.Substring(1, 1).Equals("1"))
                {
                    mod = true;
                }
                if (strRights.Substring(2, 1).Equals("1"))
                {
                    mod = true;
                }
            }
            else
            {
                add = true;
                mod = true;
                mod = true;
            }

        }
    }   

    
}

