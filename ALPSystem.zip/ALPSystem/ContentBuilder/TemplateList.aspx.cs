using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ContentBuilder_TemplateList : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    System.Web.UI.WebControls.Image[] timg;
    public string svlFileName, svlFileLocation, svlVirtualPath, str;
    public int i, x, y, z, j, ivlCount, k, page, n;
    public string TempId, SubjectId, DataId, Ar, Mode;
    Label lb;
    string[] temp;
    public Boolean flag;
    ContentReader Obj = new ContentReader();
    protected void Page_Load(object sender, EventArgs e)
    {
        //[name],templateid,sourceid,BulletImageLocation
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        dt = Obj.GetTemplatesImage();
        Mode = Request.QueryString["Mode"].ToString();
        temp = new string[dt.Rows.Count];
        if (IsPostBack == false)
        {
            BtnTempPrevious.Visible = false;
            page = 1;
            //	Response.Write(page);
            if (dt.Rows.Count > 0)
            {
                if (page == 1)
                {
                    k = 0;
                    timg = new System.Web.UI.WebControls.Image[dt.Rows.Count];
                    Table tb = new Table();
                    //tb.BackColor=System.Drawing.Color.White;
                    tb.Width = 100;
                    tb.Height = 150;
                    if (Mode == "New")
                        Mode = "New";
                    else
                        Mode = "ModT";
                    //Response.Write(Mode);
                    for (int i = 0; i < 2; i++)
                    {
                        
                        TableRow tr = new TableRow();
                        tr.BackColor = System.Drawing.Color.White;
                        tr.BorderColor = System.Drawing.Color.Violet;
                        for (int j = 0; j < 5; j++)
                        {
                            if (k < dt.Rows.Count)
                            {
                                TableCell tc = new TableCell();
                                TableCell tc1 = new TableCell();
                                tc.Attributes.Add("runat", "server");
                                svlFileName = dt.Rows[k]["BulletImageLocation"].ToString();
                                //svlFileName = temp[k];
                                svlVirtualPath = Server.MapPath("..");
                                svlFileLocation = @"\Images\TemplateManager\" + svlFileName;
                                svlFileLocation = svlVirtualPath + svlFileLocation;
                                str = dt.Rows[k]["BulletImageLocation"].ToString();
                                x = str.IndexOf(".", x);
                                str = str.Substring(x + 1, 3);
                                //if (str == "htm")
                                // {
                                if ((System.IO.File.Exists(svlFileLocation)))
                                {
                                    timg[k] = new System.Web.UI.WebControls.Image();
                                  //  timg[k].ImageUrl = svlFileLocation;
                                    timg[k].ImageUrl = "../Images/TemplateManager/" + svlFileName;
                                    timg[k].ID = dt.Rows[k]["templateid"].ToString();
                                    lb = new Label();
                                    timg[k].Height = 100;
                                    timg[k].Width = 100;
                                    tc.Width = 100;
                                    tc.Height = 150;
                                    tc.BackColor = System.Drawing.Color.White;
                                    //	Mode="ModT";
                                    timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                                    timg[k].Attributes.Add("onmouseout", "this.style.color='#000000';");
                                    timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';if (window.opener.document.getElementById('hdnTemplatechange')){window.opener.document.getElementById('hdnTemplatechange').value ='yes'};window.opener.document.forms(0).submit();self.close();");
                                    lb.Font.Size = 8;
                                    lb.Font.Name = "verdana";
                                    lb.Text = dt.Rows[k]["name"].ToString();
                                    lb.Attributes.Add("VerticalAlign", "Center");
                                    tc.HorizontalAlign = HorizontalAlign.Center;
                                    tc.Controls.Add(timg[k]);
                                    tc.Controls.Add(new LiteralControl("<br>"));
                                    tc.Controls.Add(lb);
                                    tr.Cells.Add(tc);
                                }
                                else
                                {
                                    lb = new Label();

                                    timg[k] = new System.Web.UI.WebControls.Image();
                                    timg[k].ID = dt.Rows[k]["templateid"].ToString();
                                    timg[k].AlternateText = dt.Rows[k]["name"].ToString();
                                    timg[k].Style.Add("COLOR", "#0000CD");
                                    timg[k].Style.Add("Font-Weight", "8pt");
                                    timg[k].Height = 100;
                                    timg[k].Width = 100;
                                    tc.Width = 100;
                                    tc.Height = 150;
                                    tc.BackColor = System.Drawing.Color.White;
                                    lb.Font.Size = 8;
                                    lb.Font.Name = "verdana";
                                    //	Mode="ModT";
                                    lb.Text = dt.Rows[k]["name"].ToString();
                                    lb.Attributes.Add("VerticalAlign", "Center");
                                    timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#0000CD'");
                                    timg[k].Attributes.Add("onmouseout", "this.style.color='#0000CD';");
                                    timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';if (window.opener.document.getElementById('hdnTemplatechange')){window.opener.document.getElementById('hdnTemplatechange').value ='yes'};window.opener.document.forms(0).submit();self.close();");
                                    tc.HorizontalAlign = HorizontalAlign.Center;
                                    tc.Controls.Add(timg[k]);
                                    tc.Controls.Add(new LiteralControl("<br>"));
                                    tc.Controls.Add(lb);
                                    tr.Cells.Add(tc);
                                }
                            }
                            

                            //timg[k].Attributes.Add("onclick","javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';window.opener.document.forms(0).submit();self.close();");
                            //  }
                            k = k + 1;
                            x = 0;
                        }
                        tb.Controls.Add(tr);
                        Dispalyimage.Controls.Add(tb);
                        hidk.Value = k.ToString();
                        hidn.Value = k.ToString();
                        hidpage.Value = page.ToString();
                    }
                }
            }
        }
       //BtnTempPrevious.Visible = false;
        //if (hidpage.Value == "1")
        if(dt.Rows.Count<=10)
        {
            BtnTempNext.Visible = false;
            BtnTempPrevious.Visible = false;
        }
        //BtnTempNext.Attributes.Add("onclick", "javascript:if ( parseInt(document.getElementById('hidk').value)< 10) alert('No more Templates');");
    }
    protected void BtnTempNext_Click(object sender, EventArgs e)
    {
        BtnTempPrevious.Visible = true;
        k = Convert.ToInt16(hidk.Value);        
        BtnTempPrevious.Attributes.Add("style", "display: block");
        BtnTempPrevious.Attributes.Add("style", "text-decoration: none");
        z = dt.Rows.Count;
        //	Response.Write(page);
        page = Convert.ToInt16(hidpage.Value);
        page = page + 1;
        //Response.Write(page);
        if (Mode == "New")
            Mode = "New";
        else
            Mode = "ModT";
        //	Response.Write(Mode);
        if (page > 1)
        {
            timg = new System.Web.UI.WebControls.Image[dt.Rows.Count];
            Table tb = new Table();
            for (int i = 0; i < 2; i++)
            {
                TableRow tr = new TableRow();
                tr.BorderColor = System.Drawing.Color.Violet;
                for (int j = 0; j < 5; j++)
                {
                    TableCell tc = new TableCell();
                    tc.Attributes.Add("runat", "server");

                    if (z == k)
                    {
                        BtnTempNext.Attributes.Add("style", "display: none");
                        break;
                    }
                    if ((k == 0))
                    {
                        k += 10;
                    }
                    svlFileName = dt.Rows[k]["BulletImageLocation"].ToString();
                    svlVirtualPath = Server.MapPath("..");
                    svlFileLocation = @"\Images\TemplateManager\" + svlFileName;
                    svlFileLocation = svlVirtualPath + svlFileLocation;
                    //str = dt.Rows[k][1].ToString();
                    //x = str.IndexOf(".", x);
                    //str = str.Substring(x + 1, 3);
                   //if (str == "htm")
                    //{
                        if ((System.IO.File.Exists(svlFileLocation)))
                        {
                            timg[k] = new System.Web.UI.WebControls.Image();
                         //   timg[k].ImageUrl = svlFileLocation;
                            timg[k].ImageUrl = "../Images/TemplateManager/" + svlFileName;
                            timg[k].ID = dt.Rows[k]["templateid"].ToString();
                            lb = new Label();
                            timg[k].Height = 100;
                            timg[k].Width = 100;
                            tc.Width = 100;
                            tc.Height = 150;
                            tc.BackColor = System.Drawing.Color.White;
                            //	Mode="ModT";
                            timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                            timg[k].Attributes.Add("onmouseout", "this.style.color='#000000';");
                            timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';if (window.opener.document.getElementById('hdnTemplatechange')){window.opener.document.getElementById('hdnTemplatechange').value ='yes'};window.opener.document.forms(0).submit();self.close();");
                            lb.Font.Size = 8;
                            lb.Font.Name = "verdana";
                            lb.Text = dt.Rows[k]["name"].ToString();
                            lb.Attributes.Add("VerticalAlign", "Center");
                            tc.HorizontalAlign = HorizontalAlign.Center;
                            tc.Controls.Add(timg[k]);
                            tc.Controls.Add(new LiteralControl("<br>"));
                            tc.Controls.Add(lb);

                            tr.Cells.Add(tc);
                        }
                        else
                        {
                            lb = new Label();
                            timg[k] = new System.Web.UI.WebControls.Image();
                            timg[k].ID = dt.Rows[k]["templateid"].ToString();
                            timg[k].AlternateText = dt.Rows[k][3].ToString();
                            timg[k].Style.Add("COLOR", "#0000CD");
                            timg[k].Style.Add("Font-Weight", "8pt");
                            timg[k].Height = 100;
                            timg[k].Width = 100;
                            tc.Width = 100;
                            tc.Height = 150;
                            lb.Font.Size = 8;
                            lb.Font.Name = "verdana";
                            lb.Text = dt.Rows[k]["name"].ToString();
                            lb.Attributes.Add("VerticalAlign", "Center");
                            tc.BackColor = System.Drawing.Color.White;
                            //Mode="ModT";
                            timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#0000CD'");
                            timg[k].Attributes.Add("onmouseout", "this.style.color='#0000CD';");
                            timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';if (window.opener.document.getElementById('hdnTemplatechange')){window.opener.document.getElementById('hdnTemplatechange').value ='yes'};window.opener.document.forms(0).submit();self.close();");
                            tc.HorizontalAlign = HorizontalAlign.Center;
                            tc.Controls.Add(timg[k]);
                            tc.Controls.Add(new LiteralControl("<br>"));
                            tc.Controls.Add(lb);
                            tr.Cells.Add(tc);
                        }
                        k = k + 1;
                        hidk.Value = k.ToString();
                        tb.Controls.Add(tr);
                        
                        x = 0;
                    }
               //     k = k + 1;
               //     x = 0;
               //// }
                    Dispalyimage.Controls.Add(tb);
                
                hidpage.Value = page.ToString();
            }
        }
    }
    protected void BtnTempPrevious_Click(object sender, EventArgs e)
    {
        k = Convert.ToInt16(hidk.Value);
        page = Convert.ToInt16(hidpage.Value);
        BtnTempNext.Attributes.Add("style", "display: block");
        BtnTempNext.Attributes.Add("style", "text-decoration: none");
        n = (k % 10);
        if (k % 10 != 0)
        {
            k = k - n;

        }

        k = k - 10;
        hidk.Value = k.ToString();
        BtnTempPrevious.Attributes.Add("style", "display: block");
        BtnTempPrevious.Attributes.Add("style", "text-decoration: none");
        page = page - 1;
        //Response.Write(page);
        if (Mode == "New")
            Mode = "New";
        else
            Mode = "ModT";
        //	Response.Write(Mode);
        if (page == 1)
        {
            BtnTempPrevious.Attributes.Add("style", "display: none");
            k = 0;
            hidk.Value = k.ToString();

        }
        timg = new System.Web.UI.WebControls.Image[dt.Rows.Count];
        Table tb = new Table();

        for (int i = 0; i < 2; i++)
        {
            TableRow tr = new TableRow();
            tr.BorderColor = System.Drawing.Color.Violet;
            for (int j = 0; j < 5; j++)
            {
                TableCell tc = new TableCell();
                tc.Attributes.Add("runat", "server");

                svlFileName = dt.Rows[k]["BulletImageLocation"].ToString();
                svlVirtualPath = Server.MapPath("..");
                svlFileLocation = @"\Images\TemplateManager\" + svlFileName;
                svlFileLocation = svlVirtualPath + svlFileLocation;
                //str = dt.Rows[k][1].ToString();
                //x = str.IndexOf(".", x);
                //str = str.Substring(x + 1, 3);
                //if (str == "htm")
                //{
                    if ((System.IO.File.Exists(svlFileLocation)))
                    {
                        timg[k] = new System.Web.UI.WebControls.Image();
                     //   timg[k].ImageUrl = svlFileLocation;
                        timg[k].ImageUrl = "../Images/TemplateManager/" + svlFileName;
                        timg[k].ID = dt.Rows[k]["templateid"].ToString();
                        lb = new Label();
                        timg[k].Height = 100;
                        timg[k].Width = 100;
                        tc.Width = 100;
                        tc.Height = 150;
                        tc.BackColor = System.Drawing.Color.White;
                        //	Mode="ModT";
                        timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#000000'");
                        timg[k].Attributes.Add("onmouseout", "this.style.color='#000000';");
                        timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';window.opener.document.forms(0).submit();self.close();");
                        lb.Font.Size = 8;
                        lb.Font.Name = "verdana";
                        lb.Text = dt.Rows[k]["name"].ToString();
                        lb.Attributes.Add("VerticalAlign", "Center");
                        tc.HorizontalAlign = HorizontalAlign.Center;
                        tc.Controls.Add(timg[k]);
                        tc.Controls.Add(new LiteralControl("<br>"));
                        tc.Controls.Add(lb);

                        tr.Cells.Add(tc);
                    }
                    else
                    {
                        lb = new Label();
                        timg[k] = new System.Web.UI.WebControls.Image();
                        timg[k].ID = dt.Rows[k]["templateid"].ToString();
                        timg[k].AlternateText = dt.Rows[k]["name"].ToString();
                        timg[k].Style.Add("COLOR", "#0000CD");
                        timg[k].Style.Add("Font-Weight", "8pt");
                        timg[k].Height = 100;
                        timg[k].Width = 100;
                        tc.Width = 100;
                        tc.Height = 150;
                        lb.Font.Size = 8;
                        lb.Font.Name = "verdana";
                        lb.Text = dt.Rows[k]["name"].ToString();
                        lb.Attributes.Add("VerticalAlign", "Center");
                        //Mode="ModT";
                        tc.BackColor = System.Drawing.Color.White;
                        timg[k].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#0000CD'");
                        timg[k].Attributes.Add("onmouseout", "this.style.color='#0000CD';");
                        timg[k].Attributes.Add("onclick", "javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';window.opener.document.forms(0).submit();self.close();");
                        tc.HorizontalAlign = HorizontalAlign.Center;
                        tc.Controls.Add(timg[k]);
                        tc.Controls.Add(new LiteralControl("<br>"));
                        tc.Controls.Add(lb);
                        tr.Cells.Add(tc);
                    }
                    tb.Controls.Add(tr);
               // }
                k = k + 1;

                x = 0;
            }
            Dispalyimage.Controls.Add(tb);
            hidpage.Value = page.ToString();
            //hidn.Value=k.ToString();

        }
    }
    public void prevalue(int h)
         {
	        Table tb=new Table();
			for(int i=0;i<2;i++)
			{
				TableRow tr = new TableRow();
				tr.BorderColor=System.Drawing.Color.Violet;
				for(int j=0;j<5;j++)
				{
					TableCell tc = new TableCell();
					tc.Attributes.Add("runat","server");
							
//					if (k==0)
//					{
//						break;
//					}
					svlFileName=dt.Rows[k]["BulletImageLocation"].ToString();
					svlVirtualPath = Server.MapPath("..");
					svlFileLocation = @"\Images\TemplateManager\"+svlFileName;
					svlFileLocation = svlVirtualPath + svlFileLocation;
                    //str = dt.Rows[k][1].ToString();
                    //x=str.IndexOf(".",x);
                    //str=str.Substring(x+1,3);
					//if(str == "htm")
					//{
						if((System.IO.File.Exists(svlFileLocation)))
						{
							timg[k]=new System.Web.UI.WebControls.Image();
							//timg[k].ImageUrl= svlFileLocation;
                            timg[k].ImageUrl = "../Images/TemplateManager/" + svlFileName;
							timg[k].ID=dt.Rows[k]["templateid"].ToString();
							lb=new Label();
							timg[k].Height=100;
							timg[k].Width=100;
							tc.Width=100;
							tc.Height=150;
							tc.BackColor=System.Drawing.Color.White;
							//Mode="ModT";
							timg[k].Attributes.Add("onmouseover","this.style.cursor='pointer'; this.style.color='#000000'");
							timg[k].Attributes.Add("onmouseout","this.style.color='#000000';");
							timg[k].Attributes.Add("onclick","javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';window.opener.document.forms(0).submit();self.close();");
							lb.Font.Size=8;
							lb.Font.Name="verdana";
							lb.Text=dt.Rows[k]["name"].ToString();
							lb.Attributes.Add("VerticalAlign","Center");
							tc.HorizontalAlign=HorizontalAlign.Center;
							tc.Controls.Add(timg[k]);
							tc.Controls.Add(new LiteralControl("<br>"));
							tc.Controls.Add(lb);
								
							tr.Cells.Add(tc);
						}
						else
						{
							lb=new Label();
							timg[k]=new System.Web.UI.WebControls.Image();
							timg[k].ID=dt.Rows[k]["templateid"].ToString();
							timg[k].AlternateText=dt.Rows[k]["name"].ToString();
							timg[k].Style.Add("COLOR","#0000CD");
							timg[k].Style.Add("Font-Weight","8pt");
							timg[k].Height=100;
							timg[k].Width=100;
							tc.Width=100;
							tc.Height=150;
							lb.Font.Size=8;
							lb.Font.Name="verdana";
							lb.Text=dt.Rows[k]["name"].ToString();
							lb.Attributes.Add("VerticalAlign","Center");
							//Mode="ModT";
							tc.BackColor=System.Drawing.Color.White;
							timg[k].Attributes.Add("onmouseover","this.style.cursor='pointer'; this.style.color='#0000CD'");
							timg[k].Attributes.Add("onmouseout","this.style.color='#0000CD';");
							timg[k].Attributes.Add("onclick","javascript:window.opener.document.getElementById('hidtemp').value='" + timg[k].ID + "';window.opener.document.getElementById('Mod').value='" + Mode + "';window.opener.document.forms(0).submit();self.close();");
							tc.HorizontalAlign=HorizontalAlign.Center;
							tc.Controls.Add(timg[k]);
							tc.Controls.Add(new LiteralControl("<br>"));
							tc.Controls.Add(lb);
							tr.Cells.Add(tc);
						}	
						tb.Controls.Add(tr);	
				//	}
					k=k+1;
							
					x=0;
				}
				Dispalyimage.Controls.Add(tb);
				hidpage.Value =page.ToString ();
				hidn.Value=k.ToString();
				
			}

	     }
	}


