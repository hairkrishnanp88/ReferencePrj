using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;
using System.Text;
using System.Text.RegularExpressions;

public partial class ContentBuilder_PreviewPage : System.Web.UI.Page
{
    ContentReader obj = new ContentReader();
    Templates objTemp = new Templates();
    Lists objList = new Lists();
    //public string[] ListArr = new string[12];
    public string[] ListArr1 = new string[12];
    string dataid, Tempid, Mode, Mod1, ContentValue, ContentValue1, ListContent,ToolBar1, ToolBar2, ToolBar3, ToolBar4;
 // string Content1, Content2, Content3, Content4, Content5, Content6, Content7, Content8, Content9, Content10, Content11, Content12;
    DataTable ConDTable = new DataTable();
    public int k, count,stPos, edPos,l;
    bool delFlag;
    string toolid, svlFriend = "";
    string[] Content;
    string Lists;
    string logLabel, passLabel, logTxt, passTxt, logBtn, regBtn;

    //17 July 2007
    #region ProductsModule

    string products, productId, excludecategory, detailview, uniqueId, qty, prodcategoryId, curpage, start;
    public string Products
    {
        get { return products; }
        set { products = value; }
    }
    public string ProductId
    {
        get { return productId; }
        set { productId = value; }
    }
    public string ExcludeCategory
    {
        get { return excludecategory; }
        set { excludecategory = value; }
    }

    public string Detailview
    {
        get { return detailview; }
        set { detailview = value; }
    }
    public string UniqueId
    {
        get { return uniqueId; }
        set { uniqueId = value; }
    }

    public string Qty
    {
        get { return qty; }
        set { qty = value; }
    }
    public string ProdcategoryId
    {
        get { return prodcategoryId; }
        set { prodcategoryId = value; }
    }
    public string Curpage
    {
        get { return curpage; }
        set { curpage = value; }
    }
    public string Start
    {
        get { return start; }
        set { start = value; }
    }

    public DataTable GetPublishProducts()
    {
        SqlCommand cmdPub = new SqlCommand("sp_GetAllPublishNames");
        cmdPub.CommandType = CommandType.StoredProcedure;
        return (obj.ExecuteDTQuery(cmdPub));
    }

    public DataTable GetPublishCategory()
    {
        SqlCommand cmdPub = new SqlCommand("sp_GetAllCategoryNames");
        cmdPub.CommandType = CommandType.StoredProcedure;
        return (obj.ExecuteDTQuery(cmdPub));
    }
    public DataTable GetProductCategory()
    {
        SqlCommand cmdPub = new SqlCommand("sp_GetProductCategory");
        cmdPub.Parameters.AddWithValue("@ProductId", ProductId);
        cmdPub.Parameters.AddWithValue("@ExcludeCategory", ExcludeCategory);
        cmdPub.CommandType = CommandType.StoredProcedure;
        return (obj.ExecuteDTQuery(cmdPub));
    }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        dataid = Request.QueryString["DataId"];
        Mode = Request.QueryString["Mode"];
        Tempid = Request.QueryString["Tempid"];
        Mod1 = Request.QueryString["Mod1"];        
        txtFullName.Value = Session["FullName"].ToString();

       
        
        if (Session["ToolBar1"] == null) Session["ToolBar1"] = "";
        if (Session["ToolBar2"] == null) Session["ToolBar2"] = "";
        if (Session["ToolBar3"] == null) Session["ToolBar3"] = "";
        if (Session["ToolBar4"] == null) Session["ToolBar4"] = "";

        Content = new string[13];
         
         //26Mar07
         Content[0] = "";
         Content[1] = hidContent1.Value;
         Content[2] = hidContent2.Value;
         Content[3] = hidContent3.Value;
         Content[4] = hidContent4.Value;
         Content[5] = hidContent5.Value;
         Content[6] = hidContent6.Value;
         Content[7] = hidContent7.Value;
         Content[8] = hidContent8.Value;
         Content[9] = hidContent9.Value;
         Content[10] = hidContent10.Value;
         Content[11] = hidContent11.Value;
         Content[12] = hidContent12.Value;
         //

         ToolBar1 = Session["ToolBar1"].ToString();
         ToolBar2 = Session["ToolBar2"].ToString();
         ToolBar3 = Session["ToolBar3"].ToString();
         ToolBar4 = Session["ToolBar4"].ToString();
             
         if (Mode == "modify")
         {
            ContentValue1 = GetPreView();
         }
         else
         {
            ContentValue1 = GetPreView();
         }
        ShowResult.InnerHtml = ContentValue1;
    }

    public string GetPreView()
    {
        if (Mode != "Add")
        {
            ConDTable = obj.GetAllcontentbuilder(dataid);
            
        }
        if ((ConDTable.Rows.Count > 0) || Mode=="Add")
        {

            Tempid = Request.QueryString["Tempid"];
            ContentValue = objTemp.GetTemplateContent(Tempid);

            Regex reg = new Regex("##(.*?)##");
            MatchCollection thematches = reg.Matches(ContentValue);
            for (int index = 0; index < thematches.Count; index++)
            {
                ContentValue = ContentValue.Replace(thematches[index].ToString(), thematches[index].ToString().ToLower());
            }

            //ContentValue = ContentValue.ToLower();
            if (ContentValue != null)
            {
                string[] aryLoginMarkers = new string[6];
                aryLoginMarkers[0] = "##logintext##";
                aryLoginMarkers[1] = "##loginfield##";
                aryLoginMarkers[2] = "##passwordtext##";
                aryLoginMarkers[3] = "##passwordfield##";
                aryLoginMarkers[4] = "##login##";
                aryLoginMarkers[5] = "##register##";

                if (ContentValue.IndexOf(aryLoginMarkers[0], 0) > -1)
                {
                    if (hidLoginImage.Value != "" && hidLoginImageRollOver.Value == "")
                    {
                        logLabel = "<img src =\'../Images/" + hidLoginImage.Value + "\'  name  = \"lblLogin\" alt=\'" + hidLoginImageAltText.Value +
                            "\'  border=\"0\">";
                        ContentValue = ContentValue.Replace("##logintext##", logLabel);
                    }
                    else if (hidLoginImage.Value != "" && hidLoginImageRollOver.Value != "")
                    {
                        logLabel = "<img name  = \"lblLogin\" src =\'../Images/" + hidLoginImage.Value + "\'  alt=\'" + hidLoginImageAltText.Value +
                            "\'  border=\"0\" onmouseover=\"javascript:document.lblLogin.src=\'../Images/" + hidLoginImageRollOver.Value + "\'\"; onmouseout =\"javascript:document.lblLogin.src = \'../Images/" + hidLoginImage.Value + " \'\">";
                        ContentValue = ContentValue.Replace("##logintext##", logLabel);
                    }
                    else if (hidLoginText.Value != "")
                    {
                        logLabel = "<label id=\"lblLogin\">" + hidLoginText.Value + "</label>";
                        ContentValue = ContentValue.Replace("##logintext##", logLabel);
                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##logintext##", logLabel);
                    }
                }
                if (ContentValue.IndexOf(aryLoginMarkers[1], 0) > -1)
                {
                    if (hidLoginBoxHeight.Value != "" && hidLoginBoxWidth.Value != "")
                    {
                        logTxt = "<input type=\"text\" id=\"txtUserName\" name=\"txtUserName\" style=\"height:" + hidLoginBoxHeight.Value + "px; width:" + hidLoginBoxWidth.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##loginfield##", logTxt);
                    }
                    else if (hidLoginBoxHeight.Value != "" && hidLoginBoxWidth.Value == "")
                    {
                        logTxt = "<input type=\"text\" id=\"txtUserName\" name=\"txtUserName\" style=\"height:" + hidLoginBoxHeight.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##loginfield##", logTxt);
                    }
                    else if (hidLoginBoxHeight.Value == "" && hidLoginBoxWidth.Value != "")
                    {
                        logTxt = "<input type=\"text\" id=\"txtUserName\" name=\"txtUserName\" style=\"width:" + hidLoginBoxWidth.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##loginfield##", logTxt);
                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##loginfield##", logTxt);
                    }


                }
                if (ContentValue.IndexOf(aryLoginMarkers[2], 0) > -1)
                {
                    if (hidPasswordImage.Value != "" && hidPasswordImageRollOver.Value == "")
                    {
                        passLabel = "<img name  = \"lblPassword\" src =\'../Images/" + hidPasswordImage.Value + "\'  alt=\" " + hidPasswordImageAltText.Value +
                            "\"  border='0'>";
                        ContentValue = ContentValue.Replace("##passwordtext##", passLabel);
                    }
                    else if (hidPasswordImage.Value != "" && hidPasswordImageRollOver.Value != "")
                    {
                        passLabel = "<img name  = \"lblPassword\" src =\'../Images/" + hidPasswordImage.Value + "\'  alt=\" " + hidPasswordImageAltText.Value +
                            "\"  border='0' onmouseover=\"javascript:document.lblPassword.src=\'../Images/" + hidPasswordImageRollOver.Value + "\'\"  onmouseout =\"javascript:document.lblPassword.src = \'../Images/" + hidPasswordImage.Value + " \'\"; >";
                        ContentValue = ContentValue.Replace("##passwordtext##", passLabel);
                    }
                    else if (hidPasswordText.Value != "")
                    {
                        passLabel = "<label id=\"lblPassword\">" + hidPasswordText.Value + "</label>";
                        ContentValue = ContentValue.Replace("##passwordtext##", passLabel);
                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##passwordtext##", passLabel);
                    }

                }
                if (ContentValue.IndexOf(aryLoginMarkers[3], 0) > -1)
                {
                    if (hidPasswordBoxHeight.Value != "" && hidPasswordBoxWidth.Value != "")
                    {
                        passTxt = "<input type=\"password\" id=\"txtPassword\" name=\"txtPassword\" style=\"height:" + hidPasswordBoxHeight.Value + "px; width:" + hidPasswordBoxWidth.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##passwordfield##", passTxt);
                    }
                    else if (hidPasswordBoxHeight.Value != "" && hidPasswordBoxWidth.Value == "")
                    {
                        passTxt = "<input type=\"password\" id=\"txtPassword\" name=\"txtPassword\" style=\"height:" + hidPasswordBoxHeight.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##passwordfield##", passTxt);
                    }
                    else if (hidPasswordBoxHeight.Value == "" && hidPasswordBoxWidth.Value != "")
                    {
                        passTxt = "<input type=\"password\" id=\"txtPassword\" name=\"txtPassword\" style=\"width:" + hidPasswordBoxWidth.Value + "px\"/>";
                        ContentValue = ContentValue.Replace("##passwordfield##", passTxt);
                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##passwordfield##", passTxt);
                    }
                }
                if (ContentValue.IndexOf(aryLoginMarkers[4], 0) > -1)
                {
                    if (hidSubmitImage.Value != "" && hidSubmitImageRollOver.Value == "")
                    {
                        logBtn = "<span style=\"cursor:pointer;cursor:hand\"><img  alt=\"\" onmouseout =\"javascript:document.SubmitImage.src = \'../Images/" + hidSubmitImage.Value + " \'\"  name = \"SubmitImage\" src =\'../Images/" + hidSubmitImage.Value + " \'  border =\"0\" /></span>";
                        ContentValue = ContentValue.Replace("##login##", logBtn);
                    }
                    else if (hidSubmitImage.Value != "" && hidSubmitImageRollOver.Value != "")
                    {
                        logBtn = "<span style=\"cursor:pointer;cursor:hand\"><img  alt=\"\" onmouseout =\"javascript:document.SubmitImage.src = \'../Images/" + hidSubmitImage.Value + " \'\"  onmouseover =\"javascript:document.SubmitImage.src = \'../Images/" + hidSubmitImageRollOver.Value + " \'\" name  = \"SubmitImage\" src =\'../Images/" + hidSubmitImage.Value + " \'  border =\"0\" /></span>";
                        ContentValue = ContentValue.Replace("##login##", logBtn);
                    }
                    else if (hidSubmitText.Value != "")
                    {
                        logBtn = "<a href  style=\"color:Black;text-decoration:none;\">" + hidSubmitText.Value + "</a><span style=\"cursor:pointer;cursor:hand\"></span>";
                        // logBtn = "<span style=\"cursor:pointer;cursor:hand\"><input type=\"submit\" name=\"btnLogin\" value=\" " + hidSubmitText.Value + " \" id=\"btnLogin\" style=\"width:75px;\" /></span> ";
                        ContentValue = ContentValue.Replace("##login##", logBtn);

                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##login##", logBtn);
                    }

                }
                if (ContentValue.IndexOf(aryLoginMarkers[5], 0) > -1)
                {
                    if (hidRegImage.Value != "" && hidRegImageRollOver.Value == "")
                    {
                        // regBtn = "<a href=\"#\" onmouseout =\"javascript:document.RegImage.src = \'../Images/" + hidRegImage.Value + " \'\" onclick=\"javascript:window.parent.location.href='../UserManager/UserProfile.aspx?UserId=&FromPref=No&Act=New\'\";><img  alt=\"\"  name  = \"RegImage\" src =\'../Images/" + hidRegImage.Value + " \'  border ='0'/></a>";
                        regBtn = "<span style=\"cursor:pointer;cursor:hand\"><img  alt=\"\"  name  = \"RegImage\" src =\'../Images/" + hidRegImage.Value + " \'  border ='0'/ onmouseout =\"javascript:document.RegImage.src = \'../Images/" + hidRegImage.Value + " \'\";></span> ";
                        ContentValue = ContentValue.Replace("##register##", regBtn);
                    }
                    else if (hidRegImage.Value != "" && hidRegImageRollOver.Value != "")
                    {
                        regBtn = "<span style=\"cursor:pointer;cursor:hand\"><img  alt=\"\"  name  = \"RegImage\" src =\'../Images/" + hidRegImage.Value + " \' onmouseover =\"javascript:document.RegImage.src = \'../Images/" + hidRegImageRollOver.Value + " \'\"  onmouseout =\"javascript:document.RegImage.src = \'../Images/" + hidRegImage.Value + " \'\";  border ='0'/></span>";
                        ContentValue = ContentValue.Replace("##register##", regBtn);
                    }
                    else if (hidRegText.Value != "")
                    {
                        //regBtn = "<span style=\"cursor:pointer;cursor:hand\"><input type=\"submit\" name=\"btnRegister\" value=\" " + hidRegText.Value + " \" id=\"btnRegister\" style=\"width:75px;\" /></span> ";
                        regBtn = "<a href  style=\"color:Black;text-decoration:none;\">" + hidRegText.Value + "</a><span style=\"cursor:pointer;cursor:hand\"></span>";
                        ContentValue = ContentValue.Replace("##register##", regBtn);
                    }
                    else
                    {
                        ContentValue = ContentValue.Replace("##register##", regBtn);
                    }
                }

                //Replace the Content(1-12) Markers

                string[] aryMarkers = new string[12];
                aryMarkers[0] = "##content1##";
                aryMarkers[1] = "##content2##";
                aryMarkers[2] = "##content3##";
                aryMarkers[3] = "##content4##";
                aryMarkers[4] = "##content5##";
                aryMarkers[5] = "##content6##";
                aryMarkers[6] = "##content7##";
                aryMarkers[7] = "##content8##";
                aryMarkers[8] = "##content9##";
                aryMarkers[9] = "##content10##";
                aryMarkers[10] = "##content11##";
                aryMarkers[11] = "##content12##";

                string[] aryMarkersExists = new string[12];
                int Check = 0;
                for (int i = 0; i < 12; i++)
                {
                    if (ContentValue.IndexOf(aryMarkers[i], 0) > -1)
                    {
                        if (ContentValue.IndexOf(aryMarkers[i] + "$", 0) > -1)
                        {
                            if (i < 9)
                                stPos = ContentValue.IndexOf(aryMarkers[i], 0) + 13;
                            else
                                stPos = ContentValue.IndexOf(aryMarkers[i], 0) + 14;

                            edPos = ContentValue.Substring(stPos + 2).IndexOf("$", 0);
                            svlFriend = ContentValue.Substring(stPos, edPos + 2);
                            aryMarkersExists[k] = aryMarkers[i] + "$" + svlFriend + "$";
                            //aryMarkers[k] = aryMarkersExists[k].ToLower();
                            //aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                            k = k + 1;
                        }
                        else
                        {
                            aryMarkersExists[k] = aryMarkers[i];
                            //aryMarkers[k] = aryMarkersExists[k].ToLower();
                            //aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                            k = k + 1;
                        }
                    }
                    else
                    {
                        k = k + 1;
                    }

                }
                for (int i = 0; i < 12; i++)
                {
                    //if (aryMarkersExists[i] == aryMarkers[i])
                    if (aryMarkersExists[i] != null)
                    {
                        int C = Convert.ToInt16(aryMarkersExists[i].Substring(9, 2).Replace("#", ""));
                        svlFriend = "";
                        if (aryMarkersExists[C - 1].IndexOf("$", 0) > -1)
                        {
                            if (C < 10)
                            {
                                stPos = aryMarkersExists[C - 1].IndexOf("$", 0);
                                //stPos = stPos + 1;
                            }
                            else
                            {
                                stPos = aryMarkersExists[C - 1].IndexOf("$", 0);
                                stPos = stPos + 1;
                            }
                            edPos = aryMarkersExists[C - 1].Substring(stPos + 2).IndexOf("$", 0);
                            svlFriend = aryMarkersExists[C - 1].Substring(stPos, edPos + 2);//.Replace("$", "");

                            ContentValue = ContentValue.Replace("##content" + (C) + "##", Content[C].ToString()).Replace(svlFriend, "");
                            svlFriend = ContentValue.Replace(svlFriend, "");
                            Check = 1;
                        }
                        if (Check == 0)
                        {
                            ContentValue = ContentValue.Replace("##content" + (C) + "##", Content[C].ToString().Replace("##", ""));
                            ContentValue = ContentValue.Replace("####", "");
                        }
                        Check = 0;
                    }                  
                }
                ContentValue = ContentValue.Replace("$", "");

            //Replace the List Markers
             string[] list = new string[10];
             string[] list1 = new string[10];
                //Boolean f=false;
                list[0] = "##list1##";
                list[1] = "##list2##";
                list[2] = "##list3##";
                list[3] = "##list4##";
                list[4] = "##list5##";
                list[5] = "##list6##";
                list[5] = "##list6##";
                list[6] = "##list7##";
                list[7] = "##list8##";
                list[8] = "##list9##";
                list[9] = "##list10##";
            string[] ListArr = new string[10];
          
            for (int i = 0; i < 10; i++)
            {
                if (ContentValue.IndexOf(list[i], 0) > -1)
                {
                    list1[l] = list[i];
                    list[l] = list1[l].ToLower();
                    list1[l] = list1[l].ToLower();
                    l = l + 1;
                }
                else
                {
                    l = l + 1;
                }
            }

            //Lists = Request.QueryString["List1"];
             
           // if (Lists != "" )
          //  {
                   // ListArr = "LB000001,LB000002,,,,".Split(',');
                    //if (Lists != "" )
                    //    ListArr = Lists.Split(',');
                    for ( int i = 0; i < 6; i++)
                    {
                        if (Request.QueryString["List"+(i+1)]!= "" && Request.QueryString["List"+(i+1)]!= "None")
                        {
                            int C = Convert.ToInt16(list1[i].Substring(6, 2).Replace("#", ""));
                            if (C == i + 1)
                            {
                                if (ContentValue.IndexOf("##list" + (C) + "##", 0) > -1)
                                {
                                    if (Request.QueryString["List" + (i + 1)] != "" && Request.QueryString["List" + (i + 1)] != "None")
                                    {
                                        ListContent = objList.GetPreview(Request.QueryString["List" + (i + 1)]);
                                        ContentValue = ContentValue.Replace("##list" + (C) + "##", ListContent);
                                        ListContent = "";
                                    }
                                    else
                                    {
                                        ContentValue = ContentValue.Replace("##list" + (C) + "##", "");
                                    }
                                }
                                else
                                {
                                    ContentValue = ContentValue.Replace("##list" + (C) + "##", "");
                                }
                            }
                        }
                        else
                        {
                            int C = i + 1; //= Convert.ToInt16(list1[i].Substring(6, 2).Replace("#", ""));
                            ContentValue = ContentValue.Replace("##list" + (C) + "##", "");
                        }
                    }
              //  }*/

                //Replace the News Markers
              /*  for (int i = 0; i < 12; i++)
                {
                    if (ContentValue.IndexOf("##news" + (i + 1) + "##", 0) > -1)
                    {
                        ContentValue = ContentValue.Replace("##news" + (i + 1) + "##", "");
                    }
                }*/

                //Replace the Form Markers
                if (ContentValue.IndexOf("##form##", 0) > -1)
                {
                    ContentValue = ContentValue.Replace("##form##", "");
                }

                //Replace the Aspx Page Markers
                if (ContentValue.IndexOf("##aspxpage##", 0) > -1 && Request.QueryString["aspxpage"].ToString() != null) 
                {
                    
                    StringBuilder straspx = new StringBuilder();
                    //straspx.Append("<iframe width=\"100%\" height=\"100%\"  id=\"conframe\" src=\"" + Request.QueryString["aspxpage"].ToString() + "\"> </iframe>");
                    straspx.Append("<iframe id=\"myframe\" src=\"" + Request.QueryString["aspxpage"].ToString() + "\" scrolling=\"no\" marginwidth=\"0\" marginheight=\"0\" frameborder=\"0\" vspace=\"0\" hspace=\"0\" style=\"overflow:visible; width:100%; display:none\"></iframe>");
                    ContentValue = ContentValue.Replace("##aspxpage##", straspx.ToString());
                }

               
                //Replace the ToolBar Markers
                Toolbar ToolObj = new Toolbar();
                string ToolContent = "";
                for (int i = 0; i < 4; i++)
                   {
                       if (ContentValue.IndexOf("##toolbar" + (i + 1) + "##", 0) > -1)
                       {
                           DataTable toolTD = new DataTable();
                           toolid = Request.QueryString["Tool" + (i + 1)];
                           toolTD = obj.ToolDeletedFlag(toolid);
                           if (toolid != "" || toolid != "None")
                           {
                               if (toolTD.Rows.Count != 0)
                               {
                                   delFlag = Convert.ToBoolean(toolTD.Rows[0]["DeletedFlag"].ToString());
                               }
                           }
                           if (Request.QueryString["Tool" + (i + 1)] != "" )
                           {
                               if (Request.QueryString["Tool" + (i + 1)] != "None" && delFlag == false)//new 
                               {
                                   ToolContent = ToolObj.ToolbarGenerator(Request.QueryString["Tool" + (i + 1)]);
                                   ContentValue = ContentValue.Replace("##toolbar" + (i + 1) + "##", ToolContent);
                                   ToolContent = "";
                               }
                               else
                                   ContentValue = ContentValue.Replace("##toolbar" + (i + 1) + "##", "");

                           }
                           else
                           {
                               ContentValue = ContentValue.Replace("##toolbar" + (i + 1) + "##", "");
                           }

                       }
                       else
                       {
                       }
                   }

                   //Replace Other Markers

                   MatchCollection svlOthers = reg.Matches(ContentValue);
                   for (int index = 0; index < svlOthers.Count; index++)
                   {
                       ContentValue = ContentValue.Replace(svlOthers[index].ToString(), "");
                   }

                
            }
            else
            {

                ContentValue = "";
                ContentValue = "<table align='center' width=75% bgcolor='#ffffff' height=100% border=1 bordercolor='#000000'><tr><td wiConDTableh=75% height=100% valign='top' align='center'><P><Font Face='Tahoma' Size=2px Color='#CDCDCD'>Template Not Found...</Font></P></td></tr></table>";
                
            }
        }
        return (ContentValue);

    }
    

}