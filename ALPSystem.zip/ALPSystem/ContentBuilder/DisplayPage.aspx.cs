using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ContentBuilder_DisplayPage : System.Web.UI.Page
{
    ContentReader obj = new ContentReader();
     
    Boolean add=false, mod = false, del = false;
    string dataid, Foldid, TemId, svlContent, Mode,svlPublicHomeId = "", svlPrivateHomeId = "";
    public Table tblContentList;
    public TableRow trContentList;
    public TableCell[] tdContentList;
    public LinkButton[] BtnContentPage;
    public DataTable DTContentPage = new DataTable();
    DataTable dtRights = new DataTable();
    DataTable DTLike = new DataTable();
    string pageRights = "";
    int c;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);

        //Products
    
        if (Request.QueryString["PageType"] == null)
        {
            if (HttpContext.Current.Session["UserId"] == null)
                SiteInfo.ResetSession();
            SiteInfo.ValidateSession();

            UserManager user = new UserManager();
            pageRights = Request.QueryString["BtnRights"];

            dtRights = user.BuilderRights(Request.QueryString["DataId"], "");
            if (Request.QueryString["BtnRights"] == null)
            {
                if (dtRights.Rows.Count > 0)
                    pageRights = dtRights.Rows[0][0].ToString();
            }

            if (Request.QueryString["DispType"] != null && Request.QueryString["DispType"] == "Public")
                Session["DispType"] = "Public";
            else if (Request.QueryString["DispType"] == "Private")
                Session["DispType"] = "Private";

            ShowBanner("none");
            ShowPanel("none");

            svlPublicHomeId = System.Configuration.ConfigurationManager.AppSettings["PublicHome"].ToString();
            svlPrivateHomeId = System.Configuration.ConfigurationManager.AppSettings["PrivateHome"].ToString();
            if (Session["UserId"].ToString().Trim().Equals(""))
                user.Userid = 1;
            else
                user.Userid = Convert.ToInt32(Session["UserId"].ToString());
            dtRights = user.BuilderRights("", "");
            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());
                if (Session["MenuRights"].ToString() == "none")
                {
                    PageHeader.Style.Add("display", "none");
                    Underline.Style.Add("display", "none");
                    ContentDrop.Visible = false;
                    txtContentSearch.Visible = false;
                    BtnSearch.Visible = false;
                    BtnFullList.Visible = false;
                }
                else
                {
                    PageHeader.Style.Add("display", "inline");
                    Underline.Style.Add("display", "inline");
                    ContentDrop.Visible = true;
                    txtContentSearch.Visible = true;
                    BtnSearch.Visible = true;
                    BtnFullList.Visible = true;
                }
                divMenu.Controls.Add(SiteInfo.userValidation());
            }
            if (Session["DispType"].ToString() != "Public")
            {
                ShowBanner(Session["Banner"].ToString());
                ShowPanel(Session["Panel"].ToString());

            }


            if (IsPostBack == false)
            {
                ContentDrop.Items.Add("Page");
                ContentDrop.Items.Add("Parent Folder");
                ContentDrop.Items.Add("Child Folder");
            }

            /* if (Session["UserType"].ToString() != "Admin" && Session["UserType"].ToString() != "Manager")
             {
                 tblBanner.Visible = false;
                 tblLeftPanel.Visible = false;
                 trLeft1.Visible = false;
                 tdLeft1.Visible = false;
                 tdLeft2.Visible = false;
                 tdLeft3.Visible = false;
                 trLeft4.Visible = false;
                 //tdLeftPanel.Width = "0px";
                 //tdLeftPanel.Style.Add("visibility", "hidden");
                 PageHeader.Visible = false;
                 Underline.Visible = false;

                 dataid = Request.QueryString["DataId"];
                 //svlContent = obj1.GetPageContent(dataid);
                 svlContent = obj.GetPageContent(dataid);
                 ShowResult.InnerHtml = svlContent;

                 //BtnDisplayDelete.Visible = false;
                 //BtnDisplayModify.Visible = false;
             }*/

            //        BtnDisplayDelete.Attributes.Add("Onclick", "javascript:return confirm('Do you want to delete the page?');");
            string svlCanDelete = "";
            obj.ConDataID = Request.QueryString["DataId"];
            int count = obj.CountDataIds();
            if (count == 0)
            {
                obj.ConDataID = dataid;
                TemId = "";
                svlCanDelete = "YES";
            }
            else
            {
                svlCanDelete = "NO";
                // Response.Write("<script language=javascript> alert('This Data cannnot be delete as it has been linked to Combiset or ToolBar'); </script>");
            }
            BtnDisplayDelete.Attributes.Add("Onclick", "javascript:return onDelete('" + svlPublicHomeId + "','" + svlPrivateHomeId + "','" + Request.QueryString["DataId"].ToString() + "','" + svlCanDelete + "');");

            try
            {
                if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
                {
                    //tblBanner.Visible = true;
                    tdBanner.Style.Add("display", "block");
                    //tblLeftPanel.Visible = true;
                    tblLeftPanel.Style.Add("display", "block");
                    //PageHeader.Visible = true;
                    PageHeader.Style.Add("display", "block");
                    //Underline.Visible = true;
                    Underline.Style.Add("display", "block");
                    c = 0;
                    DTContentPage = obj.GetAllContentBuilderNames();
                    tblContentList = new Table();
                    trContentList = new TableRow();
                    BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
                    tdContentList = new TableCell[DTContentPage.Rows.Count];
                    Foldid = DTContentPage.Rows[0]["parentid"].ToString();

                    foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
                    {
                        trContentList = new TableRow();
                        BtnContentPage[c] = new LinkButton();
                        tdContentList[c] = new TableCell();

                        BtnContentPage[c].Text = rowValues["name"].ToString();
                        BtnContentPage[c].ID = rowValues["dataid"].ToString();
                        BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                        BtnContentPage[c].Font.Name = "Tahoma";
                        BtnContentPage[c].Font.Size = 8;
                        BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                        BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                        BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                        BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
                        BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                        tdContentList[c].Controls.Add(BtnContentPage[c]);
                        trContentList.Cells.Add(tdContentList[c]);
                        tblContentList.Rows.Add(trContentList);
                        c++;
                    }

                    ContentPagesListTd.Controls.Add(tblContentList);                 
                    dataid = Request.QueryString["DataId"];
                    svlContent = obj.GetPageContent(dataid);                    
                    ShowResult.InnerHtml = svlContent;
                }
                else
                {
                    string BtnRights = pageRights; // Request.QueryString["BtnRights"];
                    if (BtnRights != null && BtnRights != "")
                    {
                        string rAdd = BtnRights.Substring(0, 1);
                        string rMod = BtnRights.Substring(1, 1);
                        string rDel = BtnRights.Substring(2, 1);
                        string rView = BtnRights.Substring(3, 1);

                        if (rMod == "1")
                        {
                            tdModify.Style.Add("display", "inline");
                        }
                        else
                        {
                            tdModify.Style.Add("display", "none");
                        }

                        if (rDel == "1")
                        {
                            tdDelete.Style.Add("display", "inline");
                        }
                        else
                        {
                            tdDelete.Style.Add("display", "none");
                        }

                        //new coding 21-sep-06 1230

                        //if (
                    }
                    else if (dtRights.Rows.Count != 0)
                    {
                        string Rights = dtRights.Rows[0]["Rights"].ToString();
                        dataid = dtRights.Rows[0]["BuilderId"].ToString();

                        //tblBanner.Visible = false;
                        //tblLeftPanel.Visible = false;
                        //PageHeader.Visible = false;
                        //Underline.Visible = false;

                        ContentDrop.Visible = false;
                        txtContentSearch.Visible = false;
                        BtnSearch.Visible = false;
                        BtnFullList.Visible = false;

                        string rAdd = Rights.Substring(0, 1);
                        string rMod = Rights.Substring(1, 1);
                        string rDel = Rights.Substring(2, 1);
                        string rView = Rights.Substring(3, 1);

                        if (rMod == "1")
                        {
                            tdModify.Style.Add("display", "inline");
                        }
                        else
                        {
                            tdModify.Style.Add("display", "none");
                        }

                        if (rDel == "1")
                        {
                            tdDelete.Style.Add("display", "inline");
                        }
                        else
                        {
                            tdDelete.Style.Add("display", "none");
                        }


                    }
                    c = 0;
                    //ContentDrop.Items.Add("Page");
                    //ContentDrop.Items.Add("Parent Folder");
                    // ContentDrop.Items.Add("Child Folder");

                    tblContentList = new Table();
                    trContentList = new TableRow();
                    BtnContentPage = new LinkButton[dtRights.Rows.Count];
                    tdContentList = new TableCell[dtRights.Rows.Count];

                    //Foldid = dtRights.Rows[0]["parentid"].ToString();
                    if (dtRights.Rows.Count != 0)
                    {
                        foreach (System.Data.DataRow rowValues in dtRights.Rows)
                        {
                            if (rowValues["Rights"].ToString() == "" || rowValues["Rights"].ToString().Substring(3, 1) == "1")
                            {
                                DTContentPage = obj.GetAllcontentbuilder(rowValues["BuilderId"].ToString());
                                if (DTContentPage.Rows.Count > 0)
                                {
                                    hidRights.Value = rowValues["Rights"].ToString();
                                    trContentList = new TableRow();
                                    BtnContentPage[c] = new LinkButton();
                                    tdContentList[c] = new TableCell();

                                    BtnContentPage[c].Text = DTContentPage.Rows[0]["name"].ToString();
                                    BtnContentPage[c].ID = DTContentPage.Rows[0]["dataid"].ToString();
                                    BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                                    BtnContentPage[c].Font.Name = "Tahoma";
                                    BtnContentPage[c].Font.Size = 8;
                                    BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                                    BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                                    BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                                    BtnContentPage[c].CommandArgument = DTContentPage.Rows[0]["dataid"].ToString();
                                    BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                                    tdContentList[c].Controls.Add(BtnContentPage[c]);
                                    trContentList.Cells.Add(tdContentList[c]);
                                    tblContentList.Rows.Add(trContentList);
                                    c++;
                                }
                            }
                        }
                    }
                    ContentPagesListTd.Controls.Add(tblContentList);
                    dataid = Request.QueryString["DataId"];
                    svlContent = obj.GetPageContent(dataid);
                    ShowResult.InnerHtml = svlContent;
                }
                if (Session["DispType"].ToString() == "Public" || Session["DispType"].ToString() == "Private")
                {
                    Underline.Style.Add("display", "none");
                    PageHeader.Style.Add("display", "none");
                    ShowBanner("none");
                    ShowPanel("none");
                }
                else if (Session["DispType"].ToString() == "SiteManagement")
                {
                    Underline.Style.Add("display", "inline");
                    PageHeader.Style.Add("display", "inline");
                }



            }
            catch (System.Exception ex)
            {
            }

            if (!(Session["UserType"].ToString().ToLower().Equals("admin")))
            {
                CheckRights();


                if (mod)
                {
                    BtnDisplayModify.Style.Add("display", "inline");
                }
                else
                {
                    BtnDisplayModify.Style.Add("display", "none");
                }
                if (del)
                {
                    BtnDisplayDelete.Style.Add("display", "inline");
                }
                else
                {
                    BtnDisplayDelete.Style.Add("display", "none");
                }
            }
        }
        else
        {
            if (Request.QueryString["PageType"].ToString().Equals("PUB"))
            {
                ShowBanner("none");
                ShowPanel("none");
                tblTop.Style.Add("display", "none"); 
                PageHeader.Style.Add("display", "none");
                Underline.Style.Add("display", "none");               
                dataid = Request.QueryString["DataId"];
                svlContent = obj.GetPageContent(dataid);                
                ShowResult.InnerHtml = svlContent;                
            }
        }

     }
    protected void BtnDisplayBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }
    protected void BtnDisplayDelete_Click(object sender, EventArgs e)
    {
        obj.ConDataID = dataid;
        int count = obj.CountDataIds();
        if (count == 0)
        {
            obj.ConDataID = dataid;
            TemId="";
            obj.DeleteContent();
            obj.UpdateLinksContent(dataid, TemId);
            //DeleteLinks();
            
        }
        else
        {
            Response.Write("<script language=javascript> alert('This Data cannnot be delete as it has been linked to Combiset or ToolBar'); </script>");
        }
        Response.Redirect("ContentBuilderPage.aspx");
    }
    protected void BtnDisplayModify_Click(object sender, EventArgs e)
    {
        Mode = "modify";
        Response.Redirect("AddPageContent.aspx?Dataid=" + dataid + "&Mode=" + Mode + "&Foldid=" + Foldid);
    }
    protected void ContentPage_Click(object sender, EventArgs e)
    {
        dataid  = (((LinkButton)(sender)).CommandArgument).ToString();
       // string rights = hidRights.Value;
        for (int i = 0; i < dtRights.Rows.Count; i++)
        {
            if (dtRights.Rows[i]["BuilderId"].ToString() == dataid)
            {
                hidRights.Value = dtRights.Rows[i]["Rights"].ToString();
            }

            if (dtRights.Rows[i]["Rights"].ToString() == "") //21-09-06
            {
                hidRights.Value = "1111";
            }
        }
        Response.Redirect("DisplayPage.aspx?DataId=" + dataid + "&BtnRights=" + hidRights.Value);
       
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx?Subname=" + txtContentSearch.Text + "&Dropname=" + ContentDrop.SelectedItem.Text);
    }
    protected void BtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }

    //userValidation

    protected HtmlTable userValidation()
    {
      //  objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                            cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }

                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub'); ");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                       // if (Session["UserType"].ToString() == "Admin")
                            cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }
                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }

    protected void CheckRights()
    {

        UserManager objUser = new UserManager();
        if(Session["UserId"].ToString().Trim().Equals(""))
            objUser.Userid = 1;
        else
            objUser.Userid = int.Parse(Session["UserId"].ToString());
        DataTable dtToolbars = new DataTable();
        //DataTable dtRights = new DataTable();
        dtToolbars = objUser.AllToolBarViewRights("");
        foreach (DataRow row in dtToolbars.Rows)
        {
            string strRights = objUser.MultipleRights(row[0].ToString(), "All");
            if (strRights.Substring(0, 1).Equals("1"))
            {
                add = true;
            }
            if (strRights.Substring(1, 1).Equals("1"))
            {
                mod = true;
            }
            if (strRights.Substring(2, 1).Equals("1"))
            {
                del = true;
            }
        }
    }
}

