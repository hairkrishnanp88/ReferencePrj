using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.Data.SqlClient;

public partial class ContentBuilder_PublicPageDisplay : System.Web.UI.Page
{
    HtmlTable Mt;
    HtmlTableRow Mr;
    HtmlTableCell Mc;
    string svlContent, dataid;
    public Table tblContentList;
    public TableRow trContentList;
    public TableCell[] tdContentList;
    public LinkButton[] BtnContentPage;
    public DataTable DTContentPage = new DataTable();
    int c;
    string DataID;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        ContentReader obj = new ContentReader();
        DTContentPage = obj.GetAllContentBuilderNames();
        
        tblContentList = new Table();
        trContentList = new TableRow();
        BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
        tdContentList = new TableCell[DTContentPage.Rows.Count];
        //Foldid = DTContentPage.Rows[0]["parentid"].ToString();

        foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
        {
            trContentList = new TableRow();
            BtnContentPage[c] = new LinkButton();
            tdContentList[c] = new TableCell();

            BtnContentPage[c].Text = rowValues["name"].ToString();
            BtnContentPage[c].ID = rowValues["dataid"].ToString();
            BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
            BtnContentPage[c].Font.Name = "Tahoma";
            BtnContentPage[c].Font.Size = 8;
            BtnContentPage[c].ForeColor = System.Drawing.Color.White;

            BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
            BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
            BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
            BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


            tdContentList[c].Controls.Add(BtnContentPage[c]);
            trContentList.Cells.Add(tdContentList[c]);
            tblContentList.Rows.Add(trContentList);
            c++;
        }

        ContentPagesListTd.Controls.Add(tblContentList);

        
        dataid = Request.QueryString["DataId"];
        svlContent = obj.GetPageContent(dataid);
        Mt = new HtmlTable();
        Mt.Border = 0;
        Mt.BorderColor = "#000000";
        Mt.Width = Unit.Percentage(90).ToString();
        Mt.BgColor = "#FFFFFF";

        Mr = new HtmlTableRow();
        Mr.BgColor = "#EEF0F6";
        Mr.BorderColor = "#000000";
        Mc = new HtmlTableCell();

        Mc.BorderColor = "#000000";
        Mc.InnerHtml = svlContent;

        Mr.Controls.Add(Mc);
        Mt.Controls.Add(Mr);

        ShowResult.Controls.Add(Mt);
        ShowResult.InnerHtml = svlContent;

    }
    protected void ContentPage_Click(object sender, EventArgs e)
    {
        DataID = (((LinkButton)(sender)).CommandArgument).ToString();
        Response.Redirect("PublicPageDisplay.aspx?DataId=" + DataID);

    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx?Subname=" + txtContentSearch.Text + "&Dropname=" + ContentDrop.SelectedItem.Text);
    }
    protected void BtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }
    
}
