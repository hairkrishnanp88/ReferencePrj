using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class ContentBuilder_FileUpLoad : System.Web.UI.Page
{
    string strFileDir;
    long lngMaxFileSize;
    string queryString;
    protected void Page_Load(object sender, EventArgs e)
    {
        queryString = Request.QueryString["value"];
        tblHeader.InnerText = "Image Upload";
        hideEventId.Value = queryString;
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string varFileType;
        varFileType = FileUploader.PostedFile.ContentType;
        //Response.Write(varFileType);
        
            
            if ((varFileType == "image/gif") || (varFileType == "image/pjpeg") || (varFileType == "image/x-png") || (varFileType == "image/bmp") || (varFileType == "application/octet-stream"))
            {

                strFileDir = Server.MapPath("../Images/");

                fnUpload();
            }
            else
                Response.Write("<script language='javascript'>alert('Please select image files')</script>");
        
    }

    private void fnUpload()
    {
        if ((FileUploader.PostedFile != null) && (FileUploader.PostedFile.ContentLength != 0))
        {
            string strFileName = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);
            try
            {
                lngMaxFileSize = FileUploader.PostedFile.ContentLength;
                //save file in the local disk

                for (int i = 1; ; i++)
                {
                    if (File.Exists(strFileDir + "\\" + strFileName))
                    {
                        if (i < 10)
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + "0" + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                        else
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                    }
                    else
                        break;
                }

                FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);
                hideFileName.Value = strFileName;
            }
            catch (Exception ex)
            {
                //Response.Redirect("../Errors/Error.aspx
                Response.Write("Error Occured" + ex.Message.ToString());
                //Response.End();
                //Response.Write("Error Occured");
            }
        }
    }
}
