using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ContentBuilder_AddPageContent : System.Web.UI.Page
{
    string Foldid, Mode, TempContent, dataid, FromName, Mod1, Maxid, Type1, BtnRights;
    ContentReader obj = new ContentReader();
    DataTable ContentTb = new DataTable();
    DataTable ListTable = new DataTable();
    DataTable TempDT = new DataTable();
    public Table tblContentList;
    public TableRow trContentList;
    public TableCell[] tdContentList;
    public LinkButton[] BtnContentPage;
    public DataTable DTContentPage = new DataTable();
    public DataTable DtToolBar = new DataTable();
    int c,stPos, edPos, tCheck,l;
    string svlFriend = "", Toolids;
    DataTable DTLike = new DataTable();
    DataTable dtRights = new DataTable();

    //Prdoucts
    DataTable dtProductDetails = new DataTable();
    DataTable dtCategory = new DataTable();
    DataTable dtPublishProducts = new DataTable();

    int lgCheck = 0;//login properties - 31Jan07
    int logID;
    protected void Page_Load(object sender, EventArgs e)
    {
        tCheck = 0;
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
 
        dataid = Request.QueryString["dataid"];
        Mode = Request.QueryString["Mode"];
        Foldid = Request.QueryString["Foldid"];
        FromName = Request.QueryString["FromName"];
        Mod1 = Mod.Value;
        ShowBanner(Session["Banner"].ToString());
        ShowPanel(Session["Panel"].ToString());
        

        c = 0;
        Type1 = "CB";
        DropField.AutoPostBack = false;
        DTContentPage = obj.GetAllContentBuilderNames();

        DropToolLocation.Attributes.Add("onchange", "javascript:ToolBarLocationChange();");
        DropSelectTool.Attributes.Add("onchange", "javascript:ToolBarchange()");
        DropSelectList.Attributes.Add("onchange", "javascript:ListLocationChange();");
        DropListName.Attributes.Add("onchange", "javascript:Listchange()");
        BtnSave.Attributes.Add("onclick", "javascript:if(!BrValidate()){return false;};");
        BtnEdit.Attributes.Add("onclick", "javascript:ShowCBEditor('../editor/editor.aspx?TYPE=" + Type1 + "');return false;");
        AddPageContentBody.Attributes.Add("onload", "document.getElementById('txtTempname').focus();");

        //Prdoucts
        ddlProductlocation.Attributes.Add("onchange", "javascript: ProductionLocationChange();");
        ddlSelectproduct.Attributes.Add("onchange", "javascript: SelectProductonchange()");
        ddlCategory.Attributes.Add("onchange", "javascript: Categoryonchange()");
        ddlPreviewtype.Attributes.Add("onchange", "javascript: Previewonchange()");       
      


        if (IsPostBack == false)
        {
            ContentDrop.Items.Add("Page");
            ContentDrop.Items.Add("Parent Folder");
            ContentDrop.Items.Add("Child Folder");
        }
        tblContentList = new Table();
        trContentList = new TableRow();
        BtnContentPage = new LinkButton[DTContentPage.Rows.Count];
        tdContentList = new TableCell[DTContentPage.Rows.Count];

        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }

        // //21-09-06 05:35 begin
        if (Session["UserId"].ToString() != "")
        {
            UserManager user = new UserManager();
            user.Userid = Convert.ToInt32(Session["UserId"].ToString());
            dtRights = user.BuilderRights("", "");
        }
        else
        {
            HttpContext.Current.Response.Redirect("../Errors/SessionExpired.aspx");
        }
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            foreach (System.Data.DataRow rowValues in DTContentPage.Rows)
            {
                trContentList = new TableRow();
                BtnContentPage[c] = new LinkButton();
                tdContentList[c] = new TableCell();

                BtnContentPage[c].Text = rowValues["name"].ToString();
                BtnContentPage[c].ID = rowValues["dataid"].ToString();
                BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                BtnContentPage[c].Font.Name = "Tahoma";
                BtnContentPage[c].Font.Size = 8;
                BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                BtnContentPage[c].CommandArgument = rowValues["dataid"].ToString();
                BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                tdContentList[c].Controls.Add(BtnContentPage[c]);
                trContentList.Cells.Add(tdContentList[c]);
                tblContentList.Rows.Add(trContentList);
                c++;
            }

            ContentPagesListTd.Controls.Add(tblContentList);
        }
        else
        {
            
            if (dtRights.Rows.Count != 0)
            {
                //ContentDrop.Visible = false;
                //txtContentSearch.Visible = false;
                //BtnSearch.Visible = false;
                //BtnFullList.Visible = false;
                foreach (System.Data.DataRow rowValues in dtRights.Rows)
                {
                    if(!rowValues["Rights"].ToString().Equals(""))
                    if (rowValues["Rights"].ToString().Substring(3, 1) == "1")
                    {
                        DTContentPage = obj.GetAllcontentbuilder(rowValues["BuilderId"].ToString());
                        // hidRights.Value = rowValues["Rights"].ToString();
                        if (DTContentPage.Rows.Count > 0)
                        {
                            trContentList = new TableRow();
                            BtnContentPage[c] = new LinkButton();
                            tdContentList[c] = new TableCell();

                            BtnContentPage[c].Text = DTContentPage.Rows[0]["name"].ToString();
                            BtnContentPage[c].ID = DTContentPage.Rows[0]["dataid"].ToString();
                            BtnContentPage[c].Attributes.Add("style", "text-decoration:none");
                            BtnContentPage[c].Font.Name = "Tahoma";
                            BtnContentPage[c].Font.Size = 8;
                            BtnContentPage[c].ForeColor = System.Drawing.Color.White;

                            BtnContentPage[c].Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.color='#ECF0D3'");
                            BtnContentPage[c].Attributes.Add("onmouseout", "this.style.color='#ffffff';");
                            BtnContentPage[c].CommandArgument = DTContentPage.Rows[0]["dataid"].ToString();
                            BtnContentPage[c].Click += new EventHandler(ContentPage_Click);


                            tdContentList[c].Controls.Add(BtnContentPage[c]);
                            trContentList.Cells.Add(tdContentList[c]);
                            tblContentList.Rows.Add(trContentList);
                            c++;
                        }
                    }
                }
            }
            ContentPagesListTd.Controls.Add(tblContentList);
        }    //21-09-06 05:35 end


        BtnSelectTemp.Attributes.Add("onclick", "javascript:window.open('TemplateList.aspx?Mode=" + Mode + "','','height=450, width=550, left=50, top=50; center:1; help:0 ; resizable:0;scrollbars:0; status:0;');return false;");
        ListRow1.Attributes.Add("style", "display:none");
        ListRow2.Attributes.Add("style", "display:none");
        ToolBarRow1.Attributes.Add("style", "display:none");
        ToolBarRow2.Attributes.Add("style", "display:none");
        FieldRow.Attributes.Add("style", "display:none");
        aspxRow.Style.Add("display", "none");

        //Prodcuts Conrols 16 July 07
        trProductlocation.Style.Add("display", "none");
        trSelectproduct.Style.Add("display","none");        
        trCategory.Style.Add("display","none");
        trPreviewtype.Style.Add("display", "none");        
        //End


        //Login Markers 26Mar07
        trLoginlable1.Attributes.Add("style", "display:none");
        trLoginlable2.Attributes.Add("style", "display:none");
        trLoginlable3.Attributes.Add("style", "display:none");
        trLoginlable4.Attributes.Add("style", "display:none");
        trPassword1.Attributes.Add("style", "display:none");
        trPassword2.Attributes.Add("style", "display:none");
        trPassword3.Attributes.Add("style", "display:none");
        trPassword4.Attributes.Add("style", "display:none");
        trRegister1.Attributes.Add("style", "display:none");
        trRegister2.Attributes.Add("style", "display:none");
        trRegister3.Attributes.Add("style", "display:none");
        trRegister4.Attributes.Add("style", "display:none");
        trLoginBtn1.Attributes.Add("style", "display:none");
        trLoginBtn2.Attributes.Add("style", "display:none");
        trLoginBtn3.Attributes.Add("style", "display:none");
        trLoginBtn4.Attributes.Add("style", "display:none");
        trLBoxSize.Attributes.Add("style", "display:none");
        trPBoxSize.Attributes.Add("style", "display:none");
        //


        if (Mode == "modify")
        {
            AddFolderHeader.Text = "Modify Page";
            BtnReset.Attributes.Add("style", "display:none");
            litbtnsave.Visible = false;
            litbtnback.Visible = false;           
            ContentTb = obj.GetAllcontentbuilder(dataid);
            
            if (ContentTb.Rows.Count > 0)
            {
                if (IsPostBack == false)
                {
                    txtPageName.Text = ContentTb.Rows[0]["HeaderText"].ToString();
                    hidtemp.Value = ContentTb.Rows[0]["TemplateId"].ToString();
                    txtFilename.Text = ContentTb.Rows[0]["aspxpage"].ToString();                   
                }

            }
            if (Mod1 == "ModT")
            {
                txtTempname.Text = obj.GetAllTemplateName(hidtemp.Value);
                TempContent = obj.GetTemplateContent(hidtemp.Value);
            }
            else
            {
                if (ContentTb.Rows.Count > 0)
                {
                    txtTempname.Text = obj.GetAllTemplateName(ContentTb.Rows[0]["TemplateId"].ToString());
                    TempContent = obj.GetTemplateContent(ContentTb.Rows[0]["TemplateId"].ToString());
                }

            }
            
            string[] aryMarkers = new string[12];
            aryMarkers[0] = "##content1##";
            aryMarkers[1] = "##content2##";
            aryMarkers[2] = "##content3##";
            aryMarkers[3] = "##content4##";
            aryMarkers[4] = "##content5##";
            aryMarkers[5] = "##content6##";
            aryMarkers[6] = "##content7##";
            aryMarkers[7] = "##content8##";
            aryMarkers[8] = "##content9##";
            aryMarkers[9] = "##content10##";
            aryMarkers[10] = "##content11##";
            aryMarkers[11] = "##content12##";


            string[] aryMarkersExists = new string[12];
            int k = 0, m = 0, t = 0;
            DropField.Items.Clear();
            TempContent = TempContent.ToLower();
            for (int i = 0; i < 12; i++)
            {
                if (TempContent.IndexOf(aryMarkers[i], 0) > -1)
                {
                    if (TempContent.IndexOf(aryMarkers[i] + "$", 0) > -1)
                    {
                        if (i < 9)
                            stPos = TempContent.IndexOf(aryMarkers[i], 0) + 13;
                        else
                            stPos = TempContent.IndexOf(aryMarkers[i], 0) + 14;

                        edPos = TempContent.Substring(stPos + 2).IndexOf("$", 0);
                        svlFriend = TempContent.Substring(stPos, edPos + 2);

                        aryMarkersExists[k] = aryMarkers[i] + "$" + svlFriend + "$";
                        aryMarkers[k] = aryMarkersExists[k].ToLower();
                        aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                        k = k + 1;
                    }
                    else
                    {
                        aryMarkersExists[k] = aryMarkers[i];
                        aryMarkers[k] = aryMarkersExists[k].ToLower();
                        aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                        k = k + 1;
                    }
                }
                else
                {   
                    k = k + 1;
                }
                
            }
           
           for (int i = 0; i < 12; i++)
            {
                if (aryMarkersExists[i] == aryMarkers[i])
                {
                    int C = Convert.ToInt16(aryMarkersExists[i].Substring(9, 2).Replace("#", ""));
                    svlFriend = "";
                    if (TempContent.IndexOf(aryMarkersExists[C - 1], 0) > -1)
                    {

                        FieldRow.Attributes.Add("style", "display:block");
                        if (aryMarkersExists[i].IndexOf("$", 0) > -1)
                        {
                            if (i < 9)
                                stPos = TempContent.IndexOf(aryMarkersExists[C - 1], 0) + 13;
                            else
                                stPos = TempContent.IndexOf(aryMarkersExists[C - 1], 0) + 14;
                            edPos = TempContent.Substring(stPos + 2).IndexOf("$", 0);
                            svlFriend = TempContent.Substring(stPos, edPos + 2).Replace("$", "");
                        }
                        if (svlFriend == "")
                        {
                            if (aryMarkersExists[C - 1] != null)
                                DropField.Items.Add(new ListItem(aryMarkersExists[C - 1].ToString().Replace("##", ""), Convert.ToString(i + 1)));
                        }
                        else
                            DropField.Items.Add(new ListItem(svlFriend.Replace("$", ""), Convert.ToString(i + 1)));
                    }
                }
                else
                {
                    int C = Convert.ToInt16(aryMarkers[i].Substring(9, 2).Replace("#", ""));
       
                    //New Changes 26Mar07
                    if (C == 1)
                        txtContent1.Value = "";
                    else if (C == 2)
                        txtContent2.Value = "";
                    else if (C == 3)
                        txtContent3.Value = "";
                    else if (C == 4)
                        txtContent4.Value = "";
                    else if (C == 5)
                        txtContent5.Value = "";
                    else if (C == 6)
                        txtContent6.Value = "";
                    else if (C == 7)
                        txtContent7.Value = "";
                    else if (C == 8)
                        txtContent8.Value = "";
                    else if (C == 9)
                        txtContent9.Value = "";
                    else if (C == 10)
                        txtContent10.Value = "";
                    else if (C == 11)
                        txtContent11.Value = "";
                    if (C == 12)
                        txtContent12.Value = "";
                    //

                }
            }

            string[] list = new string[10];
            string[] list1 = new string[10];
            list[0] = "##list1##";
            list[1] = "##list2##";
            list[2] = "##list3##";
            list[3] = "##list4##";
            list[4] = "##list5##";
            list[5] = "##list6##";
            list[6] = "##list7##";
            list[7] = "##list8##";
            list[8] = "##list9##";
            list[9] = "##list10##";

            for (int i = 0; i < 10; i++)
            {
                if (TempContent.IndexOf(list[i], 0) > -1)
                {
                    list1[l] = list[i];
                    list[l] = list1[l].ToLower();
                    list1[l] = list1[l].ToLower();
                    l = l + 1;
                }
                else
                {
                    l = l + 1;
                }
            }

            for (int i = 0; i < 10; i++)
            {
               // if (TempContent.IndexOf(list[i], 0) > -1)
                if(list[i]==list1[i])
                {
                    list1[m] = list[i];
                    m = m + 1;
                    Lists objlist = new Lists();
                    ListTable = objlist.GetAllListName();
                    DropSelectList.Items.Add(list1[i].Replace("##", ""));
                    ListRow1.Attributes.Add("style", "display:block");
                    ListRow2.Attributes.Add("style", "display:block");
                    t = 1;
                }
                else
                {
                    int C = i + 1;
                        if (C == 1)
                            txtList1.Value = "";
                        else if (C == 2)
                            txtList2.Value = "";
                        else if (C == 3)
                            txtList3.Value = "";
                        else if (C == 4)
                            txtList4.Value = "";
                        else if (C == 5)
                            txtList5.Value = "";
                        if (C == 6)
                            txtList6.Value = "";
                  
                }
            }
            if (t == 1)
            {
                if (ListTable.Rows.Count > 0)
                {
                    DropListName.Items.Add("None");
                    DropListName.DataSource = ListTable;
                    DropListName.DataValueField = "LBID";
                    DropListName.DataTextField = "ListName";
                    DropListName.DataBind();
                    DropListName.Items.Insert(0, new ListItem("None", "None"));
                }
            }
           DropToolLocation.Items.Clear();
           string[] ToolMark=new string[4];
           ToolMark[0] = "##toolbar1##";
           ToolMark[1] = "##toolbar2##";
           ToolMark[2] = "##toolbar3##";
           ToolMark[3] = "##toolbar4##";
           for (int i = 0; i < 4; i++)
           {
               if (TempContent.IndexOf(ToolMark[i], 0) > -1)
               {
                   DropToolLocation.Items.Add(ToolMark[i].Replace("##", ""));
                   ToolBarRow1.Attributes.Add("style", "display:block");
                   ToolBarRow2.Attributes.Add("style", "display:block");
                   DtToolBar = obj.GetToolbars();
                   t = 0;
               }
               else
               {
                   int C = Convert.ToInt16(ToolMark[i].Substring(9, 1).Replace("#", ""));
                   if (C == 1)
                       txtToolBar1.Value = "";
                   else if (C == 2)
                       txtToolBar2.Value = "";
                   else if (C == 3)
                       txtToolBar3.Value = "";
                   if (C == 4)
                       txtToolBar4.Value = "";

               }
           }
           if (t == 0)
           {
               if (DtToolBar.Rows.Count > 0)
               {
                   DropSelectTool.DataSource = DtToolBar;
                   DropSelectTool.DataValueField = "ButtonID";
                   DropSelectTool.DataTextField = "ButtonText";
                   DropSelectTool.DataBind();
                   DropSelectTool.Items.Insert(0,new ListItem("None", "None"));
                   
               }
           }


           //Login Marker 26Mar07 04:59
           string loginText = "##logintext##";
           string loginField = "##loginfield##";
           string passText = "##passwordtext##";
           string passField = "##passwordfield##";
           string loginBtn = "##login##";
           string registerBtn = "##register##";
           if (ContentTb.Rows[0]["LoginId"].ToString() != null && ContentTb.Rows[0]["LoginId"].ToString() != "" && ContentTb.Rows[0]["LoginId"].ToString() != "0") //01Feb07
           {
               DataTable dtLogin = new DataTable();
               dtLogin = obj.SelectLoginProperties(Convert.ToInt16(ContentTb.Rows[0]["LoginId"]));
               hidLoginId.Value = ContentTb.Rows[0]["LoginId"].ToString();
               if (dtLogin.Rows.Count != 0 && !IsPostBack)
               {
                   txtLoginText.Text = dtLogin.Rows[0]["LoginText"].ToString();
                   txtLoginImage.Text = dtLogin.Rows[0]["LoginImage"].ToString();
                   txtLoginImageRO.Text = dtLogin.Rows[0]["LoginImageRollOver"].ToString();
                   txtLoginAltText.Text = dtLogin.Rows[0]["LoginImageAltText"].ToString();
                   txtPassText.Text = dtLogin.Rows[0]["PasswordText"].ToString();
                   txtPassImage.Text = dtLogin.Rows[0]["PasswordImage"].ToString();
                   txtPassImageRO.Text = dtLogin.Rows[0]["PasswordImageRollOver"].ToString();
                   txtPassAltText.Text = dtLogin.Rows[0]["PasswordImageAltText"].ToString();
                   txtRegText.Text = dtLogin.Rows[0]["RegText"].ToString();
                   txtRegImage.Text = dtLogin.Rows[0]["RegImage"].ToString();
                   txtRegImageRO.Text = dtLogin.Rows[0]["RegImageRollOver"].ToString();
                   txtRegAltText.Text = dtLogin.Rows[0]["RegImageAltText"].ToString();
                   txtLoginBtn.Text = dtLogin.Rows[0]["SubmitText"].ToString();
                   txtLoginBtnI.Text = dtLogin.Rows[0]["SubmitImage"].ToString();
                   txtLoginBtnIRO.Text = dtLogin.Rows[0]["SubmitImageRollOver"].ToString();
                   txtLoginBtnAlt.Text = dtLogin.Rows[0]["SubmitImageAltText"].ToString();
                   txtLHeight.Text = dtLogin.Rows[0]["LoginBoxHeight"].ToString();
                   txtLWidht.Text = dtLogin.Rows[0]["LoginBoxWidth"].ToString();
                   txtPHeight.Text = dtLogin.Rows[0]["PasswordBoxHeight"].ToString();
                   txtPWidht.Text = dtLogin.Rows[0]["PasswordBoxWidth"].ToString();
               }
           }//01Feb07

           if (TempContent.IndexOf(loginText, 0) > -1)
           {
               trLoginlable1.Attributes.Add("style", "display:block");
               trLoginlable2.Attributes.Add("style", "display:block");
               trLoginlable3.Attributes.Add("style", "display:block");
               trLoginlable4.Attributes.Add("style", "display:block");
               lgCheck = 1;//31Jan07
           }
           if (TempContent.IndexOf(loginField, 0) > -1)
           {
               trLBoxSize.Attributes.Add("style", "display:block");
               lgCheck = 1;
           }
           if (TempContent.IndexOf(passField, 0) > -1)
           {
               trPBoxSize.Attributes.Add("style", "display:block");
               lgCheck = 1;
           }
           if (TempContent.IndexOf(passText, 0) > -1)
           {
               trPassword1.Attributes.Add("style", "display:block");
               trPassword2.Attributes.Add("style", "display:block");
               trPassword3.Attributes.Add("style", "display:block");
               trPassword4.Attributes.Add("style", "display:block");

               lgCheck = 1;//31Jan07
           }
           if (TempContent.IndexOf(registerBtn, 0) > -1)
           {
               trRegister1.Attributes.Add("style", "display:block");
               trRegister2.Attributes.Add("style", "display:block");
               trRegister3.Attributes.Add("style", "display:block");
               trRegister4.Attributes.Add("style", "display:block");
               lgCheck = 1;//31Jan07
           }
           if (TempContent.IndexOf(loginBtn, 0) > -1)
           {
               trLoginBtn1.Attributes.Add("style", "display:block");
               trLoginBtn2.Attributes.Add("style", "display:block");
               trLoginBtn3.Attributes.Add("style", "display:block");
               trLoginBtn4.Attributes.Add("style", "display:block");
               lgCheck = 1;//31Jan07
           }
           if (TempContent.IndexOf("##aspxpage##", 0) > -1)
               aspxRow.Style.Add("display", "inline");




           //Products controls display
           if (hdnTemplatechange.Value == "yes")
           {
               New_ShowProductControls();
               hdnTemplatechange.Value = "";
           }
           else
               ShowProductControls();
            

           if (!IsPostBack)
           {
               if (ContentTb.Rows.Count > 0)
               {
                   //Load Product controls values
                   string svlProducts = "";
                   svlProducts = ContentTb.Rows[0]["Products"].ToString();
                   LoadProductControls(svlProducts);
               }
           }

       

           if (Mod1 == "ModT" && lgCheck == 1)
           {
               DefaultStyleValues();
           }
           ///


        }
        else if (Mode == "Add") 
        {
            AddFolderHeader.Text = "Add Page";
            if (Mod1 == "ModT")
            {
                BtnReset.Visible = true;
                txtTempname.Text = obj.GetAllTemplateName(hidtemp.Value);
                TempContent = obj.GetTemplateContent(hidtemp.Value);
                NewTemplateContent();
            }
        }
        if (IsPostBack == false)
        {
            AssignContentOnTextboxes();
            txtLists.Value = txtList.Value;
            txtLists.Value = "";
        }
        DropSelectTool.SelectedIndex = DropSelectTool.Items.IndexOf(DropSelectTool.Items.FindByValue(txtToolBar1.Value));
        DropListName.SelectedIndex = DropListName.Items.IndexOf(DropListName.Items.FindByValue(txtList1.Value));
        BtnSelectTemp.Attributes.Add("onmouseover","this.style.cursor='pointer'; this.src='../Images/icons_template1_ovr.gif'");
        BtnSelectTemp.Attributes.Add("onmouseout", "this.src='../Images/icons_template1_nor.gif'");

        BtnEdit.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/icons_modifycontent_ovr.gif'");
        BtnEdit.Attributes.Add("onmouseout", "this.src='../Images/icons_modifycontent_nor.gif'");

        //LoginTemplate Markers 26Mar07 03:12
        loginImgROUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        loginImgUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        passImgROUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        passImgUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        regImgROUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        regImgUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        loginBtnIROUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");
        loginBtnUpload.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.src='../Images/file_icon_over.gif'");

        loginImgROUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        loginImgUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        passImgROUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        passImgUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        regImgROUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        regImgUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        loginBtnIROUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");
        loginBtnUpload.Attributes.Add("onmouseout", "this.src='../Images/file_icon.gif'");


        loginImgROUpload.Attributes.Add("onclick", "javascript:if(!LoginImage()) { return false; };");
        //loginImgUpload.Attributes.Add("onclick", "ShowPopupWindow('FileUpload.aspx?value=LoginImg')");
        loginImgUpload.Attributes.Add("onclick", " window.open('FileUpload.aspx?value=LoginImg',null,'top=300,left=300,height=250, width=500,status= no, resizable= no, scrollbars=no, toolbar=no,location=no,menubar=no')");

        passImgROUpload.Attributes.Add("onclick", "javascript:if(!Passimage()) { return false; };");
        //passImgUpload.Attributes.Add("onclick", "ShowPopupWindow('FileUpload.aspx?value=PassImg')");
        passImgUpload.Attributes.Add("onclick", "window.open('FileUpload.aspx?value=PassImg',null,'top=300,left=300,height=250, width=500,status= no, resizable= no, scrollbars=no, toolbar=no,location=no,menubar=no')");

        regImgROUpload.Attributes.Add("onclick", "javascript:if(!RegisterBtnImage()) { return false; };");
        //regImgUpload.Attributes.Add("onclick", "ShowPopupWindow('FileUpload.aspx?value=RegImg')");
        regImgUpload.Attributes.Add("onclick", "window.open('FileUpload.aspx?value=RegImg',null,'top=300,left=300,height=250, width=500,status= no, resizable= no, scrollbars=no, toolbar=no,location=no,menubar=no')");

        loginBtnIROUpload.Attributes.Add("onclick", "javascript:if(!LoginBtnImage()) { return false; };");
        //loginBtnUpload.Attributes.Add("onclick", "ShowPopupWindow('FileUpload.aspx?value=LoginBtn')");
        loginBtnUpload.Attributes.Add("onclick", "window.open('FileUpload.aspx?value=LoginBtn',null,'top=300,left=300,height=250, width=500,status= no, resizable= no, scrollbars=no, toolbar=no,location=no,menubar=no')");

        //


        if (txtToolBar1.Value == "None")
            txtToolBar1.Value = "";
        
        if (txtToolBar2.Value == "None")
            txtToolBar2.Value = "";
        
        if (txtToolBar3.Value == "None")
            txtToolBar3.Value = "";
        
        if (txtToolBar4.Value == "None")
            txtToolBar4.Value = "";

        if (txtList1.Value == "None")
            txtList1.Value = "";

        if (txtList2.Value == "None")
            txtList2.Value = "";

        if (txtList3.Value == "None")
            txtList3.Value = "";

        if (txtList4.Value == "None")
            txtList4.Value = "";

        if (txtList5.Value == "None")
            txtList5.Value = "";

        if (txtList6.Value == "None")
            txtList6.Value = "";


        
        Session["Products"] = GetPublishHiddenValues();
        
        //BtnPreview.Attributes.Add("onclick", "javascript:ShowPreviewScreen('" + Mode + "','" + dataid + "','" + hidtemp.Value + "','" + Mod.Value + "','" + txtToolBar1.Value + "','" + txtToolBar2.Value + "','" + txtToolBar3.Value + "','" + txtToolBar4.Value + "');return false;");
        BtnPreview.Attributes.Add("onclick", "javascript:ShowPreviewScreen('" + Mode + "','" + dataid + "','" + hidtemp.Value + "','" + Mod.Value + "','" + txtToolBar1.Value + "','" + txtToolBar2.Value + "','" + txtToolBar3.Value + "','" + txtToolBar4.Value + "','" + txtList1.Value + "','" + txtList2.Value + "','" + txtList3.Value + "','" + txtList4.Value + "','" + txtList5.Value + "','" + txtList6.Value + "');return false;");
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        if (FromName == "ChildPage")
        {
            Response.Redirect("ContentBuilderPage.aspx");
        }
        else if(FromName == "AddPage")
        {
            Response.Redirect("AddContent.aspx?Foldid="+ Foldid +"&Mode="+Mode);
        }
        else
        {
            Response.Redirect("ContentBuilderPage.aspx");
        }
       
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
         if (Mode == "modify")
          {

              if (lgCheck == 1 && hidLoginId.Value != "") //26Mar07
              {
                  UpDateLoginProperties();
              }
              else if (Mod1 == "ModT" && hidLoginId.Value == "") //26Mar07
              {
                  int log = AddLoginProperties();
                  hidLoginId.Value = log.ToString();
              }
              else
              {
                  hidLoginId.Value = "0";
              }

              obj.ConDataID = dataid;
              obj.ConName=txtPageName.Text;
              obj.ConHeaderText=txtPageName.Text;
              obj.ConTemplateID=hidtemp.Value;
              obj.aspxfile = txtFilename.Text;

              obj.LoginID = Convert.ToInt16(hidLoginId.Value); //26Mar07


              //26Mar07
              if (txtContent1.Value != "")
                  obj.ConContent1 = txtContent1.Value;
              else
                  obj.ConContent1 = "";
              if (txtContent2.Value != "")
                  obj.ConContent2 = txtContent2.Value;
              else
                  obj.ConContent2 = "";
              if (txtContent3.Value != "")
                  obj.ConContent3 = txtContent3.Value;
              else
                  obj.ConContent3 = "";
              if (txtContent4.Value != "")
                  obj.ConContent4 = txtContent4.Value;
              else
                  obj.ConContent4 = "";
              if (txtContent5.Value != "")
                  obj.ConContent5 = txtContent5.Value;
              else
                  obj.ConContent5 = "";
              if (txtContent6.Value != "")
                  obj.ConContent6 = txtContent6.Value;
              else
                  obj.ConContent6 = "";
              if (txtContent7.Value != "")
                  obj.ConContent7 = txtContent7.Value;
              else
                  obj.ConContent7 = "";
              if (txtContent8.Value != "")
                  obj.ConContent8 = txtContent8.Value;
              else
                  obj.ConContent8 = "";
              if (txtContent9.Value != "")
                  obj.ConContent9 = txtContent9.Value;
              else
                  obj.ConContent9 = "";
              if (txtContent10.Value != "")
                  obj.ConContent10 = txtContent10.Value;
              else
                  obj.ConContent10 = "";
              if (txtContent11.Value != "")
                  obj.ConContent11 = txtContent11.Value;
              else
                  obj.ConContent11 = "";
              if (txtContent12.Value != "")
                  obj.ConContent12 = txtContent12.Value;
              else
                  obj.ConContent12 = "";
              ////

              obj.ConNews1="";
              obj.ConNews2="";
              obj.ConNews3="";
              obj.ConNews4="";
              obj.ConNews5="";
              obj.ConNews6="";
              obj.ConNews7="";
              obj.ConNews8="";
              obj.ConNews9="";
              obj.ConNews10="";
              obj.ConNews11="";
              obj.ConNews12="";
              if (txtToolBar1.Value == "None")
                  txtToolBar1.Value = "";
              obj.ConToolBar1=txtToolBar1.Value;
              if (txtToolBar2.Value == "None")
                  txtToolBar2.Value = "";
              obj.ConToolBar2=txtToolBar2.Value;
              if (txtToolBar3.Value == "None")
                  txtToolBar3.Value = "";
              obj.ConToolBar3=txtToolBar3.Value;
              if (txtToolBar4.Value == "None")
                  txtToolBar4.Value = "";
              obj.ConToolBar4=txtToolBar4.Value;
              if (txtList1.Value == "None")
                  txtList1.Value = "";
              obj.ConList1 = txtList1.Value;
              if (txtList2.Value == "None")
                  txtList2.Value = "";
              obj.ConList2 = txtList2.Value;
              if (txtList3.Value == "None")
                  txtList3.Value = "";
              obj.ConList3 = txtList3.Value;
              if (txtList4.Value == "None")
                  txtList4.Value = "";
              obj.ConList4 = txtList4.Value;
              if (txtList5.Value == "None")
                  txtList5.Value = "";
              obj.ConList5 = txtList5.Value;
              if (txtList6.Value == "None")
                  txtList6.Value = "";
              obj.ConList6 = txtList6.Value;

              //obj.Products = GetPublishHiddenValues();
             
              obj.ConCreatedBy = Convert.ToInt16(Session["UserId"].ToString());
              obj.UpdateContentBuilder();
              Maxid = obj.GetMaxContentId();
              obj.ConDataID = dataid;
          
              string tempCom = hidtemp.Value + ',';

              //add the ToolBar into Links
              if (txtToolBar1.Value != "")
              {
                  Toolids =  "T" + txtToolBar1.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar2.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar2.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar3.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar3.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar4.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar4.Value + ',';
                  tCheck = 1;
              }

              if (tCheck == 1)
              {
                  string Linkval = tempCom + Toolids;
                  obj.UpdateLinksContent(dataid, Linkval);
              }
              else
              {
                  string Linkval = tempCom;
                  obj.UpdateLinksContent(dataid, Linkval);
              }
              tCheck = 0;
          }
          else
          {

              if (lgCheck == 1) //26Mar07
              {
                  logID = AddLoginProperties();
              }

              obj.ConParentID=Foldid;
              obj.ConName=txtPageName.Text;
              obj.ConHeaderText=txtPageName.Text;
              obj.ConTemplateID = hidtemp.Value;
              obj.aspxfile = txtFilename.Text;
              obj.LoginID = logID; //26Mar07 
           
              //26Mar07
              if (txtContent1.Value != "")
                  obj.ConContent1 = txtContent1.Value;
              else
                  obj.ConContent1 = "";
              if (txtContent2.Value != "")
                  obj.ConContent2 = txtContent2.Value;
              else
                  obj.ConContent2 = "";
              if (txtContent3.Value != "")
                  obj.ConContent3 = txtContent3.Value;
              else
                  obj.ConContent3 = "";
              if (txtContent4.Value != "")
                  obj.ConContent4 = txtContent4.Value;
              else
                  obj.ConContent4 = "";
              if (txtContent5.Value != "")
                  obj.ConContent5 = txtContent5.Value;
              else
                  obj.ConContent5 = "";
              if (txtContent6.Value != "")
                  obj.ConContent6 = txtContent6.Value;
              else
                  obj.ConContent6 = "";
              if (txtContent7.Value != "")
                  obj.ConContent7 = txtContent7.Value;
              else
                  obj.ConContent7 = "";
              if (txtContent8.Value != "")
                  obj.ConContent8 = txtContent8.Value;
              else
                  obj.ConContent8 = "";
              if (txtContent9.Value != "")
                  obj.ConContent9 = txtContent9.Value;
              else
                  obj.ConContent9 = "";
              if (txtContent10.Value != "")
                  obj.ConContent10 = txtContent10.Value;
              else
                  obj.ConContent10 = "";
              if (txtContent11.Value != "")
                  obj.ConContent11 = txtContent11.Value;
              else
                  obj.ConContent11 = "";
              if (txtContent12.Value != "")
                  obj.ConContent12 = txtContent12.Value;
              else
                  obj.ConContent12 = "";
              ////

              obj.ConNews1="";
              obj.ConNews2="";
              obj.ConNews3="";
              obj.ConNews4="";
              obj.ConNews5="";
              obj.ConNews6="";
              obj.ConNews7="";
              obj.ConNews8="";
              obj.ConNews9="";
              obj.ConNews10="";
              obj.ConNews11="";
              obj.ConNews12="";
              if (txtToolBar1.Value == "None")
                  txtToolBar1.Value = "";
              obj.ConToolBar1=txtToolBar1.Value;
              if (txtToolBar1.Value == "None")
                  txtToolBar2.Value = "";
              obj.ConToolBar2=txtToolBar2.Value;
              if (txtToolBar3.Value == "None")
                  txtToolBar3.Value = "";
              obj.ConToolBar3=txtToolBar3.Value;
              if (txtToolBar4.Value == "None")
                  txtToolBar4.Value = "";
              obj.ConToolBar4=txtToolBar4.Value;
              //obj.ConLists = txtLists.Value;

              if (txtList1.Value == "None")
                  txtList1.Value = "";
              obj.ConList1 = txtList1.Value;
              if (txtList2.Value == "None")
                  txtList2.Value = "";
              obj.ConList2 = txtList2.Value;
              if (txtList3.Value == "None")
                  txtList3.Value = "";
              obj.ConList3 = txtList3.Value;
              if (txtList4.Value == "None")
                  txtList4.Value = "";
              obj.ConList4 = txtList4.Value;
              if (txtList5.Value == "None")
                  txtList5.Value = "";
              obj.ConList5 = txtList5.Value;
              if (txtList6.Value == "None")
                  txtList6.Value = "";
              obj.ConList6 = txtList6.Value;


             //Get Products Hidden values
             //obj.Products = GetPublishHiddenValues();


              obj.ConCreatedBy = Convert.ToInt16(Session["UserId"].ToString());
              obj.AddNewContentBuilder();
              Maxid = obj.GetMaxContentId();
              obj.ConDataID = Maxid;

              string tempCom = hidtemp.Value + ',';
              
              //add the ToolBar into Links
              if (txtToolBar1.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar1.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar2.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar2.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar3.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar3.Value + ',';
                  tCheck = 1;
              }
              if (txtToolBar4.Value != "")
              {
                  Toolids = Toolids + "T" + txtToolBar4.Value + ',';
                  tCheck = 1;
              }
              if (tCheck == 1)
              {
                  string Linkval = tempCom + Toolids;
                  obj.InsertLinksContent(Linkval);
              }
              else
              {
                  string Linkval = tempCom;
                  obj.InsertLinksContent(Linkval);
              }
          }
          tCheck = 0;
          Response.Redirect("ContentBuilderPage.aspx");
    }
    protected void ContentPage_Click(object sender, EventArgs e)
    {
        dataid = (((LinkButton)(sender)).CommandArgument).ToString();
        for (int i = 0; i < dtRights.Rows.Count; i++)
        {
            if (dtRights.Rows[i]["BuilderId"].ToString() == dataid)
            {
                BtnRights = dtRights.Rows[i]["Rights"].ToString();
            }

            if (dtRights.Rows[i]["Rights"].ToString() == "" && dtRights.Rows[i]["BuilderId"].ToString() == dataid) //21-09-06
            {
                BtnRights = "1111";
            }
        }
        Response.Redirect("DisplayPage.aspx?DataId=" + dataid + "&BtnRights=" + BtnRights);
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx?Subname=" + txtContentSearch.Text + "&Dropname=" + ContentDrop.SelectedItem.Text);
    }
    protected void BtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("ContentBuilderPage.aspx");
    }
    
    protected void AssignContentOnTextboxes()
    {

        if (Mode == "Add")
        {
            //New Changes 26Mar07
            txtContent1.Value = "";
            txtContent2.Value = "";
            txtContent3.Value = "";
            txtContent4.Value = "";
            txtContent5.Value = "";
            txtContent6.Value = "";
            txtContent7.Value = "";
            txtContent8.Value = "";
            txtContent9.Value = "";
            txtContent10.Value = "";
            txtContent11.Value = "";
            txtContent12.Value = "";
            //

            txtToolBar1.Value ="";
            txtToolBar2.Value ="";
            txtToolBar3.Value ="";
            txtToolBar4.Value = "";
            txtList1.Value = "";
            txtList2.Value = "";
            txtList3.Value = "";
            txtList4.Value = "";
            txtList5.Value = "";
            txtList6.Value = "";


            
        }
        else
        {
            if (ContentTb.Rows.Count > 0)
            {
                //26Mar07
                txtContent1.Value = ContentTb.Rows[0]["Content1"].ToString();
                txtContent2.Value = ContentTb.Rows[0]["Content2"].ToString();
                txtContent3.Value = ContentTb.Rows[0]["Content3"].ToString();
                txtContent4.Value = ContentTb.Rows[0]["Content4"].ToString();
                txtContent5.Value = ContentTb.Rows[0]["Content5"].ToString();
                txtContent6.Value = ContentTb.Rows[0]["Content6"].ToString();
                txtContent7.Value = ContentTb.Rows[0]["Content7"].ToString();
                txtContent8.Value = ContentTb.Rows[0]["Content8"].ToString();
                txtContent9.Value = ContentTb.Rows[0]["Content9"].ToString();
                txtContent10.Value = ContentTb.Rows[0]["Content10"].ToString();
                txtContent11.Value = ContentTb.Rows[0]["Content11"].ToString();
                txtContent12.Value = ContentTb.Rows[0]["Content12"].ToString();
                ///

                txtToolBar1.Value = ContentTb.Rows[0]["ToolBar1"].ToString();
                txtToolBar2.Value = ContentTb.Rows[0]["ToolBar2"].ToString();
                txtToolBar3.Value = ContentTb.Rows[0]["ToolBar3"].ToString();
                txtToolBar4.Value = ContentTb.Rows[0]["ToolBar4"].ToString();
                txtList1.Value = ContentTb.Rows[0]["List1"].ToString();
                txtList2.Value = ContentTb.Rows[0]["List2"].ToString();
                txtList3.Value = ContentTb.Rows[0]["List3"].ToString();
                txtList4.Value = ContentTb.Rows[0]["List4"].ToString();
                txtList5.Value = ContentTb.Rows[0]["List5"].ToString();
                txtList6.Value = ContentTb.Rows[0]["List6"].ToString();
            }
        }

    }

    protected void NewTemplateContent()
    {
             
        string[] aryMarkers = new string[12];
        aryMarkers[0] = "##content1##";
        aryMarkers[1] = "##content2##";
        aryMarkers[2] = "##content3##";
        aryMarkers[3] = "##content4##";
        aryMarkers[4] = "##content5##";
        aryMarkers[5] = "##content6##";
        aryMarkers[6] = "##content7##";
        aryMarkers[7] = "##content8##";
        aryMarkers[8] = "##content9##";
        aryMarkers[9] = "##content10##";
        aryMarkers[10] = "##content11##";
        aryMarkers[11] = "##content12##";

        TempContent = TempContent.ToLower();


        if (TempContent.IndexOf("##aspxpage##",0)  > -1)
            aspxRow.Style.Add("display", "inline");


        string[] aryMarkersExists = new string[12];
        int k = 0, m = 0, t = 0;
        DropField.Items.Clear();
        for (int i = 0; i < 12; i++)
        {
            if (TempContent.IndexOf(aryMarkers[i], 0) > -1)
            {
                if (TempContent.IndexOf(aryMarkers[i] + "$", 0) > -1)
                {
                    if (i < 9)
                        stPos = TempContent.IndexOf(aryMarkers[i], 0) + 13;
                    else
                        stPos = TempContent.IndexOf(aryMarkers[i], 0) + 14;

                    edPos = TempContent.Substring(stPos + 2).IndexOf("$", 0);
                    svlFriend = TempContent.Substring(stPos, edPos + 2);

                    aryMarkersExists[k] = aryMarkers[i] + "$" + svlFriend + "$";
                    aryMarkers[k] = aryMarkersExists[k].ToLower();
                    aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                    k = k + 1;
                }
                else
                {
                    aryMarkersExists[k] = aryMarkers[i];
                    aryMarkers[k] = aryMarkersExists[k].ToLower();
                    aryMarkersExists[k] = aryMarkersExists[k].ToLower();
                    k = k + 1;
                }
            }
            else
            {
                k = k + 1;
            }
        }

        for (int i = 0; i < 12; i++)
        {
            if (aryMarkersExists[i] == aryMarkers[i])
            {
                int C = Convert.ToInt16(aryMarkersExists[i].Substring(9, 2).Replace("#", ""));

                svlFriend = "";
                if (TempContent.IndexOf(aryMarkersExists[C - 1], 0) > -1)
                {

                    FieldRow.Attributes.Add("style", "display:black");
                    if (aryMarkersExists[C - 1].IndexOf("$", 0) > -1)
                    {
                        if (i < 9)
                            stPos = TempContent.IndexOf(aryMarkersExists[C - 1], 0) + 13;
                        else
                            stPos = TempContent.IndexOf(aryMarkersExists[C - 1], 0) + 14;
                        edPos = TempContent.Substring(stPos + 2).IndexOf("$", 0);
                        svlFriend = TempContent.Substring(stPos, edPos + 2).Replace("$", "");
                    }
                    if (svlFriend == "")
                    {
                        if (aryMarkersExists[C - 1] != null)
                            DropField.Items.Add(new ListItem(aryMarkersExists[C - 1].ToString().Replace("##", ""), Convert.ToString(i + 1)));
                    }
                    else
                        DropField.Items.Add(new ListItem(svlFriend.Replace("$", ""), Convert.ToString(i + 1)));
                }
            }
            else
            {
                int C = Convert.ToInt16(aryMarkers[i].Substring(9, 2).Replace("#", ""));
              

                //New Changes 26Mar07
                if (C == 1)
                    txtContent1.Value = "";
                else if (C == 2)
                    txtContent2.Value = "";
                else if (C == 3)
                    txtContent3.Value = "";
                else if (C == 4)
                    txtContent4.Value = "";
                else if (C == 5)
                    txtContent5.Value = "";
                else if (C == 6)
                    txtContent6.Value = "";
                else if (C == 7)
                    txtContent7.Value = "";
                else if (C == 8)
                    txtContent8.Value = "";
                else if (C == 9)
                    txtContent9.Value = "";
                else if (C == 10)
                    txtContent10.Value = "";
                else if (C == 11)
                    txtContent11.Value = "";
                if (C == 12)
                    txtContent12.Value = "";
                //

            }
        }

        string[] list = new string[10];
        string[] list1 = new string[10];
        list[0] = "##list1##";
        list[1] = "##list2##";
        list[2] = "##list3##";
        list[3] = "##list4##";
        list[4] = "##list5##";
        list[5] = "##list6##";
        list[6] = "##list7##";
        list[7] = "##list8##";
        list[8] = "##list9##";
        list[9] = "##list10##";

        for (int i = 0; i < 10; i++)
        {
            if (TempContent.IndexOf(list[i], 0) > -1)
            {
                list1[l] = list[i];
                list[l] = list1[l].ToLower();
                list1[l] = list1[l].ToLower();
                l = l + 1;
            }
            else
            {
                l = l + 1;
            }
        }
        DropSelectList.Items.Clear();
        for (int i = 0; i < 10; i++)
        {
            // if (TempContent.IndexOf(list[i], 0) > -1)
            if (list[i] == list1[i])
            {
                list1[m] = list[i];
                m = m + 1;

                Lists objlist = new Lists();
                ListTable = objlist.GetAllListName();
                DropSelectList.Items.Add(list1[i].Replace("##", ""));
                ListRow1.Attributes.Add("style", "display:black");
                ListRow2.Attributes.Add("style", "display:black");
                t = 1;
            }
            else
            {
                int C = i + 1;
                if (C == 1)
                    txtList1.Value = "";
                else if (C == 2)
                    txtList2.Value = "";
                else if (C == 3)
                    txtList3.Value = "";
                else if (C == 4)
                    txtList4.Value = "";
                else if (C == 5)
                    txtList5.Value = "";
                if (C == 6)
                    txtList6.Value = "";

            }
        }
        if (t == 1)
        {
            if (ListTable.Rows.Count > 0)
            {
                DropListName.Items.Add("None");
                DropListName.DataSource = ListTable;
                DropListName.DataValueField = "LBID";
                DropListName.DataTextField = "ListName";
                DropListName.DataBind();
                DropListName.Items.Insert(0, new ListItem("None", "None"));
            }
        }
        DropToolLocation.Items.Clear();
        string[] ToolMark = new string[4];
        ToolMark[0] = "##toolbar1##";
        ToolMark[1] = "##toolbar2##";
        ToolMark[2] = "##toolbar3##";
        ToolMark[3] = "##toolbar4##";
        for (int i = 0; i < 4; i++)
        {
            if (TempContent.IndexOf(ToolMark[i], 0) > -1)
            {
                DropToolLocation.Items.Add(ToolMark[i].Replace("##", ""));
                ToolBarRow1.Attributes.Add("style", "display:black");
                ToolBarRow2.Attributes.Add("style", "display:black");
                DtToolBar = obj.GetToolbars();
                t = 0;
            }
            else
            {
                int C = Convert.ToInt16(ToolMark[i].Substring(9, 1).Replace("#", ""));
                if (C == 1)
                    txtToolBar1.Value = "";
                else if (C == 2)
                    txtToolBar2.Value = "";
                else if (C == 3)
                    txtToolBar3.Value = "";
                if (C == 4)
                    txtToolBar4.Value = "";
            }
        }
        if (t == 0)
        {
            if (DtToolBar.Rows.Count > 0)
            {
                DropSelectTool.DataSource = DtToolBar;
                DropSelectTool.DataValueField = "ButtonID";
                DropSelectTool.DataTextField = "ButtonText";
                DropSelectTool.DataBind();
                DropSelectTool.Items.Insert(0, new ListItem("None", "None"));
            }
        }

        //Login Marker 26Mar07 04:59
        string loginText = "##logintext##";
        string loginField = "##loginfield##";
        string passText = "##passwordtext##";
        string passField = "##passwordfield##";
        string loginBtn = "##login##";
        string registerBtn = "##register##";

        if (TempContent.IndexOf(loginText, 0) > -1)
        {
            trLoginlable1.Attributes.Add("style", "display:block");
            trLoginlable2.Attributes.Add("style", "display:block");
            trLoginlable3.Attributes.Add("style", "display:block");
            trLoginlable4.Attributes.Add("style", "display:block");
            lgCheck = 1;//31Jan07
        }
        if (TempContent.IndexOf(loginField, 0) > -1)
        {
            trLBoxSize.Attributes.Add("style", "display:block");
            lgCheck = 1;
        }
        if (TempContent.IndexOf(passField, 0) > -1)
        {
            trPBoxSize.Attributes.Add("style", "display:block");
            lgCheck = 1;
        }
        if (TempContent.IndexOf(passText, 0) > -1)
        {
            trPassword1.Attributes.Add("style", "display:block");
            trPassword2.Attributes.Add("style", "display:block");
            trPassword3.Attributes.Add("style", "display:block");
            trPassword4.Attributes.Add("style", "display:block");
            lgCheck = 1;//31Jan07
        }
        if (TempContent.IndexOf(loginBtn, 0) > -1)
        {
            trRegister1.Attributes.Add("style", "display:block");
            trRegister2.Attributes.Add("style", "display:block");
            trRegister3.Attributes.Add("style", "display:block");
            trRegister4.Attributes.Add("style", "display:block");
            lgCheck = 1;//31Jan07
        }
        if (TempContent.IndexOf(registerBtn, 0) > -1)
        {
            trLoginBtn1.Attributes.Add("style", "display:block");
            trLoginBtn2.Attributes.Add("style", "display:block");
            trLoginBtn3.Attributes.Add("style", "display:block");
            trLoginBtn4.Attributes.Add("style", "display:block");
            lgCheck = 1;//31Jan07
        }
        DefaultStyleValues(); //26Mar07

        //Products controls display
        New_ShowProductControls();        


    }
    protected void txtPageName_TextChanged(object sender, EventArgs e)
    {

    }
    protected void BtnReset_Click(object sender, EventArgs e)
    {
       if (Mode == "Add")
        {
            txtPageName.Text = "";
        }
    }

    protected void BtnEdit_Click(object sender, ImageClickEventArgs e)
    {

    }


    //userValidation

    protected HtmlTable userValidation()
    {
        //  objToolbar = new Toolbar();
        HtmlTable menuTbl = new HtmlTable();
        HtmlTableRow menuMain = new HtmlTableRow();
        HtmlTableRow menuSub = new HtmlTableRow();
        menuTbl.Width = "100%";
        menuTbl.CellPadding = 0;
        menuTbl.CellSpacing = 0;
        menuTbl.Rows.Add(menuMain);
        menuTbl.Rows.Add(menuSub);
        DataTable dtMenu;
        DataTable dtSubMenu;
        if (Session["UserType"].ToString() == "Admin" || Session["UserType"].ToString() == "Manager")
        {
            dtMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        //if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        //cell.Attributes.Add("onclick", "javascript: document.getElementById('form1').src='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }
                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub'); ");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        else if (Session["UserType"].ToString() == "Private")
        {
            dtMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='Main' and menuorder in (1,2,4,6,7) order by menuorder");
            if (dtMenu.Rows.Count > 0)
                for (int row = 0; row < dtMenu.Rows.Count; row++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    HtmlTableCell cellSub = new HtmlTableCell();
                    cellSub.VAlign = "Top";
                    cell.Width = "140px";
                    cell.Height = "24px";
                    cell.BgColor = "#666666";
                    cell.Style.Add("font-family", "Tahoma");
                    cell.Style.Add("font-size", "8pt");
                    cell.Style.Add("font-weight", "bold");
                    cell.Style.Add("color", "White");
                    cell.Attributes.Add("onmouseover", "javascript:this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                    cell.Attributes.Add("onmouseout", "javascript:this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                    cell.InnerText = "�" + dtMenu.Rows[row]["MenuName"].ToString();
                    if (dtMenu.Rows[row]["MenuName"].ToString() == "ToolBar")
                    {
                        // if (Session["UserType"].ToString() == "Admin")
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Toolbar/ToolBarHome.aspx?Type=none'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Preferences")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Logout")
                    {
                        cell.Attributes.Add("onclick", "javascript: document.forms[0].action='../Login.aspx?Act=Logout'; document.forms[0].submit(); expand('sub');");
                    }
                    else if (dtMenu.Rows[row]["MenuName"].ToString() == "Site Properties")
                    {
                        cell.Attributes.Add("onclick", "javascript:ShowNewJob();");
                    }
                    menuMain.Cells.Add(cell);
                    menuSub.Cells.Add(cellSub);

                    dtSubMenu = obj.ExecuteDTQuery("select * from adminrights where amdrights=1 and menuoption='" + dtMenu.Rows[row]["MenuName"].ToString().Replace(" ", "") + "' order by menuOrder");
                    if (dtSubMenu.Rows.Count > 0)
                    {
                        HtmlTable tblSub = new HtmlTable();
                        tblSub.CellPadding = 0;
                        tblSub.CellSpacing = 0;
                        tblSub.Border = 0;
                        tblSub.Width = cell.Width;
                        tblSub.ID = "sub" + row;
                        cell.Attributes.Add("onclick", "javascript:expand('" + tblSub.ClientID + "');");
                        //cell.Attributes.Add("onmouseout","javascript:expand('sub')");
                        for (int srow = 0; srow < dtSubMenu.Rows.Count; srow++)
                        {
                            HtmlTableRow rowSub = new HtmlTableRow();
                            HtmlTableCell cellSub1 = new HtmlTableCell();
                            cellSub1.BgColor = "#666666";
                            cellSub1.Height = "20px";
                            cellSub1.Style.Add("font-family", "Tahoma");
                            cellSub1.Style.Add("font-size", "8pt");
                            cellSub1.Style.Add("font-weight", "bold");
                            cellSub1.Style.Add("color", "White");
                            cellSub1.Attributes.Add("onmouseover", "this.style.cursor='pointer'; this.style.backgroundColor='#ECF0D3'; this.style.color='#000000';");
                            cellSub1.Attributes.Add("onmouseout", "this.style.backgroundColor='#666666'; this.style.color='#ffffff'; ");
                            cellSub1.InnerText = "��" + dtSubMenu.Rows[srow]["MenuName"].ToString();
                            // cellSub1.Attributes.Add("onmouseout", "javascript:expand('+this.id+')");
                            if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Template Manager")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../TemplateManager/MainPage.aspx?SEARCH=&TYPE=All'; document.forms[0].submit(); expand('sub');"); //"javascript:Redirect('TemplateManager/MainPage.aspx?SEARCH=&TYPE=All');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "User Manager")
                            {
                                if (Session["UserType"].ToString() == "Private")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UserProfile.aspx?UserId=" + Session["UserId"].ToString() + "&FullName=" + Session["FullName"].ToString() + "&Act=Mod'; document.forms[0].submit(); expand('sub');");
                                else if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../UserManager/UsersList.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Group Manager")
                            {
                                if (Session["UserType"].ToString() == "Admin")
                                    cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../GroupManager/AddGroup.aspx?Act=View'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Content Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript:document.forms[0].action='../ContentBuilder/ContentBuilderPage.aspx'; document.forms[0].submit(); expand('sub');");
                                //cellSub1.InnerHtml=http
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Forum")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../Forum/Discussion.aspx'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "Templates")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../TemplateManager/AddTemplates.aspx?Type=All'; document.forms[0].submit(); expand('sub');");
                            }
                            else if (dtSubMenu.Rows[srow]["MenuName"].ToString() == "List Builder")
                            {
                                cellSub1.Attributes.Add("onclick", "javascript: document.forms[0].action='../ListBuilder/MainPage.aspx?SEARCH='; document.forms[0].submit(); expand('sub');");
                            }

                            rowSub.Cells.Add(cellSub1);
                            tblSub.Rows.Add(rowSub);
                        }


                        cellSub.Controls.Add(tblSub);
                        //tblSub.Visible = false;
                        tblSub.Style.Add("display", "none");
                    }

                }
            HtmlTableCell cell1 = new HtmlTableCell();
            cell1.InnerText = "�";
            // cell1.Width = "40%";
            menuMain.Cells.Add(cell1);
            //frmMain.Attributes.Add("src", "login.aspx");
            //if (Session["CBId"] != null) frmMain.Attributes.Add("src", "ContentBuilder/DisplayPage.aspx?DataId=" + Session["CBId"].ToString());

        }
        return menuTbl;

    }

    public void ShowBanner(string value)
    {
        tdBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        leftPanel.Style.Add("display", value);
    }


    //26Mar07
    public int AddLoginProperties()
    {
        //26Mar07
        obj.LoginText = txtLoginText.Text;
        obj.LoginImage = txtLoginImage.Text;
        obj.LoginImageRollOver = txtLoginImageRO.Text;
        obj.LoginImageAltText = txtLoginAltText.Text;
        obj.PasswordText = txtPassText.Text;
        obj.PasswordImage = txtPassImage.Text;
        obj.PasswordImageRollOver = txtPassImageRO.Text;
        obj.PasswordImageAltText = txtPassAltText.Text;
        obj.RegText = txtRegText.Text;
        obj.RegImage = txtRegImage.Text;
        obj.RegImageRollOver = txtRegImageRO.Text;
        obj.RegImageAltText = txtRegAltText.Text;
        obj.SubmitText = txtLoginBtn.Text;
        obj.SubmitImage = txtLoginBtnI.Text;
        obj.SubmitImageRollOver = txtLoginBtnIRO.Text;
        obj.SubmitImageAltText = txtLoginBtnAlt.Text;
        if (txtLHeight.Text != "")
            obj.LoginBoxHeight = Convert.ToInt16(txtLHeight.Text);
        else
            obj.LoginBoxHeight = 20;
        if (txtLWidht.Text != "")
            obj.LoginBoxWidth = Convert.ToInt16(txtLWidht.Text);
        else
            obj.LoginBoxWidth = 85;
        if (txtPHeight.Text != "")
            obj.PasswordBoxHeight = Convert.ToInt16(txtPHeight.Text);
        else
            obj.PasswordBoxHeight = 20;
        if (txtPWidht.Text != "")
            obj.PasswordBoxWidth = Convert.ToInt16(txtPWidht.Text);
        else
            obj.PasswordBoxWidth = 85;

        obj.InsertLoginProperties();
        logID = obj.GetMaxLoginId();
        return logID;
    }//02Feb07

    public void UpDateLoginProperties()//26Mar07
    {
        obj.PropertyID = Convert.ToInt16(hidLoginId.Value);
        obj.LoginText = txtLoginText.Text;
        obj.LoginImage = txtLoginImage.Text;
        obj.LoginImageRollOver = txtLoginImageRO.Text;
        obj.LoginImageAltText = txtLoginAltText.Text;
        obj.PasswordText = txtPassText.Text;
        obj.PasswordImage = txtPassImage.Text;
        obj.PasswordImageRollOver = txtPassImageRO.Text;
        obj.PasswordImageAltText = txtPassAltText.Text;
        obj.RegText = txtRegText.Text;
        obj.RegImage = txtRegImage.Text;
        obj.RegImageRollOver = txtRegImageRO.Text;
        obj.RegImageAltText = txtRegAltText.Text;
        obj.SubmitText = txtLoginBtn.Text;
        obj.SubmitImage = txtLoginBtnI.Text;
        obj.SubmitImageRollOver = txtLoginBtnIRO.Text;
        obj.SubmitImageAltText = txtLoginBtnAlt.Text;
        if (txtLHeight.Text != "")
            obj.LoginBoxHeight = Convert.ToInt16(txtLHeight.Text);
        else
            obj.LoginBoxHeight = 15;
        if (txtLWidht.Text != "")
            obj.LoginBoxWidth = Convert.ToInt16(txtLWidht.Text);
        else
            obj.LoginBoxWidth = 50;
        if (txtPHeight.Text != "")
            obj.PasswordBoxHeight = Convert.ToInt16(txtPHeight.Text);
        else
            obj.PasswordBoxHeight = 15;
        if (txtPWidht.Text != "")
            obj.PasswordBoxWidth = Convert.ToInt16(txtPWidht.Text);
        else
            obj.PasswordBoxWidth = 50;

        obj.UpdateLoginProperties();
        //return logID;
    }//02Feb07

    public void DefaultStyleValues()  //26Mar07
    {
        if (hidDefaultStyle.Value == "1")
        {
            txtLoginText.Text = "User Name";
            txtPassText.Text = "Password";
            txtRegText.Text = "Register";
            txtLoginBtn.Text = "Login";
            txtLHeight.Text = "20";
            txtLWidht.Text = "85";
            txtPHeight.Text = "20";
            txtPWidht.Text = "85";
            hidDefaultStyle.Value = "2";
        }

    }  

    protected void ShowProductControls()
    {
        //Products mark replace 16 July 07
                
        bool bvlProd = false;
        string[] ProductMark = new string[6];
        ProductMark[0] = "##product1##";
        ProductMark[1] = "##product2##";
        ProductMark[2] = "##product3##";
        ProductMark[3] = "##product4##";
        ProductMark[4] = "##product5##";
        ProductMark[5] = "##product6##";
        if(!IsPostBack)
        ddlProductlocation.Items.Clear();
        for (int i = 0; i < 6; i++)
        {
            if (TempContent.IndexOf(ProductMark[i], 0) > -1)
            {
                bvlProd = true;
                if (!IsPostBack)
                    ddlProductlocation.Items.Add("Product" + (i + 1));
            }
            else
            {
                int C = Convert.ToInt16(ProductMark[i].Substring(9, 1).Replace("#", ""));
                if (C == 1)
                {
                    hdnProduct1.Value = "";                    
                }
                else if (C == 2)
                {
                    hdnProduct2.Value = "";
                }
                else if (C == 3)
                {
                    hdnProduct3.Value = "";
                }
                else if (C == 4)
                {
                    hdnProduct4.Value = "";
                }
                else if (C == 5)
                {
                    hdnProduct5.Value = "";
                }
                else if (C == 6)
                {
                    hdnProduct6.Value = "";
                }
            }
        }
        if (bvlProd)
        {
            trProductlocation.Style.Add("display", "inline");
            trSelectproduct.Style.Add("display", "inline");
            trCategory.Style.Add("display", "inline");
            trPreviewtype.Style.Add("display", "inline");

            if (!IsPostBack)
            {
                LoadProductCombo();
                LoadCategoryCombo();
                LoadPreviewCombo();
            }
            if(hdncatcombo.Value == "yes")
            {
                LoadCategoryCombo();
                LoadPreviewCombo();
                int C = Convert.ToInt16(ddlProductlocation.SelectedValue.Substring(7, 1));
                if (C == 1)
                {
                    hdnCategory1.Value = "";
                    hdnViewtype1.Value = "S";
                }
                if (C == 2)
                {
                    hdnCategory2.Value = "";
                    hdnViewtype2.Value = "S";
                }
                if (C == 3)
                {
                    hdnCategory3.Value = "";
                    hdnViewtype3.Value = "S";
                }
                if (C == 4)
                {
                    hdnCategory4.Value = "";
                    hdnViewtype4.Value = "S";
                }
                if (C == 5)
                {
                    hdnCategory5.Value = "";
                    hdnViewtype5.Value = "S";
                }
                if (C == 6)
                {
                    hdnCategory6.Value = "";
                    hdnViewtype6.Value = "S";
                }
            }
            hdncatcombo.Value = "";           
            
        }
    }


    protected void New_ShowProductControls()
    {
        //Products mark replace 16 July 07

        bool bvlProd = false;
        string[] ProductMark = new string[6];
        ProductMark[0] = "##product1##";
        ProductMark[1] = "##product2##";
        ProductMark[2] = "##product3##";
        ProductMark[3] = "##product4##";
        ProductMark[4] = "##product5##";
        ProductMark[5] = "##product6##";
        //if (!IsPostBack)
            ddlProductlocation.Items.Clear();
        for (int i = 0; i < 6; i++)
        {
            if (TempContent.IndexOf(ProductMark[i], 0) > -1)
            {
                bvlProd = true;
                //if (!IsPostBack)
                    ddlProductlocation.Items.Add("Product" + (i + 1));
            }
            else
            {
                int C = Convert.ToInt16(ProductMark[i].Substring(9, 1).Replace("#", ""));
                if (C == 1)
                    hdnProduct1.Value = "";
                else if (C == 2)
                    hdnProduct2.Value = "";
                else if (C == 3)
                    hdnProduct3.Value = "";
                else if (C == 4)
                    hdnProduct4.Value = "";
                else if (C == 5)
                    hdnProduct5.Value = "";
                else if (C == 6)
                    hdnProduct6.Value = "";
            }
        }
        if (bvlProd)
        {
            trProductlocation.Style.Add("display", "inline");
            trSelectproduct.Style.Add("display", "inline");
            trCategory.Style.Add("display", "inline");
            trPreviewtype.Style.Add("display", "inline");

            //if (!IsPostBack)

            if (hdncatcombo.Value == "yes")
            {
                LoadCategoryCombo();
                LoadPreviewCombo();

                int C = Convert.ToInt16(ddlProductlocation.SelectedValue.Substring(7, 1));
                if (C == 1)
                {
                    hdnCategory1.Value = "";
                    hdnViewtype1.Value = "S";
                }
                if (C == 2)
                {
                    hdnCategory2.Value = "";
                    hdnViewtype2.Value = "S";
                }
                if (C == 3)
                {
                    hdnCategory3.Value = "";
                    hdnViewtype3.Value = "S";
                }
                if (C == 4)
                {
                    hdnCategory4.Value = "";
                    hdnViewtype4.Value = "S";
                }
                if (C == 5)
                {
                    hdnCategory5.Value = "";
                    hdnViewtype5.Value = "S";
                }
                if (C == 6)
                {
                    hdnCategory6.Value = "";
                    hdnViewtype6.Value = "S";
                }
            }
            else
            {
                    LoadProductCombo();
                    if (ddlSelectproduct.SelectedValue != "")
                    {
                        hdnProduct1.Value = ddlSelectproduct.SelectedValue;
                    }
                    LoadCategoryCombo();
                    LoadPreviewCombo();
            }
            hdncatcombo.Value = "";

        }
    }

    protected void LoadProductControls(string svlProducts)
    {        
        string[] arrProducts = svlProducts.Split(',');
        for (int i = 0; i < arrProducts.Length-1; i++)
        {
            string svlIds = arrProducts[i].ToString();            
            string[] arrIds = svlIds.Split('#');
            if(i==0)
            {
                hdnProduct1.Value = arrIds[0].ToString();
                hdnCategory1.Value = arrIds[1].ToString();
                hdnViewtype1.Value = arrIds[2].ToString();

                ddlSelectproduct.SelectedValue = hdnProduct1.Value;
                LoadCategoryCombo();
                ddlCategory.SelectedValue = hdnCategory1.Value;
                ddlPreviewtype.SelectedValue = hdnViewtype1.Value;

            }
            else if(i==1)
            {
                hdnProduct2.Value = arrIds[0].ToString();
                hdnCategory2.Value = arrIds[1].ToString();
                hdnViewtype2.Value = arrIds[2].ToString();
            }
            else if (i == 2)
            {
                hdnProduct3.Value = arrIds[0].ToString();
                hdnCategory3.Value = arrIds[1].ToString();
                hdnViewtype3.Value = arrIds[2].ToString();
            }
            else if (i == 3)
            {
                hdnProduct4.Value = arrIds[0].ToString();
                hdnCategory4.Value = arrIds[1].ToString();
                hdnViewtype4.Value = arrIds[2].ToString();
            }
            else if (i == 4)
            {
                hdnProduct5.Value = arrIds[0].ToString();
                hdnCategory5.Value = arrIds[1].ToString();
                hdnViewtype5.Value = arrIds[2].ToString();
            }
            else if (i == 5)
            {
                hdnProduct6.Value = arrIds[0].ToString();
                hdnCategory6.Value = arrIds[1].ToString();
                hdnViewtype6.Value = arrIds[2].ToString();
            }
        }

        if (ddlProductlocation.SelectedValue != "")
        {
            switch (ddlProductlocation.SelectedValue)
            {
                case "1":
                    ddlSelectproduct.SelectedValue = hdnProduct1.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory1.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype1.Value;
                    break;
                case "2":
                    ddlSelectproduct.SelectedValue = hdnProduct2.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory2.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype2.Value;
                    break;
               case "3":
                   ddlSelectproduct.SelectedValue = hdnProduct3.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory3.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype3.Value;
                    break;
                case "4":
                    ddlSelectproduct.SelectedValue = hdnProduct4.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory4.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype4.Value;
                    break;
                case "5":
                    ddlSelectproduct.SelectedValue = hdnProduct5.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory5.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype5.Value;
                    break;
                case "6":
                    ddlSelectproduct.SelectedValue = hdnProduct6.Value;
                    LoadCategoryCombo();
                    ddlCategory.SelectedValue = hdnCategory6.Value;
                    ddlPreviewtype.SelectedValue = hdnViewtype6.Value;
                    break;

            }                
           
        }

        
    }

    protected string GetPublishHiddenValues()
    {
        string svlproducts = "";
        if (hdnProduct1.Value == "None")
            hdnProduct1.Value = "";        
        if (hdnProduct2.Value == "None")
            hdnProduct2.Value = "";
        if (hdnProduct3.Value == "None")
            hdnProduct3.Value = "";
        if (hdnProduct4.Value == "None")
            hdnProduct4.Value = "";
        if (hdnProduct5.Value == "None")
            hdnProduct5.Value = "";
        if (hdnProduct6.Value == "None")
            hdnProduct6.Value = "";

        if (hdnProduct1.Value == "")
        {
            hdnCategory1.Value = "";
            hdnViewtype1.Value = "";
        }
        if (hdnProduct2.Value == "")
        {
            hdnCategory2.Value = "";
            hdnViewtype2.Value = "";
        }
        if (hdnProduct3.Value == "")
        {
            hdnCategory3.Value = "";
            hdnViewtype3.Value = "";
        }
        if (hdnProduct4.Value == "")
        {
            hdnCategory4.Value = "";
            hdnViewtype4.Value = "";
        }
        if (hdnProduct5.Value == "")
        {
            hdnCategory5.Value = "";
            hdnViewtype5.Value = "";
        }
        if (hdnProduct6.Value == "")
        {
            hdnCategory6.Value = "";
            hdnViewtype6.Value = "";
        }

        svlproducts = hdnProduct1.Value + "#" + hdnCategory1.Value + "#" + hdnViewtype1.Value + ",";
        svlproducts += hdnProduct2.Value + "#" + hdnCategory2.Value + "#" + hdnViewtype2.Value + ",";
        svlproducts += hdnProduct3.Value + "#" + hdnCategory3.Value + "#" + hdnViewtype3.Value + ",";
        svlproducts += hdnProduct4.Value + "#" + hdnCategory4.Value + "#" + hdnViewtype4.Value + ",";
        svlproducts += hdnProduct5.Value + "#" + hdnCategory5.Value + "#" + hdnViewtype5.Value + ",";
        svlproducts += hdnProduct6.Value + "#" + hdnCategory6.Value + "#" + hdnViewtype6.Value;

        return svlproducts;
    }

    public string ReplaceWithQuotes(string ContentToReplace)
    {
        ContentToReplace = ContentToReplace.Trim();
        if (!ContentToReplace.StartsWith("'"))
        {
            string[] aryContentToReplace = new string[100];
            ContentToReplace = ContentToReplace.Replace(",,", ",");
            if (ContentToReplace.Trim().Length >= 1)
            {
                if (ContentToReplace.StartsWith(","))
                    ContentToReplace = ContentToReplace.Substring(1);
                if (ContentToReplace.EndsWith(","))
                    ContentToReplace = ContentToReplace.Substring(0, ContentToReplace.Length - 1);
                aryContentToReplace = ContentToReplace.Split(',');
                ContentToReplace = "";
                for (int i = 0; i <= aryContentToReplace.Length - 1; i++)
                {
                    if (ContentToReplace.Trim() != "")
                        ContentToReplace = ContentToReplace + ",";
                    ContentToReplace = ContentToReplace + "'" + aryContentToReplace[i] + "'";
                }
            }
            else
                ContentToReplace = "";

        }
        if (ContentToReplace == "")
            ContentToReplace = "''";
        return ContentToReplace;

    }
    protected void LoadProductCombo()
    {
        ddlSelectproduct.Items.Clear();
        //dtPublishProducts = obj.GetPublishProducts();
        if (dtPublishProducts.Rows.Count > 0)
        {
            ddlSelectproduct.DataSource = dtPublishProducts;
            ddlSelectproduct.DataValueField = "UniqueID";
            ddlSelectproduct.DataTextField = "Name";
            ddlSelectproduct.DataBind();
        }
        else
        {
            ddlSelectproduct.Items.Insert(0, new ListItem("None", ""));
        }
    }
    protected void LoadCategoryCombo()
    {
        ddlCategory.Items.Clear();
        if (ddlSelectproduct.SelectedValue != "")
        {
            string svlquery = "Select * from Productpublish Where DeletedFlag='N' And  UniqueId=" + ddlSelectproduct.SelectedValue + "";
            dtProductDetails = obj.ExecuteDTQuery(svlquery);
            string svlProdId = "", svlAddtocombo = "", svlExculCatIds = "";
            if (dtProductDetails.Rows.Count > 0)
            {
                svlProdId = dtProductDetails.Rows[0]["ProductId"].ToString();
                svlAddtocombo = dtProductDetails.Rows[0]["AddtoCombo"].ToString();
                svlExculCatIds = dtProductDetails.Rows[0]["ExcludeCategory"].ToString();
            }

            if (svlAddtocombo == "N")
            {
                //obj.ProductId = svlProdId;
                //obj.ExcludeCategory = ReplaceWithQuotes(svlExculCatIds);
                //dtCategory = obj.GetProductCategory();

                if (dtCategory.Rows.Count > 0)
                {
                    ddlCategory.DataSource = dtCategory;
                    ddlCategory.DataValueField = "CategoryID";
                    ddlCategory.DataTextField = "CategoryName";
                    ddlCategory.DataBind();
                }
            }
        }
        ddlCategory.Items.Insert(0, new ListItem("All Categories", ""));       


    }
    protected void LoadPreviewCombo()
    {
        ddlPreviewtype.Items.Clear();
        ddlPreviewtype.Items.Insert(0, new ListItem("Single Product Per Row", "S"));
        ddlPreviewtype.Items.Insert(1, new ListItem("Multiple Products Per Row", "M"));

    }



   
}
