
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using NGWS.CMPApplication;

public partial class ListBuilder_EditEntries : System.Web.UI.Page
{
    int[] cellwidth = new int[10];
    bool cbold;
    string str1, itm_id, listitmqry, hdrqry;
    string[] name, hdnfld;
    string LBIds = "";
    string[] rangeData = new string[1000];  
    int newrow_count = 0, dup_rowcount = 0, dec_ctr = 2;
    public string hbold, listid, idval;
    int Columncount, RowCount;
    int x, y, z;
    public string HForecolor, Hbordercolor, HBgcolor, CFontSize, HFontName, HFontsize, CFontColor, CFontName, CBGColor, CBGAltColor, GFontColor, GBGColor, HBorder, innertxt;
    DataTable dt1 = new DataTable();
    DataTable temp = new DataTable();
    Lists db = new Lists();
    Lists lstObj = new Lists();
    DataRow newrow;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        lblUser.Text = Session["FullName"].ToString();
        fullList.Controls.Add(display_top10list());

        if (!Page.IsPostBack)
        {
            dup_rowcount = 0;
            newrow_count = 0;
            dec_ctr = 2;
            ViewState["dup_rowcount"] = "0";
            ViewState["newrow_count"] = "0";
            ViewState["dec_ctr"] = "2";
        }

        dup_rowcount = int.Parse(ViewState["dup_rowcount"].ToString());
        newrow_count = int.Parse(ViewState["newrow_count"].ToString());
        dec_ctr = int.Parse(ViewState["dec_ctr"].ToString());


        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End
        
        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());

        DataTable dt = new DataTable();
        
        
        listid = Request.QueryString["LBID"];
       

        string stritm = "select count(listbuilderid) from ListItems where listbuilderid='" + listid + "'";
        
        dt = db.GetAllLists(listid);
        if (dt.Rows.Count > 0)
            Columncount = int.Parse(dt.Rows[0]["columncount"].ToString());
        hdrqry = "select  listitemid,";
        for (x = 1; x < Columncount + 1; x++)
        {
            hdrqry += "field" + x.ToString();
            if (x != Columncount)
                hdrqry += ",";
        }
        hdrqry += " from listitems where listbuilderid='" + listid + "' and rowid in('2') order by rowid";

        temp = db.ExecuteDTQuery(hdrqry);
        cellwidth[0] = 0;
        if(temp.Rows.Count>0)
        for (x = 1; x <= Columncount; x++)
        {
            cellwidth[x] = int.Parse(temp.Rows[0][x].ToString());
        }
        listitmqry = "select listitemid,";
        for (x = 1; x < Columncount + 1; x++)
        {
            listitmqry += "field" + x.ToString();
            if (x != Columncount)
                listitmqry += ",";
        }
        listitmqry += " from listitems where listbuilderid='" + listid + "'  and rowid not in('2') order by rowid";

        dt = db.GetAllLists(listid);


        if (dt.Rows.Count > 0)
        {

            Columncount = Convert.ToInt16(dt.Rows[0]["ColumnCount"].ToString());
            RowCount = Convert.ToInt16(db.ExecuteScalar(stritm).ToString());
            string hdr = dt.Rows[0]["HeaderText"].ToString();
            string itmname = dt.Rows[0]["listname"].ToString();
            string align = dt.Rows[0]["TableAlignment"].ToString();
            if (align.Equals("C"))
                align = "center";
            int width = Convert.ToInt32(dt.Rows[0]["TableWidth"].ToString());
            int cellpad = Convert.ToInt32(dt.Rows[0]["Cellpadding"].ToString());


            HFontName = dt.Rows[0]["HeaderFontType"].ToString();
            HFontsize = dt.Rows[0]["HeaderFontSize"].ToString();
            string HFontbold = dt.Rows[0]["HeaderFontBold"].ToString();

            if (HFontbold.Equals("True"))
                hbold = "bold";
            else
                hbold = "normal";
            if (dt.Rows[0]["HeaderFontColor"].ToString() != "")
                HForecolor = color(dt.Rows[0]["HeaderFontColor"].ToString());
            if (dt.Rows[0]["Border"].ToString() != "")
                HBorder = dt.Rows[0]["Border"].ToString();

            if (dt.Rows[0]["Bordercolor"].ToString() != "")
                Hbordercolor = color(dt.Rows[0]["Bordercolor"].ToString());

            if (dt.Rows[0]["HeaderBgcolor"].ToString() != "")
                HBgcolor = color(dt.Rows[0]["HeaderBgcolor"].ToString());

            //Cell Attributes
            CFontName = dt.Rows[0]["CellFontType"].ToString();
            CFontSize = dt.Rows[0]["CellFontSize"].ToString();
            string CFontBold = dt.Rows[0]["CellFontBold"].ToString();

            if (CFontBold.Equals("True"))
                cbold = true;
            else
                cbold = false;

            if (dt.Rows[0]["CellFontColor"].ToString() != "")
                CFontColor = color(dt.Rows[0]["CellFontColor"].ToString());

            if (dt.Rows[0]["CellBGColor"].ToString() != "")
                CBGColor = color(dt.Rows[0]["CellBGColor"].ToString());

            if ((dt.Rows[0]["CellBGAltColor"].ToString() != ""))
                CBGAltColor = color(dt.Rows[0]["CellBGAltColor"].ToString());
            else
                CBGAltColor = CBGColor;

            //Group Header Attributes
            string GFontName = dt.Rows[0]["HeadFontType"].ToString();
            int GFontSize = Convert.ToInt32(dt.Rows[0]["HeadFontSize"].ToString());
            string GFontBold = dt.Rows[0]["HeadFontBold"].ToString();
            if (GFontBold.Equals("True"))
                GFontBold = "bold";
            else
                GFontBold = "normal";

            if (dt.Rows[0]["HeadFontColor"].ToString() != "")
                GFontColor = color(dt.Rows[0]["HeadFontColor"].ToString());

            if (dt.Rows[0]["HeadBGColor"].ToString() != "")
                GBGColor = color(dt.Rows[0]["HeadBGColor"].ToString());
            int span = Columncount + 1;

            innertxt += "<table align='" + align + "' width='" + width.ToString() + "%' cellPadding='" + cellpad + "' cellSpacing='0'   bordercolor='" + Hbordercolor + "' >";
            innertxt += "<tr bgcolor='" + GBGColor + "' Style = 'font-family:" + GFontName + ";font-size:" + GFontSize + "pt;font-weight:" + GFontBold + ";color:" + GFontColor + "' ><td colspan=" + span + ">" + hdr + "</td></tr>";
            innertxt += "</table>";

            tab.InnerHtml = innertxt;
            dgtab.Align = align;
            dgtab.Width = System.Web.UI.WebControls.Unit.Percentage((double)width).ToString();

            dg.BorderColor = System.Drawing.Color.FromName(Hbordercolor);
            dg.BorderWidth = System.Web.UI.WebControls.Unit.Pixel(int.Parse(HBorder));



            dg.ItemStyle.BackColor = System.Drawing.Color.FromName(CBGAltColor);

            dg.ItemStyle.ForeColor = System.Drawing.Color.FromName(CFontColor);
            dg.ItemStyle.Font.Name = CFontName;
            dg.ItemStyle.Font.Size = System.Web.UI.WebControls.FontUnit.Parse(CFontSize);
            dg.ItemStyle.Font.Bold = cbold;
            dg.AlternatingItemStyle.BackColor = System.Drawing.Color.FromName(CBGColor);


            dg.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
            dt1 = db.ExecuteDTQuery(listitmqry);
            DataColumn colDelete = new DataColumn("Delete");
            //colDelete.DataTyp
            dt1.Columns.Add(colDelete);
            if (!Page.IsPostBack)
                ViewState["add_flag"] = "norm";

            if (ViewState["add_flag"].ToString().Equals("add"))
            {

                for (x = 0; x < newrow_count; x++)
                {
                    newrow = dt1.NewRow();

                    int k;
                    for (k = 0; k < Columncount; k++)
                        newrow[k] = "";
                    //dt1.Columns.Add();
                    dt1.Rows.Add(newrow);

                }
            }
            if (dt1.Rows.Count > 0)
                dg.DataSource = dt1;
            dg.DataBind();
        }
       
        delete.Attributes.Add("onclick", "javascript:return del('" + idval + "')");

    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {

                    lbl = new LinkButton();
                    lbl.Text = row["listname"].ToString();
                    lbl.Font.Size = 8;
                    lbl.Font.Name = "Tahoma";
                    lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                    lbl.Style.Add("text-decoration", "none");
                    TableRow tr = new TableRow();
                    TableCell td = new TableCell();
                    td.Controls.Add(lbl);
                    tr.Cells.Add(td);
                    dispTbl.Rows.Add(tr);

                    lbl.CommandArgument = row["lbid"].ToString();
                    lbl.Click += new EventHandler(Select_Click);
                    lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                    lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

                }
            }
        }

        return dispTbl;
    }
    private void Select_Click(object sender, System.EventArgs e)
    {

        string lstid = (((LinkButton)(sender)).CommandArgument).ToString();

        Session["lstname"] = lstid;
        Response.Redirect("Listitem.aspx?LBID=" + lstid);
    }
    public string color(string colorname)
    {
        x = y = z = 0;
        if (colorname.Length > 8)
        {
            x = colorname.IndexOf("(", x);
            y = colorname.IndexOf(")", y);
            z = (y - (x + 1));
            colorname = colorname.Substring(x + 1, z);
            return (colorname);
        }
        else
            return (colorname);
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    

    protected void dg_ItemDataBound1(object sender, DataGridItemEventArgs e)
    {
        
        
        e.Item.Cells[0].Visible = false;
        CheckBox chkDelete = new CheckBox();
        chkDelete.ID = e.Item.Cells[0].Text;
        if (Page.IsPostBack)
        {
            if (e.Item.ItemIndex < dt1.Rows.Count - newrow_count)
            {
                e.Item.Cells[dt1.Columns.Count - 1].Controls.Add(chkDelete);
               
            }
        }
        else
        {
           e.Item.Cells[dt1.Columns.Count - 1].Controls.Add(chkDelete);
           
        }

        if (e.Item.ItemIndex == 0)
        {
            Label[] hdr = new Label[dt1.Columns.Count - 1];
            for (x = 0; x < dt1.Columns.Count-1 ; x++)
            {
                hdr[x] = new Label();
                hdr[x].Text = e.Item.Cells[x].Text;
                hdr[x].Style.Add("color", HForecolor);
                hdr[x].Style.Add("font-weight", hbold);
                hdr[x].Style.Add("font-family", HFontName);
                hdr[x].Style.Add("font-size", System.Web.UI.WebControls.FontUnit.Point(int.Parse(HFontsize)).ToString());
                e.Item.Cells[x].BackColor = System.Drawing.Color.FromName(HBgcolor);
                e.Item.Cells[x].BorderColor = System.Drawing.Color.FromName("black");
                e.Item.Cells[x].BorderWidth = 1;
                e.Item.Cells[x].Controls.Add(hdr[x]);
            }
            e.Item.Cells[dt1.Columns.Count - 1].Text = "Delete";
            e.Item.Cells[dt1.Columns.Count - 1].Font.Bold = (hbold == "bold") ? true : false;
            e.Item.Cells[dt1.Columns.Count - 1].ForeColor = System.Drawing.Color.FromName(HForecolor);
            e.Item.Cells[dt1.Columns.Count - 1].BackColor = System.Drawing.Color.FromName(HBgcolor);
            e.Item.Cells[dt1.Columns.Count - 1].Font.Name = HFontName;
            e.Item.Cells[dt1.Columns.Count - 1].Font.Size = System.Web.UI.WebControls.FontUnit.Point(int.Parse(HFontsize));
            e.Item.Cells[dt1.Columns.Count - 1].BorderColor = System.Drawing.Color.FromName("black");
            e.Item.Cells[dt1.Columns.Count - 1].BorderWidth = 1;
        }
        else
        {
            for (x = 0; x < dt1.Columns.Count-1 ; x++)
            {
                if (e.Item.Cells[x].Text.StartsWith("<a target") || e.Item.Cells[x].Text.StartsWith("<img")|| e.Item.Cells[x].Text.StartsWith("~RTF~") ||(e.Item.Cells[x].Text.StartsWith("<a href='..")))
                {
                    //TextBox txt = new TextBox();
                    HtmlTextArea txt = new HtmlTextArea();
                    HiddenField hdn = new HiddenField();
                    e.Item.Cells[x].BorderColor = System.Drawing.Color.FromName("black");
                    e.Item.Cells[x].BorderWidth = 1;
                    e.Item.Cells[x].Width = System.Web.UI.WebControls.Unit.Percentage((double)cellwidth[x]);
                    if (e.Item.Cells[x].Text.Equals("&nbsp;"))
                        txt.InnerText = "";
                    else
                        txt.InnerText = data(e.Item.Cells[x].Text);
                    
                    hdn.Value = hdnVal(e.Item.Cells[x].Text);
                    
                    txt.Style.Add("width", "80%");
                    txt.Rows = 1;
                    txt.Style.Add("overflow", "hidden");
                    txt.Style.Add("font-family", CFontName);
                    txt.Style.Add("font-size", "12");
                    
                    txt.ID = "txt" + e.Item.ItemIndex.ToString() + "" + x.ToString();
                    e.Item.Cells[x].Controls.Add(txt);
                    e.Item.Cells[x].Controls.Add(hdn);
                    HtmlImage img = new HtmlImage();
                    
                    e.Item.Cells[x].Controls.Add(img);
                    if (e.Item.Cells[x].Text.StartsWith("<a href='.."))
                    {
                        img.Attributes.Add("onclick", "javascript:openFile('Page','" + hdn.ClientID + "','" + txt.ClientID + "','" + x + "')");
                        img.Alt = "Add Page Link";
                        img.Src = "../Images/icons/Data.gif";
                        txt.Disabled = false;
                        
                    }
                    else if (e.Item.Cells[x].Text.StartsWith("<a target"))
                    {
                        img.Attributes.Add("onclick", "javascript:openFile('Document','" + hdn.ClientID + "','" + txt.ClientID + "','"+ x +"')");
                        img.Alt = "Upload Document";
                        img.Src ="../Images/file_icon.jpg";
                        txt.Disabled = false;
                    }
                    else if (e.Item.Cells[x].Text.StartsWith("<img"))
                    {
                        img.Attributes.Add("onclick", "javascript:openFile('Images','" + hdn.ClientID + "','" + txt.ClientID + "','" + x + "')");
                        img.Alt = "Upload Image";
                        img.Src = "../Images/icons/ImageUploader.gif";
                        txt.Disabled = true;
                    }
                    else if (e.Item.Cells[x].Text.StartsWith("~RTF~"))
                    {
                        img.Attributes.Add("onclick", "javascript:openFile('Rich Text','" + hdn.ClientID + "','" + txt.ClientID + "','" + e.Item.Cells[0].Text + "','" + x + "')");
                        img.Alt = "Add Rich Text";
                        img.Src = "../Images/icons_modifycontent_nor.gif";
                        txt.Disabled = true;
                    }
                    img.Style.Add("cursor", "hand");
                    
                    
                }
                else
                {
                    HtmlTextArea txt = new HtmlTextArea();
                    HiddenField hdn = new HiddenField();
                    e.Item.Cells[x].BorderColor = System.Drawing.Color.FromName("black");
                    e.Item.Cells[x].BorderWidth = 1;
                    e.Item.Cells[x].Width = System.Web.UI.WebControls.Unit.Percentage((double)cellwidth[x]);

                    if (e.Item.Cells[x].Text.Equals("&nbsp;"))
                        txt.InnerText = "";
                    else
                        txt.InnerText = data(e.Item.Cells[x].Text);
                    hdn.Value = hdnVal(e.Item.Cells[x].Text);
                    
                    txt.Style.Add("overflow", "hidden");
                    txt.Style.Add("border-width", "0");
                    txt.Style.Add("font-family", CFontName);
                    txt.Style.Add("font-size", System.Web.UI.WebControls.FontUnit.Parse(CFontSize).ToString());
                    txt.Style.Add("width", "96%");
                    txt.ID = "txt" + e.Item.ItemIndex.ToString() + "" + x.ToString();
                    e.Item.Cells[x].Controls.Add(txt);
                    e.Item.Cells[x].Controls.Add(hdn);
                }

            }
            e.Item.Cells[dt1.Columns.Count - 1].BorderColor = System.Drawing.Color.FromName("black");
            e.Item.Cells[dt1.Columns.Count - 1].BorderWidth = 1;
       
        }

    }

    protected void addrow_Click(object sender, EventArgs e)
    {
        newrow_count += 1;
        ViewState["newrow_count"] = newrow_count.ToString();
        int cnt = dt1.Rows.Count;
        int k;
        int dec = dec_ctr++;
        ViewState["dec_ctr"] = dec_ctr.ToString();
        for (x = 0; x < cnt + newrow_count - (dec); x++)
        {
            for (k = 0; k <= Columncount; k++)
            {
                HtmlTextArea newrow_txt = new HtmlTextArea();
                newrow_txt = (HtmlTextArea)(dg.Items[x + 1].Cells[k].Controls[0]);
                string name = "txt" + x.ToString() + "" + k.ToString();
                ViewState[name] = data(newrow_txt.InnerText);

                HiddenField newhdn_fld = new HiddenField();
                newhdn_fld = (HiddenField)(dg.Items[x + 1].Cells[k].Controls[1]);
                string hdnname = "hdn" + x.ToString() + "" + k.ToString();
                ViewState[hdnname] = hdnVal(newhdn_fld.Value);
            }
        }

        dt1 = db.ExecuteDTQuery(listitmqry);
        dt1.Columns.Add();
        ViewState["add_flag"] = "add";

        for (x = 0; x < newrow_count; x++)
        {
            newrow = dt1.NewRow();


            for (k = 0; k <=Columncount; k++)
            {
                string name = "txt" + x.ToString() + "" + k.ToString();
                if (x != newrow_count - 1)
                {
                    string t = ViewState[name].ToString();
                    newrow[k] = ViewState[name].ToString();
                }
                else
                    newrow[k] = "";
            }
            dt1.Rows.Add(newrow);
        }
        dg.DataSource = dt1;
        dg.DataBind();
        for (x = 0; x < cnt - 1; x++)
        {
            for (k = 0; k <= Columncount; k++)
            {
                string name = "txt" + x.ToString() + "" + k.ToString();
                HtmlTextArea newrow_txt = new HtmlTextArea();
                newrow_txt = (HtmlTextArea)(dg.Items[x + 1].Cells[k].Controls[0]);
                newrow_txt.InnerText = ViewState[name].ToString();

                string hdnname = "hdn" + x.ToString() + "" + k.ToString();
                HiddenField newhdn_fld = new HiddenField();
                newhdn_fld = (HiddenField)(dg.Items[x + 1].Cells[k].Controls[1]);
                newhdn_fld.Value = ViewState[hdnname].ToString();
            }
        }

    }
    protected void delete_Click(object sender, EventArgs e)
    {
        int cnt = dt1.Rows.Count-newrow_count;
        int k;
        for (x = 0; x < cnt - 1; x++)
        {

            CheckBox ocb = (CheckBox)(dg.Items[x + 1].Cells[dt1.Columns.Count - 1].Controls[0]);

            if (ocb.Checked.Equals(true))
            {
                idval += dg.Items[x+1].Cells[0].Text + ",";
            }
         
         }
         Lists udb = new Lists();
        if (idval != null)
            if (idval != "")
            {
                string ids;
                string[] id = idval.Split(new Char[] { ',' });
                int i;
                for (i = 0; i < id.Length - 1; i++)
                {
                    ids = id[i];
                    udb.DeleteItems(ids);
                }
            }
        
        SqlCommand cmdListBuilder = new SqlCommand("sp_updateLBwithLI");
        cmdListBuilder.CommandType = CommandType.StoredProcedure;
        cmdListBuilder.Parameters.AddWithValue("@id", listid);
       // cmdListBuilder.Parameters.AddWithValue("@createdby", Session["UserId"].ToString());
        udb.ExecuteNonQuery(cmdListBuilder);
       
       // Response.Redirect("EditEntries.aspx?LBID=" + listid);


        //Modification on 09Jan2007

        for (x = cnt - 1; x < cnt + newrow_count - 1; x++)
        {
            for (k = 0; k <= Columncount; k++)
            {
                HtmlTextArea newrow_txt = new HtmlTextArea();
                newrow_txt = (HtmlTextArea)(dg.Items[x + 1].Cells[k].Controls[0]);
                string name = "new" + x.ToString() + "" + k.ToString();
                ViewState[name] = data(newrow_txt.InnerText);
            }
        }

        dt1 = db.ExecuteDTQuery(listitmqry);
        dt1.Columns.Add();



        for (x = cnt - 1; x < cnt + newrow_count - 1; x++)
        {
            newrow = dt1.NewRow();
            for (k = 0; k <= Columncount; k++)
            {
                string name = "new" + x.ToString() + "" + k.ToString();
                {
                    string t = ViewState[name].ToString();
                    newrow[k] = ViewState[name].ToString();
                }

            }
            dt1.Rows.Add(newrow);

        }
        dg.DataSource = dt1;
        dg.DataBind();


        //End of Modification
    }
    public string seperate_id(string id)
    {
        int index = id.IndexOf("_", 4);
        string sep_id = id.Substring(index + 1);
        return sep_id;
    }
    protected void savelist_Click(object sender, EventArgs e)
    {
        
			int ctr;
			
			for(ctr=0;ctr<dg.Items.Count-1;ctr++)
			{			
				
				Lists db1=new Lists();
				Lists db2=new Lists();
				Lists db3=new Lists();
				string st="select max(rowid) from listitems where listbuilderid='"+ listid+"'";
				name=new string[10];
                hdnfld = new string[10];
				
				Lists itm=new Lists();
				string str1=Request.QueryString["LBID"];

				if(ViewState["add_flag"].ToString().Equals("add"))
				{				
					for(x=0;x<=Columncount-1;x++)
					{
						HtmlTextArea txtarea=new HtmlTextArea();
						txtarea=(HtmlTextArea)(dg.Items[dg.Items.Count-newrow_count].Cells[x+1].Controls[0]);
						name[x]=data(txtarea.InnerText);

                        HiddenField hdnfield = new HiddenField();
                        hdnfield = (HiddenField)(dg.Items[dg.Items.Count - newrow_count].Cells[x + 1].Controls[1]);
                        hdnfld[x] = hdnVal(hdnfield.Value);
					}
					newrow_count--;
					dup_rowcount++;
                    ViewState["newrow_count"] = newrow_count.ToString();
                    ViewState["dec_ctr"] = dec_ctr.ToString();

				}
				else
				{
					for(x=0;x<=Columncount-1;x++)
					{
						HtmlTextArea txtarea1=new HtmlTextArea();
						txtarea1=(HtmlTextArea)(dg.Items[ctr+1-dup_rowcount].Cells[x+1].Controls[0]);
						name[x]=data(txtarea1.InnerText);

                        HiddenField hdnfield = new HiddenField();
                        hdnfield = (HiddenField)(dg.Items[ctr + 1 - dup_rowcount].Cells[x + 1].Controls[1]);
                        hdnfld[x] = hdnVal(hdnfield.Value);
					}
					HtmlTextArea itmid=new HtmlTextArea();
					itmid=(HtmlTextArea)(dg.Items[ctr+1-dup_rowcount].Cells[0].Controls[0]);
					itm_id=itmid.InnerText;
				}
				
				itm.field1=name[0];
				itm.field2=name[1];
				itm.field3=name[2];
				itm.field4=name[3];
				itm.field5=name[4];
				itm.field6=name[5];
				itm.field7=name[6];
				itm.field8=name[7];
				itm.field9=name[8];
				itm.field10=name[9];

				
				
				
				itm.listbuilderid=str1;
                itm.createdby = int.Parse(Session["UserId"].ToString());
				itm.stat="N";
				if(ViewState["add_flag"].ToString().Equals("add"))
				{
					int datafl=0;
					for(x=0;x<=Columncount-1;x++)
					{
                        if (!name[x].Equals(""))
                        {
                            datafl = 0;
                            break;
                        }
                        else
                            datafl = 1;
					}
					if(datafl!=1)
					{
						string j=db3.ExecuteScalar(st);
						int k=int.Parse(j);
                        k += 1;
                        itm.rowid = k.ToString();

                        itm.createdby = Int32.Parse(Session["UserId"].ToString());
                        itm.inserttolistitems();
											
					}
					if(newrow_count==0)
						ViewState["add_flag"]="norm";
				}
				else
				{
                    DataTable oldData = itm.GetAllListDetails(itm_id);
                    for (int ccnt = 0; ccnt < 10; ccnt++)
                    {
                        int col = ccnt + 1;
                        string data=oldData.Rows[0]["field" + col.ToString()].ToString();
                        //if (data.Length > 11)
                        {
                            if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("<a href='.."))
                            {
                                string hrefVal = name[ccnt];
                                name[ccnt] = hdnfld[ccnt] + hrefVal + "</a>";
                            }
                            else if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("<a href='h"))
                            {
                                string hrefVal = name[ccnt];
                                name[ccnt] = "<a href='http://" + hrefVal + "' target='_new'>" + hrefVal + "</a>";
                            }
                            else if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("<a href='m"))
                            {
                                string hrefVal = name[ccnt];
                                name[ccnt] = "<a href='mailto:" + hrefVal + "'>" + hrefVal + "</a>";
                            }
                            else if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("<a target"))
                            {
                                string hrefVal = name[ccnt];
                                name[ccnt] = "<a target='_blank'  href='../Images/ListBuilder/Documents/" + hdnfld[ccnt]  + "' >" +hrefVal + "</a>";
                            }
                            else if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("<img"))
                            {
                                string hrefVal = name[ccnt];
                                name[ccnt] = "<img src='../Images/ListBuilder/Images/" + hdnfld[ccnt] + "'>";
                            }
                            else if (oldData.Rows[0]["field" + col.ToString()].ToString().StartsWith("~RTF~"))
                            {
                                name[ccnt] = "~RTF~"+hdnfld[ccnt];
                            }
                        }
                    }
                    itm.field1 = name[0];
                    itm.field2 = name[1];
                    itm.field3 = name[2];
                    itm.field4 = name[3];
                    itm.field5 = name[4];
                    itm.field6 = name[5];
                    itm.field7 = name[6];
                    itm.field8 = name[7];
                    itm.field9 = name[8];
                    itm.field10 = name[9];
                    itm.listitemid = itm_id;
                    itm.modifytolistitem_itmid();
					
				}

			}
			dup_rowcount=0;
			newrow_count=0;
            dec_ctr = 2;
            ViewState["newrow_count"] = newrow_count.ToString();
            ViewState["dec_ctr"] = dec_ctr.ToString();
            UpDateLinks();
			Response.Redirect("listitem.aspx?LBID="+listid);
		}

    private void UpDateLinks()
    {
        Lists itm = new Lists();
        string qry = "select ";
        for (int cnt = 1; cnt <= Columncount; cnt++)
        {
            qry += "field" + cnt;
            if (cnt != Columncount)
                qry += ",";
        }
        qry += " from listitems where listbuilderid='" + listid + "' and rowid not in (1,2)";

        DataTable dtListItems = new DataTable();
        dtListItems = itm.ExecuteDTQuery(qry);

        string LinkedIds = "";
        if (dtListItems.Rows.Count > 0)
        {
            for (int rcnt = 0; rcnt < dtListItems.Rows.Count; rcnt++)
            {
                for (int ccnt = 0; ccnt < dtListItems.Columns.Count; ccnt++)
                {
                    if (dtListItems.Rows[rcnt][ccnt].ToString().StartsWith("<a href="))
                    {
                        if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("DA") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("DA"), 8) + ",";
                        }
                        else if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("CS") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("CS"), 8) + ",";
                        }
                        else if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("=LB") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("=LB"), 8) + ",";
                        }
                    }
                }
            }
        }

        string updateqry = "update Links set LinkTo='" + LinkedIds + "' where source='" + listid+"'";
        itm.ExecuteNonQuery(updateqry);
    }
    public string data(string addr)
    {
        string data = "";
        //if (addr.Length > 10)
        {
            if (addr.StartsWith("<a href='"))
            {
                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);

                return data;
            }
            else if ((addr.StartsWith("<img")))
            {
                int k = 0;
                int i = addr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if (addr.StartsWith("<a target"))
            {

                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);

                return data;
            }
            else if (addr.StartsWith("~RTF~"))
            {
                return "Rich Text";
            }
            else
                return addr;
        }
        
    }


    public string hdnVal(string addr)
    {
        string data = "";
        //if (addr.Length > 10)
        {
            if (addr.StartsWith("<a href='.."))
            {
                string[] datas = addr.Split('>');
                data = datas[0] + ">";
                return data;
            }
            else if (addr.StartsWith("<a href='"))
            {
                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);

                return data;
            }
            else if ((addr.StartsWith("<img")))
            {
                int k = 0;
                int i = addr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if (addr.StartsWith("<a target"))
            {

                string tempaddr = addr.Substring(0, addr.Length - 4);
                int i = tempaddr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                int k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if (addr.StartsWith("~RTF~"))
            {
                addr=addr.Remove(0,5);
                return addr;
            }
            else
                return addr;
        }
       

    }


    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //trLeft1.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        leftPanel.Style.Add("display", value);
    }

    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length > 0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);
        return LBIds;
    }


    protected void lnkbtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
    }
}
