using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ListBuilder_Preview : System.Web.UI.Page
{

    Lists lstObj = new Lists();
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        if (Request.QueryString["PageType"] == null)
        {
            SiteInfo.ValidateSession();
            trTitle.Style.Add("display", "inline");
            trLine.Style.Add("display", "inline");
        }
        else
        {
            trTitle.Style.Add("display", "none");
            trLine.Style.Add("display", "none");
            //Page.Title = Session["SiteName"].ToString();
            string str1 = Request.QueryString["LBID"].ToString();
            string sql = "Select * from listBuilder where ListTable = '1' and LBID='" + str1 + "'";
            DataTable dt = new DataTable("Dt");
            SqlCommand cmd = new SqlCommand(sql);
            dt = lstObj.ExecuteDTQuery(cmd);
            data2.InnerHtml = lstObj.GetPreview(str1);
        }
    }
    
}
