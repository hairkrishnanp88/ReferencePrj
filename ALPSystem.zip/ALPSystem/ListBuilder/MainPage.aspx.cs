using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.Text;
using System.Data.SqlClient;

public partial class ListBuilder_MainPage : System.Web.UI.Page
{
    Lists lstObj = new Lists();
    LinkButton[] lbl;
    int Flag=0;
    string searchkeyword = "";
    string LBIds = "";
    string[] rangeData = new string[1000];  
    Boolean add = false, mod = false, del = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End
            // Top Banner Displaying
            ShowBanner(Session["Banner"].ToString());

            //LeftPanel Displaying
            ShowPanel(Session["Panel"].ToString());


            
            Session["Column"] = "None";
            searchkeyword = Request.QueryString["SEARCH"].ToString();

            if (!Session["UserType"].ToString().ToLower().Equals("admin"))
            {
                CheckRights(); //For Button Visible..

                if (add)
                {
                    lnkbtnAdd.Style.Add("display", "inline");
                }
                else
                {
                    lnkbtnAdd.Style.Add("display", "none");
                }


            }

            string range = UserTopics();

            rangeData = range.Split(',');


			DataTable dt=new DataTable();
            dt = lstObj.List(searchkeyword);
			
			Table tab=new Table();
			lbl=new LinkButton[dt.Rows.Count];
			int i=0;
            if (!Session["UserType"].ToString().ToLower().Equals("admin"))
            {
                if (dt.Rows.Count > 0)
                {
                    foreach (System.Data.DataRow row in dt.Rows)
                    {
                        Flag = 0;
                        for (int j = 0; j < rangeData.Length; j++)
                        {
                            if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                            {
                                System.Web.UI.WebControls.FontUnit pt = 8;
                                lbl[i] = new LinkButton();
                                lbl[i].ForeColor = System.Drawing.Color.Black;
                                lbl[i].Text = row["ListName"].ToString();
                                lbl[i].Font.Size = pt;
                                lbl[i].Font.Name = "Verdana";
                                lbl[i].Style.Add("text-decoration", "none");
                                lbl[i].Width = System.Web.UI.WebControls.Unit.Percentage(100);
                                TableRow tr = new TableRow();
                                TableCell td = new TableCell();

                                td.Controls.Add(lbl[i]);

                                tr.Cells.Add(td);
                                tab.Rows.Add(tr);


                                lbl[i].Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                                lbl[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                                lbl[i].CommandArgument = row["LBID"].ToString();
                                lbl[i].Click += new EventHandler(Select_Click);
                                i++;
                                displayTemplates.Controls.Add(tab);
                            }
                        }

                    }
                }
            }
            else
            {
                if (dt.Rows.Count > 0)
                {
                    foreach (System.Data.DataRow row in dt.Rows)
                    {

                        System.Web.UI.WebControls.FontUnit pt = 8;
                        lbl[i] = new LinkButton();
                        lbl[i].ForeColor = System.Drawing.Color.Black;
                        lbl[i].Text = row["ListName"].ToString();
                        lbl[i].Font.Size = pt;
                        lbl[i].Font.Name = "Verdana";
                        lbl[i].Style.Add("text-decoration", "none");
                        lbl[i].Width = System.Web.UI.WebControls.Unit.Percentage(100);
                        TableRow tr = new TableRow();
                        TableCell td = new TableCell();

                        td.Controls.Add(lbl[i]);

                        tr.Cells.Add(td);
                        tab.Rows.Add(tr);


                        lbl[i].Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                        lbl[i].Attributes.Add("onmouseout", "this.style.color='#000000';");

                        lbl[i].CommandArgument = row["LBID"].ToString();
                        lbl[i].Click += new EventHandler(Select_Click);
                        i++;
                        displayTemplates.Controls.Add(tab);


                    }
                }
            }
            fullList.Controls.Add(display_top10list());

            

		}
		

        
    private void Select_Click(object sender, System.EventArgs e)
		{
			
				string lstid=(((LinkButton)(sender)).CommandArgument).ToString();

                Session["lstname"] = lstid;
				Response.Redirect("Listitem.aspx?LBID="+lstid);
		}
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {

                    lbl = new LinkButton();
                    lbl.Text = row["listname"].ToString();
                    lbl.Font.Size = 8;
                    lbl.Font.Name = "Tahoma";
                    lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                    lbl.Style.Add("text-decoration", "none");
                    TableRow tr = new TableRow();
                    TableCell td = new TableCell();
                    td.Controls.Add(lbl);
                    tr.Cells.Add(td);
                    dispTbl.Rows.Add(tr);

                    lbl.CommandArgument = row["lbid"].ToString();
                    lbl.Click += new EventHandler(Select_Click);
                    lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                    lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

                }
            }
        }

        return dispTbl;
    }

    protected void lnkbtnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("Addlist.aspx?ACT=NEW");
    }
    
    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //trLeft1.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        leftPanel.Style.Add("display", value);
    }

    public void CheckRights()
    {

        UserManager objUser = new UserManager();
        DataTable dtCombiRights = new DataTable();
        objUser.Userid = int.Parse(Session["UserId"].ToString());
        dtCombiRights = objUser.LBRights("", "");
        if (dtCombiRights.Rows.Count > 0)
        {
            foreach (DataRow row in dtCombiRights.Rows)
            {
                string strRights = row[1].ToString();
                if (strRights != "")
                {
                    if (strRights.Substring(0, 1).Equals("1"))
                    {
                        add = true;
                    }
                    if (strRights.Substring(1, 1).Equals("1"))
                    {
                        mod = true;
                    }
                    if (strRights.Substring(2, 1).Equals("1"))
                    {
                        del = true;
                    }
                }

            }
        }
    }
    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();
        
        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() +",";                        
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length >0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);        
        return LBIds;
    }


}
