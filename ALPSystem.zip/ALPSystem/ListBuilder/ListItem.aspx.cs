using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.Drawing;

public partial class ListBuilder_ListItem : System.Web.UI.Page
{
    string st, sel_ids = "", col = "";
    public string str1, itmname;
    string LBIds = "";
    string[] rangeData = new string[1000];  
    Boolean add1 = false, mod1 = false, del1 = false,view1=false;
    Lists lstObj = new Lists();
    int Flag = 0;
    public CheckBox[] cb;
    public ImageButton[] ib;
    public Table tbl = new Table();
    public static string recordcount = "";
    public LinkButton[] lbl;
    public int n;
    public int Columncount, RowCount;
    public string innertxt = "", row = "",idval="";
    int x, y, z;
    public string HForecolor, Hbordercolor, HBgcolor, CFontColor, CBGColor, CBGAltColor, GFontColor, GBGColor, HBorder;
    DataTable ListTable;
    DataTable ListItem;
    DataTable listcount;
    string ListBuild;
    int  Border, Alter;
    string  GHbgcolor, HeadFontbold, CFontBold, HFontbold;
    string HeadFontcolor, CellAlign, CellSpace;
    int[] Cellwidth;
    
    

    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["PageType"] == null)
        {
            SiteInfo.SetSiteName(this);
            SiteInfo.ValidateSession();
            //Page.Title = Session["SiteName"].ToString();
            lblUser.Text = Session["FullName"].ToString();
            fullList.Controls.Add(display_top10list());
            str1 = Request.QueryString["LBID"].ToString();

            // Start Menu Displaying    
            if (Session["UserType"].ToString() != "Anonymous")
            {
                tdMenu.Style.Add("display", Session["MenuRights"].ToString());

                divMenu.Controls.Add(SiteInfo.userValidation());
                //HtmlTable tst=new HtmlTable();

                //divMenu.Controls.Add(tst);
                //divMenu.InnerHtml = SiteInfo.userValidation();
                // Top Banner Displaying
                ShowBanner(Session["Banner"].ToString());

                //LeftPanel Displaying
                ShowPanel(Session["Panel"].ToString());
            }
            //End
            else 
            {
                // Top Banner Displaying
                //ShowBanner("none");
                //LeftPanel Displaying
                //ShowPanel("none");

                Response.Redirect("Preview.aspx?PageType=PUB&LBID=" + Request.QueryString["LBID"].ToString());
                

            
            }


            DataTable dt = new DataTable();
            dt = lstObj.GetAllLists(str1);
            add.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
            add.Attributes.Add("onmouseout", "this.style.color='blue';");
            edit.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
            edit.Attributes.Add("onmouseout", "this.style.color='blue';");
            mod.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
            mod.Attributes.Add("onmouseout", "this.style.color='blue';");
            delete.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
            delete.Attributes.Add("onmouseout", "this.style.color='blue';");
            back.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
            back.Attributes.Add("onmouseout", "this.style.color='blue';");
            delete.Attributes.Add("onclick", "javascript:if(!confirm('Do you want to remove the list?')) {return false;} ;");
            if (dt.Rows.Count > 0)
                itmname = dt.Rows[0]["ListName"].ToString();
            if (!Session["UserType"].ToString().ToLower().Equals("admin"))
            {
                CheckRights();
                //if (view1)
                //{
                //    tblOuter.Style.Add("display", "inline");
                //}
                //else
                //{
                //    tblOuter.Style.Add("display", "none");
                //}
                if (add1)
                {
                    tdAdd.Style.Add("display", "inline");
                }
                else
                {
                    tdAdd.Style.Add("display", "none");
                }
                if (del1)
                {
                    tdDel.Style.Add("display", "inline");
                }
                else
                {
                    tdDel.Style.Add("display", "none");
                }
                if (mod1)
                {
                    tdMod.Style.Add("display", "inline");
                    tdEdit.Style.Add("display", "inline");
                    Modify.Style.Add("display", "inline");
                    AddData.Style.Add("display", "inline");
                    Del.Style.Add("display", "inline");
                }
                else
                {
                    tdMod.Style.Add("display", "none");
                    tdEdit.Style.Add("display", "none");
                    Modify.Style.Add("display", "none");
                    AddData.Style.Add("display", "none");
                    Del.Style.Add("display", "none");
                }
            }

            else
            {
                mod.Style.Add("display", "inline");
                delete.Style.Add("display", "inline");
            }
            if (!Page.IsPostBack)
            {
                view.InnerText += itmname;
            }
            data2.InnerHtml = "";
            data2.InnerHtml = GetList(str1);



            st = Session["records"].ToString();

            Preview.Attributes.Add("onclick", "javascript:window.open('Preview.aspx?PageType=PUB&LBID=" + str1 + "','','scrollbars=1,resizable=1,status=0,center=1')");
            Del.Attributes.Add("onclick", "javascript:return del('" + st + "')");
        }
        else
        {
            if (Request.QueryString["PageType"].ToString() == "PUB")
            {
                //ShowBanner("none");
                //ShowPanel("none");
                //Table2.Style.Add("display", "none");
                //Table3.Style.Add("display", "none");
                Response.Redirect("Preview.aspx?PageType=PUB&LBID=" + Request.QueryString["LBID"].ToString());
                
            }
        }
        

    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    //public Table getList(DataTable data)
    //{
    //    LinkButton lbl;
    //    Table dispTbl = new Table();
    //    if (data.Rows.Count > 0)
    //    {
    //        foreach (System.Data.DataRow row in data.Rows)
    //        {
    //            lbl = new LinkButton();
    //            lbl.Text = row["listname"].ToString();
    //            lbl.Font.Size = 8;
    //            lbl.Font.Name = "Tahoma";
    //            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
    //            lbl.Style.Add("text-decoration", "none");
    //            TableRow tr = new TableRow();
    //            TableCell td = new TableCell();
    //            td.Controls.Add(lbl);
    //            tr.Cells.Add(td);
    //            dispTbl.Rows.Add(tr);

    //            lbl.CommandArgument = row["lbid"].ToString();
    //            lbl.Click += new EventHandler(Select_Click);
    //            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
    //            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

    //        }
    //    }
    //    return dispTbl;
    //}
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                   
                        lbl = new LinkButton();
                        lbl.Text = row["listname"].ToString();
                        lbl.Font.Size = 8;
                        lbl.Font.Name = "Tahoma";
                        lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                        lbl.Style.Add("text-decoration", "none");
                        TableRow tr = new TableRow();
                        TableCell td = new TableCell();
                        td.Controls.Add(lbl);
                        tr.Cells.Add(td);
                        dispTbl.Rows.Add(tr);

                        lbl.CommandArgument = row["lbid"].ToString();
                        lbl.Click += new EventHandler(Select_Click);
                        lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                        lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                  
                }
            }
        }

        return dispTbl;
    }
    private void Select_Click(object sender, System.EventArgs e)
    {

        string lstid = (((LinkButton)(sender)).CommandArgument).ToString();

        Session["lstname"] = lstid;
        Response.Redirect("Listitem.aspx?LBID=" + lstid);
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void add_Click(object sender, EventArgs e)
    {
        Response.Redirect("Addlist.aspx?&ACT=NEW");
    }
    protected void mod_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddList.aspx?LBID=" + str1 +"&ACT=MOD");
    }
    protected void AddData_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddData.aspx?ACT=NEW&LBID=" + str1);
    }
    protected void Modify_Click(object sender, EventArgs e)
    {
        

        DataTable dt = lstObj.GetListItem4modhdr(str1);
        if (dt.Rows.Count > 0)
            Response.Redirect("ModifyHeader.aspx?ACT=MOD&LBID=" + str1);
        else
            Response.Redirect("ModifyHeader.aspx?ACT=NEW&LBID=" + str1);
    }
    protected void Del_Click(object sender, EventArgs e)
    {
        sel_ids = Request.QueryString["selected"];
        if (sel_ids != null)
            if (sel_ids != "")
            {
                string ids;
                string[] id = sel_ids.Split(new Char[] { ',' });
                int i;
                for (i = 0; i < id.Length - 1; i++)
                {
                    ids = id[i];


                    lstObj.DeleteItems(ids);
                }
            }
        Lists udb = new Lists();
        SqlCommand cmdListBuilder = new SqlCommand("sp_updateLBwithLI");
        cmdListBuilder.CommandType = CommandType.StoredProcedure;
        cmdListBuilder.Parameters.AddWithValue("@id", str1);
        //cmdListBuilder.Parameters.AddWithValue("@createdby", Session["UserId"].ToString());
        udb.ExecuteNonQuery(cmdListBuilder);
        Response.Redirect("ListItem.aspx?LBID=" + str1);
    }
    protected void back_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void edit_Click(object sender, EventArgs e)
    {
        if (Flag != 1)
        {
            Response.Redirect("EditEntries.aspx?LBID=" + str1);
        }
    }
    public string GetList(string ListID)
    {
        try
        {
            Alter = 1;
            
            cmd = new SqlCommand("sp_select_lists");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@listbuilderid", SqlDbType.VarChar, 50));
            cmd.Parameters["@listbuilderid"].Value = ListID;
            
            ListTable =lstObj.ExecuteDTQuery(cmd);


            //cmd = new SqlCommand("sp_select_listitems");
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add(new SqlParameter("@listitemid", SqlDbType.VarChar, 50));
            //cmd.Parameters["@listitemid"].Value = ListID;
            
            //ListItem =lstObj.ExecuteDTQuery(cmd);
            string column = (ListTable.Rows[0]["sortby"] != null && !ListTable.Rows[0]["sortby"].ToString().Equals("None") && !ListTable.Rows[0]["sortby"].ToString().Equals("")) ? ListTable.Rows[0]["sortby"].ToString() : "rowid";
            string order;
            if (!column.Equals("rowid"))
            {
                order = (ListTable.Rows[0]["sortorder"].ToString().Equals("A")) ? "asc" : "desc";
            }
            else
            {
                order = "asc";
            }
            string qry ="";
            if (!column.Equals("rowid"))
            {
                qry= "select listitemid,RowID,Stat,Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8,Field9,Field10,substring(" + column + " ,1,6) as orderfield from ListItems where listbuilderid='" + ListID + "' and rowid not in (1,2)  order by orderfield " + order + "";
            }
            else
            {
                qry = "select listitemid,RowID,Stat,Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8,Field9,Field10 as orderfield from ListItems where listbuilderid='" + ListID + "' and rowid not in (1,2)  order by rowid " + order + "";
            }
            string hdrqry = "select listitemid,RowID,Stat,Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8,Field9,Field10 from ListItems where listbuilderid='" + ListID + "' and rowid in (1,2) order by rowid";
            ListItem = lstObj.ExecuteDTQuery(qry);
            DataTable ListHdr = lstObj.ExecuteDTQuery(hdrqry);
            cmd = new SqlCommand("sp_count_listitems");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@listid", SqlDbType.VarChar, 50));
            cmd.Parameters["@listid"].Value = ListID;
            

            listcount =lstObj.ExecuteDTQuery(cmd);

            RowCount = Convert.ToInt16(listcount.Rows[0][0].ToString());
            Columncount = Convert.ToInt16(ListTable.Rows[0]["ColumnCount"].ToString());

            //Main heading
            string align = ListTable.Rows[0]["Tablealignment"].ToString();
            if (align == "C" || align == "center" || align == "CENTER")
                align = "center";
            else if (align == "L" || align == "Left")
                align = "left";
            else
                align = "right";
            int width = Convert.ToInt32(ListTable.Rows[0]["TableWidth"].ToString());
            int cellpad = Convert.ToInt32(ListTable.Rows[0]["Cellpadding"].ToString());
            //int cellspace=Convert.ToInt16(ListTable.Rows[0]["New_Cellspacing"].ToString());
            string HFontName = ListTable.Rows[0]["HeaderFontType"].ToString();
            int HFontsize = Convert.ToInt32(ListTable.Rows[0]["HeaderFontSize"].ToString());
            string HFontbold1 = ListTable.Rows[0]["HeaderFontBold"].ToString();
            if (HFontbold1.Equals("True"))
                HFontbold = "bold";
            else
                HFontbold = "normal";

            if (ListTable.Rows[0]["HeaderFontColor"].ToString() != "")
                HForecolor = color(ListTable.Rows[0]["HeaderFontColor"].ToString());

            if (ListTable.Rows[0]["Bordercolor"].ToString() != "")
                Hbordercolor = color(ListTable.Rows[0]["Bordercolor"].ToString());

            if (ListTable.Rows[0]["HeaderBgcolor"].ToString() != "")
                HBgcolor = color(ListTable.Rows[0]["HeaderBgcolor"].ToString());

            //Cell Attributes
            string CFontName = ListTable.Rows[0]["CellFontType"].ToString();
            int CFontSize = Convert.ToInt32(ListTable.Rows[0]["CellFontSize"].ToString());
            string CFontBold1 = ListTable.Rows[0]["CellFontBold"].ToString();
            if (CFontBold1.Equals("True"))
                CFontBold = "bold";
            else
                CFontBold = "normal";

            if (ListTable.Rows[0]["CellFontColor"].ToString() != "")
                CFontColor = color(ListTable.Rows[0]["CellFontColor"].ToString());

            if (ListTable.Rows[0]["CellBGColor"].ToString() != "")
                CBGColor = color(ListTable.Rows[0]["CellBGColor"].ToString());

            if ((ListTable.Rows[0]["CellBGAltColor"].ToString() != ""))
                CBGAltColor = color(ListTable.Rows[0]["CellBGAltColor"].ToString());
            else
                CBGAltColor = CBGColor;

            if (ListTable.Rows[0]["CellAlignment"].ToString() != "")
                CellAlign =ListTable.Rows[0]["CellAlignment"].ToString();
            if (CellAlign == "C" || CellAlign == "center" || CellAlign == "CENTER")
                CellAlign = "center";
            else if (CellAlign == "L" || CellAlign == "Left")
                CellAlign = "left";
            else
                CellAlign = "right";


            if (ListTable.Rows[0]["Border"].ToString() != "")
                Border = Convert.ToInt16(ListTable.Rows[0]["Border"].ToString());

            //Table Heading attributes
            if (ListTable.Rows[0]["HeadBGColor"].ToString() != "")
                GHbgcolor = color(ListTable.Rows[0]["HeadBGColor"].ToString());

            if (ListTable.Rows[0]["HeadFontColor"].ToString() != "")
                HeadFontcolor = color(ListTable.Rows[0]["HeadFontColor"].ToString());

            string HeadFontbold1 = ListTable.Rows[0]["HeadFontBold"].ToString();
            if (HeadFontbold1.Equals("True"))
                HeadFontbold = "bold";
            else
                HeadFontbold = "normal";

            string HeadFontName = ListTable.Rows[0]["HeadFontType"].ToString();

            int HeadFontSize = Convert.ToInt32(ListTable.Rows[0]["HeadFontSize"].ToString());
            string idval = "";

            Cellwidth = new int[Columncount + 1];

            if (ListHdr.Rows.Count > 1)
            {

                if (ListHdr.Rows[1]["Stat"].ToString() == "Y")
                {
                    for (int j = 1; j <= Columncount; j++)
                    {
                        Cellwidth[j] = (Convert.ToInt16(ListHdr.Rows[1]["Field" + j].ToString()));
                    }

                }
            }
            else
            {
                AddData.Style.Add("display", "none");
                Flag = 1;
                edit.Attributes.Add("onclick","javascript: alert('No Table Header found for this List. Please click Modify Header to add the Header.');return false;");
                ListBuild = "<font color='Red' face='Verdana' style='font-size:8pt'>No Table Header found for this List.<br> Please click Modify Header to add the Header.</font>";
                Session["records"] = "";
                return (ListBuild);
            }

            
            ListBuild = "";
            ListBuild += "<table align='center' width='" + width + "%'><tr align='left'><td colspan='" + Columncount + "' bgcolor='" +GHbgcolor + "' Style = 'font-family:" + HeadFontName + ";font-size:" + HeadFontSize + "pt;font-weight:" + HeadFontbold + ";color:" + HeadFontcolor + "' >" + ListTable.Rows[0]["HeaderText"].ToString() + "</td></tr></table>";
            ListBuild += "<br>";
            ListBuild += "<table align='center' width='" + width + "%' cellPadding='" + cellpad + "' border='" + Border + "pt' bordercolor='" + Hbordercolor + "' cellSpacing='" + CellSpace + "'>";

            int tstcnt = ListItem.Rows.Count;
            if (ListHdr.Rows[0]["Stat"].ToString() == "H")
            {
                ListBuild += "<tr>";
                for (int j = 1; j <= Columncount; j++)
                {
                    ListBuild += "<td bgcolor='" + HBgcolor + "' align='"+align+"' width='" + Cellwidth[j] + "%' Style = 'font-family:" + HFontName + ";font-size:" + HFontsize + "pt;font-weight:" + HFontbold + ";color:" + HForecolor + "'>" + ListHdr.Rows[0]["Field" + j] + "</td>";

                }
                if (mod1 || Session["UserType"].ToString().ToLower().Equals("admin"))
                {
                    ListBuild += "<td bgcolor='" + HBgcolor + "' align='" + align + "' Style = 'font-family:" + HFontName + ";font-size:" + HFontsize + "pt;font-weight:" + HFontbold + ";color:" + HForecolor + "'>Edit</td><td bgcolor='" + HBgcolor + "' align='" + align + "' Style = 'font-family:" + HFontName + ";font-size:" + HFontsize + "pt;font-weight:" + HFontbold + ";color:" + HForecolor + "'>Delete</td></tr>";
                }
                
            }
            for (int i = 0; i < RowCount ; i++)
            {
                if ((Alter == 1))
                {
                    ListBuild += "<tr bgcolor='" + CBGColor + "' Style = 'font-family:" + CFontName + ";font-size:" + CFontSize + "pt;font-weight:" + CFontBold + ";color:" + CFontColor + "'>";
                    for (int j = 1; j <= Columncount; j++)
                    {
                        if ((ListItem.Rows[i]["Stat"].ToString() != "H"))
                            ListBuild += "<td width='" + Cellwidth[j] + "%' align='" + CellAlign + "'>&nbsp;" + data(ListItem.Rows[i]["Field" + j].ToString()) + "</td>";

                        Alter = 0;
                    }
                    if (mod1 || Session["UserType"].ToString().ToLower().Equals("admin"))
                    {
                        ListBuild += "<td align=center><img alt='' id='e";
                        ListBuild += i.ToString();
                        int row_cnt = i + 1;
                        string row = ListItem.Rows[i]["rowid"].ToString();

                        ListBuild += "'src='../Images/edit.gif' onmouseover=this.style.cursor='hand' onclick=javascript:newwin('" + row + "')";

                        ListBuild += "></td><td align=center ><input type='checkbox' id='" + ListItem.Rows[i]["listitemid"].ToString() + "'>";


                        ListBuild += "</tr></td>";
                    }
                    idval += ListItem.Rows[i]["listitemid"].ToString() + ",";

                }
                else if ((Alter == 0))
                {
                    ListBuild += "<tr bgcolor='" + CBGAltColor + "' Style = 'font-family:" + CFontName + ";font-size:" + CFontSize + "pt;font-weight:" + CFontBold + ";color:" + CFontColor + "'>";
                    for (int j = 1; j <= Columncount; j++)
                    {
                        if ((ListItem.Rows[i]["Stat"].ToString() != "H"))
                            ListBuild += "<td width='" + Cellwidth[j] + "%' align='" + CellAlign + "'>&nbsp;" + data(ListItem.Rows[i]["Field" + j].ToString()) + "</td>";
                        Alter = 1;
                    }
                    if (mod1 || Session["UserType"].ToString().ToLower().Equals("admin"))
                    {
                        ListBuild += "<td align=center><img alt='' id='e";
                        ListBuild += i.ToString();
                        int row_cnt = i + 1;
                        string row = ListItem.Rows[i]["rowid"].ToString();

                        ListBuild += "'src='../Images/edit.gif' onmouseover=this.style.cursor='hand' onclick=javascript:newwin('" + row + "')";

                        ListBuild += "></td><td align=center ><input type='checkbox' id='" + ListItem.Rows[i]["listitemid"].ToString() + "'>";


                        ListBuild += "</tr></td>";
                    }
                    idval += ListItem.Rows[i]["listitemid"].ToString() + ",";

                }
            }
            ListBuild += "</table>";
            //                conn.Close();
            Session["records"] = idval;
        }
        catch (System.Exception ex)
         {
            Session["records"] = idval;
            string msg = ex.Message;

        }
        return (ListBuild);
    }
    public string color(string colorname)
    {
        x = y = z = 0;
        if (colorname.Length > 8)
        {
            x = colorname.IndexOf("(", x);
            y = colorname.IndexOf(")", y);
            z = (y - (x + 1));
            colorname = colorname.Substring(x + 1, z);
            return (colorname);
        }
        else
            return (colorname);
    }


    protected void delete_Click(object sender, EventArgs e)
    {
        DataTable dtListLink=new DataTable();
        dtListLink=lstObj.ExecuteDTQuery("select * from links where Linkto like '%"+str1+"%'");
        if (dtListLink.Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>alert('Cannot delete the List. The List is linked to Content Builder Pages or Toolbars.');</script>");
        }
        else
        {
            string del_list = "update listbuilder set deletedflag=1 where lbid='" + str1 + "'";
            lstObj.ExecuteNonQuery(del_list);
            string del_meta = "Delete from metatag where ModuleId='" + str1 + "'";
            lstObj.ExecuteNonQuery(del_meta);

            string del_itm = "delete from listitems where listbuilderid='" + str1 + "'";
            lstObj.ExecuteNonQuery(del_itm);
            Response.Redirect("MainPage.aspx?SEARCH=");
        }
    }

    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //trLeft1.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        leftPanel.Style.Add("display", value);
    }

    public void CheckRights()
    {
        UserManager objUser = new UserManager();
        DataTable dtCombiRights = new DataTable();
        if(Session["UserId"].ToString().Trim().Equals(""))
            objUser.Userid = 1;
        else
            objUser.Userid = int.Parse(Session["UserId"].ToString());
        dtCombiRights = objUser.LBRights(Request.QueryString["LBID"].ToString(), "");
       
        if (dtCombiRights.Rows.Count > 0)
        {
            
            string strRights = dtCombiRights.Rows[0][0].ToString();
            if (!strRights.Equals(""))
            {
                if (strRights.Substring(0, 1).Equals("1"))
                {
                    add1 = true;
                }
                if (strRights.Substring(1, 1).Equals("1"))
                {
                    mod1 = true;
                }
                if (strRights.Substring(2, 1).Equals("1"))
                {
                    del1 = true;
                }
                //if (strRights.Substring(3, 1).Equals("1"))
                //{
                //    view1 = true;
                //}
            }
            else
            {
                add1 = true;
                mod1 = true;
                del1 = true;
            }
        }
    }
    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length > 0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);
        return LBIds;
    }

    public string data(string addr)
    {
        if (addr.StartsWith("~RTF~"))
        {
            addr = addr.Remove(0, 5);
            return addr;
        }
        else
        {
            return addr;
        }
    }
}
