using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.Data.SqlClient;

public partial class ListBuilder_AddList : System.Web.UI.Page
{
    Lists db = new Lists();
    Lists lstObj = new Lists();
    string LBIds = "";
    string[] rangeData = new string[1000];  
    string order;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        lblUser.Text = Session["FullName"].ToString();

        
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());


        if (Request.QueryString["ACT"].ToString().Equals("NEW"))
            sort.Style.Add("display", "none");

        fullList.Controls.Add(display_top10list());
        gen.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
        gen.Attributes.Add("onmouseout", "this.style.color='blue';");
        hdr.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
        hdr.Attributes.Add("onmouseout", "this.style.color='blue';");
        desc.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
        desc.Attributes.Add("onmouseout", "this.style.color='blue';");
        cell.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
        cell.Attributes.Add("onmouseout", "this.style.color='blue';");
        if (!Page.IsPostBack)
        {
            gen_tab.Attributes.Add("style", "display: block");
            desc_tab.Attributes.Add("style", "display: none");
            hdr_tab.Attributes.Add("style", "display: none");
            cell_tab.Attributes.Add("style", "display: none");

            string[] type = new string[] { "Arial", "Arial Black", "Comic Sans MS", "Courier New", "Impact", "Lucida Console", "Tahoma", "Times new roman", "Verdana", "Wingdings" };            
            lstfonttype.DataSource = type;
            lstfonttype.DataBind();
            lstfonttype.Value = lstfonttype.Items.FindByText("Verdana").Value;

            int[] size = new int[] { 8,9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            lstfontsize.DataSource = size;
            lstfontsize.DataBind();
            lstfontsize.Value = lstfontsize.Items.FindByText("14").Value;

            lstfonttype1.DataSource = type;
            lstfonttype1.DataBind();
            lstfonttype1.Value = lstfonttype1.Items.FindByText("Verdana").Value;

            lstfontsize1.DataSource = size;
            lstfontsize1.DataBind();
            lstfontsize1.Value = lstfontsize1.Items.FindByText("11").Value;

            lstfonttype2.DataSource = type;
            lstfonttype2.DataBind();
            lstfonttype2.Value = lstfonttype2.Items.FindByText("Verdana").Value;

            lstfontsize2.DataSource = size;
            lstfontsize2.DataBind();
            lstfontsize2.Value = lstfontsize2.Items.FindByText("11").Value;
        }
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))              
        {
            btnCancel1.Value = "Show List";
            btnCancel2.Value = "Show List";
            btnCancel3.Value = "Show List";
            btnCancel.Value = "Show List";
            btnSave1.Visible = true;
            btnSave2.Visible = true;
            btnSave3.Visible = true;
            btnNext1.Visible = false;
            btnNext2.Visible = false;
            btnNext3.Visible = false;

        }
        else
        {
            btnSave1.Visible = false;
            btnSave2.Visible = false;
            btnSave3.Visible = false;
            btnNext1.Visible = true;
            btnNext2.Visible = true;
            btnNext3.Visible = true;
        }
        if (Request.QueryString["ACT"].ToString().Equals("MOD") && !Page.IsPostBack)
        {
            
            DataTable dt = new DataTable("Dt");
            dt = db.GetAllLists(Request.QueryString["LBID"].ToString());
            //sort.Visible = false;
            System.Data.DataRow row;
            row = dt.Rows[0];
            if (dt.Rows.Count > 0)
            {
                txtLstname.Text = row["listname"].ToString();
                txtColumnCount.Text = row["ColumnCount"].ToString();
                txtListDesc.Text = row["headertext"].ToString();
                txtDescBGcolor.Text = row["headbgcolor"].ToString();
                txtDescFGcolor.Text = row["headfontcolor"].ToString();
                chkBold.Checked = getbold("headfontbold", dt.Rows[0]);
                chkBold1.Checked = getbold("headerfontbold", dt.Rows[0]);
                chkBold2.Checked = getbold("cellfontbold", dt.Rows[0]);
                txtTHdrBGcolor.Text = row["headerbgcolor"].ToString();
                txtTHdrFGcolor.Text = row["headerfontcolor"].ToString();
                txtTWidth.Text = row["tablewidth"].ToString();
                txtTBorderWidth.Text = row["border"].ToString();

                lstfonttype.Value = lstfonttype.Items.FindByText(row["headfonttype"].ToString()).Value;
                lstfontsize.Value = lstfontsize.Items.FindByText(row["headfontsize"].ToString()).Value;

                lstfonttype1.Value = lstfonttype1.Items.FindByText(row["headerfonttype"].ToString()).Value;
                lstfontsize1.Value = lstfontsize1.Items.FindByText(row["headerfontsize"].ToString()).Value;


                lstfonttype2.Value = lstfonttype2.Items.FindByText(row["cellfonttype"].ToString()).Value;
                lstfontsize2.Value = lstfontsize2.Items.FindByText(row["cellfontsize"].ToString()).Value;

                if (row["tablealignment"].ToString().Equals("C"))
                    talign.Value = talign.Items.FindByText("Center").Value;
                else if (row["tablealignment"].ToString().Equals("R"))
                    talign.Value = talign.Items.FindByText("Right").Value;
                else if (row["tablealignment"].ToString().Equals("L"))
                    talign.Value = talign.Items.FindByText("Left").Value;

                if (row["cellalignment"].ToString().Equals("C"))
                    calign.Value = calign.Items.FindByText("Center").Value;
                else if (row["cellalignment"].ToString().Equals("R"))
                    calign.Value = calign.Items.FindByText("Right").Value;
                else if (row["cellalignment"].ToString().Equals("L"))
                    calign.Value = calign.Items.FindByText("Left").Value;

                txtTBordercolor.Text = row["bordercolor"].ToString();
                txtCellPadding.Text = row["cellpadding"].ToString();
                txtCellBGcolor.Text = row["cellbgcolor"].ToString();
                txtCellBGAltcolor.Text = row["cellbgaltcolor"].ToString();
                txtCellFGcolor.Text = row["cellfontcolor"].ToString();


                DataTable dtt = new DataTable();


                dtt = db.ExecuteDTQuery("select field1,field2,field3,field4,field5,field6,field7,field8,field9,field10 from listitems where listbuilderid='" + Request.QueryString["LBID"] + "' and rowid=1");
                int i;
                ListItem itm1 = new ListItem("None", "None");
                sorton.Items.Add(itm1);
                if (dtt.Rows.Count > 0)
                {
                    for (i = 0; i < 10; i++)
                    {
                        if (dtt.Rows[0][i].ToString() != "")
                        {
                            int j=i+1;
                            ListItem itm = new ListItem(dtt.Rows[0][i].ToString(), "field"+j.ToString());                     
                            sorton.Items.Add(itm);
                        }
                    }
                }
                else
                {
                    sorton.Visible = false;
                    sortlbl.Visible = false;
                    sortby.Visible = false;
                }

                sorton.DataBind();
                if (row["sortby"] != null && !row["sortby"].ToString().Equals(""))
                {
                    if (sorton.Items.FindByValue(row["sortby"].ToString()) != null)
		    {
		    	sorton.Value = sorton.Items.FindByValue(row["sortby"].ToString()).Value;
		    }
		    else
		    {
		 	sorton.Value = sorton.Items.FindByText("None").Value;
                    }
                }
                else
                {
                    sorton.Value = sorton.Items.FindByText("None").Value;
                }



                sortby.Value = (row["sortorder"].ToString().Equals("A")) ? "0" : "1";
                order = (sortby.Value.Equals("0")) ? "A" : "D";
            }
            Session["Column"] = sorton.Items[sorton.SelectedIndex].Value.ToString();
        }

        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Session["Column"] = sorton.Items[sorton.SelectedIndex].Value.ToString();
        btnNext1.Attributes.Add("onclick", "javascript: if(!(BrValidate())){return false;};");
        btnNext2.Attributes.Add("onclick", "javascript: if(!(val())){return false;};");
        btnNext3.Attributes.Add("onclick", "javascript: if(!(val())){return false;};");
        desc.Attributes.Add("onclick", "javascript: if(!(BrValidate())){return false;};");
        hdr.Attributes.Add("onclick", "javascript: if(!(val())){return false;};");
        cell.Attributes.Add("onclick", "javascript: if(!(val())){return false;};");
    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {

                    lbl = new LinkButton();
                    lbl.Text = row["listname"].ToString();
                    lbl.Font.Size = 8;
                    lbl.Font.Name = "Tahoma";
                    lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                    lbl.Style.Add("text-decoration", "none");
                    TableRow tr = new TableRow();
                    TableCell td = new TableCell();
                    td.Controls.Add(lbl);
                    tr.Cells.Add(td);
                    dispTbl.Rows.Add(tr);

                    lbl.CommandArgument = row["lbid"].ToString();
                    lbl.Click += new EventHandler(Select_Click);
                    lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                    lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

                }
            }
        }

        return dispTbl;
    }
    private void Select_Click(object sender, System.EventArgs e)
    {

        string lstid = (((LinkButton)(sender)).CommandArgument).ToString();

        Session["lstname"] = lstid;
        Response.Redirect("Listitem.aspx?LBID=" + lstid);
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void desc_Click(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: block");
        hdr_tab.Attributes.Add("style", "display: none");
        cell_tab.Attributes.Add("style", "display: none");
    }
    protected void hdr_Click(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: none");
        hdr_tab.Attributes.Add("style", "display: block");
        cell_tab.Attributes.Add("style", "display: none");
    }
    protected void cell_Click(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: none");
        hdr_tab.Attributes.Add("style", "display: none");
        cell_tab.Attributes.Add("style", "display: block");
    }
    protected void gen_Click(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: block");
        desc_tab.Attributes.Add("style", "display: none");
        hdr_tab.Attributes.Add("style", "display: none");
        cell_tab.Attributes.Add("style", "display: none");
    }
   
    
    
    protected void btnNext1_ServerClick(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: block");
        hdr_tab.Attributes.Add("style", "display: none");
        cell_tab.Attributes.Add("style", "display: none");
    }
    protected void btnNext2_ServerClick(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: none");
        hdr_tab.Attributes.Add("style", "display: block");
        cell_tab.Attributes.Add("style", "display: none");
    }
    protected void btnNext3_ServerClick(object sender, EventArgs e)
    {
        gen_tab.Attributes.Add("style", "display: none");
        desc_tab.Attributes.Add("style", "display: none");
        hdr_tab.Attributes.Add("style", "display: none");
        cell_tab.Attributes.Add("style", "display: block");
    }
    protected void btnSave_ServerClick(object sender, EventArgs e)
    {
       
        Lists lstObj = new Lists();



        lstObj.approved = 1;
        lstObj.content = "";
        lstObj.listtable = 1;

        lstObj.sortorder = "A";
        lstObj.sortorder = (sortby.Value.Equals("0")) ? "A" : "D";
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            lstObj.sortby = sorton.Items[sorton.SelectedIndex].Value.ToString();
        else
            lstObj.sortby = "None";
        lstObj.name = txtLstname.Text.ToString();
        lstObj.columncount = int.Parse(txtColumnCount.Text.Trim());


        lstObj.headertext = txtListDesc.Text.ToString();
        lstObj.headbgcolor = txtDescBGcolor.Text.ToString();
        lstObj.headfontcolor = txtDescFGcolor.Text.ToString(); ;
        lstObj.headfonttype = lstfonttype.Items[lstfonttype.SelectedIndex].Text.ToString();
        lstObj.headfontsize = int.Parse(lstfontsize.Items[lstfontsize.SelectedIndex].Value);
        lstObj.headfontbold = Convert.ToInt16(chkBold.Checked);


        lstObj.headerbgcolor = txtTHdrBGcolor.Text.ToString();
        lstObj.headerfontcolor = txtTHdrFGcolor.Text.ToString();
        lstObj.headerfonttype = lstfonttype1.Items[lstfonttype1.SelectedIndex].Text.ToString();
        lstObj.headerfontsize = int.Parse(lstfontsize1.Items[lstfontsize1.SelectedIndex].Value);
        lstObj.headerfontbold = Convert.ToInt16(chkBold1.Checked);

        if (txtTWidth.Text != "")
            lstObj.tablewidth = int.Parse(txtTWidth.Text.Trim());
        else
            lstObj.tablewidth = 96;

        if (txtTBorderWidth.Text != "")
            lstObj.border = int.Parse(txtTBorderWidth.Text.Trim());
        else
            lstObj.border = 1;
        lstObj.bordercolor = txtTBordercolor.Text.ToString();
        if (talign.Items[talign.SelectedIndex].Text.ToString().Equals("Center"))
            lstObj.tablealignment = "C";
        else if (talign.Items[talign.SelectedIndex].Text.ToString().Equals("Left"))
            lstObj.tablealignment = "L";
        else if (talign.Items[talign.SelectedIndex].Text.ToString().Equals("Right"))
            lstObj.tablealignment = "R";

        if (calign.Items[calign.SelectedIndex].Text.ToString().Equals("Center"))
            lstObj.cellalignment = "C";
        else if (calign.Items[calign.SelectedIndex].Text.ToString().Equals("Left"))
            lstObj.cellalignment = "L";
        else if (calign.Items[calign.SelectedIndex].Text.ToString().Equals("Right"))
            lstObj.cellalignment = "R";

        if (txtCellBGAltcolor.Text != "")
            lstObj.cellbgaltcolor = txtCellBGAltcolor.Text.ToString();
        else
            lstObj.cellbgaltcolor = "";
        lstObj.cellbgcolor = txtCellBGcolor.Text.ToString();
        lstObj.cellfontbold = Convert.ToInt16(chkBold2.Checked);
        lstObj.cellfontcolor = txtCellFGcolor.Text.ToString();
        lstObj.cellfontsize = int.Parse(lstfontsize2.Items[lstfontsize2.SelectedIndex].Value);
        lstObj.cellfonttype = lstfonttype2.Items[lstfonttype2.SelectedIndex].Text.ToString();

        if (txtCellPadding.Text != "")
            lstObj.cellpadding = int.Parse(txtCellPadding.Text.Trim());
        else
            lstObj.cellpadding = 2;
        lstObj.createdby =int.Parse(Session["UserId"].ToString());
        if (Request.QueryString["ACT"].ToString().Equals("NEW"))
        {
            
            lstObj.insertlistbuilder();
            Session["lbid"] = lstObj.lbid;
            string insertqry = "insert into Links (Source,LinkTo,Status) values('" + lstObj.lbid + "','','N')";
            lstObj.ExecuteNonQuery(insertqry);
            Response.Redirect("ModifyHeader.aspx?ACT=NEW&LBID=" + lstObj.lbid);
        }
        else
        {
            //lstObj.sortorder = (sortby.SelectedIndex == 0) ? "A" : "D";
            
            lstObj.lbid = Request.QueryString["LBID"].ToString();
            lstObj.modifylistbuilder();
        }


    }


    public bool getbold(string str, DataRow row)
    {
        string s=row[str].ToString();
        if (row[str].ToString().Equals("True"))
            return true;
        else
            return false;
    }
    protected void btnCancel_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
        else
            Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void btnCancel1_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
        else
            Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void btnCancel2_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
        else
            Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void btnCancel3_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
        else
            Response.Redirect("MainPage.aspx?SEARCH=");
    }
    
    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        
        leftPanel.Style.Add("display", value);
    }
    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length > 0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);
        return LBIds;
    }

    protected void btnSave1_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
        {
            DataTable dt = new DataTable("Dt");
            dt = db.GetAllLists(Request.QueryString["LBID"].ToString());
            if (!txtColumnCount.Text.Equals(dt.Rows[0]["ColumnCount"].ToString()))
            {
                if (int.Parse(txtColumnCount.Text) > int.Parse(dt.Rows[0]["ColumnCount"].ToString()))
                {
                    btnSave_ServerClick(this, null);
                }
                Response.Redirect("ModifyHeader.aspx?ACT=MOD&LBID=" + Request.QueryString["LBID"].ToString() + "&OldColCnt=" + dt.Rows[0]["ColumnCount"].ToString());
            }
            else
            {
                btnSave_ServerClick(this, null);
            }
        }
        
    }
    protected void lnkbtnBack_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["ACT"].ToString().Equals("MOD"))
            Response.Redirect("Listitem.aspx?LBID=" + Request.QueryString["LBID"].ToString());
        else
            Response.Redirect("MainPage.aspx?SEARCH=");
    }
}
