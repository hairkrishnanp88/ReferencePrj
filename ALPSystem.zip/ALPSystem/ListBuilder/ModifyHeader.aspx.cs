using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using NGWS.CMPApplication;

public partial class ListBuilder_ModifyHeader : System.Web.UI.Page
{
    public string str = "";
    Lists db = new Lists();
    string LBIds = "";
    string[] rangeData = new string[1000];  
    Lists lstObj = new Lists();
    public string hdr = "";
    public string st = "";
    public string str1, lsname;
    public int ColumnCount;
    CheckBox[] chk;
    TextBox[] txtname, txtwidth;
    Label[] lbl;
    DataTable dt = new DataTable();
    DataTable dt1 = new DataTable();
    DataTable dt2 = new DataTable();
    string s = "";
    string listid = "";
    string listid1 = "";
    string[] name, width;
    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        //Page.Title = Session["SiteName"].ToString();
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End
        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());
        
        s = Request.QueryString["ACT"];
        str1 = Request.QueryString["LBID"];
        fullList.Controls.Add(display_top10list());
        lblUser.Text = Session["FullName"].ToString();
       
        dt = db.GetAllLists(str1);
        if (s.Equals("MOD"))
        {
            string str3 = "select * from ListItems where listbuilderid='" + str1 + "' and RowID =2";
            dt1 = db.GetListItem4modhdr(str1);
            dt2 = db.ExecuteDTQuery(str3);
        }
        if(dt.Rows.Count>0)
        ColumnCount = Convert.ToInt16(dt.Rows[0]["ColumnCount"].ToString());
        name = new string[10];
        width = new string[10];
        lsname = dt.Rows[0]["listName"].ToString();
        if (!Page.IsPostBack)
            if (s.Equals("MOD"))
                view.InnerText += lsname;
            else
                view.InnerText = "Add List - " + lsname;

        Table tab = new Table();
        chk = new CheckBox[ColumnCount];
        lbl = new Label[ColumnCount];
       
        txtname = new TextBox[ColumnCount];
        txtwidth = new TextBox[ColumnCount];
        Label lbl4 = new Label();
        Label lbl1 = new Label();
        Label lbl2 = new Label();
        Label lbl3 = new Label();
        TableRow tr1 = new TableRow();
        TableCell td2 = new TableCell();
        TableCell tddmy = new TableCell();
        TableCell tdwdth = new TableCell();
        TableCell tddel = new TableCell();
        
        td2.Controls.Add(lbl1);
        tdwdth.Controls.Add(lbl2);
        tddel.Controls.Add(lbl3);

        

        lbl2.Text = "Width%";
        lbl2.CssClass = "ClsLabelBold";
        
        if (s.Equals("MOD"))
        {
            
            lbl3.Text = "Delete";
            lbl3.CssClass = "ClsLabelBold";
        }
        tr1.Cells.Add(tddmy);
        
        tr1.Cells.Add(td2);
        tr1.Cells.Add(tdwdth);
        tr1.Cells.Add(tddel);
        tab.Rows.Add(tr1);
        for (int i = 0; i < ColumnCount; i++)
        {
            lbl[i] = new Label();
          
            txtname[i] = new TextBox();
            txtwidth[i] = new TextBox();
            chk[i] = new CheckBox();
            // dlbl[i].Width = 10;
            TableRow tr = new TableRow();
            TableCell tdlbl = new TableCell();
            TableCell tdname = new TableCell();
            TableCell tdwidth = new TableCell();
            TableCell tdchk = new TableCell();
            if (s.Equals("MOD"))
            {
                if (dt1.Rows.Count > 0)
                    hdr = dt1.Rows[0]["Field" + (i + 1).ToString()].ToString();
                if (dt2.Rows.Count > 0)
                    st = dt2.Rows[0]["Field" + (i + 1).ToString()].ToString();
                else
                    st = "";
            }
            lbl[i].Text = "Table Header" + (i + 1);
            lbl[i].Width = 120;
            lbl[i].CssClass = "ClsLabel";
           
          
            txtname[i].Text = hdr;
         
            txtname[i].CssClass = "ClsTextBox";

           
            txtwidth[i].Text = st;
        
            txtwidth[i].CssClass = "ClsTextBox";
            txtwidth[i].Width = Unit.Point(50);
            tdlbl.Controls.Add(lbl[i]);

            tdname.Controls.Add(txtname[i]);
            
            tdwidth.Controls.Add(txtwidth[i]);
            
            if (s.Equals("MOD"))
            {
                if ((txtname[i].Text != "") && (txtwidth[i].Text != ""))
                    tdchk.Controls.Add(chk[i]);
                else
                    lbl3.Visible = false;

            }
            tr.Cells.Add(tdlbl);
            
            tr.Cells.Add(tdname);
            tr.Cells.Add(tdwidth);
            tr.Cells.Add(tdchk);
            tr.Style.Add("align", "center");

            tab.Rows.Add(tr);
            tab.Style.Add("align", "center");


        }
        tabcell.Controls.Add(tab);		
    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {

                    lbl = new LinkButton();
                    lbl.Text = row["listname"].ToString();
                    lbl.Font.Size = 8;
                    lbl.Font.Name = "Tahoma";
                    lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                    lbl.Style.Add("text-decoration", "none");
                    TableRow tr = new TableRow();
                    TableCell td = new TableCell();
                    td.Controls.Add(lbl);
                    tr.Cells.Add(td);
                    dispTbl.Rows.Add(tr);

                    lbl.CommandArgument = row["lbid"].ToString();
                    lbl.Click += new EventHandler(Select_Click);
                    lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                    lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

                }
            }
        }

        return dispTbl;
    }
    private void Select_Click(object sender, System.EventArgs e)
    {

        string lstid = (((LinkButton)(sender)).CommandArgument).ToString();

        Session["lstname"] = lstid;
        Response.Redirect("Listitem.aspx?LBID=" + lstid);
    }
    public bool isNumeric(string s)
    {
        for (int i = 0; i < s.Length; i++)
            if (!Char.IsNumber(s[i]))
                return false;

        return true;
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    protected void cancel_ServerClick(object sender, EventArgs e)
    {
        if (Request.QueryString["OldColCnt"] != null)
        {
            Lists udb = new Lists();
            string updatbuilder = "update listbuilder set columncount=" + Request.QueryString["OldColCnt"].ToString() + " where lbid='" + str1 + "'";
            udb.ExecuteNonQuery(updatbuilder);
        }
        Response.Redirect("listitem.aspx?MODE=SHOW&LBID=" + str1);
    }
    protected void save_ServerClick(object sender, EventArgs e)
    {
        int i;
			
			Lists db1=new Lists();
			Lists db2=new Lists();
			int j=1;
			int fl=1;
			int sum=0;
            int newColCnt = 0;
			if(s.Equals("MOD"))
			{
                string meta = "update metatag set status='M' where ModuleId='" + str1 + "'";
                db1.ExecuteNonQuery(meta);
				for(i=0;i<ColumnCount;i++)
					if(chk[i].Checked==false)
                        if ((txtname[i].Text != "") && (txtwidth[i].Text != "") && (isNumeric(txtwidth[i].Text)))
                        {
                            sum += int.Parse(txtwidth[i].Text);
                            newColCnt+=1;
                        }
                        else
                        {
                            fl = 0; break;
                        }
				if(fl==0)
				{
                    string alert = "<script language='javascript'>alert('Please make sure that you have entered correct data in all fields ');</script>";
					Response.Write(alert);
					
				}
				else
				{

					if(sum==100)
					{
						
						string s1="select listitemid from listitems where listbuilderid='"+str1+"' and Stat Not in ('Y','A') and RowID =1 ";
						listid=db1.ExecuteScalar(s1);
						string s2="select listitemid from listitems where listbuilderid='"+str1+"'and RowID =2 ";
						listid1=db2.ExecuteScalar(s2);
			
						//row creation
						for(i=0;i<ColumnCount;i++)
						{
							db1.rowid="1";
							db2.rowid="2";
										
							if(chk[i].Checked==false)
							{
								Lists udb=new Lists();
								for(j=i;j<ColumnCount;j++)
								{
								
									int k=j+1;
									string updathdr="update listitems set field"+k.ToString()+"='"+txtname[j].Text+"' where listbuilderid='"+str1+"' and rowid=1";
									udb.ExecuteNonQuery(updathdr);
									string updatwidth="update listitems set field"+k.ToString()+"='"+txtwidth[j].Text+"' where listbuilderid='"+str1+"' and rowid=2";
									udb.ExecuteNonQuery(updatwidth);
                                    SqlCommand cmdListBuilder = new SqlCommand("sp_updateLBwithLI");
                                    cmdListBuilder.CommandType = CommandType.StoredProcedure;
                                    cmdListBuilder.Parameters.AddWithValue("@id", str1);
                                    //cmdListBuilder.Parameters.AddWithValue("@createdby", Session["UserId"].ToString());
                                    udb.ExecuteNonQuery(cmdListBuilder);
								}
							}
							if(chk[i].Checked==true)
							{
					
								Lists udb=new Lists();
								int con=i;
								for(j=i;j<ColumnCount;j++)
								{
									if(chk[j].Checked==false)
									{
								
										int k=j+1;
                                        string updathdr = "update listitems set field" + k.ToString() + "='" + txtname[j].Text + "' where listbuilderid='" + str1 + "' and rowid=1";
										udb.ExecuteNonQuery(updathdr);
                                        string updatwidth = "update listitems set field" + k.ToString() + "='" + txtwidth[j].Text + "' where listbuilderid='" + str1 + "' and rowid=2";
										udb.ExecuteNonQuery(updatwidth);
									}
								}
                                int fixedno = 0;
								for(j=0;j<ColumnCount;j++)
								{
                                    for (int cnt = j; cnt < ColumnCount; cnt++)
                                    {
                                        int k = cnt + 1;
                                        int l = cnt + 2;
                                        if (chk[j].Checked == true)
                                        {
                                            k = k - fixedno;
                                            l = l - fixedno;
                                            string updatitem = "update listitems set field" + k.ToString() + "=field"+ l.ToString()+ " where listbuilderid='" + str1 + "'";
                                            udb.ExecuteNonQuery(updatitem);
                                            
                                        }
                                    }
                                    if (chk[j].Checked == true)
                                    {
                                        fixedno += 1;
                                    }
								}
                                
								string updatbuilder="update listbuilder set columncount="+(newColCnt)+" where lbid='"+str1+"'";
								udb.ExecuteNonQuery(updatbuilder);
                                SqlCommand cmdListBuilder = new SqlCommand("sp_updateLBwithLI");
                                cmdListBuilder.CommandType = CommandType.StoredProcedure;
                                cmdListBuilder.Parameters.AddWithValue("@id", str1);
                                //cmdListBuilder.Parameters.AddWithValue("@createdby", Session["UserId"].ToString());
                                udb.ExecuteNonQuery(cmdListBuilder);
								break;
						
							}
					
					
						}
						Response.Redirect("listitem.aspx?MODE=SHOW&LBID="+str1);
					
					}
					else
					{
						string alert="<script language='javascript'>alert('Please make sure that the total width of all Headers is 100%');</script>";
						Response.Write(alert);
					}
				}
			}
			else if(s.Equals("NEW"))
			{
				str1=Request.QueryString["LBID"];
				for(i=0;i<ColumnCount;i++)
					if((txtname[i].Text!="") && (txtwidth[i].Text!="") && (isNumeric(txtwidth[i].Text)))

						sum+=int.Parse(txtwidth[i].Text);
					else
					{
						fl=0;	break;
					}
				if(fl==0)
				{
					string alert="<script language='javascript'>alert('Please make sure that you have entered correct data in all fields ');</script>";
					Response.Write(alert);
					
				}
				else
				{
					
					if(sum==100)
					{
						j=1;
						db1.field1="";
						db2.field1="";
						db1.field2="";
						db2.field2="";
						db1.field3="";
						db2.field3="";
						db1.field4="";
						db2.field4="";
						db1.field5="";
						db2.field5="";
						db1.field6="";
						db2.field6="";
						db1.field7="";
						db2.field7="";
						db1.field8="";
						db2.field8="";
						db1.field9="";
						db2.field9="";
						db1.field10="";
						db2.field10="";
	
						for(i=0;i<ColumnCount;i++)
						{
							db1.rowid="1";
							db2.rowid="2";
							for(i=0;i<ColumnCount;i++)
							{
								name[i]=txtname[i].Text;
								width[i]=txtwidth[i].Text;
							}
							db1.field1=name[0];
							db1.field2=name[1];
							db1.field3=name[2];
							db1.field4=name[3];
							db1.field5=name[4];
							db1.field6=name[5];
							db1.field7=name[6];
							db1.field8=name[7];
							db1.field9=name[8];
							db1.field10=name[9];

							db2.field1=width[0];
							db2.field2=width[1];
							db2.field3=width[2];
							db2.field4=width[3];
							db2.field5=width[4];
							db2.field6=width[5];
							db2.field7=width[6];
							db2.field8=width[7];
							db2.field9=width[8];
							db2.field10=width[9];

							
							db1.listbuilderid=str1;
							db2.listbuilderid=str1;
							db1.stat="H";
							db2.stat="Y";
                            db1.createdby = int.Parse(Session["UserId"].ToString());
                            db2.createdby = int.Parse(Session["UserId"].ToString());
                            db1.inserttolistitems();
                            db2.inserttolistitems();
						
					}
						Response.Redirect("AddData.aspx?ACT=NEW&LBID="+str1);
					}
					else
					{
                        string alert = "<script language='javascript'>alert('Please make sure that the total width of all Headers is 100%');</script>";
						Response.Write(alert);
					}
				}
			}

		}

        public void ShowBanner(string value)
        {
            tblBanner.Style.Add("display", value);
        }

        public void ShowPanel(string value)
        {
            //trLeft1.Style.Add("display", value);
            //trLeft4.Style.Add("display", value);
            //tdLeft1.Style.Add("display", value);
            //tdLeft2.Style.Add("display", value);
            //tdLeft3.Style.Add("display", value);
            leftPanel.Style.Add("display", value);
        }
    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length > 0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);
        return LBIds;
    }

    }

