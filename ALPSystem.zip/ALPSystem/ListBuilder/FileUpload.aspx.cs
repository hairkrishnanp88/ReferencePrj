using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
using System.IO;
using System.Text.RegularExpressions;


public partial class FileUpload : System.Web.UI.Page
{
    private long lngMaxFileSize;
    string qryStringVar;
    string strFileDir;
    public string maincontent;
    Templates dbf = new Templates();
    Templates tempObj = new Templates();
    protected void Page_Load(object sender, EventArgs e)
    {
        qryStringVar = Request.QueryString["value"].ToString();
        if (Request.QueryString["id"] != null)
        {
            string txtId = Request.QueryString["id"].ToString();
            hdnId.Value = txtId;
        }
        if (Request.QueryString["txtid"] != null)
        {
            string Id = Request.QueryString["txtid"].ToString();
            hdnTxtId.Value = Id;
        }
        hideEventId.Value = qryStringVar;
        if (qryStringVar == "ImgLoc")
            tblHeader.InnerText = "Image Upload";
        else if (qryStringVar == "TempLoc")
            tblHeader.InnerText = "Template Upload";
        else if (qryStringVar == "Document")
            tblHeader.InnerText = "Document Upload";
    }

    private string findimageurl(string templatecontent)
    {
        string none = "";
        if (templatecontent.Length > 0)
        {
            String strSource = templatecontent;
            maincontent = templatecontent;
            String imgurls = "";
            Int32 Arraylength, lastIndex1, lastIndex2, arrLength, arrPrevious;
            String strResult, strPattern, strFinal;

            strPattern = "";


            String[] strTest = new String[100];
            strTest = strSource.Split('.');

            String[] strImageType = { "jpg", "gif", "bmp", "ico", "png", "wmf", "jpe" };

            Arraylength = strTest.Length;

            for (int i = 1; i < Arraylength; i++)
            {

                if (strTest[i].Length >= 3)
                {
                    strPattern = strTest[i].Substring(0, 3).Trim();
                }
                else
                    strPattern = "";


                for (int image = 0; image < strImageType.Length; image++)
                {

                    if (strPattern == strImageType[image])
                    {

                        arrPrevious = i - 1;
                        string test = strTest[arrPrevious];
                        lastIndex1 = strTest[arrPrevious].LastIndexOf("(");
                        lastIndex2 = strTest[arrPrevious].LastIndexOf('"');
                        if (lastIndex1 < 0)
                            lastIndex1 = 0;
                        if (lastIndex2 < 0)
                            lastIndex2 = 0;

                        if (lastIndex1 > lastIndex2)
                        {

                            arrLength = strTest[arrPrevious].Length;

                            int total = arrLength - lastIndex1;

                            strFinal = strTest[arrPrevious].Substring(lastIndex1, total).Replace("(", ""); ;

                            strResult = String.Concat(strFinal, "." + strPattern);
                            int index = 0;
                            if (strFinal.LastIndexOf('/') < 0)
                                index = 0;
                            else
                                index = strFinal.LastIndexOf('/') + 1;

                            int sindex = 0;
                            if (strResult.LastIndexOf('/') > 0)
                                sindex = strResult.LastIndexOf('/');
                            string file = strFinal.Substring(sindex);
                            string tempfile = file;
                            for (int n = 1; ; n++)
                            {

                                strFileDir = Server.MapPath("../Images/Templatemanager");
                                if (File.Exists(strFileDir + file + "." + strPattern))
                                {
                                    file = tempfile + n.ToString();
                                }

                                else

                                    break;
                            }

                            if (arrPrevious > 0 && strTest[arrPrevious - 1].Equals(""))
                                file = "/Images/Templatemanager" + file;
                            else
                                file = "../Images/Templatemanager" + file;
                            maincontent = Regex.Replace(maincontent, strFinal, file);

                            imgurls += strResult + "%";
                        }
                        else
                        {

                            arrLength = strTest[arrPrevious].Length;

                            int total = arrLength - lastIndex2;

                            strFinal = strTest[arrPrevious].Substring(lastIndex2, total).Replace('"'.ToString(), "");

                            strResult = String.Concat(strFinal, "." + strPattern);
                            int index = 0;
                            if (strFinal.LastIndexOf('/') < 0)
                                index = 0;
                            else
                                index = strFinal.LastIndexOf('/') + 1;
                            int sindex = 0;
                            if (strResult.LastIndexOf('/') > 0)
                                sindex = strResult.LastIndexOf('/');
                            string file = strFinal.Substring(sindex);
                            string tempfile = file;

                            for (int n = 1; ; n++)
                            {

                                strFileDir = Server.MapPath("../Images/Templatemanager");
                                if (File.Exists(strFileDir + file + "." + strPattern))
                                {
                                    if (n < 10)
                                        file = tempfile + "0" + n.ToString();
                                    else
                                        file = tempfile + n.ToString();
                                }

                                else

                                    break;
                            }

                            if (arrPrevious > 0 && strTest[arrPrevious - 1].Equals(""))
                                file = "/Images/Templatemanager" + file;
                            else
                                file = "../Images/Templatemanager" + file;


                            maincontent = Regex.Replace(maincontent, strFinal, file);
                            imgurls += strResult + "%";
                        }
                    }


                }

            }

            return imgurls;
        }
        else
            return none;

    }

    private void fnUpload()
    {
        if ((FileUploader.PostedFile != null) && (FileUploader.PostedFile.ContentLength != 0))
        {
            string strFileName = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);
            try
            {
                lngMaxFileSize = FileUploader.PostedFile.ContentLength;
                //save file in the local disk

                for (int i = 1; ; i++)
                {
                    if (File.Exists(strFileDir + "\\" + strFileName))
                    {
                        if (i < 10)
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + "0" + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                        else
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                    }
                    else
                        break;
                }

                FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);
                hideFileName.Value = strFileName;
            }
            catch (Exception ex)
            {
                //Response.Redirect("../Errors/Error.aspx
                Response.Write("Error Occured" + ex.Message.ToString());
                //Response.End();
                //Response.Write("Error Occured");
            }
        }
    }
    public string GetPageHTML(string pageUrl)
    {
        System.Net.WebResponse response = null;

        try
        {

            // Setup our Web request
            System.Net.WebRequest request = System.Net.WebRequest.Create(pageUrl);

            // Retrieve data from request
            response = request.GetResponse();

            System.IO.Stream streamReceive = response.GetResponseStream();
            System.Text.Encoding encoding = System.Text.Encoding.GetEncoding("utf-8");
            System.IO.StreamReader streamRead = new System.IO.StreamReader(streamReceive, encoding);

            // return the retrieved HTML
            return streamRead.ReadToEnd();
        }
        catch (Exception ex)
        {
            // Error occured grabbing data, return empty string.
            Response.Write("<script language='javascript'>alert('File Cannot be Uploaded...\n " + ex.Message + "'); </script>");
            return "";
        }
        finally
        {
            // Check if exists, then close the response.
            if (response != null)
            {
                response.Close();
            }
        }
    }


    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string varFileType;
        varFileType = FileUploader.PostedFile.ContentType;
        //Response.Write(varFileType);
        if ((FileUploader.PostedFile != null) && (FileUploader.PostedFile.ContentLength != 0))
        {
            if (qryStringVar == "ImgLoc")
            {
                tblHeader.InnerText = "Image Upload";
                if ((varFileType == "image/gif") || (varFileType == "image/pjpeg") || (varFileType == "image/x-png") || (varFileType == "image/bmp") || (varFileType == "application/octet-stream"))
                {

                    strFileDir = Server.MapPath("../Images/ListBuilder/Images");

                    fnUpload();
                }
                else
                    Response.Write("<script language='javascript'>alert('Please select image files')</script>");
            }
            else if (qryStringVar == "Document")
            {
                //if ((varFileType == "text/html") || (varFileType == "text/plain"))
                {
                    string strFileName = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);

                    strFileDir = Server.MapPath("../Images/ListBuilder/Documents");

                    for (int i = 1; ; i++)
                    {
                        if (File.Exists(strFileDir + "\\" + strFileName))
                        {
                            if (i < 10)
                                strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + "0" + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                            else
                                strFileName = System.IO.Path.GetFileNameWithoutExtension(FileUploader.PostedFile.FileName) + i.ToString() + Path.GetExtension(FileUploader.PostedFile.FileName);
                        }
                        else
                            break;
                    }

                    FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);



                    //FileUploader.PostedFile.SaveAs(strFileDir + "\\" + strFileName);
                    string templatelocation = FileUploader.PostedFile.FileName;
                    DataTable templatenames = new DataTable();
                    string templatecontentcopy = GetPageHTML(strFileDir + "\\" + strFileName);
                    if (templatecontentcopy.Equals(""))
                        hideFileName.Value = "";
                    else
                        hideFileName.Value = strFileName;

                    /*hideImgLoc.Value = findimageurl(templatecontentcopy);

                    {

                        tempObj.HTML_Content = maincontent;
                        tempObj.HTML_DFlag = "0";
                        tempObj.HTML_UserId = Session["UserId"].ToString();
                        tempObj.HTML_Name = System.IO.Path.GetFileName(FileUploader.PostedFile.FileName);
                        string id = "TP" + tempObj.GetMaxValueString("templates", "TempId");
                        tempObj.AddNewTemplate(id);
                        templateid.Value = id;
                    }
                    */
                    strFileDir = Server.MapPath("../Images/ListBuilder/Documents");



                }
                //else
                // Response.Write("<script language='javascript'>alert('Please select html files')</script>");
            }
        }
        //else if (qryStringVar == "Document")
        //{

        //}

    }
   
}



