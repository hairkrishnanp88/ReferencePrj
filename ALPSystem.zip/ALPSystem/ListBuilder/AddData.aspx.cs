using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;

public partial class ListBuilder_AddData : System.Web.UI.Page
{
    int ColumnCount;
    string[] name;
    //HtmlSelect[] opt;
    DropDownList[] opt;
    string str1, lsname, hdr, st;
    Label[] lbl, lb;
    Image[] img;
    HtmlInputHidden[] hdn;
    string LBIds = "";
    string[] rangeData = new string[1000];  
    TextBox[] txt;
    Lists db = new Lists();
    Lists lstObj = new Lists();
    int rowid, row;
    string s, new_rowid = "", itm_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        SiteInfo.SetSiteName(this);
        SiteInfo.ValidateSession();
        
        //Page.Title = Session["SiteName"].ToString();
        // Start Menu Displaying    
        if (Session["UserType"].ToString() != "Anonymous")
        {
            tdMenu.Style.Add("display", Session["MenuRights"].ToString());
            divMenu.Controls.Add(SiteInfo.userValidation());
        }
        //End

        // Top Banner Displaying
        ShowBanner(Session["Banner"].ToString());

        //LeftPanel Displaying
        ShowPanel(Session["Panel"].ToString());

        s = Request.QueryString["ACT"];
        lblUser.Text = Session["FullName"].ToString();
        fullList.Controls.Add(display_top10list());
        {

            Table tbl = new Table();
            str1 = Request.QueryString["LBID"].ToString();

            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable("Dt");

            dt2 = db.GetListItem4modhdr(str1);
            dt = db.GetAllLists(str1);

            if (dt.Rows.Count > 0)
            {
                ColumnCount = Convert.ToInt16(dt.Rows[0]["ColumnCount"].ToString());
                lsname = dt.Rows[0]["listname"].ToString();
            }
            lbl = new Label[ColumnCount];
            lb = new Label[ColumnCount];
            img = new Image[ColumnCount];
            //opt = new HtmlSelect[ColumnCount];
            opt = new DropDownList[ColumnCount];
            txt = new TextBox[ColumnCount];
            hdn=new HtmlInputHidden[ColumnCount];

            string[] itm = new string[] { "None", "http://", "mailto:","Document","Page","Rich Text","Images"};
            if (!Page.IsPostBack)
            {

                if (s.Equals("NEW"))
                    view.InnerText += lsname;
                else
                    view.InnerText = "Edit ListItem - " + lsname;
            }
            for (int i = 0; i < ColumnCount; i++)
            {
                int j = i + 1;
                lbl[i] = new Label();
                txt[i] = new TextBox();
                txt[i].CssClass = "ClsTextBox";
                lb[i] = new Label();
                img[i] = new Image();
                //opt[i] = new HtmlSelect();
                opt[i] = new DropDownList();
                hdn[i]=new HtmlInputHidden();
                hdn[i].ID="hdn"+i.ToString();
                opt[i].DataSource = itm;
                opt[i].Style.Add("Font-Size", "11");
                opt[i].Style.Add("Font-Name", "Verdana");
                opt[i].DataBind();

                if (dt2.Rows.Count > 0)
                {
                    hdr = dt2.Rows[0]["Field" + j.ToString()].ToString();
                    st = dt2.Rows[0]["Field" + j.ToString()].ToString();
                }
                else
                    st = "";
                lb[i].Text = "";
                lb[i].Width = 20;
                lbl[i].Text = hdr;
                lbl[i].Style.Add("text-align", "right");
                lbl[i].Font.Size = 8;
                lbl[i].Font.Name = "Verdana";
                lbl[i].Width = 120;
                opt[i].ID = "OPT" + i.ToString();
                txt[i].Width = 120;
                if (s.Equals("NEW"))
                    txt[i].Text = "";
                else if (s.Equals("MOD") && !Page.IsPostBack)
                {
                    rowid = int.Parse(Request.QueryString["ROW"].ToString());
                    row = rowid - 1;

                    DataTable dt3 = new DataTable();
                    dt3 = db.ExecuteDTQuery("select * from Listitems where rowid="+rowid.ToString()+" and listbuilderid='"+str1+"'");
                    itm_id = dt3.Rows[0]["listitemid"].ToString();
                    
                    opt[i].SelectedValue = option(dt3.Rows[0]["Field" + j.ToString()].ToString());
                    
                    txt[i].Text = data(dt3.Rows[0]["Field" + j.ToString()].ToString());
                    
                    if (opt[i].SelectedValue.Equals("Document") || opt[i].SelectedValue.Equals("Images")||opt[i].SelectedValue.Equals("Rich Text")||opt[i].SelectedValue.Equals("Page"))
                        hdn[i].Value = hdnVal(dt3.Rows[0]["Field" + j.ToString()].ToString());
                    else
                        hdn[i].Value = "";
                    
                    
                    new_rowid = dt3.Rows[0]["rowid"].ToString();
                }
                txt[i].ID = "txt" + i.ToString();
                img[i].ID = "img" + i.ToString();
                img[i].ImageUrl = "../Images/file_icon.jpg";
                TableRow tr = new TableRow();
                TableCell td = new TableCell();
                TableCell td1 = new TableCell();
                td.Controls.Add(lbl[i]);
                td.Controls.Add(lb[i]);
                td.Controls.Add(txt[i]);
                td1.Controls.Add(opt[i]);
                td1.Controls.Add(img[i]);
                td1.Controls.Add(hdn[i]);
                if (opt[i].SelectedValue == "Document" || opt[i].SelectedValue == "Images" ||opt[i].SelectedValue == "Rich Text" ||opt[i].SelectedValue == "Page")
                {
                    img[i].Style.Add("display", "inline");
                }
                else
                {
                    img[i].Style.Add("display", "none");
                }
                tr.Cells.Add(td);
                tr.Cells.Add(td1);
                tbl.Rows.Add(tr);
                opt[i].Attributes.Add("onchange", "javascript:{showFolderIcon('" + opt[i].ClientID + "','" + img[i].ClientID + "','" + txt[i].ClientID + "','"+hdn[i].ClientID+"');mouseoverIcon('" + opt[i].ClientID + "','" + img[i].ClientID + "');}");
                if (!Page.IsPostBack)
                {
                    if (s.Equals("MOD"))
                    {
                        if (opt[i].SelectedValue == "Rich Text")
                            img[i].Attributes.Add("onclick", "javascript:openFile('" + opt[i].ClientID + "','" + hdn[i].ClientID + "','" + txt[i].ClientID + "','" + Request.QueryString["LBID"].ToString() + "','" + Request.QueryString["ROW"].ToString() + "')");
                        else
                            img[i].Attributes.Add("onclick", "javascript:openFiles('" + opt[i].ClientID + "','" + hdn[i].ClientID + "','" + txt[i].ClientID + "');");
                    }
                    else
                    {
                        img[i].Attributes.Add("onclick", "javascript:openFiles('" + opt[i].ClientID + "','" + hdn[i].ClientID + "','" + txt[i].ClientID + "');");
                    }
                }
                img[i].Style.Add("cursor", "hand");
                img[i].Attributes.Add("onmouseover", "javascript:mouseoverIcon('" + opt[i].ClientID + "','" + img[i].ClientID + "');");
                //img[i].Attributes.Add("onmouseout", "javascript:mouseOutIcon(" + opt[i].ClientID + "','" + img[i].ClientID + "');");


                if (opt[i].SelectedValue == "Document")
                {
                    img[i].ImageUrl = "../Images/file_icon.jpg";
                    img[i].AlternateText = "Upload Document";
                    txt[i].ReadOnly = false;
                }
                else if (opt[i].SelectedValue == "Page")
                {
                    img[i].AlternateText = "Add Page Link";
                    img[i].ImageUrl = "../Images/icons/Data.gif";
                    txt[i].ReadOnly = false;
                }
                else if (opt[i].SelectedValue == "Rich Text")
                {
                    img[i].AlternateText = "Add Rich Text";
                    img[i].ImageUrl = "../Images/icons_modifycontent_nor.gif";
                    txt[i].ReadOnly = true;
                }
                else if (opt[i].SelectedValue == "Images")
                {
                    img[i].ImageUrl = "../Images/icons/ImageUploader.gif";
                    img[i].AlternateText = "Upload Image";
                    txt[i].ReadOnly = true;
                }
            }
            
            tab.Controls.Add(tbl);
        }

        btnSave.Attributes.Add("onclick", "javascript:return ValidateData('" + ColumnCount + "');");
    }
    public Table display_top10list()
    {


        DataTable list = new DataTable();
        list = lstObj.Top10List();

        Table dispTbl = new Table();
        dispTbl = getList(list);

        return dispTbl;

    }
    public Table getList(DataTable data)
    {
        LinkButton lbl;
        Table dispTbl = new Table();
        string range = UserTopics();

        rangeData = range.Split(',');
        if (!Session["UserType"].ToString().ToLower().Equals("admin"))
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {
                    for (int j = 0; j < rangeData.Length; j++)
                    {
                        if (rangeData[j].ToString().Equals(row["LBID"].ToString()) || row["createdby"].ToString().Equals(Session["UserId"].ToString()))
                        {
                            lbl = new LinkButton();
                            lbl.Text = row["listname"].ToString();
                            lbl.Font.Size = 8;
                            lbl.Font.Name = "Tahoma";
                            lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                            lbl.Style.Add("text-decoration", "none");
                            TableRow tr = new TableRow();
                            TableCell td = new TableCell();
                            td.Controls.Add(lbl);
                            tr.Cells.Add(td);
                            dispTbl.Rows.Add(tr);

                            lbl.CommandArgument = row["lbid"].ToString();
                            lbl.Click += new EventHandler(Select_Click);
                            lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                            lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");
                        }
                    }
                }
            }
        }
        else
        {
            if (data.Rows.Count > 0)
            {
                foreach (System.Data.DataRow row in data.Rows)
                {

                    lbl = new LinkButton();
                    lbl.Text = row["listname"].ToString();
                    lbl.Font.Size = 8;
                    lbl.Font.Name = "Tahoma";
                    lbl.ForeColor = System.Drawing.ColorTranslator.FromHtml("black");
                    lbl.Style.Add("text-decoration", "none");
                    TableRow tr = new TableRow();
                    TableCell td = new TableCell();
                    td.Controls.Add(lbl);
                    tr.Cells.Add(td);
                    dispTbl.Rows.Add(tr);

                    lbl.CommandArgument = row["lbid"].ToString();
                    lbl.Click += new EventHandler(Select_Click);
                    lbl.Attributes.Add("onmouseover", "this.style.color='#9f2409'; ");
                    lbl.Attributes.Add("onmouseout", "this.style.color='#000000';");

                }
            }
        }

        return dispTbl;
    }
    private void Select_Click(object sender, System.EventArgs e)
    {

        string lstid = (((LinkButton)(sender)).CommandArgument).ToString();

        Session["lstname"] = lstid;
        Response.Redirect("Listitem.aspx?LBID=" + lstid);
    }
    protected void lnkbtnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=" + txtSearch.Text);
    }
    protected void lnkbtnFullList_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainPage.aspx?SEARCH=");
    }
    public string data(string addr)
    {
        string data = "";
        
        {
            if (addr.StartsWith("<a href='"))
            {
                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                
                return data;
            }
            else if ((addr.StartsWith("<img")))
            {
                int k = 0;
                int i = addr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if(addr.StartsWith("<a target"))
            {

                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                
                return data;
            }
            else if (addr.StartsWith("~RTF~"))
            {
                return "Rich Text";
            }
            else
                return addr;
        }
       
    }
    public string hdnVal(string addr)
    {
        string data = "";
        
        {
            if (addr.StartsWith("<a href='.."))
            {
                string[] datas=addr.Split('>');
                data = datas[0] + ">";
                return data;
            }
            else if (addr.StartsWith("<a href='"))
            {
                int k = addr.Length - 2;
                int i = addr.IndexOf('>', 0, k);
                int j = addr.IndexOf('<', i);
                k = j - i - 1;
                data = addr.Substring(i + 1, k);

                return data;
            }
            else if ((addr.StartsWith("<img")))
            {
                int k = 0;
                int i = addr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if (addr.StartsWith("<a target"))
            {

                string tempaddr = addr.Substring(0, addr.Length - 4);
                int i = tempaddr.LastIndexOf("/");
                int j = addr.LastIndexOf("'");
                int k = j - i - 1;
                data = addr.Substring(i + 1, k);
                return data;
            }
            else if (addr.StartsWith("~RTF~"))
            {
                addr = addr.Remove(0, 5);
                return addr;
            }
            else
                return addr;
        }
       
        
    }
    public string option(string addr)
    {
        string option = "";
        //if (addr.Length > 10)
        {
            if(addr.StartsWith("<a href='.."))
            {
                return "Page";
            }
            else if (addr.StartsWith("<a href='"))
            {
                option = addr.Substring(9, 7);
                return option;
            }
            else if ((addr.StartsWith("<img")))
            {
                option = "Images";
                return option;
            }

            else if (addr.StartsWith("<a target"))
            {
                option = "Document";
                return option;
            }
            else if (addr.StartsWith("~RTF~"))
            {
                option = "Rich Text";
                return option;
            }
            else
                return "None";
        }
        
    }

    protected void btnCancel_ServerClick(object sender, EventArgs e)
    {
        Response.Redirect("listitem.aspx?MODE=SHOW&LBID=" + str1);
    }
    protected void btnSave_ServerClick(object sender, EventArgs e)
    {
        int i;

        Lists db1 = new Lists();
        Lists db2 = new Lists();
        Lists db3 = new Lists();
        string st = "select max(rowid) from listitems where listbuilderid='" + str1 + "'";


        name = new string[10];

        Lists itm = new Lists();



        str1 = Request.QueryString["LBID"];
        string j = db3.ExecuteScalar(st);
        if (j.Equals(""))
            j = "2";
        int k = int.Parse(j);




        for (i = 0; i < ColumnCount; i++)
        {
            if (ViewState["opt" + i.ToString()] == null)
                ViewState["opt" + i.ToString()] = opt[i].Items[opt[i].SelectedIndex].Text;
            else
                opt[i].SelectedValue = ViewState["opt" + i.ToString()].ToString();
        }
        for (i = 0; i < ColumnCount; i++)
        {
            string optval = ViewState["opt" + i.ToString()].ToString(); ;
            if (optval.Equals("http://"))
                name[i] = "<a href='http://" + txt[i].Text + "' target='_new'>" + txt[i].Text + "</a>";
            else if (optval.Equals("mailto:"))
                name[i] = "<a href='mailto:" + txt[i].Text + "'>" + txt[i].Text + "</a>";
            else if (optval.Equals("Document"))
            {
                name[i] = "<a target='_blank'  href='../Images/ListBuilder/Documents/" + hdn[i].Value + "' >" + txt[i].Text + "</a>";
            }
            else if (optval.Equals("Images") && !(txt[i].Text.Trim().Equals("")))
                name[i] = "<img src='../Images/ListBuilder/Images/" + hdn[i].Value + "'>";
            else if (optval.Equals("Rich Text"))
                name[i] = "~RTF~" + hdn[i].Value;
            else if (optval.Equals("Page") && !hdn[i].Value.Equals(""))
                name[i] = hdn[i].Value+txt[i].Text+"</a>";
            else
                name[i] = txt[i].Text;
        }


        itm.field1 = name[0];
        itm.field2 = name[1];
        itm.field3 = name[2];
        itm.field4 = name[3];
        itm.field5 = name[4];
        itm.field6 = name[5];
        itm.field7 = name[6];
        itm.field8 = name[7];
        itm.field9 = name[8];
        itm.field10 = name[9];

        
        itm.listbuilderid = str1;



        itm.createdby = int.Parse(Session["UserId"].ToString());
        itm.stat = "N";
        if (s.Equals("NEW"))
        {
            int datafl = 0,x;
            
            for (x = 0; x <= ColumnCount - 1; x++)
            {
                if (!name[x].Equals(""))
                {
                    datafl = 0;
                    break;
                }
                else
                    datafl = 1;
            }
            if (datafl != 1)
            {
                k = k + 1;
                itm.rowid = k.ToString();
                itm.inserttolistitems();
            }
            
        }
        else if (s.Equals("MOD"))
        {

            itm.rowid = Request.QueryString["ROW"].ToString();
            itm.modifytolistitems();

        }

        UpdateLinks();

        Response.Redirect("listitem.aspx?MODE=SHOW&LBID=" + str1);
    }

    private void UpdateLinks()
    {
        Lists itm = new Lists();
        string qry = "select ";
        for (int cnt = 1; cnt <= ColumnCount; cnt++)
        {
            qry += "field" + cnt;
            if (cnt != ColumnCount)
                qry += ",";
        }
        qry += " from listitems where listbuilderid='" + str1 + "' and rowid not in (1,2)";

        DataTable dtListItems = new DataTable();
        dtListItems = itm.ExecuteDTQuery(qry);

        string LinkedIds = "";
        if (dtListItems.Rows.Count > 0)
        {
            for (int rcnt = 0; rcnt < dtListItems.Rows.Count; rcnt++)
            {
                for (int ccnt = 0; ccnt < dtListItems.Columns.Count; ccnt++)
                {
                    if (dtListItems.Rows[rcnt][ccnt].ToString().StartsWith("<a href="))
                    {
                        if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("DA") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("DA"), 8) + ",";
                        }
                        else if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("CS") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("CS"), 8) + ",";
                        }
                        else if (dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("=LB") != -1)
                        {
                            LinkedIds += dtListItems.Rows[rcnt][ccnt].ToString().Substring(dtListItems.Rows[rcnt][ccnt].ToString().IndexOf("=LB")+1, 8) + ",";
                        }
                    }
                }
            }
        }

        string updateqry = "update Links set LinkTo='" + LinkedIds + "' where source='" + str1 + "'";
        itm.ExecuteNonQuery(updateqry);
    }

    //private string[] FindEachOccurrenceOf(string p, int p_2, string pattern)
    //{
    //      string[] occurrences;
    //    Reg
    //    Dim RE As Regex = New Regex(pattern, RegexOptions.Multiline)
    //    Dim theMatches As MatchCollection = RE.Matches(source)
    //    Dim index As Integer = (occurrence - 1)
    //    While index < theMatches.Count
    //        occurrences.Add(theMatches(index))
    //        index += occurrence
    //    End While
    //    Return (occurrences)

    //}

    public void ShowBanner(string value)
    {
        tblBanner.Style.Add("display", value);
    }

    public void ShowPanel(string value)
    {
        //trLeft1.Style.Add("display", value);
        //trLeft4.Style.Add("display", value);
        //tdLeft1.Style.Add("display", value);
        //tdLeft2.Style.Add("display", value);
        //tdLeft3.Style.Add("display", value);
        leftPanel.Style.Add("display", value);
    }

    protected string UserTopics() // Function to display user based topics...
    {
        //StringBuilder LBId = new StringBuilder();

        DataTable dtToolbar = new DataTable();
        SqlCommand cmdToolbar = new SqlCommand("sp_toolbar_rights");
        cmdToolbar.CommandType = CommandType.StoredProcedure;
        cmdToolbar.Parameters.AddWithValue("@UserID", Session["UserId"]);
        dtToolbar = lstObj.ExecuteDTQuery(cmdToolbar);
        DataTable dtLinks = new DataTable();
        SqlCommand cmdLinks = new SqlCommand("sp_user_ListbuilderRights");
        cmdLinks.CommandType = CommandType.StoredProcedure;
        LBIds = "";
        if (dtToolbar.Rows.Count > 0)
        {
            foreach (DataRow row in dtToolbar.Rows)
            {
                cmdLinks.Parameters.AddWithValue("@userId", Session["UserId"]);
                cmdLinks.Parameters.AddWithValue("@toolbarid", row["ButtonID"].ToString());
                dtLinks = lstObj.ExecuteDTQuery(cmdLinks);
                if (dtLinks.Rows.Count > 0)
                {
                    foreach (DataRow linkrow in dtLinks.Rows)
                    {
                        LBIds += linkrow["Link"].ToString() + ",";
                    }
                }
                cmdLinks.Parameters.Clear();
            }
        }

        if (LBIds.Length > 0) LBIds = LBIds.ToString().Remove(LBIds.Length - 1, 1);
        return LBIds;
    }


}
