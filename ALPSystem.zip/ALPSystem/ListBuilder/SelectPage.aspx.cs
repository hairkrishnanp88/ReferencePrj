using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using NGWS.CMPApplication;
public partial class ListBuilder_SelectPage : System.Web.UI.Page
{
    Toolbar objToolBar = new Toolbar();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            fillCombiset();
            fillPages();
            fillListBuilder();
        }
        if (drpList.SelectedValue == "Page")
        {
            lstPages.Style.Add("display", "inline");
            lstCombi.Style.Add("display", "none");
            lstLists.Style.Add("display", "none");
        }
        else if (drpList.SelectedValue == "Combiset")
        {
            lstPages.Style.Add("display", "none");
            lstCombi.Style.Add("display", "inline");
            lstLists.Style.Add("display", "none");
        }
        else
        {
            lstPages.Style.Add("display", "none");
            lstCombi.Style.Add("display", "none");
            lstLists.Style.Add("display", "inline");
        }
        drpList.Attributes.Add("onchange", "javascript:change();");
    }
    protected void fillCombiset()
    {
        DataTable combisetTable = objToolBar.getCombiSet();
        lstCombi.Items.Clear();
        foreach (DataRow row in combisetTable.Rows)
        {
            ListItem item = new ListItem(row["Combiname"].ToString(), row["CombiId"].ToString());
            lstCombi.Items.Add(item);
        }

    }

    protected void fillListBuilder()
    {
        DataTable listBuilderTable = objToolBar.getListBuilder();
        lstLists.Items.Clear();
        foreach (DataRow row in listBuilderTable.Rows)
        {
            ListItem item = new ListItem(row["List Name"].ToString(), row["List Builder ID"].ToString());
            lstLists.Items.Add(item);
        }
    }

    protected void fillPages()
    {
        DataTable contentBuilderTable = objToolBar.getContentBuilder();
        lstPages.Items.Clear();
        foreach (DataRow row in contentBuilderTable.Rows)
        {
            ListItem item = new ListItem(row["Name"].ToString(), row["DataID"].ToString());
            lstPages.Items.Add(item);
        }
    }




    protected void btnSelect_Click(object sender, EventArgs e)
    {
        string link = "";
        if (drpList.SelectedValue.Equals("Combiset"))
        {
           if(!lstCombi.SelectedValue.Equals(""))
            link = "<a href=\'../CombiSet/view.aspx?CId=" + lstCombi.SelectedValue + "&Mode=Preview&From=Index\'>";
        }
        else if (drpList.SelectedValue.Equals("Page"))
        {
            if (!lstPages.SelectedValue.Equals(""))
            link = "<a href=\'../ContentBuilder/DisplayPage.aspx?DataId=" + lstPages.SelectedValue + "\'>";
        }
        else
        {
            if (!lstLists.SelectedValue.Equals(""))
            link = "<a href=\'../ListBuilder/Listitem.aspx?LBID=" + lstLists.SelectedValue+"\'>";
        }
        string funct = "";
        if (link.Equals(""))
        {
            funct="<script language='javascript'>" +
                "alert('Please select the Link');"+
                "</script>";
        }
        else
        {
             funct= "<script language='javascript'>" +
                "window.opener.document.getElementById('" + Request.QueryString["Id"].ToString() + "').value='" + link.Replace("'", "\\'") + "';" +
                "window.close();" +
                "</script>";
        }
        Response.Write(funct);
    }
}
