﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilesInFolders
{
    public partial class FileExtractor : Form
    {
        public FileExtractor()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string path = string.Empty; string filter = string.Empty;
            string resultstring = string.Empty;
            if (txtsearchextension.Text != string.Empty && txtsearchextension.Text != null)
            {
                filter = "*." + txtsearchextension.Text;
            }
            else
            {
                filter = "*.*";
            }
            if (txtfolderpath.Text != string.Empty && txtfolderpath.Text != null)
            {
                path = txtfolderpath.Text;
                string[] files = Directory.GetFiles(path, filter);
                for (int i = 0; i < files.Length; i++)
                    //files[i] = Path.GetFileName(files[i]);
                    resultstring += Path.GetFileName(files[i]) + "\r\n";
            }
            txtresult.Text = resultstring;
        }
    }
}