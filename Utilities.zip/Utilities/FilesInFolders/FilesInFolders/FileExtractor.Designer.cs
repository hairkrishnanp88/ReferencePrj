﻿namespace FilesInFolders
{
    partial class FileExtractor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfolderpath = new System.Windows.Forms.TextBox();
            this.lblfolderpath = new System.Windows.Forms.Label();
            this.lblsrchexten = new System.Windows.Forms.Label();
            this.txtsearchextension = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtfolderpath
            // 
            this.txtfolderpath.Location = new System.Drawing.Point(13, 44);
            this.txtfolderpath.Name = "txtfolderpath";
            this.txtfolderpath.Size = new System.Drawing.Size(426, 20);
            this.txtfolderpath.TabIndex = 0;
            // 
            // lblfolderpath
            // 
            this.lblfolderpath.AutoSize = true;
            this.lblfolderpath.Location = new System.Drawing.Point(13, 13);
            this.lblfolderpath.Name = "lblfolderpath";
            this.lblfolderpath.Size = new System.Drawing.Size(89, 13);
            this.lblfolderpath.TabIndex = 1;
            this.lblfolderpath.Text = "Enter Folder Path";
            // 
            // lblsrchexten
            // 
            this.lblsrchexten.AutoSize = true;
            this.lblsrchexten.Location = new System.Drawing.Point(456, 9);
            this.lblsrchexten.Name = "lblsrchexten";
            this.lblsrchexten.Size = new System.Drawing.Size(102, 13);
            this.lblsrchexten.TabIndex = 3;
            this.lblsrchexten.Text = "Extension to Search";
            // 
            // txtsearchextension
            // 
            this.txtsearchextension.Location = new System.Drawing.Point(456, 43);
            this.txtsearchextension.Name = "txtsearchextension";
            this.txtsearchextension.Size = new System.Drawing.Size(115, 20);
            this.txtsearchextension.TabIndex = 2;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(605, 40);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 4;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(13, 96);
            this.txtresult.Multiline = true;
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(667, 406);
            this.txtresult.TabIndex = 5;
            // 
            // FileExtractor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 514);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.lblsrchexten);
            this.Controls.Add(this.txtsearchextension);
            this.Controls.Add(this.lblfolderpath);
            this.Controls.Add(this.txtfolderpath);
            this.Name = "FileExtractor";
            this.Text = "Files in Folders";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtfolderpath;
        private System.Windows.Forms.Label lblfolderpath;
        private System.Windows.Forms.Label lblsrchexten;
        private System.Windows.Forms.TextBox txtsearchextension;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.TextBox txtresult;
    }
}

