﻿namespace FilesInFolders
{
    partial class CBMS_TXT_File_Gen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcompletedfiles = new System.Windows.Forms.Label();
            this.lblcurrentfile = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtfilterextension = new System.Windows.Forms.TextBox();
            this.lstfilelist = new System.Windows.Forms.ListBox();
            this.btngenerate = new System.Windows.Forms.Button();
            this.btngo = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtoutputfilepath = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtU = new System.Windows.Forms.TextBox();
            this.txtS = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtO = new System.Windows.Forms.TextBox();
            this.txtinputfileslistpath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtI = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblcompletedfiles
            // 
            this.lblcompletedfiles.AutoSize = true;
            this.lblcompletedfiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcompletedfiles.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblcompletedfiles.Location = new System.Drawing.Point(16, 467);
            this.lblcompletedfiles.Name = "lblcompletedfiles";
            this.lblcompletedfiles.Size = new System.Drawing.Size(0, 13);
            this.lblcompletedfiles.TabIndex = 7;
            // 
            // lblcurrentfile
            // 
            this.lblcurrentfile.AutoSize = true;
            this.lblcurrentfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrentfile.ForeColor = System.Drawing.Color.Gold;
            this.lblcurrentfile.Location = new System.Drawing.Point(16, 368);
            this.lblcurrentfile.Name = "lblcurrentfile";
            this.lblcurrentfile.Size = new System.Drawing.Size(0, 17);
            this.lblcurrentfile.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(11, 66);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(2);
            this.label8.Size = new System.Drawing.Size(124, 21);
            this.label8.TabIndex = 17;
            this.label8.Text = "Filter Extension";
            // 
            // txtfilterextension
            // 
            this.txtfilterextension.Location = new System.Drawing.Point(194, 65);
            this.txtfilterextension.Multiline = true;
            this.txtfilterextension.Name = "txtfilterextension";
            this.txtfilterextension.Size = new System.Drawing.Size(302, 30);
            this.txtfilterextension.TabIndex = 16;
            // 
            // lstfilelist
            // 
            this.lstfilelist.FormattingEnabled = true;
            this.lstfilelist.Location = new System.Drawing.Point(572, 25);
            this.lstfilelist.Name = "lstfilelist";
            this.lstfilelist.ScrollAlwaysVisible = true;
            this.lstfilelist.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstfilelist.Size = new System.Drawing.Size(387, 459);
            this.lstfilelist.TabIndex = 5;
            // 
            // btngenerate
            // 
            this.btngenerate.Location = new System.Drawing.Point(468, 448);
            this.btngenerate.Name = "btngenerate";
            this.btngenerate.Size = new System.Drawing.Size(98, 36);
            this.btngenerate.TabIndex = 12;
            this.btngenerate.Text = "Generate";
            this.btngenerate.UseVisualStyleBackColor = true;
            this.btngenerate.Click += new System.EventHandler(this.btngenerate_Click);
            // 
            // btngo
            // 
            this.btngo.Location = new System.Drawing.Point(502, 66);
            this.btngo.Name = "btngo";
            this.btngo.Size = new System.Drawing.Size(52, 29);
            this.btngo.TabIndex = 15;
            this.btngo.Text = "GO";
            this.btngo.UseVisualStyleBackColor = true;
            this.btngo.Click += new System.EventHandler(this.btngo_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 113);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(2);
            this.label7.Size = new System.Drawing.Size(169, 21);
            this.label7.TabIndex = 14;
            this.label7.Text = "Output Files List Path";
            // 
            // txtoutputfilepath
            // 
            this.txtoutputfilepath.Location = new System.Drawing.Point(194, 103);
            this.txtoutputfilepath.Multiline = true;
            this.txtoutputfilepath.Name = "txtoutputfilepath";
            this.txtoutputfilepath.Size = new System.Drawing.Size(360, 30);
            this.txtoutputfilepath.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(154, 269);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(2);
            this.label2.Size = new System.Drawing.Size(27, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "-u";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(154, 143);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(2);
            this.label1.Size = new System.Drawing.Size(26, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "-s";
            // 
            // txtU
            // 
            this.txtU.Location = new System.Drawing.Point(194, 278);
            this.txtU.Multiline = true;
            this.txtU.Name = "txtU";
            this.txtU.Size = new System.Drawing.Size(360, 30);
            this.txtU.TabIndex = 2;
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(194, 143);
            this.txtS.Multiline = true;
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(360, 30);
            this.txtS.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 25);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(2);
            this.label6.Size = new System.Drawing.Size(156, 21);
            this.label6.TabIndex = 11;
            this.label6.Text = "Input Files List Path";
            // 
            // txtO
            // 
            this.txtO.Location = new System.Drawing.Point(194, 230);
            this.txtO.Multiline = true;
            this.txtO.Name = "txtO";
            this.txtO.Size = new System.Drawing.Size(360, 30);
            this.txtO.TabIndex = 6;
            // 
            // txtinputfileslistpath
            // 
            this.txtinputfileslistpath.Location = new System.Drawing.Point(194, 24);
            this.txtinputfileslistpath.Multiline = true;
            this.txtinputfileslistpath.Name = "txtinputfileslistpath";
            this.txtinputfileslistpath.Size = new System.Drawing.Size(360, 30);
            this.txtinputfileslistpath.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(154, 185);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(2);
            this.label3.Size = new System.Drawing.Size(22, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "-i";
            // 
            // txtI
            // 
            this.txtI.Location = new System.Drawing.Point(194, 185);
            this.txtI.Multiline = true;
            this.txtI.Name = "txtI";
            this.txtI.Size = new System.Drawing.Size(360, 30);
            this.txtI.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(154, 221);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(2);
            this.label4.Size = new System.Drawing.Size(27, 21);
            this.label4.TabIndex = 7;
            this.label4.Text = "-o";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblcompletedfiles);
            this.groupBox1.Controls.Add(this.lblcurrentfile);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtfilterextension);
            this.groupBox1.Controls.Add(this.lstfilelist);
            this.groupBox1.Controls.Add(this.btngenerate);
            this.groupBox1.Controls.Add(this.btngo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtoutputfilepath);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtU);
            this.groupBox1.Controls.Add(this.txtS);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtO);
            this.groupBox1.Controls.Add(this.txtinputfileslistpath);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtI);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(58, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(965, 498);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BAT File config";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(364, 444);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 36);
            this.button1.TabIndex = 18;
            this.button1.Text = "CCCIS Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnccccisgenerate_Click);
            // 
            // CBMS_TXT_File_Gen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 539);
            this.Controls.Add(this.groupBox1);
            this.Name = "CBMS_TXT_File_Gen";
            this.Text = "CBMS_TXT_File_Gen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblcompletedfiles;
        private System.Windows.Forms.Label lblcurrentfile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtfilterextension;
        private System.Windows.Forms.ListBox lstfilelist;
        private System.Windows.Forms.Button btngenerate;
        private System.Windows.Forms.Button btngo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtoutputfilepath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtU;
        private System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtO;
        private System.Windows.Forms.TextBox txtinputfileslistpath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
    }
}