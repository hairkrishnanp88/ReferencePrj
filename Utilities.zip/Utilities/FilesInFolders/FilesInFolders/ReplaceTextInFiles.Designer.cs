﻿namespace FilesInFolders
{
    partial class ReplaceTextInFiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.txtoutputfilepath = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtinputfileslistpath = new System.Windows.Forms.TextBox();
            this.lstfilelist = new System.Windows.Forms.ListBox();
            this.btncopyfiles = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnreplace = new System.Windows.Forms.Button();
            this.lblmessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(569, 12);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(2);
            this.label7.Size = new System.Drawing.Size(169, 21);
            this.label7.TabIndex = 21;
            this.label7.Text = "Output Files List Path";
            // 
            // txtoutputfilepath
            // 
            this.txtoutputfilepath.Location = new System.Drawing.Point(752, 12);
            this.txtoutputfilepath.Multiline = true;
            this.txtoutputfilepath.Name = "txtoutputfilepath";
            this.txtoutputfilepath.Size = new System.Drawing.Size(307, 30);
            this.txtoutputfilepath.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 9);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(2);
            this.label6.Size = new System.Drawing.Size(156, 21);
            this.label6.TabIndex = 19;
            this.label6.Text = "Input Files List Path";
            // 
            // txtinputfileslistpath
            // 
            this.txtinputfileslistpath.Location = new System.Drawing.Point(200, 8);
            this.txtinputfileslistpath.Multiline = true;
            this.txtinputfileslistpath.Name = "txtinputfileslistpath";
            this.txtinputfileslistpath.Size = new System.Drawing.Size(363, 30);
            this.txtinputfileslistpath.TabIndex = 18;
            // 
            // lstfilelist
            // 
            this.lstfilelist.FormattingEnabled = true;
            this.lstfilelist.Location = new System.Drawing.Point(12, 58);
            this.lstfilelist.Name = "lstfilelist";
            this.lstfilelist.ScrollAlwaysVisible = true;
            this.lstfilelist.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstfilelist.Size = new System.Drawing.Size(387, 420);
            this.lstfilelist.TabIndex = 25;
            // 
            // btncopyfiles
            // 
            this.btncopyfiles.Location = new System.Drawing.Point(405, 58);
            this.btncopyfiles.Name = "btncopyfiles";
            this.btncopyfiles.Size = new System.Drawing.Size(98, 36);
            this.btncopyfiles.TabIndex = 26;
            this.btncopyfiles.Text = "Copy Files";
            this.btncopyfiles.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(405, 177);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(2);
            this.label1.Size = new System.Drawing.Size(107, 21);
            this.label1.TabIndex = 28;
            this.label1.Text = "Replace Text";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(588, 177);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(307, 30);
            this.textBox1.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(405, 134);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(2);
            this.label2.Size = new System.Drawing.Size(79, 21);
            this.label2.TabIndex = 30;
            this.label2.Text = "Find Text";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(588, 134);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(307, 30);
            this.textBox2.TabIndex = 29;
            // 
            // btnreplace
            // 
            this.btnreplace.Location = new System.Drawing.Point(797, 245);
            this.btnreplace.Name = "btnreplace";
            this.btnreplace.Size = new System.Drawing.Size(98, 36);
            this.btnreplace.TabIndex = 31;
            this.btnreplace.Text = "Replace";
            this.btnreplace.UseVisualStyleBackColor = true;
            // 
            // lblmessage
            // 
            this.lblmessage.AutoSize = true;
            this.lblmessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmessage.ForeColor = System.Drawing.Color.Tomato;
            this.lblmessage.Location = new System.Drawing.Point(405, 431);
            this.lblmessage.Name = "lblmessage";
            this.lblmessage.Padding = new System.Windows.Forms.Padding(2);
            this.lblmessage.Size = new System.Drawing.Size(18, 21);
            this.lblmessage.TabIndex = 32;
            this.lblmessage.Text = "-";
            // 
            // ReplaceTextInFiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 495);
            this.Controls.Add(this.lblmessage);
            this.Controls.Add(this.btnreplace);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btncopyfiles);
            this.Controls.Add(this.lstfilelist);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtoutputfilepath);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtinputfileslistpath);
            this.Name = "ReplaceTextInFiles";
            this.Text = "ReplaceTextInFiles";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtoutputfilepath;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtinputfileslistpath;
        private System.Windows.Forms.ListBox lstfilelist;
        private System.Windows.Forms.Button btncopyfiles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnreplace;
        private System.Windows.Forms.Label lblmessage;
    }
}