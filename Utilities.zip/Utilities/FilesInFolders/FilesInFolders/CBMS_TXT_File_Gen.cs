﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilesInFolders
{
    public partial class CBMS_TXT_File_Gen : Form
    {
        public CBMS_TXT_File_Gen()
        {
            InitializeComponent();
        }

        private void btngo_Click(object sender, EventArgs e)
        {
            if (txtinputfileslistpath.Text != string.Empty && txtinputfileslistpath.Text != null)
            {
                string filter = string.Empty;
                string resultstring = string.Empty;
                if (txtfilterextension.Text != string.Empty && txtfilterextension.Text != null)
                {
                    filter = "*." + txtfilterextension.Text;
                }
                else
                {
                    filter = "*.*";
                }
                lstfilelist.Items.Clear();
                string[] files = Directory.GetFiles(txtinputfileslistpath.Text, "*.txt"); //filter);
                for (int i = 0; i < files.Length; i++)
                    lstfilelist.Items.Add(Path.GetFileName(files[i]));
            }
        }

        private void btngenerate_Click(object sender, EventArgs e)
        {
            string strcompletedfileslist = string.Empty;
            if (lstfilelist.SelectedItems.Count > 0)
            {
                var lst = lstfilelist.SelectedItems;
                foreach (var item in lst)
                {
                    string filename = item.ToString().Substring(0, item.ToString().LastIndexOf('.')).Trim();
                    //MessageBox.Show(item.ToString());// Or Row[1]...
                    string path = @"" + txtoutputfilepath.Text + filename + "_EDM" + ".txt";
                    if (!File.Exists(path))
                    {
                        // Create a file to write to.                   
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            sw.WriteLine("-s " + txtS.Text);
                            sw.WriteLine("-i " + txtI.Text + filename + ".dat.gz");
                            sw.WriteLine("-o " + txtO.Text + filename + ".dat.gz");
                            sw.WriteLine("-u " + txtU.Text);
                            lblcurrentfile.Text = "Progressing file..." + item.ToString().ToUpper();
                            strcompletedfileslist += item.ToString().ToUpper() + ",";
                        }
                    }
                }
                lblcompletedfiles.Text = strcompletedfileslist;
                strcompletedfileslist = string.Empty;
                lblcurrentfile.Text = string.Empty;
            }
        }

        private void btnccccisgenerate_Click(object sender, EventArgs e)
        {
            string strcompletedfileslist = string.Empty;
            if (lstfilelist.SelectedItems.Count > 0)
            {
                var lst = lstfilelist.SelectedItems;
                foreach (var item in lst)
                {
                    string filename = item.ToString().Substring(0, item.ToString().LastIndexOf('.')).Trim();
                    //MessageBox.Show(item.ToString());// Or Row[1]...
                    string path = @"" + txtoutputfilepath.Text + filename + ".txt";
                    if (!File.Exists(path))
                    {
                        // Create a file to write to.                   
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            sw.WriteLine("-s " + txtS.Text);
                            sw.WriteLine("-i " + txtI.Text + filename + ".dat.gz");
                            sw.WriteLine("-o " + txtO.Text + filename);
                            sw.WriteLine("-u " + txtU.Text);
                            lblcurrentfile.Text = "Progressing file..." + item.ToString().ToUpper();
                            strcompletedfileslist += item.ToString().ToUpper() + ",";
                        }
                    }
                }
                lblcompletedfiles.Text = strcompletedfileslist;
                strcompletedfileslist = string.Empty;
                lblcurrentfile.Text = string.Empty;
            }
        }
    }
}