﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class MaintainPackageProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProductGrid();
                BindPackageName();
            }
        }

        private void BindPackageName()
        {
            try
            {
                ddlpackagename.Items.Clear();
                ProductPackageService objpdtserv = new ProductPackageService();
                ddlpackagename.DataSource = objpdtserv.ListPackageDetails();
                ddlpackagename.DataTextField = "PackageName";
                ddlpackagename.DataValueField = "PackageID";
                ddlpackagename.DataBind();
                ddlpackagename.Items.Insert(0, new ListItem("-Select Package Name-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindProductGrid()
        {
            try
            {
                ProductPackageService objpdtserv = new ProductPackageService();
                PackageProducts objpackpdt = new PackageProducts();
                if (ddlpackagename.SelectedValue == string.Empty)
                    objpackpdt.PackageID = null;
                else
                    objpackpdt.PackageID = Guid.Parse(ddlpackagename.SelectedValue);
                GVproductList.DataSource = objpdtserv.ListAllPackageProducts(objpackpdt);
                GVproductList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                PackageProducts objpackagepdt = new PackageProducts();
                objpackagepdt.PackageID = Guid.Parse(ddlpackagename.SelectedValue);
                objpackagepdt.ProductIDs = HdnfldProductIds.Value;
                objpackagepdt.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                ProductPackageService objpdtpackserv = new ProductPackageService();
                objpdtpackserv.InsertPackageProducts(objpackagepdt);
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void ddlpackagename_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindProductGrid();
        }
    }
}