﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class EPinManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserTypeID"] != null)
                {
                    BindEPinGrid(ddlpinstatus.SelectedValue);
                    BindEPinSendTo();
                    BindEPinTransferTo();
                    if (Session["UserTypeID"].ToString() == "1" || Session["UserTypeID"].ToString() == "2")
                    {
                        pnl_epingenerator.Visible = true;
                    }
                }
            }
        }

        private void BindEPinGrid(string pinstatus)
        {
            try
            {
                if (Session["UserID"] != null && Session["UserTypeID"] != null)
                {
                    EPinSerivce objepinserv = new EPinSerivce();
                    List<EPIN> lstepinserv = objepinserv.ListAllEPINBySendTo(Guid.Parse(Session["UserID"].ToString()), int.Parse(Session["UserTypeID"].ToString()));
                    if (pinstatus !=string.Empty)
                        lstepinserv = lstepinserv.FindAll(t => t.PinStatus == bool.Parse(pinstatus));
                    GVEPinList.DataSource = lstepinserv;
                    GVEPinList.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindEPinSendTo()
        {
            try
            {
                ddlsendto.Items.Clear();
                UserDetailService objusrdetserv = new UserDetailService();
                ddlsendto.DataSource = objusrdetserv.ListAllUserDetailsByOrganizationID(Guid.Parse(System.Configuration.ConfigurationManager.AppSettings["organizationid"]));
                ddlsendto.DataTextField = "NamewithPin";
                ddlsendto.DataValueField = "UserID";
                ddlsendto.DataBind();
                ddlsendto.Items.Insert(0, new ListItem("-Select Referal-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindEPinTransferTo()
        {
            try
            {
                ddltransferto.Items.Clear();
                UserDetailService objusrdetserv = new UserDetailService();
                ddltransferto.DataSource = objusrdetserv.ListAllUserDetailsByOrganizationID(Guid.Parse(System.Configuration.ConfigurationManager.AppSettings["organizationid"]));
                ddltransferto.DataTextField = "NamewithPin";
                ddltransferto.DataValueField = "UserID";
                ddltransferto.DataBind();
                ddltransferto.Items.Insert(0, new ListItem("-Select Referal-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserTypeID"] != null)
                {
                    if (Session["UserTypeID"].ToString() == "1" || Session["UserTypeID"].ToString() == "2")
                    {
                        EPIN objepin = new EPIN();
                        objepin.EPinStartingLetter = txtepinstartingletter.Text.Trim().ToUpper();
                        objepin.PinCount = int.Parse(txtnoofpins.Text);
                        objepin.GeneratedBy = Guid.Parse(Session["UserID"].ToString());
                        objepin.SendTo = Guid.Parse(ddlsendto.SelectedValue);
                        objepin.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                        EPinSerivce objepinserv = new EPinSerivce();
                        objepinserv.InsertEPIN(objepin);
                        BindEPinGrid(ddlpinstatus.SelectedValue);
                    }
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btntransferpin_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserTypeID"] != null && Session["UserID"] != null)
                {
                    EPIN objepin = new EPIN();
                    string strEpinIds = string.Empty;
                    int iTransCount = 0;
                    foreach (GridViewRow row in GVEPinList.Rows)
                    {
                        if (row.RowType == DataControlRowType.DataRow)
                        {
                            CheckBox chkRow = (row.FindControl("CheckBox1") as CheckBox);
                            Label lblepinid = (row.FindControl("lblepinid") as Label);
                            if (chkRow.Checked)
                            {
                                strEpinIds += lblepinid.Text + ";";
                                iTransCount++;
                            }
                        }
                    }
                    objepin.EPINIDs = strEpinIds;
                    objepin.SendTo = Guid.Parse(ddltransferto.SelectedValue);
                    objepin.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                    EPinSerivce objepinserv = new EPinSerivce();
                    objepinserv.TransferEPin(objepin, iTransCount);
                    BindEPinGrid(ddlpinstatus.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btndeletesubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (HdnfldEPinID.Value != string.Empty)
                {
                    EPIN objepin = new EPIN();
                    objepin.EPINID = Guid.Parse(HdnfldEPinID.Value);
                    objepin.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                    EPinSerivce objepinserv = new EPinSerivce();
                    objepinserv.DeleteEPIN(objepin);
                    BindEPinGrid(ddlpinstatus.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void RowDataBound(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            BindEPinGrid(ddlpinstatus.SelectedValue);
            GVEPinList.PageIndex = e.NewPageIndex;
            GVEPinList.DataBind();
        }

        protected void ddlpinstatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindEPinGrid(ddlpinstatus.SelectedValue);
        }
    }
}