﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class MaintainPackageDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindPackageGrid();
                HdnfldPackageAction.Value = "1";
            }
        }

        private void BindPackageGrid()
        {
            try
            {
                ProductPackageService objpackagdetserv = new ProductPackageService();
                GVPackageList.DataSource = objpackagdetserv.ListPackageDetails();
                GVPackageList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblerrormessage.Text = string.Empty;
                PackageDetails objpackagedet = new PackageDetails();
                ProductPackageService objpackagedetservice = new ProductPackageService();
                objpackagedet.PackageDescription = txtpackagedescription.Text.Trim();
                objpackagedet.PackageName = txtpackagename.Text.Trim();
                if (HdnfldPackageAction.Value != string.Empty)
                    switch (int.Parse(HdnfldPackageAction.Value))
                    {
                        case 1:
                            objpackagedet.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                            objpackagedet.PackageID = System.Guid.NewGuid();
                            objpackagedetservice.InsertPackageDetails(objpackagedet);
                            break;
                        case 2:
                            objpackagedet.PackageID = Guid.Parse(HdnfldPackageID.Value);
                            objpackagedet.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                            objpackagedetservice.UpdatePackageDetails(objpackagedet);
                            break;
                    }
                ProductPackageService.RefreshPackageDetails();
                BindPackageGrid();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnhidensubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblerrormessage.Text = string.Empty;
                PackageDetails objpackagedet = new PackageDetails();
                ProductPackageService objpackagedetservice = new ProductPackageService();
                if (HdnfldPackageID.Value != string.Empty)
                {
                    objpackagedet.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                    objpackagedet.PackageID = Guid.Parse(HdnfldPackageID.Value);
                    objpackagedetservice.DeletePackageDetails(objpackagedet);
                }
                ProductPackageService.RefreshPackageDetails();
                BindPackageGrid();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}