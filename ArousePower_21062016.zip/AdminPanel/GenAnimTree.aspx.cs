﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.Core.BLL;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class GenAnimTree : System.Web.UI.Page
    {
        private static string strResult = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = string.Empty;
            DocumentService objdocserv = new DocumentService();
            MLMTreeViewService._JQORGlstMLMTreeUser = null;
            //Literal1.Text = objdocserv.PopulateTreeViewUsers(Guid.Parse("E97C97A0-D438-4D45-B15A-8A14A4502DEF"));
            BindTree(TreeView1);
        }

        private void BindTree(TreeView treeview)
        {
            string strltree = string.Empty;
            MLMTreeViewService ListAllUserserv = new MLMTreeViewService();

            List<MLMUsers> FolderDocuments = MLMTreeViewService.ListAllMLMTreeUserBy().FindAll(t => t.MLMUserID == Guid.Parse("93723047-1BB3-4020-A6FE-4454D98FAF0E"));
            List<MLMUsers> FolderDocuments1 = MLMTreeViewService.ListAllMLMTreeUserBy();
            TreeNode RootNodeDefault = new TreeNode();
            //RootNodeDefault.Value = "0";
            // RootNodeDefault.ImageUrl = HttpContext.Current.Server.MapPath("~\\Images\\global.png");

            treeview.Nodes.Add(RootNodeDefault);
            List<MLMUsers> ChildDocumnts = FolderDocuments.FindAll(t => t.ParentID == Guid.Empty).OrderBy(t => t.UserID).ToList();
            //strResult += "<ul  id='org' style='display: none'> <li> " + ChildDocumnts.FirstOrDefault().Name;
            char strquot = '"';
            foreach (MLMUsers dc in ChildDocumnts)
            {
                strResult += "id: " + strquot + dc.ParentID + strquot + ", name: " + strquot + dc.FullName + strquot + ", data: {}, ";
                TreeNode RootNode = new TreeNode();
                RootNode.Text = dc.FullName;

                //strResult += "<li>" + dc.Name + "</li>";
                RootNode.Value = "";
                PopulateTreeView(treeview, RootNode, FolderDocuments1, dc.UserID);
                treeview.Nodes.Add(RootNode);

                treeview.CollapseAll();
                strResult += "}]";
                // treeview.Nodes[0].Expand();
            }
            Label1.Text = strResult;
        }

        private static void PopulateTreeView(TreeView treeview, TreeNode treeviewnode, List<MLMUsers> ListAllUser, Guid MLMUsersID)
        {
            List<MLMUsers> ChildDocumnts = ListAllUser.FindAll(t => t.ParentID == MLMUsersID).OrderBy(t => t.UserID).ToList();
            char strquot = '"';
            strResult += "children: [{";
            foreach (MLMUsers dc in ChildDocumnts)
            {

                TreeNode childNode = new TreeNode();
                childNode.Text = dc.FullName;

                childNode.Value = dc.UserID.ToString();
                childNode.ImageUrl = "~/Images/Folder.PNG";
                treeviewnode.ChildNodes.Add(childNode);
                strResult += "id: " + strquot + dc.UserID + strquot + ", name: " + strquot + dc.FullName + strquot + ", data: {}, children: [{ ";
                PopulateTreeView(treeview, childNode, ListAllUser, dc.UserID);
                //strResult += "}]";
            }
            strResult += " }]},";
        }
    }
}