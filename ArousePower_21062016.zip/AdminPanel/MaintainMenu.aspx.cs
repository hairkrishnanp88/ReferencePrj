﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class MaintainMenu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindMenuGrid();
                BindMenuDDL();
                HdnfldMenuAction.Value = "1";
            }
        }

        private void BindMenuDDL()
        {
            try
            {
                ddlmenuname.Items.Clear();
                MenuService objmenuserv = new MenuService();
                ddlmenuname.DataSource = objmenuserv.ListAllDDLMenus();
                ddlmenuname.DataValueField = "MenuID";
                ddlmenuname.DataTextField = "MenuName";
                ddlmenuname.DataBind();
                ddlmenuname.Items.Insert(0, new ListItem("-Select Parent Menu-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindMenuGrid()
        {
            try
            {
                MenuService objmenuserv = new MenuService();
                GVMenuList.DataSource = objmenuserv.ListAllMenus();
                GVMenuList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void GVMenuList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVMenuList.PageIndex = e.NewPageIndex;
            BindMenuGrid();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (HdnfldMenuAction.Value != string.Empty)
                {
                    Menus objMenus = new Menus();
                    objMenus.MenuName = txtMenuname.Text.Trim();
                    objMenus.PageName = txtpagename.Text.Trim();
                    objMenus.PageNameWithExtn = txtpagenamewithextension.Text.Trim();
                    if (ddlmenuname.SelectedValue != string.Empty)
                        objMenus.ParentID = Guid.Parse(ddlmenuname.SelectedValue);
                    else
                        objMenus.ParentID = null;
                    MenuService objmenuserv = new MenuService();
                    switch (int.Parse(HdnfldMenuAction.Value))
                    {
                        case 1:
                            objMenus.MenuID = System.Guid.NewGuid();
                            objMenus.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                            objmenuserv.InsertMenus(objMenus);
                            break;
                        case 2:
                            objMenus.MenuID = HdnfldMenuID.Value != string.Empty ? Guid.Parse(HdnfldMenuID.Value) : Guid.Empty;
                            objMenus.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                            objmenuserv.UpdateMenus(objMenus);
                            break;
                    }
                }
                BindMenuGrid();
                BindMenuDDL();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }

        }

        protected void btnhidensubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Menus objMenus = new Menus();
                MenuService objmenuserv = new MenuService();
                objMenus.MenuID = HdnfldMenuID.Value != string.Empty ? Guid.Parse(HdnfldMenuID.Value) : Guid.Empty;
                objMenus.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                objmenuserv.DeleteMenus(objMenus);
                BindMenuGrid();
                BindMenuDDL();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }

        }
    }
}