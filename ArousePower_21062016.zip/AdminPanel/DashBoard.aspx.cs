﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;
using System.Data;

namespace AdminPanel
{
    public partial class DashBoard : System.Web.UI.Page
    {
        private DataSet dsDashBoardContent;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDashBoardTopContent();
                BindLeftPairs();
                BindRightPairs();
                BindBinaryIncome();
                BindSponserIncome();
                BindAccountTransaction();
            }
        }

        private void BindLeftPairs()
        {
            try
            {
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[1];
                GVLeftMembers.DataSource = dtdashbrd;
                GVLeftMembers.DataBind();
            }
            catch (Exception ex)
            { }
        }

        private void BindRightPairs()
        {
            try
            {
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[2];
                GVRightMembers.DataSource = dtdashbrd;
                GVRightMembers.DataBind();
            }
            catch (Exception ex)
            { }
        }

        private void BindBinaryIncome()
        {
            try
            {
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[4];
                GVBinaryIncome.DataSource = dtdashbrd;
                GVBinaryIncome.DataBind();
            }
            catch (Exception ex)
            { }
        }

        private void BindSponserIncome()
        {
            try
            {
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[3];
                GVSponserIncome.DataSource = dtdashbrd;
                GVSponserIncome.DataBind();
            }
            catch (Exception ex)
            { }
        }

        private void BindAccountTransaction()
        {
            try
            {
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[5];
                GVAccountTrans.DataSource = dtdashbrd;
                GVAccountTrans.DataBind();
            }
            catch (Exception ex)
            { }
        }

        private void BindDashBoardTopContent()
        {
            try
            {
                dsDashBoardContent = DashBoardService.ListAllDashBoardContent(Guid.Parse(Session["UserID"].ToString()));
                DataTable dtdashbrd = new DataTable();
                dtdashbrd = dsDashBoardContent.Tables[6];
                lbltotwallet.Text = dtdashbrd.Rows[0][0].ToString();
                lbltotsponserincome.Text = dtdashbrd.Rows[0][1].ToString();
                lbltotbinaryincome.Text = dtdashbrd.Rows[0][2].ToString();
                lbltotgenincome.Text = dtdashbrd.Rows[0][3].ToString();
                lbltotalmemberdownline.Text = (int.Parse(dtdashbrd.Rows[0][4].ToString()) + int.Parse(dtdashbrd.Rows[0][5].ToString())).ToString();
                lbltotleftmembers.Text = dtdashbrd.Rows[0][4].ToString();
                lbltotrightmembers.Text = dtdashbrd.Rows[0][5].ToString();
                lblnewmemcurrentdate.Text = dtdashbrd.Rows[0][6].ToString();
                lblfreshleft.Text = dtdashbrd.Rows[0][7].ToString();
                lblfreshright.Text = dtdashbrd.Rows[0][8].ToString();
            }
            catch (Exception ex)
            { }
        }
    }
}