﻿using CommonBL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminPanel
{
    public partial class LRPairMembers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindLRMembers();
                if (Request.QueryString["LRPair"] != null)
                {
                    switch (Request.QueryString["LRPair"])
                    {
                        case "0":
                            lbllrpair.Text = "Left Pari Members";
                            break;
                        case "1":
                            lbllrpair.Text = "Right Pari Members";
                            break;
                    }
                }
            }
        }

        private void BindLRMembers()
        {
            try
            {
                if (Session["UserID"] != null && Request.QueryString["LRPair"] != null)
                {
                    PayoutTransactionService objpaytranserv = new PayoutTransactionService();
                    GVLRMembers.DataSource = objpaytranserv.ListAllLRMembers(Guid.Parse(Session["UserID"].ToString()), Request.QueryString["LRPair"] == "0" ? false : true);
                    GVLRMembers.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}