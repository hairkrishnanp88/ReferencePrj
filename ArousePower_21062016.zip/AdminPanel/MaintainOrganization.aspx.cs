﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.Common;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class MaintainOrganization : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCountry();
                BindState(0);
                BindDistrict(0);
                BindOrganizationCss();
                BindOrganizationGrid();
            }
        }

        private void BindCountry()
        {
            try
            {
                ddlorgcountry.DataSource = CountryService.ListAllCountry();
                ddlorgcountry.DataTextField = "CountryName";
                ddlorgcountry.DataValueField = "CountryID";
                ddlorgcountry.DataBind();
                ddlorgcountry.Items.Insert(0, new ListItem("-Select Country-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindState(int pCountryID)
        {
            try
            {
                List<State> lststate = StateService.ListAllState();
                ddlorgstate.Items.Clear();
                if (pCountryID != 0)
                {
                    ddlorgstate.DataSource = lststate.FindAll(t => t.CountryID == pCountryID);
                    ddlorgstate.DataTextField = "StateName";
                    ddlorgstate.DataValueField = "StateID";
                    ddlorgstate.DataBind();
                }
                ddlorgstate.Items.Insert(0, new ListItem("-Select State-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindDistrict(int pStateID)
        {
            try
            {
                List<District> lstsdistrict = DistrictService.ListAllDistrict();
                ddlorgcity.Items.Clear();
                if (pStateID != 0)
                {
                    ddlorgcity.DataSource = lstsdistrict.FindAll(t => t.StateID == pStateID);
                    ddlorgcity.DataTextField = "DistrictName";
                    ddlorgcity.DataValueField = "DistrictID";
                    ddlorgcity.DataBind();
                }
                ddlorgcity.Items.Insert(0, new ListItem("-Select City-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void ddlorgcountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindState(int.Parse(ddlorgcountry.SelectedValue));
        }

        protected void ddlorgstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDistrict(int.Parse(ddlorgstate.SelectedValue));
        }

        private void BindOrganizationCss()
        {
            try
            {
                ddlorgcss.Items.Clear();
                ddlorgcss.DataSource = CSSService.ListAllCSS();
                ddlorgcss.DataTextField = "CSSName";
                ddlorgcss.DataValueField = "CSSID";
                ddlorgcss.DataBind();
                ddlorgcss.Items.Insert(0, new ListItem("-Select CSS-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindOrganizationGrid()
        {
            try
            {
                OrganizationService objorganizationserv = new OrganizationService();
                GVOrganizationList.DataSource = objorganizationserv.ListAllOrganization();
                GVOrganizationList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Organization objOrganization = new Organization();
                objOrganization.OrganizationName = txtorganization.Text.Trim();
                objOrganization.Org_Address1 = txtorgaddress1.Text.Trim();
                objOrganization.Org_Address2 = txtorgaddress2.Text.Trim();
                objOrganization.Org_City = int.Parse(ddlorgcity.SelectedValue);
                objOrganization.Org_State = int.Parse(ddlorgstate.SelectedValue);
                objOrganization.Org_Country = int.Parse(ddlorgcountry.SelectedValue);
                objOrganization.Org_ZipCode = txtorgzipcode.Text.Trim();
                objOrganization.Org_PhoneNumber = txtorgphoneno.Text.Trim();
                objOrganization.Org_MobileNo = txtorgmobileno.Text.Trim();
                objOrganization.Org_Website = txtorgwebsite.Text.Trim();
                objOrganization.Org_Logo = HdnfldOrganizationLogoName.Value == string.Empty ? txtorganization.Text.Trim() + "_" + fuporglogo.FileName : HdnfldOrganizationLogoName.Value;
                objOrganization.Org_ServerName = txtorgserveraddress.Text.Trim();
                objOrganization.Org_DataBaseName = txtorgdbname.Text.Trim();
                objOrganization.Org_DataBaseUserName = txtorgDBUsername.Text.Trim();
                objOrganization.Org_DataBasePassword = txtorgDBPassword.Text.Trim();
                objOrganization.Org_CssID = int.Parse(ddlorgcss.SelectedValue);
                objOrganization.Org_MaxLevels = txtorgmaxlevels.Text.Trim() != string.Empty ? int.Parse(txtorgmaxlevels.Text.Trim()) : 0;
                objOrganization.Org_MaxStages = txtorgmaxstages.Text.Trim() != string.Empty ? int.Parse(txtorgmaxstages.Text.Trim()) : 0;
                OrganizationService objorganizationserv = new OrganizationService();
                switch (int.Parse(HdnfldOrganizationAction.Value))
                {
                    case 1:
                        Guid gOrganizationID = System.Guid.NewGuid();
                        objOrganization.OrganizationID = gOrganizationID;
                        objOrganization.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                        objorganizationserv.InsertOrganization(objOrganization);
                        break;
                    case 2:
                        if (HdnfldOrganizationID.Value != string.Empty)
                        {
                            objOrganization.OrganizationID = Guid.Parse(HdnfldOrganizationID.Value);
                            objOrganization.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                            objorganizationserv.UpdateOrganization(objOrganization);
                        }
                        break;
                    case 3:
                        if (HdnfldOrganizationID.Value != string.Empty)
                        {
                            objOrganization.OrganizationID = Guid.Parse(HdnfldOrganizationID.Value);
                            objOrganization.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                            objorganizationserv.DeleteOrganization(objOrganization);
                        }
                        break;
                }
                objOrganization = null;
                BindOrganizationGrid();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void lnkbtnhidebinddropdown_Click(object sender, EventArgs e)
        {
            BindState(int.Parse(ddlorgcountry.SelectedValue));
            BindDistrict(int.Parse(ddlorgstate.SelectedValue));
        }

    }
}