﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminPanel
{
    public partial class IncomeGen : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsponserincome_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("EXEC USP_SponserIncomeGenerator");
            cmd.ExecuteScalar();
            con.Close();
        }

        protected void btnbinaryincome_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("EXEC USP_BinaryIncomeGenerator '" + txtdate.Text.Trim() + "'");
            cmd.ExecuteScalar();
            con.Close();

        }
    }
}