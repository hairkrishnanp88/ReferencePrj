﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.Core.Common;
using CommonBL.BLL;
using CommonBL.Core.BLL;

namespace AdminPanel
{
    public partial class JQTreeSep : System.Web.UI.Page
    {
        protected string strCss;
        private static string strResult = string.Empty;


        protected void Page_Load(object sender, EventArgs e)
        {
            SiteAdminValidation.ValidateAdminUserSession();
            if (!IsPostBack)
            {
                if (Session["Org_Css"] != null)
                {
                    strCss = Session["Org_Css"].ToString();
                    masterbody.Attributes.Add("class", "sidebar-mini " + strCss + "");
                }
                if (Session["UserID"] != null && Session["UserID"].ToString() != string.Empty)
                {
                    lbluserfullname.Text = Session["UserFullName"].ToString();
                    img_userimage.ImageUrl = Session["UserImage"] != null ? "userimages/" + Session["UserImage"].ToString() : "../images/avatar.png";
                    imguserimageicon.ImageUrl = Session["UserImage"] != null ? "userimages/" + Session["UserImage"].ToString() : "../images/avatar.png";
                }

                DocumentService objdocserv = new DocumentService();
                MLMTreeViewService._JQORGlstMLMTreeUser = null;
                ltrltree.Text = string.Empty;
                //Literal1.Text = objdocserv.PopulateTreeViewUsers(Guid.Parse("E97C97A0-D438-4D45-B15A-8A14A4502DEF"));
                BindTree(TreeView1);

            }
        }



        private void BindTree(TreeView treeview)
        {
            MLMTreeViewService ListAllUserserv = new MLMTreeViewService();

            List<MLMUsers> FolderDocuments = MLMTreeViewService.ListAllMLMTreeUserBy().FindAll(t => t.MLMUserID == Guid.Parse("8A949B08-9D2E-4712-B1AC-FCA2B5E299EF"));
            List<MLMUsers> FolderDocuments1 = MLMTreeViewService.ListAllMLMTreeUserBy();
            TreeNode RootNodeDefault = new TreeNode();
            //RootNodeDefault.Value = "0";
            // RootNodeDefault.ImageUrl = HttpContext.Current.Server.MapPath("~\\Images\\global.png");

            treeview.Nodes.Add(RootNodeDefault);
            List<MLMUsers> ChildDocumnts = FolderDocuments.FindAll(t => t.ParentID == Guid.Empty).OrderBy(t => t.UserID).ToList();
            //strResult += "<ul  id='org' style='display: none'> <li> " + ChildDocumnts.FirstOrDefault().Name;
            foreach (MLMUsers dc in ChildDocumnts)
            {
                strResult += "<li> " + dc.FullName;
                TreeNode RootNode = new TreeNode();
                RootNode.Text = dc.FullName;

                //strResult += "<li>" + dc.Name + "</li>";
                RootNode.Value = "";
                PopulateTreeView(treeview, RootNode, FolderDocuments1, dc.UserID);
                treeview.Nodes.Add(RootNode);

                treeview.CollapseAll();
                strResult += "</li>";
                // treeview.Nodes[0].Expand();
            }
            ltrltree.Text = strResult;
        }

        private static void PopulateTreeView(TreeView treeview, TreeNode treeviewnode, List<MLMUsers> ListAllUser, Guid MLMUsersID)
        {
            List<MLMUsers> ChildDocumnts = ListAllUser.FindAll(t => t.ParentID == MLMUsersID).OrderBy(t => t.UserID).ToList();
            strResult += "<ul>";
            foreach (MLMUsers dc in ChildDocumnts)
            {

                TreeNode childNode = new TreeNode();
                childNode.Text = dc.FullName;

                childNode.Value = dc.UserID.ToString();
                childNode.ImageUrl = "~/Images/Folder.PNG";
                treeviewnode.ChildNodes.Add(childNode);
                strResult += "<li>" + dc.FullName;
                PopulateTreeView(treeview, childNode, ListAllUser, dc.UserID);
                strResult += "</li>";
            }
            strResult += "</ul>";
        }

        protected void btnsigout_Click(object sender, EventArgs e)
        {
            SessionHandeler.LogOut();
            Response.Redirect("Login.aspx");
        }
    }
}