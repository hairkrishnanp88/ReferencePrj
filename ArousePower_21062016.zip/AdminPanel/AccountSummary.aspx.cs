﻿using CommonBL.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminPanel
{
    public partial class AccountSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAccountTransaction();
                if (Request.QueryString["IncType"] != null)
                {
                    switch (Request.QueryString["IncType"])
                    {
                        case "A":
                            lblpageheader.Text = lblpagebreadcrumbs.Text = lblgridheader.Text = "Account Transaction";
                            break;
                        case "B":
                            lblpageheader.Text = lblpagebreadcrumbs.Text = lblgridheader.Text = "Binary Income";
                            break;
                        case "S":
                            lblpageheader.Text = lblpagebreadcrumbs.Text = lblgridheader.Text = "Sponser Income";
                            break;
                    }
                }
            }
        }

        private void BindAccountTransaction()
        {
            try
            {
                if (Session["UserID"] != null && Request.QueryString["IncType"] != null)
                {
                    PayoutTransactionService objpaytranserv = new PayoutTransactionService();
                    GVAccountTrans.DataSource = objpaytranserv.ListAllAccountTransaction(Guid.Parse(Session["UserID"].ToString()), Request.QueryString["IncType"]);
                    GVAccountTrans.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}