﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.Core.BLL;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class ManageProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCategoryTree();
                BindProductGrid();
                HdnfldproductAction.Value = "1";
            }
        }

        private void BindCategoryTree()
        {
            try
            {
                DocumentService objdocserv = new DocumentService();
                ltrlcategorytree.Text = objdocserv.PopulateTreeViewCategory();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindProductGrid()
        {
            try
            {
                ProductService objpdtserv = new ProductService();
                GVproductList.DataSource = objpdtserv.ListAllProducts();
                GVproductList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Products objproducts = new Products();
                ProductService objpdtserv = new ProductService();
                objproducts.ProductName = txtproductname.Text.Trim();
                objproducts.ProductCode = txtproductcode.Text.Trim();
                objproducts.ProductDescription = txtproductdesc.Text.Trim();
                objproducts.CategoryID = Guid.Parse(HdnfldCategoryID.Value);
                if (HdnfldSubCategoryID.Value != string.Empty || HdnfldSubCategoryID.Value != Guid.Empty.ToString() || HdnfldSubCategoryID.Value != null)
                    objproducts.SubCategoryID = Guid.Parse(HdnfldSubCategoryID.Value);
                else
                    objproducts.SubCategoryID = null;
                objproducts.ProductUnitPrice = txtunitprice.Text != string.Empty ? decimal.Parse(txtunitprice.Text.Trim()) : 0;
                objproducts.ProductSellingPrice = txtsellingprice.Text != string.Empty ? decimal.Parse(txtsellingprice.Text.Trim()) : 0;
                objproducts.ProductQuantity = txtproductquantity.Text.Trim() != string.Empty ? Int32.Parse(txtproductquantity.Text.Trim()) : 0;
                objproducts.ProductMainImage = HdnfldProductImageName.Value;
                if (HdnfldproductAction.Value != string.Empty)
                    switch (int.Parse(HdnfldproductAction.Value))
                    {
                        case 1:
                            objproducts.ProductID = System.Guid.NewGuid();
                            objproducts.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                            objpdtserv.InsertProducts(objproducts);
                            break;
                        case 2:
                            objproducts.ProductID = Guid.Parse(HdnfldproductID.Value);
                            objproducts.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                            objpdtserv.UpdateProducts(objproducts);
                            break;
                    }
                btnSubmit.Text = "Submit";
                BindProductGrid();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btndeleteproducts_Click(object sender, EventArgs e)
        {
            try
            {
                Products objproducts = new Products();
                objproducts.ProductID = Guid.Parse(HdnfldproductID.Value);
                objproducts.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                ProductService objpdtserv = new ProductService();
                objpdtserv.DeleteProducts(objproducts);
                BindProductGrid();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}