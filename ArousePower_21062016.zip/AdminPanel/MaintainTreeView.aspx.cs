﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using CommonBL.BLL;
using CommonBL.Core.Common;
using CommonBL.Common;

namespace AdminPanel
{
    public partial class MaintainTreeView : System.Web.UI.Page
    {
        private static Guid gUserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CountryService._ListAllCountry = null;
                StateService._ListAllState = null;
                DistrictService._ListAllDistrict = null;
                BindCountry();
                BindState(1);
                BindDistrict(0);
                BindOrganizationCss();
                BindPackageName();
                BindUpLevel();
                if (Session["UserID"] != null && Session["UserID"].ToString() != string.Empty)
                    gUserID = Guid.Parse(Session["UserID"].ToString());
            }
        }

        [WebMethod]
        public static List<object> GetChartData()
        {
            List<object> chartData = new List<object>();
            if (gUserID != null && gUserID.ToString() != string.Empty)
            {
                try
                {
                    MLMTreeViewService objmlmtreeuserserv = new MLMTreeViewService();
                    chartData = objmlmtreeuserserv.ListAllMLMTreeUser(gUserID);
                }
                catch (Exception ex)
                {
                }
            }
            return chartData;
        }

        //[WebMethod]
        //public static List<object> GetChartData()
        //{
        //    string query = ";WITH ret AS(SELECT * FROM TBL_MLMUsers WHERE ParentID IS NULL    UNION ALL      SELECT t.*      FROM TBL_MLMUsers t  INNER JOIN        ret r ON t.ParentID = r.UserID)  SELECT T1.UserID AS MemberId , T1.ParentID , T2.FirstName AS Name,T2.UserImage FROM    ret  T1 INNER JOIN TBL_UserDetails T2 ON T1.UserID = T2.UserID";
        //    //query += " FROM FamilyHierarchy";
        //    string constr = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        //    using (SqlConnection con = new SqlConnection(constr))
        //    {
        //        using (SqlCommand cmd = new SqlCommand(query))
        //        {
        //            List<object> chartData = new List<object>();
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Connection = con;
        //            con.Open();
        //            using (SqlDataReader sdr = cmd.ExecuteReader())
        //            {
        //                while (sdr.Read())
        //                {
        //                    chartData.Add(new object[]
        //                {
        //                    sdr["MemberId"], sdr["Name"], sdr["ParentId"],sdr["UserImage"]
        //                });
        //                }
        //            }
        //            con.Close();
        //            return chartData;
        //        }
        //    }
        //}




        private void BindUpLevel()
        {
            try
            {
                ddlrefereal.Items.Clear();
                UserDetailService objusrdetserv = new UserDetailService();
                ddlrefereal.DataSource = objusrdetserv.ListAllUserDetailsByOrganizationID(Guid.Parse(System.Configuration.ConfigurationManager.AppSettings["organizationid"]));
                ddlrefereal.DataTextField = "NamewithPin";
                ddlrefereal.DataValueField = "UserID";
                ddlrefereal.DataBind();
                ddlrefereal.Items.Insert(0, new ListItem("-Select Referal-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindPackageName()
        {
            try
            {
                ddljoingpackages.Items.Clear();
                ProductPackageService objpdtserv = new ProductPackageService();
                ddljoingpackages.DataSource = objpdtserv.ListPackageDetails();
                ddljoingpackages.DataTextField = "PackageName";
                ddljoingpackages.DataValueField = "PackageID";
                ddljoingpackages.DataBind();
                ddljoingpackages.Items.Insert(0, new ListItem("-Select Package Name-", ""));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }


        private void BindOrganizationCss()
        {
            try
            {
                ddlorgcss.Items.Clear();
                ddlorgcss.DataSource = CSSService.ListAllCSS();
                ddlorgcss.DataTextField = "CSSName";
                ddlorgcss.DataValueField = "CSSID";
                ddlorgcss.DataBind();
                ddlorgcss.Items.Insert(0, new ListItem("-Select CSS-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }


        private void BindCountry()
        {
            try
            {
                ddlcountry.DataSource = CountryService.ListAllCountry();
                ddlcountry.DataTextField = "CountryName";
                ddlcountry.DataValueField = "CountryID";
                ddlcountry.DataBind();
                //ddlcountry.Items.Insert(0, new ListItem("-Select Country-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindState(int pCountryID)
        {
            try
            {
                List<State> lststate = StateService.ListAllState();
                ddlstate.Items.Clear();
                if (pCountryID != 0)
                {
                    ddlstate.DataSource = lststate.FindAll(t => t.CountryID == pCountryID);
                    ddlstate.DataTextField = "StateName";
                    ddlstate.DataValueField = "StateID";
                    ddlstate.DataBind();
                }
                ddlstate.Items.Insert(0, new ListItem("-Select State-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindDistrict(int pStateID)
        {
            try
            {
                List<District> lstsdistrict = DistrictService.ListAllDistrict();
                ddlcity.Items.Clear();
                if (pStateID != 0)
                {
                    ddlcity.DataSource = lstsdistrict.FindAll(t => t.StateID == pStateID);
                    ddlcity.DataTextField = "DistrictName";
                    ddlcity.DataValueField = "DistrictID";
                    ddlcity.DataBind();
                }
                ddlcity.Items.Insert(0, new ListItem("-Select City-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void ddlcountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindState(int.Parse(ddlcountry.SelectedValue));
        }

        protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDistrict(int.Parse(ddlstate.SelectedValue));
        }

        protected void lnkbtnsetepindynamically_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserID"] != null && Session["UserID"].ToString() != string.Empty)
                {
                    EPinSerivce objepinserv = new EPinSerivce();
                    string strgetsetepin = objepinserv.GetEPinNoByUserID(Guid.Parse(Session["UserID"].ToString()));
                    if (strgetsetepin != string.Empty && strgetsetepin != null)
                        txtreferencepin.Text = strgetsetepin;
                    else
                        lblerrormessage.Text = "You dont have Epin.Please contact adminstrator";
                }
            }
            catch (SqlException ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblerrormessage.Text = string.Empty;
                UserDetails objUserDetails = new UserDetails();
                ManageEncryption objmgenrypt = new ManageEncryption();
                bool IsValidEpin = EPinSerivce.GetEPINByNumber(txtreferencepin.Text.Trim());
                if (IsValidEpin)
                {
                    objUserDetails.UserID = System.Guid.NewGuid();
                    objUserDetails.UserTypeID = 3;
                    objUserDetails.UserName = txtusername.Text.Trim();
                    objUserDetails.Password = objmgenrypt.GetEncryptedString(txtpassword.Text.Trim());
                    objUserDetails.EmailID = txtemailid.Text.Trim();
                    objUserDetails.MobileNo = txtmobileno.Text.Trim();
                    objUserDetails.FirstName = txtfirstname.Text.Trim();
                    objUserDetails.LastName = txtlastname.Text.Trim();
                    if (HdnfldJoinUnderID.Value == null || HdnfldJoinUnderID.Value == string.Empty)
                        return;
                    else
                        objUserDetails.JoinUnder = Guid.Parse(HdnfldJoinUnderID.Value);
                    if (ddlrefereal.SelectedValue != string.Empty)
                        objUserDetails.ReferralID = Guid.Parse(ddlrefereal.SelectedValue);
                    else
                        objUserDetails.ReferralID = null;
                    objUserDetails.ReferencePin = txtreferencepin.Text.Trim();
                    objUserDetails.IsEmailVerified = false;
                    objUserDetails.IsMobileVerified = false;
                    objUserDetails.Address1 = txtaddress1.Text.Trim();
                    objUserDetails.Address2 = txtaddress2.Text.Trim();
                    objUserDetails.CityID = int.Parse(ddlcity.SelectedValue);
                    objUserDetails.StateID = int.Parse(ddlstate.SelectedValue);
                    objUserDetails.CountryID = int.Parse(ddlcountry.SelectedValue);
                    objUserDetails.ZipCode = txtzipcode.Text.Trim();
                    objUserDetails.OrganizationID = Guid.Parse(System.Configuration.ConfigurationManager.AppSettings["organizationid"]);
                    objUserDetails.CSSID = int.Parse(ddlorgcss.SelectedValue);
                    objUserDetails.Bnk_AccountHolderName = txtaccountholdername.Text.Trim();
                    objUserDetails.Bnk_AccountNumber = txtaccountnumber.Text.Trim();
                    objUserDetails.Bnk_Name = txtbankname.Text.Trim();
                    objUserDetails.Bnk_IFSCCode = txtifsccode.Text.Trim();
                    objUserDetails.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                    objUserDetails.PacakageType = ddljoingpackages.SelectedValue != string.Empty ? Guid.Parse(ddljoingpackages.SelectedValue) : Guid.Empty;
                    if (HdnfldLRPair.Value == null || HdnfldLRPair.Value == string.Empty)
                        return;
                    else
                        objUserDetails.LRPair = bool.Parse(HdnfldLRPair.Value);
                    UserDetailService objusrdetserv = new UserDetailService();
                    objusrdetserv.InsertUserDetails(objUserDetails);
                    Response.Redirect("MaintainTreeView.aspx");
                    BindUpLevel();
                }
            }
            catch (SqlException ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}