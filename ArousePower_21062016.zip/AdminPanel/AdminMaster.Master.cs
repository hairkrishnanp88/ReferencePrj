﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.Core.Common;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        protected string strCss;

        protected void Page_Load(object sender, EventArgs e)
        {
            SiteAdminValidation.ValidateAdminUserSession();
            if (!IsPostBack)
            {
                if (Session["Org_Css"] != null)
                {
                    strCss = Session["Org_Css"].ToString();
                    masterbody.Attributes.Add("class", "sidebar-mini " + strCss + "");
                }
                if (Session["UserID"] != null && Session["UserID"].ToString() != string.Empty)
                {
                    lbluserfullname.Text = Session["UserFullName"].ToString();
                    lbluserfirstname.Text = Session["UserFullName"].ToString();
                    img_userimage.ImageUrl = Session["UserImage"] != null ? "userimages/" + Session["UserImage"].ToString() : "../images/avatar.png";
                    imguserimageicon.ImageUrl = Session["UserImage"] != null ? "userimages/" + Session["UserImage"].ToString() : "../images/avatar.png";
                }
            }
        }

        protected void btnsigout_Click(object sender, EventArgs e)
        {
            SessionHandeler.LogOut();
            Response.Redirect("Login.aspx");
        }
    }
}