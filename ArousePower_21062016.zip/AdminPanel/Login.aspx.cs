﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using CommonBL.Core.Common;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string strOrganizationid = ConfigurationManager.AppSettings["organizationid"];
                if (strOrganizationid != string.Empty)
                {
                    CreateOrganizationSessions(strOrganizationid);
                }
            }
        }

        private void CreateOrganizationSessions(string strOrgID)
        {
            OrganizationService orgserv = new OrganizationService();
            Organization objorg = orgserv.GetOrganizationByOrganizationID(Guid.Parse(strOrgID));
            Session["Org_Name"] = objorg.OrganizationName;
            Session["Org_ID"] = objorg.OrganizationID;
            Session["Org_Logo"] = objorg.Org_Logo;
            Session["Org_Css"] = objorg.Org_Cssname;
            imgorganizationlogo.ImageUrl = "img/" + objorg.Org_Logo;
            //lblorganizationlogo.Text = objorg.OrganizationName;
        }

        protected void btnsigin_Click(object sender, EventArgs e)
        {
            try
            {
                if (SessionHandeler.IsValidUser(txtusername.Text.Trim(), txtpassword.Text.Trim()))
                {
                    Response.Redirect("DashBoard.aspx", false);
                }
                else
                {
                    lblerrormessage.Text = "Please provide valid username and password";
                    return;
                }
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }
    }
}