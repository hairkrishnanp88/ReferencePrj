﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class MaintainUserType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUserTypeGrid();
                HdnfldUserTypeAction.Value = "1";
            }
        }

        private void BindUserTypeGrid()
        {
            try
            {
                UserTypeService objUserTypeService = new UserTypeService();
                GVUserTypeList.DataSource = objUserTypeService.ListAllUserType();
                GVUserTypeList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblerrormessage.Text = string.Empty;
                UserType objusertype = new UserType();
                objusertype.UserTypeName = txtusertypename.Text.Trim();
                UserTypeService objusertypeservice = new UserTypeService();
                if (HdnfldUserTypeAction.Value != string.Empty)
                    switch (int.Parse(HdnfldUserTypeAction.Value))
                    {
                        case 1:
                            objusertype.CreatedBy = Guid.Parse(Session["UserID"].ToString());
                            objusertypeservice.InsertUserType(objusertype);
                            break;
                        case 2:
                            objusertype.UserTypeID = int.Parse(HdnfldUserTypeID.Value);
                            objusertype.ModifiedBy = Guid.Parse(Session["UserID"].ToString());
                            objusertypeservice.UpdateUserType(objusertype);
                            break;
                        case 3:
                            objusertype.UserTypeID = int.Parse(HdnfldUserTypeID.Value);
                            objusertype.DeletedBy = Guid.Parse(Session["UserID"].ToString());
                            objusertypeservice.DeleteUserType(objusertype);
                            break;
                    }
                ClearControl();
                BindUserTypeGrid();

            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void ClearControl()
        {
            txtusertypename.Text = string.Empty;
            lblerrormessage.Text = string.Empty;            
        }
    }
}