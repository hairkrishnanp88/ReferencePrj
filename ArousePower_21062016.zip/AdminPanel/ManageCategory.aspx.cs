﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;
using CommonBL.Core.BLL;

namespace AdminPanel
{
    public partial class ManageCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //BindCategoryTree();
                BindCategoryGrid();
                BindCategoryType();
            }
        }


        private void BindCategoryType()
        {
            try
            {
                ddlCatType.DataSource = CategoryTypeService.ListAllStaticCategoryType();
                ddlCatType.DataTextField = "TypeName";
                ddlCatType.DataValueField = "CategoryTypeID";
                ddlCatType.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindCategoryGrid()
        {
            try
            {
                DocumentService objdocserv = new DocumentService();
                gvCategory.DataSource = objdocserv.ParentTreeView();
                gvCategory.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindCategoryTree()
        {
            try
            {
                DocumentService objdocserv = new DocumentService();
                //tvCategory.DataSource = objdocserv.PopulateTreeViewCategory();
                //tvCategory.DataBind();
                HdnfldCatStatusType.Value = "0";
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                try
                {
                    DocumentService objdocserv = new DocumentService();
                    string customerId = gvCategory.DataKeys[e.Row.RowIndex].Value.ToString();
                    GridView gvOrders = e.Row.FindControl("gvSubCategory") as GridView;
                    gvOrders.DataSource = objdocserv.ChildTreeView(Guid.Parse(customerId));
                    gvOrders.DataBind();
                }
                catch (Exception ex)
                {
                    lblerrormessage.Text = ex.Message.ToString();
                }
            }
        }

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            try
            {
                CategoryService objcatserv = new CategoryService();
                Category objcat = new Category();
                string strcaticon = string.Empty; string strcatimage = string.Empty;
                objcat.CatName = txtCatName.Text;
                objcat.CatShortName = txtCatShortName.Text;
                objcat.CatDescription = txtCatDescription.Text;
                objcat.CatTypeID = 1;
                if (fupcaticon.HasFile)
                    strcaticon = fupcaticon.PostedFile.FileName;
                if (fupcatimage.HasFile)
                    strcatimage = fupcatimage.PostedFile.FileName;
                objcat.CatIcon = strcaticon;
                objcat.CatImage = strcatimage;
                if (HdnfldCatStatusType.Value != string.Empty)
                {
                    switch (int.Parse(HdnfldCatStatusType.Value))
                    {
                        case 0:
                            objcat.CategoryID = System.Guid.NewGuid();
                            objcat.SubCategoryID = null;
                            objcatserv.InsertCategory(objcat);
                            break;
                        case 1:
                            objcat.CategoryID = Guid.Parse(HdnfldCategoryID.Value);
                            objcat.SubCategoryID = null;
                            objcatserv.UpdateCategory(objcat);
                            break;
                        case 2:
                            objcat.CategoryID = System.Guid.NewGuid();
                            objcat.SubCategoryID = Guid.Parse(HdnfldCategoryID.Value);
                            objcatserv.InsertCategory(objcat);
                            break;
                        case 3:
                            objcat.CategoryID = Guid.Parse(HdnfldCategoryID.Value);
                            objcat.SubCategoryID = Guid.Parse(HdnfldSubCategoryID.Value);
                            objcatserv.UpdateCategory(objcat);
                            break;
                    }
                    CategoryService.RefreshCategory();
                    BindCategoryGrid();
                    BindCategoryTree();
                }
            }
            catch (Exception ex)
            {               
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btndeletecategory_Click(object sender, EventArgs e)
        {
            try
            {
                CategoryService objcatserv = new CategoryService();
                Category objcat = new Category();
                objcat.CategoryID = Guid.Parse(HdnfldCategoryID.Value);
                objcat.SubCategoryID = Guid.Parse(HdnfldSubCategoryID.Value);
                objcatserv.DeleteCategory(objcat);
                CategoryService.RefreshCategory();
                BindCategoryGrid();
                BindCategoryTree();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }


        protected void gvCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCategory.PageIndex = e.NewPageIndex;
            BindCategoryGrid();
        }
    }
}