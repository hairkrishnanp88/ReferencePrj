﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonBL.BLL;

namespace AdminPanel
{
    public partial class ManageMenuRights : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUserTypeDDL(0);
                BindMenuRightsGrid();
            }
        }

        private void BindMenuRightsGrid()
        {
            try
            {                
                UserTypeService objusrtypserv = new UserTypeService();
                ddlusertypename.DataSource = objusrtypserv.ListAllUserType();
                ddlusertypename.DataTextField = "UserTypeName";
                ddlusertypename.DataValueField = "UserTypeID";
                ddlusertypename.DataBind();
                ddlusertypename.Items.Insert(0, new ListItem("-Select User Type Name-", "0"));
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        private void BindUserTypeDDL(int pUserTypeid)
        {
            try
            {
                MenuService objusrtypserv = new MenuService();
                GVMenuRightsList.DataSource = objusrtypserv.ListAllMenusWithRights(pUserTypeid);
                GVMenuRightsList.DataBind();
            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                lblerrormessage.Text = ex.Message.ToString();
            }
        }

        protected void ddlusertypename_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}